package com.itachi1706.opengl;

/**
 * Created by Kenneth on 27/10/2014, 8:17 PM
 * for OpenGL in package com.itachi1706.opengl
 */
public class Util {
    public static final boolean DEBUG = true;
    public static final String LOG_TAG = "gles20tut";
}
