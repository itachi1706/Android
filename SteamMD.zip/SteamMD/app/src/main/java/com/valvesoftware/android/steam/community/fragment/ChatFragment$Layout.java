// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.fragment;


// Referenced classes of package com.valvesoftware.android.steam.community.fragment:
//            ChatFragment

public static final class  extends Enum
{

    private static final .VALUES $VALUES[];
    public static final .VALUES Bubbles;
    public static final .VALUES BubblesLeft;
    public static final .VALUES TextOnly;

    public static  valueOf(String s)
    {
        return ()Enum.valueOf(com/valvesoftware/android/steam/community/fragment/ChatFragment$Layout, s);
    }

    public static [] values()
    {
        return ([])$VALUES.clone();
    }

    static 
    {
        Bubbles = new <init>("Bubbles", 0);
        BubblesLeft = new <init>("BubblesLeft", 1);
        TextOnly = new <init>("TextOnly", 2);
        t_3B_.clone aclone[] = new <init>[3];
        aclone[0] = Bubbles;
        aclone[1] = BubblesLeft;
        aclone[2] = TextOnly;
        $VALUES = aclone;
    }

    private (String s, int i)
    {
        super(s, i);
    }
}
