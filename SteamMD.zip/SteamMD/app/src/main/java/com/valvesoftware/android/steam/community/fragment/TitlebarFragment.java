// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.TextView;
import com.valvesoftware.android.steam.community.AndroidUtils;
import com.valvesoftware.android.steam.community.activity.ActivityHelper;

// Referenced classes of package com.valvesoftware.android.steam.community.fragment:
//            NavigationFragment

public class TitlebarFragment extends Fragment
{
    public static interface TitlebarButtonHander
    {

        public abstract void onTitlebarButtonClicked(int i);
    }


    private boolean m_bRefreshEnabled;
    private boolean m_bRefreshingNow;
    private TitlebarButtonHander m_searchHandler;

    public TitlebarFragment()
    {
        m_bRefreshingNow = false;
        m_bRefreshEnabled = true;
        m_searchHandler = null;
    }

    private void attachButtonHandler(final int btnid, int i, final TitlebarButtonHander hdlr)
    {
        int j;
        View view;
label0:
        {
            j = 0x7f060010;
            view = getActivity().findViewById(btnid);
            if (view != null)
            {
                view.setOnClickListener(new android.view.View.OnClickListener() {

                    final TitlebarFragment this$0;
                    final int val$btnid;
                    final TitlebarButtonHander val$hdlr;

                    public void onClick(View view2)
                    {
                        while (btnid == 0x7f090038 && m_bRefreshingNow || hdlr == null) 
                        {
                            return;
                        }
                        hdlr.onTitlebarButtonClicked(btnid);
                    }

            
            {
                this$0 = TitlebarFragment.this;
                btnid = i;
                hdlr = titlebarbuttonhander;
                super();
            }
                });
                if (btnid != 0x7f090038)
                {
                    break label0;
                }
                View view1;
                if (m_bRefreshEnabled)
                {
                    if (m_bRefreshingNow)
                    {
                        i = 0x7f02000b;
                    }
                } else
                {
                    i = j;
                }
                view.setBackgroundResource(i);
                view1 = getActivity().findViewById(0x7f090039);
                if (view1 != null && m_bRefreshingNow)
                {
                    int k;
                    if (m_bRefreshEnabled)
                    {
                        k = 0;
                    } else
                    {
                        k = 8;
                    }
                    view1.setVisibility(k);
                    if (m_bRefreshEnabled)
                    {
                        j = 0x7f02000e;
                    }
                    view1.setBackgroundResource(j);
                }
            }
            return;
        }
        if (hdlr == null)
        {
            i = j;
        }
        view.setBackgroundResource(i);
    }

    public void onActivityCreated(Bundle bundle)
    {
        super.onActivityCreated(bundle);
        View view = getActivity().findViewById(0x7f090035);
        if (view != null)
        {
            view.setOnClickListener(new android.view.View.OnClickListener() {

                final TitlebarFragment this$0;

                public void onClick(View view1)
                {
                    NavigationFragment navigationfragment = ActivityHelper.GetNavigationFragmentForActivity(getActivity());
                    if (navigationfragment != null)
                    {
                        navigationfragment.onNavActivationButtonClicked();
                    }
                }

            
            {
                this$0 = TitlebarFragment.this;
                super();
            }
            });
        }
        int i = getActivity().getIntent().getIntExtra("title_resid", 0);
        if (i != 0)
        {
            setTitleLabel(i);
        }
    }

    public View onCreateView(LayoutInflater layoutinflater, ViewGroup viewgroup, Bundle bundle)
    {
        return layoutinflater.inflate(0x7f030016, viewgroup, false);
    }

    public void onResume()
    {
        super.onResume();
    }

    public boolean overrideActivityOnSearchPressed()
    {
        if (m_searchHandler != null)
        {
            m_searchHandler.onTitlebarButtonClicked(0x7f090037);
            return true;
        } else
        {
            return false;
        }
    }

    public void setRefreshHandler(TitlebarButtonHander titlebarbuttonhander)
    {
        boolean flag;
        if (titlebarbuttonhander != null)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        m_bRefreshEnabled = flag;
        attachButtonHandler(0x7f090038, 0x7f02000f, titlebarbuttonhander);
    }

    public void setRefreshInProgress(boolean flag)
    {
        int i = 0x7f060010;
        if (flag != m_bRefreshingNow)
        {
            m_bRefreshingNow = flag;
            View view = getActivity().findViewById(0x7f090038);
            View view1 = getActivity().findViewById(0x7f090039);
            if (view1 != null && view != null)
            {
                if (m_bRefreshingNow)
                {
                    int k;
                    int l;
                    if (m_bRefreshEnabled)
                    {
                        k = 0x7f02000b;
                    } else
                    {
                        k = i;
                    }
                    view.setBackgroundResource(k);
                    if (m_bRefreshEnabled)
                    {
                        l = 0;
                    } else
                    {
                        l = 8;
                    }
                    view1.setVisibility(l);
                    if (m_bRefreshEnabled)
                    {
                        i = 0x7f02000e;
                    }
                    view1.setBackgroundResource(i);
                    view1.startAnimation(AnimationUtils.loadAnimation(getActivity(), 0x7f040004));
                    return;
                }
                int j;
                if (m_bRefreshEnabled)
                {
                    j = 0x7f02000f;
                } else
                {
                    j = i;
                }
                view.setBackgroundResource(j);
                view1.setVisibility(8);
                view1.setBackgroundResource(i);
                view1.clearAnimation();
                return;
            }
        }
    }

    public void setSearchHandler(TitlebarButtonHander titlebarbuttonhander)
    {
        setSearchHandler(titlebarbuttonhander, 0x7f020010);
    }

    public void setSearchHandler(TitlebarButtonHander titlebarbuttonhander, int i)
    {
        m_searchHandler = titlebarbuttonhander;
        attachButtonHandler(0x7f090037, i, titlebarbuttonhander);
    }

    public void setTitleLabel(int i)
    {
        TextView textview = (TextView)getActivity().findViewById(0x7f090036);
        if (textview != null)
        {
            textview.setText(i);
        }
    }

    public void setTitleLabel(String s)
    {
        TextView textview = (TextView)getActivity().findViewById(0x7f090036);
        if (textview != null)
        {
            AndroidUtils.setTextViewText(textview, s);
        }
    }

}
