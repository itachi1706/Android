// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;

import android.app.Notification;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import java.util.ArrayList;

// Referenced classes of package com.valvesoftware.android.steam.community:
//            Config, SteamCommunityApplication, SettingInfo, C2DMessaging, 
//            SteamWebApi

public class SettingInfoDB extends BroadcastReceiver
{

    public static final String KEY_CHATS_LAYOUT = "chats_layout";
    public static final String KEY_CHATS_LINKS_NONSTEAM = "chats_links_nonsteam";
    public static final String KEY_CHATS_RECENT_SECONDS = "chats_recent_seconds";
    public static final String KEY_CHATS_TIMESTAMP_SECONDS = "chats_timestamp_seconds";
    public static final String KEY_HW_ACCELERATION = "hw_acceleration";
    public static final String KEY_NOTIFICATIONS_IM = "notifications_im2";
    public static final String KEY_NOTIFICATIONS_ONGOING = "notifications_ongoing";
    public static final String KEY_NOTIFICATIONS_RINGTONE = "notifications_ringtone";
    public static final String KEY_NOTIFICATIONS_SOUND = "notifications_sound";
    public static final String KEY_NOTIFICATIONS_VIBRATE = "notifications_vibrate";
    public static final String KEY_PERSONAL_DOB = "personal_dob";
    public static final String KEY_SSL_UNTRUSTED_PROMPT = "ssl_untrusted_prompt";
    public static final int SETTING_NOTIFY_ALL = -1;
    public static final int SETTING_NOTIFY_FIRST = 0;
    public static final int SETTING_NOTIFY_NEVER = 1;
    public static final String URL_SETTINGS_ONLINE;
    private final String m_className = getClass().getName();
    public SettingInfo m_settingChatsAlertLinks;
    public SettingInfo m_settingChatsLayout;
    public SettingInfo m_settingChatsMarkRead;
    public SettingInfo m_settingChatsRecent;
    public SettingInfo m_settingChatsTimestamp;
    public SettingInfo m_settingDOB;
    public SettingInfo m_settingForegroundService;
    public SettingInfo m_settingHardwareAcceleration;
    public SettingInfo m_settingNotificationsIMs2;
    private SettingInfo m_settingRing;
    private SettingInfo m_settingSound;
    public SettingInfo m_settingSslUntrustedPrompt;
    private SettingInfo m_settingVibrate;
    private ArrayList m_settingsList;

    SettingInfoDB()
    {
        m_settingsList = new ArrayList();
        SteamCommunityApplication.GetInstance().registerReceiver(this, new IntentFilter(m_className));
        SettingInfo settinginfo = new SettingInfo();
        settinginfo.m_resid = 0x7f070089;
        settinginfo.m_resid_detailed = 0x7f07008a;
        settinginfo.m_defaultValue = SteamCommunityApplication.GetInstance().getString(settinginfo.m_resid_detailed);
        settinginfo.m_type = SettingInfo.SettingType.UNREADMSG;
        settinginfo.m_access = SettingInfo.AccessRight.VALID_ACCOUNT;
        m_settingChatsMarkRead = settinginfo;
        m_settingsList.add(settinginfo);
        SettingInfo settinginfo1 = new SettingInfo();
        settinginfo1.m_resid = 0x7f07008d;
        SettingInfo.RadioSelectorItem aradioselectoritem[] = new SettingInfo.RadioSelectorItem[5];
        aradioselectoritem[0] = new SettingInfo.RadioSelectorItem();
        aradioselectoritem[0].value = 0x93a80;
        aradioselectoritem[0].resid_text = 0x7f07008e;
        aradioselectoritem[1] = new SettingInfo.RadioSelectorItem();
        aradioselectoritem[1].value = 0x2a300;
        aradioselectoritem[1].resid_text = 0x7f07008f;
        aradioselectoritem[2] = new SettingInfo.RadioSelectorItem();
        aradioselectoritem[2].value = 0x15180;
        aradioselectoritem[2].resid_text = 0x7f070090;
        aradioselectoritem[3] = new SettingInfo.RadioSelectorItem();
        aradioselectoritem[3].value = 3600;
        aradioselectoritem[3].resid_text = 0x7f070091;
        aradioselectoritem[4] = new SettingInfo.RadioSelectorItem();
        aradioselectoritem[4].value = 0;
        aradioselectoritem[4].resid_text = 0x7f070092;
        settinginfo1.m_extraData = aradioselectoritem;
        settinginfo1.m_key = "chats_recent_seconds";
        settinginfo1.m_defaultValue = String.valueOf(0x2a300);
        settinginfo1.m_type = SettingInfo.SettingType.RADIOSELECTOR;
        settinginfo1.m_access = SettingInfo.AccessRight.VALID_ACCOUNT;
        m_settingChatsRecent = settinginfo1;
        m_settingsList.add(settinginfo1);
        SettingInfo settinginfo2 = new SettingInfo();
        settinginfo2.m_resid = 0x7f070093;
        SettingInfo.RadioSelectorItem aradioselectoritem1[] = new SettingInfo.RadioSelectorItem[3];
        aradioselectoritem1[0] = new SettingInfo.RadioSelectorItem();
        aradioselectoritem1[0].value = com.valvesoftware.android.steam.community.fragment.ChatFragment.Layout.Bubbles.ordinal();
        aradioselectoritem1[0].resid_text = 0x7f070094;
        aradioselectoritem1[1] = new SettingInfo.RadioSelectorItem();
        aradioselectoritem1[1].value = com.valvesoftware.android.steam.community.fragment.ChatFragment.Layout.BubblesLeft.ordinal();
        aradioselectoritem1[1].resid_text = 0x7f070095;
        aradioselectoritem1[2] = new SettingInfo.RadioSelectorItem();
        aradioselectoritem1[2].value = com.valvesoftware.android.steam.community.fragment.ChatFragment.Layout.TextOnly.ordinal();
        aradioselectoritem1[2].resid_text = 0x7f070096;
        settinginfo2.m_extraData = aradioselectoritem1;
        settinginfo2.m_key = "chats_layout";
        settinginfo2.m_defaultValue = String.valueOf(com.valvesoftware.android.steam.community.fragment.ChatFragment.Layout.Bubbles.ordinal());
        settinginfo2.m_type = SettingInfo.SettingType.RADIOSELECTOR;
        settinginfo2.m_access = SettingInfo.AccessRight.VALID_ACCOUNT;
        m_settingChatsLayout = settinginfo2;
        m_settingsList.add(settinginfo2);
        SettingInfo settinginfo3 = new SettingInfo();
        settinginfo3.m_resid = 0x7f070097;
        SettingInfo.RadioSelectorItem aradioselectoritem2[] = new SettingInfo.RadioSelectorItem[5];
        aradioselectoritem2[0] = new SettingInfo.RadioSelectorItem();
        aradioselectoritem2[0].value = 0x15180;
        aradioselectoritem2[0].resid_text = 0x7f070098;
        aradioselectoritem2[1] = new SettingInfo.RadioSelectorItem();
        aradioselectoritem2[1].value = 3600;
        aradioselectoritem2[1].resid_text = 0x7f070099;
        aradioselectoritem2[2] = new SettingInfo.RadioSelectorItem();
        aradioselectoritem2[2].value = 900;
        aradioselectoritem2[2].resid_text = 0x7f07009a;
        aradioselectoritem2[3] = new SettingInfo.RadioSelectorItem();
        aradioselectoritem2[3].value = 60;
        aradioselectoritem2[3].resid_text = 0x7f07009b;
        aradioselectoritem2[4] = new SettingInfo.RadioSelectorItem();
        aradioselectoritem2[4].value = 0;
        aradioselectoritem2[4].resid_text = 0x7f07009c;
        settinginfo3.m_extraData = aradioselectoritem2;
        settinginfo3.m_key = "chats_timestamp_seconds";
        settinginfo3.m_defaultValue = String.valueOf(900);
        settinginfo3.m_type = SettingInfo.SettingType.RADIOSELECTOR;
        settinginfo3.m_access = SettingInfo.AccessRight.VALID_ACCOUNT;
        m_settingChatsTimestamp = settinginfo3;
        m_settingsList.add(settinginfo3);
        SettingInfo settinginfo4 = new SettingInfo();
        settinginfo4.m_resid = 0x7f07009d;
        settinginfo4.m_resid_detailed = 0x7f07009e;
        settinginfo4.m_key = "chats_links_nonsteam";
        settinginfo4.m_defaultValue = "1";
        settinginfo4.m_type = SettingInfo.SettingType.CHECK;
        settinginfo4.m_access = SettingInfo.AccessRight.VALID_ACCOUNT;
        m_settingChatsAlertLinks = settinginfo4;
        m_settingsList.add(settinginfo4);
        if (android.os.Build.VERSION.SDK_INT >= 11)
        {
            SettingInfo settinginfo5 = new SettingInfo();
            settinginfo5.m_resid = 0x7f0700a2;
            settinginfo5.m_resid_detailed = 0x7f0700a3;
            settinginfo5.m_key = "hw_acceleration";
            settinginfo5.m_defaultValue = "1";
            settinginfo5.m_type = SettingInfo.SettingType.CHECK;
            settinginfo5.m_access = SettingInfo.AccessRight.VALID_ACCOUNT;
            m_settingHardwareAcceleration = settinginfo5;
            m_settingsList.add(settinginfo5);
        }
        SettingInfo settinginfo6 = new SettingInfo();
        settinginfo6.m_resid = 0x7f07004d;
        settinginfo6.m_access = SettingInfo.AccessRight.VALID_ACCOUNT;
        m_settingsList.add(settinginfo6);
        SettingInfo settinginfo7 = new SettingInfo();
        settinginfo7.m_resid = 0x7f070050;
        settinginfo7.m_resid_detailed = 0x7f070051;
        settinginfo7.m_defaultValue = URL_SETTINGS_ONLINE;
        settinginfo7.m_type = SettingInfo.SettingType.URI;
        settinginfo7.m_access = SettingInfo.AccessRight.VALID_ACCOUNT;
        m_settingsList.add(settinginfo7);
        SettingInfo settinginfo8 = new SettingInfo();
        settinginfo8.m_resid = 0x7f07004e;
        settinginfo8.m_resid_detailed = 0x7f07004f;
        settinginfo8.m_key = "personal_dob";
        settinginfo8.m_defaultValue = "";
        settinginfo8.m_type = SettingInfo.SettingType.DATE;
        settinginfo8.m_access = SettingInfo.AccessRight.VALID_ACCOUNT;
        settinginfo8.m_pUpdateListener = new SettingInfo.UpdateListener() {

            final SettingInfoDB this$0;

            public void OnSettingInfoValueUpdate(SettingInfo settinginfo18, String s1, SettingInfo.Transaction transaction)
            {
                SteamWebApi.SetCookie2("dob", SettingInfo.DateConverter.makeUnixTime(s1));
                transaction.markCookiesForSync();
            }

            
            {
                this$0 = SettingInfoDB.this;
                super();
            }
        };
        m_settingDOB = settinginfo8;
        m_settingsList.add(settinginfo8);
        SettingInfo settinginfo9 = new SettingInfo();
        settinginfo9.m_resid = 0x7f07003b;
        settinginfo9.m_access = SettingInfo.AccessRight.VALID_ACCOUNT;
        m_settingsList.add(settinginfo9);
        SettingInfo settinginfo10 = new SettingInfo();
        settinginfo10.m_resid = 0x7f07003c;
        settinginfo10.m_resid_detailed = 0x7f07003d;
        settinginfo10.m_key = "notifications_ongoing";
        settinginfo10.m_defaultValue = "1";
        settinginfo10.m_type = SettingInfo.SettingType.CHECK;
        settinginfo10.m_access = SettingInfo.AccessRight.VALID_ACCOUNT;
        settinginfo10.m_pUpdateListener = new SettingInfo.UpdateListener() {

            final SettingInfoDB this$0;

            public void OnSettingInfoValueUpdate(SettingInfo settinginfo18, String s1, SettingInfo.Transaction transaction)
            {
                SteamDBService.REQ_ACT_SETTINGCHANGE_DATA req_act_settingchange_data = new SteamDBService.REQ_ACT_SETTINGCHANGE_DATA();
                req_act_settingchange_data.sSteamID = SteamWebApi.GetLoginSteamID();
                req_act_settingchange_data.sSettingKey = "notifications_ongoing";
                req_act_settingchange_data.sNewValue = s1;
                SteamWebApi.SubmitSimpleActionRequest("SettingChange", req_act_settingchange_data);
            }

            
            {
                this$0 = SettingInfoDB.this;
                super();
            }
        };
        m_settingForegroundService = settinginfo10;
        m_settingsList.add(settinginfo10);
        boolean flag = C2DMessaging.isSupported();
        SettingInfo settinginfo11 = new SettingInfo();
        settinginfo11.m_resid = 0x7f07003e;
        byte byte0;
        SettingInfo.RadioSelectorItem aradioselectoritem3[];
        int i;
        String s;
        SettingInfo settinginfo12;
        SettingInfo settinginfo13;
        SettingInfo.RadioSelectorItem aradioselectoritem4[];
        SettingInfo settinginfo14;
        SettingInfo.RadioSelectorItem aradioselectoritem5[];
        SettingInfo settinginfo15;
        SettingInfo.RadioSelectorItem aradioselectoritem6[];
        SettingInfo.AccessRight accessright;
        SettingInfo settinginfo16;
        SettingInfo settinginfo17;
        if (flag)
        {
            byte0 = 3;
        } else
        {
            byte0 = 2;
        }
        aradioselectoritem3 = new SettingInfo.RadioSelectorItem[byte0];
        aradioselectoritem3[0] = new SettingInfo.RadioSelectorItem();
        aradioselectoritem3[0].value = 2;
        aradioselectoritem3[0].resid_text = 0x7f07003f;
        i = 0 + 1;
        if (flag)
        {
            aradioselectoritem3[i] = new SettingInfo.RadioSelectorItem();
            aradioselectoritem3[i].value = 1;
            aradioselectoritem3[i].resid_text = 0x7f070040;
            i++;
        }
        aradioselectoritem3[i] = new SettingInfo.RadioSelectorItem();
        aradioselectoritem3[i].value = 0;
        aradioselectoritem3[i].resid_text = 0x7f070041;
        settinginfo11.m_extraData = aradioselectoritem3;
        settinginfo11.m_key = "notifications_im2";
        if (flag)
        {
            s = "1";
        } else
        {
            s = "0";
        }
        settinginfo11.m_defaultValue = s;
        settinginfo11.m_type = SettingInfo.SettingType.RADIOSELECTOR;
        settinginfo11.m_access = SettingInfo.AccessRight.VALID_ACCOUNT;
        settinginfo11.m_pUpdateListener = new SettingInfo.UpdateListener() {

            final SettingInfoDB this$0;

            public void OnSettingInfoValueUpdate(SettingInfo settinginfo18, String s1, SettingInfo.Transaction transaction)
            {
                SteamDBService.REQ_ACT_SETTINGCHANGE_DATA req_act_settingchange_data = new SteamDBService.REQ_ACT_SETTINGCHANGE_DATA();
                req_act_settingchange_data.sSteamID = SteamWebApi.GetLoginSteamID();
                req_act_settingchange_data.sSettingKey = "notifications_im2";
                req_act_settingchange_data.sNewValue = s1;
                SteamWebApi.SubmitSimpleActionRequest("SettingChange", req_act_settingchange_data);
            }

            
            {
                this$0 = SettingInfoDB.this;
                super();
            }
        };
        m_settingNotificationsIMs2 = settinginfo11;
        m_settingsList.add(settinginfo11);
        settinginfo12 = new SettingInfo();
        settinginfo12.m_resid = 0x7f070042;
        settinginfo12.m_key = "notifications_ringtone";
        settinginfo12.m_defaultValue = "android.resource://com.valvesoftware.android.steam.community/raw/m";
        settinginfo12.m_type = SettingInfo.SettingType.RINGTONESELECTOR;
        settinginfo12.m_access = SettingInfo.AccessRight.VALID_ACCOUNT;
        m_settingRing = settinginfo12;
        m_settingsList.add(settinginfo12);
        settinginfo13 = new SettingInfo();
        settinginfo13.m_resid = 0x7f070045;
        aradioselectoritem4 = new SettingInfo.RadioSelectorItem[3];
        aradioselectoritem4[0] = new SettingInfo.RadioSelectorItem();
        aradioselectoritem4[0].value = -1;
        aradioselectoritem4[0].resid_text = 0x7f070046;
        aradioselectoritem4[1] = new SettingInfo.RadioSelectorItem();
        aradioselectoritem4[1].value = 0;
        aradioselectoritem4[1].resid_text = 0x7f070047;
        aradioselectoritem4[2] = new SettingInfo.RadioSelectorItem();
        aradioselectoritem4[2].value = 1;
        aradioselectoritem4[2].resid_text = 0x7f070048;
        settinginfo13.m_extraData = aradioselectoritem4;
        settinginfo13.m_key = "notifications_sound";
        settinginfo13.m_defaultValue = String.valueOf(0);
        settinginfo13.m_type = SettingInfo.SettingType.RADIOSELECTOR;
        settinginfo13.m_access = SettingInfo.AccessRight.VALID_ACCOUNT;
        m_settingSound = settinginfo13;
        m_settingsList.add(settinginfo13);
        settinginfo14 = new SettingInfo();
        settinginfo14.m_resid = 0x7f070049;
        aradioselectoritem5 = new SettingInfo.RadioSelectorItem[3];
        aradioselectoritem5[0] = new SettingInfo.RadioSelectorItem();
        aradioselectoritem5[0].value = -1;
        aradioselectoritem5[0].resid_text = 0x7f07004a;
        aradioselectoritem5[1] = new SettingInfo.RadioSelectorItem();
        aradioselectoritem5[1].value = 0;
        aradioselectoritem5[1].resid_text = 0x7f07004b;
        aradioselectoritem5[2] = new SettingInfo.RadioSelectorItem();
        aradioselectoritem5[2].value = 1;
        aradioselectoritem5[2].resid_text = 0x7f07004c;
        settinginfo14.m_extraData = aradioselectoritem5;
        settinginfo14.m_key = "notifications_vibrate";
        settinginfo14.m_defaultValue = String.valueOf(0);
        settinginfo14.m_type = SettingInfo.SettingType.RADIOSELECTOR;
        settinginfo14.m_access = SettingInfo.AccessRight.VALID_ACCOUNT;
        m_settingVibrate = settinginfo14;
        m_settingsList.add(settinginfo14);
        settinginfo15 = new SettingInfo();
        settinginfo15.m_resid = 0x7f070052;
        aradioselectoritem6 = new SettingInfo.RadioSelectorItem[3];
        aradioselectoritem6[0] = new SettingInfo.RadioSelectorItem();
        aradioselectoritem6[0].value = 1;
        aradioselectoritem6[0].resid_text = 0x7f070053;
        aradioselectoritem6[1] = new SettingInfo.RadioSelectorItem();
        aradioselectoritem6[1].value = 0;
        aradioselectoritem6[1].resid_text = 0x7f070054;
        aradioselectoritem6[2] = new SettingInfo.RadioSelectorItem();
        aradioselectoritem6[2].value = -1;
        aradioselectoritem6[2].resid_text = 0x7f070055;
        settinginfo15.m_extraData = aradioselectoritem6;
        settinginfo15.m_key = "ssl_untrusted_prompt";
        settinginfo15.m_defaultValue = String.valueOf(1);
        settinginfo15.m_type = SettingInfo.SettingType.RADIOSELECTOR;
        if (android.os.Build.VERSION.SDK_INT < 8)
        {
            accessright = SettingInfo.AccessRight.CODE;
        } else
        {
            accessright = SettingInfo.AccessRight.NONE;
        }
        settinginfo15.m_access = accessright;
        m_settingSslUntrustedPrompt = settinginfo15;
        m_settingsList.add(settinginfo15);
        settinginfo16 = new SettingInfo();
        settinginfo16.m_resid = 0x7f07007f;
        settinginfo16.m_access = SettingInfo.AccessRight.USER;
        m_settingsList.add(settinginfo16);
        settinginfo17 = new SettingInfo();
        settinginfo17.m_resid = 0x7f070080;
        settinginfo17.m_defaultValue = (new StringBuilder()).append(Config.APP_VERSION).append(" / ").append(Config.APP_VERSION_ID).toString();
        settinginfo17.m_type = SettingInfo.SettingType.MARKET;
        settinginfo17.m_access = SettingInfo.AccessRight.USER;
        m_settingsList.add(settinginfo17);
    }

    public ArrayList GetSettingsList()
    {
        return m_settingsList;
    }

    public void configureNotificationObject(Notification notification, boolean flag)
    {
        Context context = SteamCommunityApplication.GetInstance().getApplicationContext();
        SettingInfo.RadioSelectorItem radioselectoritem = m_settingSound.getRadioSelectorItemValue(context);
        SettingInfo.RadioSelectorItem radioselectoritem1 = m_settingVibrate.getRadioSelectorItemValue(context);
        notification.defaults = 4;
        boolean flag1;
        boolean flag2;
        if (radioselectoritem.value == -1 || radioselectoritem.value == 0 && flag)
        {
            flag1 = true;
        } else
        {
            flag1 = false;
        }
        if (flag1)
        {
            try
            {
                notification.sound = Uri.parse(m_settingRing.getValue(context));
            }
            catch (Exception exception)
            {
                notification.sound = Uri.parse(m_settingRing.m_defaultValue);
            }
        }
        if (radioselectoritem1.value == -1 || radioselectoritem1.value == 0 && flag)
        {
            flag2 = true;
        } else
        {
            flag2 = false;
        }
        if (flag2)
        {
            long al[] = new long[5];
            al[0] = 0L;
            al[1] = 200;
            al[2] = 200;
            al[3] = 200;
            al[4] = 1000;
            notification.vibrate = al;
        }
    }

    public void onReceive(Context context, Intent intent)
    {
    }

    static 
    {
        URL_SETTINGS_ONLINE = (new StringBuilder()).append("steammobile://opencategoryurl?url=").append(Config.URL_COMMUNITY_BASE_INSECURE).append("/mobilesettings/GetManifest/v0001").toString();
    }
}
