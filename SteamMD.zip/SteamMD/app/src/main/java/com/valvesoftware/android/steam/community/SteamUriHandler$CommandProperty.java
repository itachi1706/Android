// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;


// Referenced classes of package com.valvesoftware.android.steam.community:
//            SteamUriHandler

public static final class  extends Enum
{

    private static final .VALUES $VALUES[];
    public static final .VALUES call;
    public static final .VALUES oauth_token;
    public static final .VALUES steamid;
    public static final .VALUES title;
    public static final .VALUES url;
    public static final .VALUES webcookie;

    public static  valueOf(String s)
    {
        return ()Enum.valueOf(com/valvesoftware/android/steam/community/SteamUriHandler$CommandProperty, s);
    }

    public static [] values()
    {
        return ([])$VALUES.clone();
    }

    static 
    {
        url = new <init>("url", 0);
        call = new <init>("call", 1);
        title = new <init>("title", 2);
        steamid = new <init>("steamid", 3);
        oauth_token = new <init>("oauth_token", 4);
        webcookie = new <init>("webcookie", 5);
        y_3B_.clone aclone[] = new <init>[6];
        aclone[0] = url;
        aclone[1] = call;
        aclone[2] = title;
        aclone[3] = steamid;
        aclone[4] = oauth_token;
        aclone[5] = webcookie;
        $VALUES = aclone;
    }

    private (String s, int i)
    {
        super(s, i);
    }
}
