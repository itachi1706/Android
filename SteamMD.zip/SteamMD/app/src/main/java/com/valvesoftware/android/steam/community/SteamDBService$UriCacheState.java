// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;


// Referenced classes of package com.valvesoftware.android.steam.community:
//            SteamDBService

public static final class  extends Enum
{

    private static final .VALUES $VALUES[];
    public static final .VALUES CacheIsLive;
    public static final .VALUES CacheIsMissing;
    public static final .VALUES CacheIsStale;

    public static  valueOf(String s)
    {
        return ()Enum.valueOf(com/valvesoftware/android/steam/community/SteamDBService$UriCacheState, s);
    }

    public static [] values()
    {
        return ([])$VALUES.clone();
    }

    static 
    {
        CacheIsLive = new <init>("CacheIsLive", 0);
        CacheIsStale = new <init>("CacheIsStale", 1);
        CacheIsMissing = new <init>("CacheIsMissing", 2);
        e_3B_.clone aclone[] = new <init>[3];
        aclone[0] = CacheIsLive;
        aclone[1] = CacheIsStale;
        aclone[2] = CacheIsMissing;
        $VALUES = aclone;
    }

    private (String s, int i)
    {
        super(s, i);
    }
}
