// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.fragment;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.valvesoftware.android.steam.community.SteamWebApi;

// Referenced classes of package com.valvesoftware.android.steam.community.fragment:
//            SettingsFragment

private class <init> extends BroadcastReceiver
{

    final SettingsFragment this$0;

    public void onReceive(Context context, Intent intent)
    {
        while (getActivity() == null || !intent.getStringExtra("type").equalsIgnoreCase("umqstate")) 
        {
            return;
        }
        if (SteamWebApi.IsLoggedIn() != SettingsFragment.access$300(SettingsFragment.this))
        {
            refreshListView();
            return;
        } else
        {
            SettingsFragment.access$100(SettingsFragment.this, SettingsFragment.access$000(SettingsFragment.this));
            return;
        }
    }

    private ()
    {
        this$0 = SettingsFragment.this;
        super();
    }

    this._cls0(this._cls0 _pcls0)
    {
        this();
    }
}
