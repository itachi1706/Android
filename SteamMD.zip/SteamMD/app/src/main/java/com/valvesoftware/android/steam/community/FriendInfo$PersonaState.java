// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;


// Referenced classes of package com.valvesoftware.android.steam.community:
//            FriendInfo

public static final class  extends Enum
{

    private static final .VALUES $VALUES[];
    public static final .VALUES AWAY;
    public static final .VALUES BUSY;
    public static final .VALUES OFFLINE;
    public static final .VALUES ONLINE;
    public static final .VALUES SNOOZE;

    public static  FromInteger(int i)
    {
        switch (i)
        {
        default:
            return OFFLINE;

        case 0: // '\0'
            return OFFLINE;

        case 1: // '\001'
            return ONLINE;

        case 2: // '\002'
            return BUSY;

        case 3: // '\003'
            return AWAY;

        case 4: // '\004'
            return SNOOZE;
        }
    }

    public static SNOOZE valueOf(String s)
    {
        return (SNOOZE)Enum.valueOf(com/valvesoftware/android/steam/community/FriendInfo$PersonaState, s);
    }

    public static SNOOZE[] values()
    {
        return (SNOOZE[])$VALUES.clone();
    }

    public int GetDisplayString()
    {
        switch (com.valvesoftware.android.steam.community.FriendInfo.PersonaState[ordinal()])
        {
        default:
            return 0x7f070027;

        case 1: // '\001'
            return 0x7f070021;

        case 2: // '\002'
            return 0x7f070020;

        case 3: // '\003'
            return 0x7f070024;

        case 4: // '\004'
            return 0x7f070025;

        case 5: // '\005'
            return 0x7f070026;
        }
    }

    static 
    {
        OFFLINE = new <init>("OFFLINE", 0);
        ONLINE = new <init>("ONLINE", 1);
        BUSY = new <init>("BUSY", 2);
        AWAY = new <init>("AWAY", 3);
        SNOOZE = new <init>("SNOOZE", 4);
        ordinal aordinal[] = new <init>[5];
        aordinal[0] = OFFLINE;
        aordinal[1] = ONLINE;
        aordinal[2] = BUSY;
        aordinal[3] = AWAY;
        aordinal[4] = SNOOZE;
        $VALUES = aordinal;
    }

    private (String s, int i)
    {
        super(s, i);
    }
}
