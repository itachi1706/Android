// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;
import java.util.ArrayList;
import java.util.Calendar;

public class SteamDebugUtilDatabase
{
    public static class CrashTrace
    {

        public int id;
        public String info;
        public long timestamp;

        public CrashTrace()
        {
        }
    }

    private class DbOpenHelper extends SQLiteOpenHelper
    {

        final SteamDebugUtilDatabase this$0;

        public void onCreate(SQLiteDatabase sqlitedatabase)
        {
            sqlitedatabase.execSQL("CREATE TABLE dbgutil (   _id integer primary key autoincrement , parent_id integer default null , threadid integer not null , msgtime integer not null , key text default null , value text default null , sessionstate integer default null  )");
            sqlitedatabase.execSQL("CREATE INDEX idxDbgSessionState ON dbgutil ( sessionstate )");
        }

        public void onUpgrade(SQLiteDatabase sqlitedatabase, int i, int j)
        {
            sqlitedatabase.execSQL("DROP TABLE if exists dbgutil");
            onCreate(sqlitedatabase);
        }

        public DbOpenHelper(Context context)
        {
            this$0 = SteamDebugUtilDatabase.this;
            super(context, "dbgutil.db", null, 1);
        }
    }


    private static final String DB_C_DBG_ID = "_id";
    private static final String DB_C_DBG_KEY = "key";
    private static final String DB_C_DBG_PARENT_ID = "parent_id";
    private static final String DB_C_DBG_SESSIONSTATE = "sessionstate";
    private static final String DB_C_DBG_THREAD_ID = "threadid";
    private static final String DB_C_DBG_TIME = "msgtime";
    private static final String DB_C_DBG_VALUE = "value";
    private static final String DB_IDX_DBG_SESSIONSTATE = "idxDbgSessionState";
    private static final String DB_NAME = "dbgutil.db";
    private static final String DB_T_DBG = "dbgutil";
    private static final long DB_VAL_DBG_SESSIONSTATE_EXCEPTION = 2L;
    private static final long DB_VAL_DBG_SESSIONSTATE_TRACE = 1L;
    private static final long DB_VAL_DBG_SESSIONSTATE_TRACE_UPLOADED = 3L;
    private static final int DB_VERSION = 1;
    private SQLiteStatement dbStmt_SQL_INSERT;
    private SQLiteStatement dbStmt_SQL_UPDATE;
    private Context m_context;
    private SQLiteDatabase m_db;
    private DbOpenHelper m_helper;

    public SteamDebugUtilDatabase(Context context)
    {
        dbStmt_SQL_INSERT = null;
        dbStmt_SQL_UPDATE = null;
        m_context = context;
        m_helper = new DbOpenHelper(m_context);
        m_db = m_helper.getWritableDatabase();
    }

    public String getDbName()
    {
        return "dbgutil.db";
    }

    public boolean insertMessage(SteamDebugUtil.DebugUtilRecord debugutilrecord)
    {
        boolean flag = true;
        this;
        JVM INSTR monitorenter ;
        if (dbStmt_SQL_INSERT == null)
        {
            dbStmt_SQL_INSERT = m_db.compileStatement("INSERT INTO dbgutil ( parent_id,threadid,msgtime,key,value,sessionstate ) VALUES ( ?,?, ?, ?,?, ? )");
        }
        if (debugutilrecord.parent == null) goto _L2; else goto _L1
_L1:
        dbStmt_SQL_INSERT.bindLong(1, debugutilrecord.parent.getId());
_L7:
        SQLiteStatement sqlitestatement;
        dbStmt_SQL_INSERT.bindLong(2, debugutilrecord.threadid);
        long l = debugutilrecord.timestamp.getTimeInMillis() / 1000L;
        dbStmt_SQL_INSERT.bindLong(3, l);
        sqlitestatement = dbStmt_SQL_INSERT;
        if (debugutilrecord.key == null) goto _L4; else goto _L3
_L3:
        String s = debugutilrecord.key;
_L8:
        SQLiteStatement sqlitestatement1;
        String s1;
        sqlitestatement.bindString(4, s);
        sqlitestatement1 = dbStmt_SQL_INSERT;
        if (debugutilrecord.value == null)
        {
            break MISSING_BLOCK_LABEL_266;
        }
        s1 = debugutilrecord.value;
_L10:
        sqlitestatement1.bindString(5, s1);
        if (debugutilrecord.sessionstate <= 0L) goto _L6; else goto _L5
_L5:
        dbStmt_SQL_INSERT.bindLong(6, debugutilrecord.sessionstate);
_L9:
        long l1;
        debugutilrecord.id = dbStmt_SQL_INSERT.executeInsert();
        l1 = debugutilrecord.id;
        Exception exception;
        SQLiteStatement sqlitestatement2;
        long l2;
        if (l1 == -1L)
        {
            flag = false;
        }
        this;
        JVM INSTR monitorexit ;
        return flag;
_L2:
        dbStmt_SQL_INSERT.bindNull(1);
          goto _L7
        exception;
        throw exception;
_L4:
        s = "";
          goto _L8
_L6:
        if (debugutilrecord.key != null)
        {
            break MISSING_BLOCK_LABEL_249;
        }
        sqlitestatement2 = dbStmt_SQL_INSERT;
        if (debugutilrecord.value == null)
        {
            l2 = 2L;
        } else
        {
            l2 = 1L;
        }
        sqlitestatement2.bindLong(6, l2);
          goto _L9
        dbStmt_SQL_INSERT.bindNull(6);
          goto _L9
        s1 = "";
          goto _L10
    }

    public ArrayList selectCrashTraces()
    {
        this;
        JVM INSTR monitorenter ;
        ArrayList arraylist;
        Cursor cursor;
        arraylist = new ArrayList();
        cursor = m_db.rawQuery("SELECT _id,msgtime,value FROM dbgutil WHERE sessionstate=1", null);
        cursor.moveToFirst();
        for (; !cursor.isAfterLast(); cursor.moveToNext())
        {
            CrashTrace crashtrace = new CrashTrace();
            crashtrace.id = cursor.getInt(0);
            crashtrace.timestamp = cursor.getLong(1);
            crashtrace.info = cursor.getString(2);
            arraylist.add(crashtrace);
        }

        break MISSING_BLOCK_LABEL_104;
        Exception exception;
        exception;
        throw exception;
        cursor.close();
        this;
        JVM INSTR monitorexit ;
        return arraylist;
    }

    public void updateMarkCrashTraceUploaded(CrashTrace crashtrace)
    {
        this;
        JVM INSTR monitorenter ;
        if (dbStmt_SQL_UPDATE == null)
        {
            dbStmt_SQL_UPDATE = m_db.compileStatement("DELETE FROM dbgutil WHERE _id<=?");
        }
        dbStmt_SQL_UPDATE.bindLong(1, crashtrace.id);
        dbStmt_SQL_UPDATE.execute();
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }
}
