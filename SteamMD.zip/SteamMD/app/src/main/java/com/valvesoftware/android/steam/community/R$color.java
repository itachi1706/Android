// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;


// Referenced classes of package com.valvesoftware.android.steam.community:
//            R

public static final class 
{

    public static final int almost_fully_transparent = 0x7f060010;
    public static final int aqua = 0x7f060009;
    public static final int black = 0x7f06000f;
    public static final int blue = 0x7f06000d;
    public static final int category_label = 0x7f060011;
    public static final int chat_background = 0x7f060015;
    public static final int chat_load_more = 0x7f06001e;
    public static final int chat_my_failed = 0x7f06001a;
    public static final int chat_my_sending = 0x7f060018;
    public static final int chat_my_sending_text = 0x7f06001c;
    public static final int chat_my_sent = 0x7f060019;
    public static final int chat_my_sent_text = 0x7f06001d;
    public static final int chat_my_text_background = 0x7f060017;
    public static final int chat_other = 0x7f060016;
    public static final int chat_other_text = 0x7f06001b;
    public static final int fuchsia = 0x7f060002;
    public static final int gray = 0x7f060005;
    public static final int green = 0x7f06000c;
    public static final int ingame = 0x7f060013;
    public static final int lime = 0x7f06000a;
    public static final int maroon = 0x7f060008;
    public static final int navigation_section_title = 0x7f060023;
    public static final int navigation_section_title_underline = 0x7f060024;
    public static final int navy = 0x7f06000e;
    public static final int offline = 0x7f060012;
    public static final int olive = 0x7f060006;
    public static final int online = 0x7f060014;
    public static final int purple = 0x7f060007;
    public static final int red = 0x7f060003;
    public static final int settings_background = 0x7f060025;
    public static final int settings_changeuser = 0x7f060028;
    public static final int settings_item_detail = 0x7f060027;
    public static final int settings_item_title = 0x7f060026;
    public static final int silver = 0x7f060004;
    public static final int tab_selector_active = 0x7f06001f;
    public static final int tab_selector_bg_active = 0x7f060021;
    public static final int tab_selector_bg_default = 0x7f060022;
    public static final int tab_selector_default = 0x7f060020;
    public static final int teal = 0x7f06000b;
    public static final int white = 0x7f060000;
    public static final int yellow = 0x7f060001;

    public ()
    {
    }
}
