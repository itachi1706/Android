// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

public class C2DMessaging
{

    public static final String BACKOFF = "backoff";
    private static final long DEFAULT_BACKOFF = 30000L;
    public static final String EXTRA_APPLICATION_PENDING_INTENT = "app";
    public static final String EXTRA_SENDER = "sender";
    public static final String GSF_PACKAGE = "com.google.android.gsf";
    public static final String LAST_REGISTRATION_CHANGE = "last_registration_change";
    private static final long MAXIMUM_BACKOFF = 0x6ddd00L;
    static final String PREFERENCE = "com.google.android.c2dm";
    public static final String REQUEST_REGISTRATION_INTENT = "com.google.android.c2dm.intent.REGISTER";
    public static final String REQUEST_UNREGISTRATION_INTENT = "com.google.android.c2dm.intent.UNREGISTER";
    public static final String STORED_REGISTRATION_ID = "c2dm_registration_id_2";
    public static final String TAG = "C2DM";

    public C2DMessaging()
    {
    }

    static void clearRegistrationId(Context context)
    {
        android.content.SharedPreferences.Editor editor = context.getSharedPreferences("com.google.android.c2dm", 0).edit();
        editor.putString("c2dm_registration_id_2", "");
        editor.putLong("last_registration_change", System.currentTimeMillis());
        editor.commit();
    }

    static long getBackoff(Context context)
    {
        return Math.min(context.getSharedPreferences("com.google.android.c2dm", 0).getLong("backoff", 30000L), 0x6ddd00L);
    }

    public static long getLastRegistrationChange(Context context)
    {
        return context.getSharedPreferences("com.google.android.c2dm", 0).getLong("last_registration_change", 0L);
    }

    public static String getRegistrationId(Context context)
    {
        if (!isSupported())
        {
            return "";
        } else
        {
            return context.getSharedPreferences("com.google.android.c2dm", 0).getString("c2dm_registration_id_2", "");
        }
    }

    public static boolean isSupported()
    {
        boolean flag;
        if (android.os.Build.VERSION.SDK_INT >= 8)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (flag);
        return flag;
    }

    public static void register(Context context, String s)
    {
        if (!isSupported())
        {
            return;
        }
        try
        {
            Intent intent = new Intent("com.google.android.c2dm.intent.REGISTER");
            intent.setPackage("com.google.android.gsf");
            intent.putExtra("app", PendingIntent.getBroadcast(context, 0, new Intent(), 0));
            intent.putExtra("sender", s);
            context.startService(intent);
            return;
        }
        catch (Exception exception)
        {
            return;
        }
    }

    static void resetBackoff(Context context)
    {
        setBackoff(context, 30000L);
    }

    static void setBackoff(Context context, long l)
    {
        long l1 = Math.min(l, 0x6ddd00L);
        android.content.SharedPreferences.Editor editor = context.getSharedPreferences("com.google.android.c2dm", 0).edit();
        editor.putLong("backoff", l1);
        editor.commit();
    }

    static void setRegistrationId(Context context, String s)
    {
        android.content.SharedPreferences.Editor editor = context.getSharedPreferences("com.google.android.c2dm", 0).edit();
        editor.putString("c2dm_registration_id_2", s);
        editor.commit();
    }

    public static void unregister(Context context)
    {
        if (!isSupported())
        {
            return;
        }
        try
        {
            Intent intent = new Intent("com.google.android.c2dm.intent.UNREGISTER");
            intent.setPackage("com.google.android.gsf");
            intent.putExtra("app", PendingIntent.getBroadcast(context, 0, new Intent(), 0));
            context.startService(intent);
            return;
        }
        catch (Exception exception)
        {
            return;
        }
    }
}
