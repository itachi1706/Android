// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;

import android.net.Uri;
import org.json.JSONObject;

// Referenced classes of package com.valvesoftware.android.steam.community:
//            SteamUmqCommunicationService, C2DMProcessor

private class SetPostData extends SetPostData
{

    private boolean m_bClientPushIsActive;
    final SteamUmqCommunicationService this$0;

    public void RequestFailedOnResponseWorkerThread()
    {
        synchronized (SteamUmqCommunicationService.access$1200(SteamUmqCommunicationService.this))
        {
            SteamUmqCommunicationService.access$1200(SteamUmqCommunicationService.this).ntToServer = true;
        }
        return;
        exception;
        setpostdata;
        JVM INSTR monitorexit ;
        throw exception;
    }

    public void RequestSucceededOnResponseWorkerThread()
    {
        if (!"OK".equals(m_jsonDocument.optString("error", "fail")))
        {
            RequestFailedOnResponseWorkerThread();
            return;
        }
        synchronized (SteamUmqCommunicationService.access$1200(SteamUmqCommunicationService.this))
        {
            SteamUmqCommunicationService.access$1200(SteamUmqCommunicationService.this).IsActive = m_bClientPushIsActive;
        }
        return;
        exception;
        nttoserver;
        JVM INSTR monitorexit ;
        throw exception;
    }

    public a(String s)
    {
        this$0 = SteamUmqCommunicationService.this;
        super(SteamUmqCommunicationService.this, "JobQueueUMQdeviceinfo");
        m_bClientPushIsActive = false;
        SetUriAndDocumentType(SteamUmqCommunicationService.access$2500(), SetUriAndDocumentType);
        SetRequestAction();
        String s1 = Uri.encode(SteamUmqCommunicationService.access$1200(SteamUmqCommunicationService.this).onId);
        StringBuilder stringbuilder = new StringBuilder(12 + (16 + (8 + (16 + s.length()) + s1.length())));
        stringbuilder.append(s);
        stringbuilder.append("&deviceid=");
        stringbuilder.append("GOOG%3A");
        stringbuilder.append(s1);
        stringbuilder.append("&lang=");
        stringbuilder.append(SteamUmqCommunicationService.access$1200(SteamUmqCommunicationService.this).onLanguage);
        stringbuilder.append("&im_enable=");
        m_bClientPushIsActive = SteamUmqCommunicationService.access$1200(SteamUmqCommunicationService.this).ve();
        String s2;
        if (m_bClientPushIsActive)
        {
            s2 = "1";
        } else
        {
            s2 = "0";
        }
        stringbuilder.append(s2);
        stringbuilder.append("&im_id=");
        stringbuilder.append(C2DMProcessor.getIMID(SteamUmqCommunicationService.access$700(SteamUmqCommunicationService.this)));
        SetPostData(stringbuilder.toString());
    }
}
