// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;


// Referenced classes of package com.valvesoftware.android.steam.community:
//            WorkerThreadPool

private static final class  extends Enum
{

    private static final .VALUES $VALUES[];
    public static final .VALUES AddBackToPool;
    public static final .VALUES Continue;
    public static final .VALUES ShutdownQueue;

    public static  valueOf(String s)
    {
        return ()Enum.valueOf(com/valvesoftware/android/steam/community/WorkerThreadPool$TaskResult, s);
    }

    public static [] values()
    {
        return ([])$VALUES.clone();
    }

    static 
    {
        Continue = new <init>("Continue", 0);
        AddBackToPool = new <init>("AddBackToPool", 1);
        ShutdownQueue = new <init>("ShutdownQueue", 2);
        t_3B_.clone aclone[] = new <init>[3];
        aclone[0] = Continue;
        aclone[1] = AddBackToPool;
        aclone[2] = ShutdownQueue;
        $VALUES = aclone;
    }

    private (String s, int i)
    {
        super(s, i);
    }
}
