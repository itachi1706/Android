// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;


// Referenced classes of package com.valvesoftware.android.steam.community:
//            R

public static final class 
{

    public static final int chat_activity = 0x7f030000;
    public static final int chat_fragment = 0x7f030001;
    public static final int chat_view_entry_other = 0x7f030002;
    public static final int chat_view_entry_other_text = 0x7f030003;
    public static final int chat_view_entry_user = 0x7f030004;
    public static final int chat_view_entry_user_left = 0x7f030005;
    public static final int chat_view_entry_user_text = 0x7f030006;
    public static final int community_activity = 0x7f030007;
    public static final int community_groups_activity = 0x7f030008;
    public static final int friend_list_item = 0x7f030009;
    public static final int friends_fragment = 0x7f03000a;
    public static final int group_list_item = 0x7f03000b;
    public static final int login = 0x7f03000c;
    public static final int navigation_fragment = 0x7f03000d;
    public static final int navigation_list_item = 0x7f03000e;
    public static final int search_friends_activity = 0x7f03000f;
    public static final int search_groups_activity = 0x7f030010;
    public static final int settings_activity = 0x7f030011;
    public static final int settings_fragment = 0x7f030012;
    public static final int settings_list_item_info = 0x7f030013;
    public static final int tabs = 0x7f030014;
    public static final int tabs_indicator = 0x7f030015;
    public static final int titlebar_fragment = 0x7f030016;
    public static final int web_view_list_item = 0x7f030017;
    public static final int webview_activity = 0x7f030018;
    public static final int webview_fragment = 0x7f030019;

    public ()
    {
    }
}
