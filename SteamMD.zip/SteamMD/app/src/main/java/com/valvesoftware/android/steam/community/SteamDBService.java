// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;

// Referenced classes of package com.valvesoftware.android.steam.community:
//            SteamDebugUtil, WorkerThreadPool, SteamUmqCommunicationService, SteamCommunityApplication, 
//            C2DMProcessor, ISteamDebugUtil, ISteamUmqCommunicationDatabase, SteamDBDiskCache

public class SteamDBService extends Service
{
    public static class REQ_ACT_LOGININFO_DATA
    {

        public String sOAuthToken;
        public String sSteamID;

        public REQ_ACT_LOGININFO_DATA()
        {
        }
    }

    public static class REQ_ACT_MARKREADMESSAGES_DATA
    {

        public boolean deleteAllMessages;
        public String mysteamid;
        public String withsteamid;

        public REQ_ACT_MARKREADMESSAGES_DATA()
        {
        }
    }

    public static class REQ_ACT_SENDMESSAGE_DATA
    {

        public String intentcontext;
        public ISteamUmqCommunicationDatabase.Message msg;
        public REQ_ACT_LOGININFO_DATA mylogin;

        public REQ_ACT_SENDMESSAGE_DATA()
        {
        }
    }

    public static class REQ_ACT_SETTINGCHANGE_DATA
    {

        public String sNewValue;
        public String sSettingKey;
        public String sSteamID;

        public REQ_ACT_SETTINGCHANGE_DATA()
        {
        }
    }

    public static class REQ_ACT_UMQACTIVITY_DATA
    {

        public REQ_ACT_UMQACTIVITY_DATA()
        {
        }
    }

    public class SteamDBTempBinder extends Binder
    {

        final SteamDBService this$0;

        SteamDBService getService()
        {
            return SteamDBService.this;
        }

        public SteamDBTempBinder()
        {
            this$0 = SteamDBService.this;
            super();
        }
    }

    private static abstract class TaskDiskCacheBase
        implements WorkerThreadPool.Task
    {

        protected SteamWebApi.RequestBase.DiskCacheInfo m_cache;

        public String GetRequestQueue()
        {
            return "JobQueueDiskCache";
        }

        protected TaskDiskCacheBase(SteamWebApi.RequestBase.DiskCacheInfo diskcacheinfo)
        {
            m_cache = diskcacheinfo;
        }
    }

    private static class TaskDiskCacheDelete extends TaskDiskCacheBase
    {

        public void Run()
        {
            if (!(m_cache.disk instanceof SteamDBDiskCache.IndefiniteCache))
            {
                return;
            } else
            {
                ((SteamDBDiskCache.IndefiniteCache)m_cache.disk).Delete(m_cache.uri);
                return;
            }
        }

        TaskDiskCacheDelete(SteamWebApi.RequestBase.DiskCacheInfo diskcacheinfo)
        {
            super(diskcacheinfo);
        }
    }

    private static class TaskDiskCacheWrite extends TaskDiskCacheBase
    {

        private byte m_data[];

        public void Run()
        {
            m_cache.disk.Write(m_cache.uri, m_data);
        }

        TaskDiskCacheWrite(SteamWebApi.RequestBase.DiskCacheInfo diskcacheinfo, byte abyte0[])
        {
            super(diskcacheinfo);
            m_data = null;
            m_data = abyte0;
        }
    }

    public static class TaskDoRequest
        implements WorkerThreadPool.Task
    {

        protected SteamWebApi.RequestBase m_request;

        private UriData FetchFromHttp()
            throws Exception
        {
            HttpResponse httpresponse = m_request.FetchHttpResponseOnWorkerThread();
            HttpEntity httpentity = httpresponse.getEntity();
            StatusLine statusline = httpresponse.getStatusLine();
            if (statusline.getStatusCode() == 200 && httpentity != null)
            {
                InputStream inputstream = httpentity.getContent();
                UriData uridata1 = new UriData();
                ByteArrayOutputStream bytearrayoutputstream = SteamDBService.ConvertInputStreamToByteArray(inputstream);
                if (m_request.IsRequestForByteData())
                {
                    uridata1.SetRequestIsLive(bytearrayoutputstream.toByteArray());
                    return uridata1;
                } else
                {
                    uridata1.SetRequestIsLive(bytearrayoutputstream.toString());
                    return uridata1;
                }
            } else
            {
                UriData uridata = new UriData();
                uridata.SetRequestError(statusline.getStatusCode());
                return uridata;
            }
        }

        private UriData ReadFromMemoryOrCache()
        {
            UriData uridata = new UriData();
            SteamWebApi.RequestBase.DiskCacheInfo diskcacheinfo = m_request.GetDiskCacheInfo();
            byte abyte0[] = diskcacheinfo.disk.Read(diskcacheinfo.uri);
            if (abyte0 != null)
            {
                uridata.SetRequestIsLive(abyte0);
            }
            if (abyte0 == null);
            return uridata;
        }

        public String GetRequestQueue()
        {
            static class _cls1
            {

                static final int $SwitchMap$com$valvesoftware$android$steam$community$SteamWebApi$RequestActionType[];

                static 
                {
                    $SwitchMap$com$valvesoftware$android$steam$community$SteamWebApi$RequestActionType = new int[SteamWebApi.RequestActionType.values().length];
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$SteamWebApi$RequestActionType[SteamWebApi.RequestActionType.GetFromCacheOnly.ordinal()] = 1;
                    }
                    catch (NoSuchFieldError nosuchfielderror) { }
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$SteamWebApi$RequestActionType[SteamWebApi.RequestActionType.GetFromCacheOrDoHttpRequestAndCacheResults.ordinal()] = 2;
                    }
                    catch (NoSuchFieldError nosuchfielderror1) { }
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$SteamWebApi$RequestActionType[SteamWebApi.RequestActionType.DoHttpRequestNoCache.ordinal()] = 3;
                    }
                    catch (NoSuchFieldError nosuchfielderror2) { }
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$SteamWebApi$RequestActionType[SteamWebApi.RequestActionType.DoHttpRequestAndCacheResults.ordinal()] = 4;
                    }
                    catch (NoSuchFieldError nosuchfielderror3)
                    {
                        return;
                    }
                }
            }

            switch (_cls1..SwitchMap.com.valvesoftware.android.steam.community.SteamWebApi.RequestActionType[m_request.GetRequestAction().ordinal()])
            {
            default:
                return m_request.GetRequestQueue();

            case 1: // '\001'
            case 2: // '\002'
                return "JobQueueDiskCache";
            }
        }

        public void Run()
        {
            if (m_request.OnTaskReadyToRunOnJobQueue()) goto _L2; else goto _L1
_L1:
            return;
_L2:
            String s;
            int i;
            UriData uridata;
            s = m_request.GetCallerIntent();
            if (s != null && "JOB_INTENT_SHUTDOWN_JOB_QUEUE".equals(s))
            {
                throw new WorkerThreadPool.ShutdownJobQueueException();
            }
            i = _cls1..SwitchMap.com.valvesoftware.android.steam.community.SteamWebApi.RequestActionType[m_request.GetRequestAction().ordinal()];
            uridata = null;
            i;
            JVM INSTR tableswitch 1 2: default 80
        //                       1 199
        //                       2 207;
               goto _L3 _L4 _L5
_L3:
            _cls1..SwitchMap.com.valvesoftware.android.steam.community.SteamWebApi.RequestActionType[m_request.GetRequestAction().ordinal()];
            JVM INSTR tableswitch 3 4: default 116
        //                       3 240
        //                       4 248;
               goto _L6 _L7 _L8
_L6:
            UriCacheState uricachestate;
            UriCacheState uricachestate1;
            uricachestate = uridata.GetRequestCacheState();
            uricachestate1 = UriCacheState.CacheIsMissing;
            boolean flag = false;
            if (uricachestate == uricachestate1) goto _L10; else goto _L9
_L9:
            m_request.OnResponseWorkerThread(uridata);
            flag = true;
_L10:
            if (!flag)
            {
                m_request.OnFailureWorkerThread(uridata);
            }
            if (s != null)
            {
                Intent intent2 = new Intent(s);
                intent2.putExtra("intent_id", m_request.GetIntentId());
                SteamCommunityApplication.GetInstance().sendBroadcast(intent2);
                return;
            }
              goto _L1
_L4:
            uridata = ReadFromMemoryOrCache();
              goto _L3
_L5:
            uridata = ReadFromMemoryOrCache();
            if (uridata.GetRequestCacheState() != UriCacheState.CacheIsMissing) goto _L3; else goto _L11
_L11:
            m_request.SetRequestAction(SteamWebApi.RequestActionType.DoHttpRequestAndCacheResults);
            throw new WorkerThreadPool.AddBackToPoolException();
_L7:
            uridata = FetchFromHttp();
              goto _L6
_L8:
            uridata = FetchFromHttp();
            if (uridata.IsRequestLive())
            {
                WriteToCacheInBackground(uridata);
            }
              goto _L6
            Exception exception1;
            exception1;
            UriData uridata1 = uridata;
            uridata = new UriData();
            uridata.SetRequestError(2);
            if (true)
            {
                m_request.OnFailureWorkerThread(uridata);
            }
            if (s == null) goto _L1; else goto _L12
_L12:
            Intent intent1 = new Intent(s);
            intent1.putExtra("intent_id", m_request.GetIntentId());
            SteamCommunityApplication.GetInstance().sendBroadcast(intent1);
            return;
            Exception exception;
            exception;
_L14:
            if (true)
            {
                m_request.OnFailureWorkerThread(uridata);
            }
            if (s != null)
            {
                Intent intent = new Intent(s);
                intent.putExtra("intent_id", m_request.GetIntentId());
                SteamCommunityApplication.GetInstance().sendBroadcast(intent);
            }
            throw exception;
            exception;
            uridata = uridata1;
            if (true) goto _L14; else goto _L13
_L13:
        }

        protected void WriteToCacheInBackground(UriData uridata)
        {
        }

        public TaskDoRequest(SteamWebApi.RequestBase requestbase)
        {
            m_request = null;
            m_request = requestbase;
        }
    }

    public class TaskDoRequestWithCache extends TaskDoRequest
    {

        final SteamDBService this$0;

        protected void WriteToCacheInBackground(UriData uridata)
        {
            m_workerThreadPool.AddTask(new TaskDiskCacheWrite(m_request.GetDiskCacheInfo(), uridata.GetByteData()));
        }

        public TaskDoRequestWithCache(SteamWebApi.RequestBase requestbase)
        {
            this$0 = SteamDBService.this;
            super(requestbase);
        }
    }

    public static final class UriCacheState extends Enum
    {

        private static final UriCacheState $VALUES[];
        public static final UriCacheState CacheIsLive;
        public static final UriCacheState CacheIsMissing;
        public static final UriCacheState CacheIsStale;

        public static UriCacheState valueOf(String s)
        {
            return (UriCacheState)Enum.valueOf(com/valvesoftware/android/steam/community/SteamDBService$UriCacheState, s);
        }

        public static UriCacheState[] values()
        {
            return (UriCacheState[])$VALUES.clone();
        }

        static 
        {
            CacheIsLive = new UriCacheState("CacheIsLive", 0);
            CacheIsStale = new UriCacheState("CacheIsStale", 1);
            CacheIsMissing = new UriCacheState("CacheIsMissing", 2);
            UriCacheState auricachestate[] = new UriCacheState[3];
            auricachestate[0] = CacheIsLive;
            auricachestate[1] = CacheIsStale;
            auricachestate[2] = CacheIsMissing;
            $VALUES = auricachestate;
        }

        private UriCacheState(String s, int i)
        {
            super(s, i);
        }
    }

    public static class UriData
    {

        public static final int RESULT_HTTP_EXCEPTION = 2;
        public static final int RESULT_INVALID_CONTENT = 1;
        public int m_httpResult;
        private byte m_resultByteData[];
        private String m_resultDocument;
        public UriDataState m_state;

        public byte[] GetByteData()
        {
            if (m_resultByteData == null && m_resultDocument != null)
            {
                m_resultByteData = m_resultDocument.getBytes();
            }
            return m_resultByteData;
        }

        public String GetDocument()
        {
            if (m_resultDocument == null && m_resultByteData != null)
            {
                m_resultDocument = new String(m_resultByteData);
            }
            return m_resultDocument;
        }

        public UriCacheState GetRequestCacheState()
        {
            if (m_state == UriDataState.RequestIsLive)
            {
                return UriCacheState.CacheIsLive;
            }
            if (m_resultDocument != null || m_resultByteData != null)
            {
                return UriCacheState.CacheIsStale;
            } else
            {
                return UriCacheState.CacheIsMissing;
            }
        }

        public boolean IsRequestLive()
        {
            return m_state == UriDataState.RequestIsLive;
        }

        public void SetRequestError(int i)
        {
            m_state = UriDataState.RequestError;
            m_httpResult = i;
        }

        public void SetRequestIsLive(String s)
        {
            m_state = UriDataState.RequestIsLive;
            m_httpResult = 200;
            m_resultDocument = s;
            m_resultByteData = null;
        }

        public void SetRequestIsLive(byte abyte0[])
        {
            m_state = UriDataState.RequestIsLive;
            m_httpResult = 200;
            m_resultDocument = null;
            m_resultByteData = abyte0;
        }

        public UriData()
        {
            m_state = UriDataState.RequestError;
        }
    }

    public static final class UriDataState extends Enum
    {

        private static final UriDataState $VALUES[];
        public static final UriDataState RequestError;
        public static final UriDataState RequestIsLive;

        public static UriDataState valueOf(String s)
        {
            return (UriDataState)Enum.valueOf(com/valvesoftware/android/steam/community/SteamDBService$UriDataState, s);
        }

        public static UriDataState[] values()
        {
            return (UriDataState[])$VALUES.clone();
        }

        static 
        {
            RequestIsLive = new UriDataState("RequestIsLive", 0);
            RequestError = new UriDataState("RequestError", 1);
            UriDataState auridatastate[] = new UriDataState[2];
            auridatastate[0] = RequestIsLive;
            auridatastate[1] = RequestError;
            $VALUES = auridatastate;
        }

        private UriDataState(String s, int i)
        {
            super(s, i);
        }
    }


    public static final String JOB_INTENT_SHUTDOWN_JOB_QUEUE = "JOB_INTENT_SHUTDOWN_JOB_QUEUE";
    public static final String JOB_QUEUE_APPS_DB = "JobQueueAppsDB";
    public static final String JOB_QUEUE_AVATARS_FRIENDS = "JobQueueAvatarsFriends";
    public static final String JOB_QUEUE_AVATARS_GROUPS = "JobQueueAvatarsGroups";
    public static final String JOB_QUEUE_CATALOG = "JobQueueCatalog";
    public static final String JOB_QUEUE_DISKCACHE = "JobQueueDiskCache";
    public static final String JOB_QUEUE_FRIENDS_DB = "JobQueueFriendsDB";
    public static final String JOB_QUEUE_GROUPS_DB = "JobQueueGroupsDB";
    public static final String JOB_QUEUE_SIMPLEACTION = "JobQueueSimpleAction";
    public static final String JOB_QUEUE_UMQ_DEVICEINFO = "JobQueueUMQdeviceinfo";
    public static final String JOB_QUEUE_UMQ_POLL = "JobQueueUMQpoll";
    public static final String JOB_QUEUE_UMQ_SENDMESSAGE = "JobQueueUMQsendmsg";
    public static final String REQ_ACT_LOGININFO = "SetLoginInformation";
    public static final String REQ_ACT_MARKREADMESSAGES = "MarkReadMessages";
    public static final String REQ_ACT_SENDMESSAGE = "SendMessage";
    public static final String REQ_ACT_SETTINGCHANGE = "SettingChange";
    public static final String REQ_ACT_UMQACTIVITY = "UmqActivity";
    private static final String TAG = "SteamDataBase";
    private final IBinder binder = new SteamDBTempBinder();
    private ISteamDebugUtil m_steamDebugUtil;
    private SteamUmqCommunicationService m_umqCommunicationService;
    private final WorkerThreadPool m_workerThreadPool = new WorkerThreadPool();

    public SteamDBService()
    {
        m_umqCommunicationService = null;
        m_steamDebugUtil = new SteamDebugUtil(null);
    }

    private static ByteArrayOutputStream ConvertInputStreamToByteArray(InputStream inputstream)
        throws Exception
    {
        ByteArrayOutputStream bytearrayoutputstream;
        byte abyte0[];
        bytearrayoutputstream = new ByteArrayOutputStream();
        abyte0 = new byte[1024];
_L1:
        int i = inputstream.read(abyte0, 0, abyte0.length);
        if (i == -1)
        {
            break MISSING_BLOCK_LABEL_48;
        }
        bytearrayoutputstream.write(abyte0, 0, i);
          goto _L1
        Exception exception;
        exception;
        inputstream.close();
        throw exception;
        bytearrayoutputstream.flush();
        inputstream.close();
        return bytearrayoutputstream;
    }

    public void DeleteIndefiniteCached(SteamWebApi.RequestBase requestbase)
    {
        m_workerThreadPool.AddTask(new TaskDiskCacheDelete(requestbase.GetDiskCacheInfo()));
    }

    public void SubmitRequest(SteamWebApi.RequestBase requestbase)
    {
        if (!"JobQueueSimpleAction".equals(requestbase.GetRequestQueue()))
        {
            break MISSING_BLOCK_LABEL_213;
        }
        if (!"SetLoginInformation".equals(requestbase.GetUri()) || !(requestbase.GetObjData() instanceof REQ_ACT_LOGININFO_DATA)) goto _L2; else goto _L1
_L1:
        REQ_ACT_LOGININFO_DATA req_act_logininfo_data = (REQ_ACT_LOGININFO_DATA)requestbase.GetObjData();
        m_umqCommunicationService.SvcReq_SetUmqCommunicationSettings(req_act_logininfo_data);
_L4:
        return;
_L2:
        if ("SendMessage".equals(requestbase.GetUri()) && (requestbase.GetObjData() instanceof REQ_ACT_SENDMESSAGE_DATA))
        {
            REQ_ACT_SENDMESSAGE_DATA req_act_sendmessage_data = (REQ_ACT_SENDMESSAGE_DATA)requestbase.GetObjData();
            m_umqCommunicationService.SvcReq_SendMessage(req_act_sendmessage_data);
            return;
        }
        if ("UmqActivity".equals(requestbase.GetUri()) && (requestbase.GetObjData() instanceof REQ_ACT_UMQACTIVITY_DATA))
        {
            REQ_ACT_UMQACTIVITY_DATA req_act_umqactivity_data = (REQ_ACT_UMQACTIVITY_DATA)requestbase.GetObjData();
            m_umqCommunicationService.SvcReq_UmqActivity(req_act_umqactivity_data);
            return;
        }
        if ("MarkReadMessages".equals(requestbase.GetUri()) && (requestbase.GetObjData() instanceof REQ_ACT_MARKREADMESSAGES_DATA))
        {
            REQ_ACT_MARKREADMESSAGES_DATA req_act_markreadmessages_data = (REQ_ACT_MARKREADMESSAGES_DATA)requestbase.GetObjData();
            m_umqCommunicationService.SvcReq_MarkReadMessages(req_act_markreadmessages_data);
            return;
        }
        if (!"SettingChange".equals(requestbase.GetUri()) || !(requestbase.GetObjData() instanceof REQ_ACT_SETTINGCHANGE_DATA)) goto _L4; else goto _L3
_L3:
        REQ_ACT_SETTINGCHANGE_DATA req_act_settingchange_data = (REQ_ACT_SETTINGCHANGE_DATA)requestbase.GetObjData();
        m_umqCommunicationService.SvcReq_SettingChange(req_act_settingchange_data);
        return;
        m_workerThreadPool.AddTask(new TaskDoRequestWithCache(requestbase));
        return;
    }

    public ISteamDebugUtil getDebugUtil()
    {
        return m_steamDebugUtil;
    }

    public ISteamUmqCommunicationDatabase getSteamUmqCommunicationServiceDB()
    {
        return m_umqCommunicationService.getDB();
    }

    public SteamUmqCommunicationService.UmqConnectionState getSteamUmqConnectionState()
    {
        return m_umqCommunicationService.SvcReq_GetUmqConnectionState();
    }

    public int getSteamUmqCurrentServerTime()
    {
        return m_umqCommunicationService.SvcReq_GetUmqCurrentServerTime();
    }

    public IBinder onBind(Intent intent)
    {
        return binder;
    }

    public void onCreate()
    {
        m_umqCommunicationService = new SteamUmqCommunicationService(this);
        if (m_steamDebugUtil instanceof SteamDebugUtil)
        {
            ((SteamDebugUtil)m_steamDebugUtil).SetServiceContext(this);
        }
        SteamCommunityApplication.m_CrashHandler.m_dbgUtil = m_steamDebugUtil;
        SteamCommunityApplication.m_CrashHandler.register();
        C2DMProcessor.refreshAppC2DMRegistrationState(getApplicationContext());
    }

    public int onStartCommand(Intent intent, int i, int j)
    {
        return 1;
    }


}
