// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;

import android.net.Uri;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Properties;
import org.json.JSONArray;
import org.json.JSONObject;

public class SteamUriHandler
{
    public static final class Command extends Enum
    {

        private static final Command $VALUES[];
        public static final Command agecheck;
        public static final Command agecheckfailed;
        public static final Command application_internal;
        public static final Command chat;
        public static final Command closethis;
        public static final Command errorrecovery;
        public static final Command login;
        public static final Command mobileloginsucceeded;
        public static final Command notfound;
        public static final Command opencategoryurl;
        public static final Command openexternalurl;
        public static final Command openurl;
        public static final Command reloadpage;
        public static final Command settitle;

        public static Command valueOf(String s)
        {
            return (Command)Enum.valueOf(com/valvesoftware/android/steam/community/SteamUriHandler$Command, s);
        }

        public static Command[] values()
        {
            return (Command[])$VALUES.clone();
        }

        static 
        {
            openurl = new Command("openurl", 0);
            settitle = new Command("settitle", 1);
            login = new Command("login", 2);
            closethis = new Command("closethis", 3);
            notfound = new Command("notfound", 4);
            agecheck = new Command("agecheck", 5);
            agecheckfailed = new Command("agecheckfailed", 6);
            opencategoryurl = new Command("opencategoryurl", 7);
            errorrecovery = new Command("errorrecovery", 8);
            reloadpage = new Command("reloadpage", 9);
            chat = new Command("chat", 10);
            openexternalurl = new Command("openexternalurl", 11);
            mobileloginsucceeded = new Command("mobileloginsucceeded", 12);
            application_internal = new Command("application_internal", 13);
            Command acommand[] = new Command[14];
            acommand[0] = openurl;
            acommand[1] = settitle;
            acommand[2] = login;
            acommand[3] = closethis;
            acommand[4] = notfound;
            acommand[5] = agecheck;
            acommand[6] = agecheckfailed;
            acommand[7] = opencategoryurl;
            acommand[8] = errorrecovery;
            acommand[9] = reloadpage;
            acommand[10] = chat;
            acommand[11] = openexternalurl;
            acommand[12] = mobileloginsucceeded;
            acommand[13] = application_internal;
            $VALUES = acommand;
        }

        private Command(String s, int i)
        {
            super(s, i);
        }
    }

    public static final class CommandProperty extends Enum
    {

        private static final CommandProperty $VALUES[];
        public static final CommandProperty call;
        public static final CommandProperty oauth_token;
        public static final CommandProperty steamid;
        public static final CommandProperty title;
        public static final CommandProperty url;
        public static final CommandProperty webcookie;

        public static CommandProperty valueOf(String s)
        {
            return (CommandProperty)Enum.valueOf(com/valvesoftware/android/steam/community/SteamUriHandler$CommandProperty, s);
        }

        public static CommandProperty[] values()
        {
            return (CommandProperty[])$VALUES.clone();
        }

        static 
        {
            url = new CommandProperty("url", 0);
            call = new CommandProperty("call", 1);
            title = new CommandProperty("title", 2);
            steamid = new CommandProperty("steamid", 3);
            oauth_token = new CommandProperty("oauth_token", 4);
            webcookie = new CommandProperty("webcookie", 5);
            CommandProperty acommandproperty[] = new CommandProperty[6];
            acommandproperty[0] = url;
            acommandproperty[1] = call;
            acommandproperty[2] = title;
            acommandproperty[3] = steamid;
            acommandproperty[4] = oauth_token;
            acommandproperty[5] = webcookie;
            $VALUES = acommandproperty;
        }

        private CommandProperty(String s, int i)
        {
            super(s, i);
        }
    }

    public static class Result
    {

        public Command command;
        public boolean handled;
        public Properties props;

        public String getProperty(CommandProperty commandproperty)
        {
            return props.getProperty(commandproperty.toString());
        }

        public String getProperty(CommandProperty commandproperty, String s)
        {
            return props.getProperty(commandproperty.toString(), s);
        }

        public Result()
        {
            handled = false;
        }
    }


    public static final String MOBILE_PROTOCOL = "steammobile://";
    public static final String TAG = "SteamUriHandler";

    public SteamUriHandler()
    {
    }

    public static Result HandleSteamURI(Uri uri)
    {
        String s;
        String s1;
        Result result;
        s = uri.toString();
        s1 = uri.getEncodedQuery();
        result = new Result();
        if (!s.startsWith("steammobile://"))
        {
            break MISSING_BLOCK_LABEL_76;
        }
        String s4;
        int k;
        s4 = s.substring("steammobile://".length());
        k = s4.indexOf("?");
        if (k <= 0)
        {
            break MISSING_BLOCK_LABEL_62;
        }
        s4 = s4.substring(0, k);
        result.command = Command.valueOf(s4);
        result.handled = true;
_L9:
        if (!result.handled) goto _L2; else goto _L1
_L1:
        Command command;
        Command command1;
        JSONObject jsonobject;
        JSONArray jsonarray;
        int i;
        int j;
        try
        {
            result.props = new Properties();
        }
        catch (IOException ioexception)
        {
            return result;
        }
        if (s1 == null) goto _L2; else goto _L3
_L3:
        command = result.command;
        command1 = Command.mobileloginsucceeded;
        if (command != command1) goto _L5; else goto _L4
_L4:
        jsonobject = new JSONObject(Uri.decode(s1));
        jsonarray = jsonobject.names();
        i = 0;
_L6:
        j = jsonarray.length();
        if (i >= j)
        {
            break; /* Loop/switch isn't completed */
        }
        String s2 = (String)jsonarray.opt(i);
        String s3 = jsonobject.get(s2).toString();
        result.props.put(s2, s3);
_L7:
        i++;
        if (true) goto _L6; else goto _L2
_L5:
        result.props.load(new ByteArrayInputStream(s1.getBytes()));
_L2:
        return result;
        Exception exception;
        exception;
        return result;
        Exception exception1;
        exception1;
          goto _L7
        RuntimeException runtimeexception;
        runtimeexception;
        if (true) goto _L9; else goto _L8
_L8:
    }
}
