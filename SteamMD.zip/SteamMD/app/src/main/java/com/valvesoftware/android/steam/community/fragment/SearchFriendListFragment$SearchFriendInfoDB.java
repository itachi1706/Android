// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.fragment;

import android.net.Uri;
import com.valvesoftware.android.steam.community.FriendInfo;
import com.valvesoftware.android.steam.community.FriendInfoDB;
import com.valvesoftware.android.steam.community.SteamWebApi;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

// Referenced classes of package com.valvesoftware.android.steam.community.fragment:
//            SearchFriendListFragment

public class this._cls0 extends FriendInfoDB
{

    final SearchFriendListFragment this$0;

    protected void HandleListRefreshDocument(com.valvesoftware.android.steam.community.ndInfoDB ndinfodb, boolean flag)
    {
        ArrayList arraylist;
        JSONObject jsonobject = ndinfodb.ndInfoDB();
        if (jsonobject == null)
        {
            return;
        }
        JSONArray jsonarray;
        int i;
        int j;
        String s;
        FriendInfo friendinfo;
        try
        {
            jsonarray = jsonobject.getJSONArray("results");
            m_queryTotalResults = jsonobject.optInt("total");
            m_queryActualResults = jsonobject.optInt("count");
        }
        catch (JSONException jsonexception)
        {
            return;
        }
        i = jsonarray.length();
        arraylist = new ArrayList();
        m_searchResultsOrderMap.clear();
        j = 0;
        if (j >= i)
        {
            break; /* Loop/switch isn't completed */
        }
        s = jsonarray.getJSONObject(j).getString("steamid");
        arraylist.add(s);
        friendinfo = GetOrAllocateNewFriendInfo(s);
        friendinfo.m_relationship = com.valvesoftware.android.steam.community.ndInfoDB.GetOrAllocateNewFriendInfo;
        m_searchResultsOrderMap.put(friendinfo.m_steamID, Integer.valueOf(j));
_L4:
        j++;
        if (true) goto _L2; else goto _L1
_L1:
        break; /* Loop/switch isn't completed */
_L2:
        break MISSING_BLOCK_LABEL_73;
        Exception exception;
        exception;
        if (true) goto _L4; else goto _L3
_L3:
        String as[] = new String[arraylist.size()];
        arraylist.toArray(as);
        IssueItemSummaryRequest(as, flag);
        refreshListView();
        return;
    }

    protected com.valvesoftware.android.steam.community.ndInfoDB IssueFullListRefreshRequest(boolean flag)
    {
        com.valvesoftware.android.steam.community.ndInfoDB ndinfodb = new com.valvesoftware.android.steam.community.ndInfoDB("JobQueueFriendsDB");
        String s = SteamWebApi.GetLoginAccessToken();
        String s1 = Uri.encode(m_queryText);
        int i = 32 + SearchFriendListFragment.access$000().length();
        int j;
        StringBuilder stringbuilder;
        if (s != null)
        {
            j = s.length();
        } else
        {
            j = 0;
        }
        stringbuilder = new StringBuilder(128 + (32 + (j + i) + s1.length()));
        stringbuilder.append(SearchFriendListFragment.access$000());
        stringbuilder.append("?access_token=");
        stringbuilder.append(s);
        stringbuilder.append("&keywords=");
        stringbuilder.append(s1);
        stringbuilder.append("&offset=");
        stringbuilder.append(m_queryOffset);
        stringbuilder.append("&count=");
        stringbuilder.append(m_queryPageSize);
        stringbuilder.append("&targets=users&fields=all");
        ndinfodb.e(stringbuilder.toString(), com.valvesoftware.android.steam.community.e);
        ndinfodb.e(com.valvesoftware.android.steam.community.oCache);
        return ndinfodb;
    }

    public void SetAutoRefreshIfDataMightBeStale(boolean flag)
    {
    }

    public ()
    {
        this$0 = SearchFriendListFragment.this;
        super();
    }
}
