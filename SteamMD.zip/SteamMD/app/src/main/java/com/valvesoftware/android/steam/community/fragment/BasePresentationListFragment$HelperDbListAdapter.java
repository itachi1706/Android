// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.fragment;

import android.widget.ArrayAdapter;
import android.widget.ListView;
import com.valvesoftware.android.steam.community.GenericListDB;
import java.util.ArrayList;

// Referenced classes of package com.valvesoftware.android.steam.community.fragment:
//            BasePresentationListFragment

protected class this._cls0 extends ArrayAdapter
{

    final BasePresentationListFragment this$0;

    public void RequestVisibleAvatars()
    {
        RequestVisibleAvatars(false);
    }

    public void RequestVisibleAvatars(boolean flag)
    {
        if (getListAdapter() != this)
        {
            return;
        }
        int i = getListView().getFirstVisiblePosition();
        int j = getListView().getLastVisiblePosition();
        com.valvesoftware.android.steam.community.tAdapter atadapter[] = null;
        if (j >= i)
        {
            atadapter = null;
            if (i >= 0)
            {
                int k = 1 + (j - i);
                atadapter = new com.valvesoftware.android.steam.community.[k];
                for (int l = 0; l < k; l++)
                {
                    if (m_presentationArray.size() > i + l)
                    {
                        atadapter[l] = (com.valvesoftware.android.steam.community.ionArray)m_presentationArray.get(i + l);
                    }
                    if (atadapter[l] == null || atadapter[l].())
                    {
                        atadapter[l] = null;
                    }
                }

            }
        }
        myListDb().RequestAvatarImage(atadapter);
    }

    public void notifyDataSetChanged()
    {
        super.notifyDataSetChanged();
        RequestVisibleAvatars(true);
    }

    public i(int i)
    {
        this$0 = BasePresentationListFragment.this;
        super(getActivity(), i, m_presentationArray);
    }
}
