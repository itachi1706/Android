// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;

import android.content.Context;
import android.content.SharedPreferences;

// Referenced classes of package com.valvesoftware.android.steam.community:
//            SteamWebApi, SettingInfo

public static class m_editor
{

    private boolean m_bCookiesMarkedForSync;
    private android.content. m_editor;

    public void commit()
    {
        if (m_bCookiesMarkedForSync)
        {
            SteamWebApi.SyncAllCookies();
            m_bCookiesMarkedForSync = false;
        }
        if (m_editor != null)
        {
            m_editor.commit();
        }
    }

    public void markCookiesForSync()
    {
        m_bCookiesMarkedForSync = true;
    }

    public void setValue(SettingInfo settinginfo, String s)
    {
        if (m_editor != null)
        {
            m_editor.putString(settinginfo.m_key, s);
        }
        if (settinginfo.m_pUpdateListener != null)
        {
            settinginfo.m_pUpdateListener.OnSettingInfoValueUpdate(settinginfo, s, this);
        }
    }

    public er(Context context)
    {
        m_editor = null;
        m_bCookiesMarkedForSync = false;
        String s = SteamWebApi.GetLoginSteamID();
        if (s != null && !s.equals(""))
        {
            m_editor = context.getSharedPreferences((new StringBuilder()).append("steam.settings.").append(s).toString(), 0).edit();
        }
    }
}
