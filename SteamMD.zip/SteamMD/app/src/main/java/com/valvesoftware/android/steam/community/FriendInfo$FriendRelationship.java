// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;


// Referenced classes of package com.valvesoftware.android.steam.community:
//            FriendInfo

public static final class  extends Enum
{

    private static final .VALUES $VALUES[];
    public static final .VALUES blocked;
    public static final .VALUES friend;
    public static final .VALUES ignored;
    public static final .VALUES ignoredfriend;
    public static final .VALUES myself;
    public static final .VALUES none;
    public static final .VALUES requestinitiator;
    public static final .VALUES requestrecipient;
    public static final .VALUES suggested;

    public static  valueOf(String s)
    {
        return ()Enum.valueOf(com/valvesoftware/android/steam/community/FriendInfo$FriendRelationship, s);
    }

    public static [] values()
    {
        return ([])$VALUES.clone();
    }

    static 
    {
        none = new <init>("none", 0);
        myself = new <init>("myself", 1);
        friend = new <init>("friend", 2);
        blocked = new <init>("blocked", 3);
        requestrecipient = new <init>("requestrecipient", 4);
        requestinitiator = new <init>("requestinitiator", 5);
        ignored = new <init>("ignored", 6);
        ignoredfriend = new <init>("ignoredfriend", 7);
        suggested = new <init>("suggested", 8);
        p_3B_.clone aclone[] = new <init>[9];
        aclone[0] = none;
        aclone[1] = myself;
        aclone[2] = friend;
        aclone[3] = blocked;
        aclone[4] = requestrecipient;
        aclone[5] = requestinitiator;
        aclone[6] = ignored;
        aclone[7] = ignoredfriend;
        aclone[8] = suggested;
        $VALUES = aclone;
    }

    private (String s, int i)
    {
        super(s, i);
    }
}
