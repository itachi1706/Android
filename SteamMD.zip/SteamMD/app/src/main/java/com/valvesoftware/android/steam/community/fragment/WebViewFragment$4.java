// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.fragment;

import android.content.Intent;
import android.net.Uri;
import android.support.v4.app.FragmentActivity;
import com.valvesoftware.android.steam.community.activity.SteamMobileUriActivity;

// Referenced classes of package com.valvesoftware.android.steam.community.fragment:
//            WebViewFragment

class val.uriSearch
    implements itlebarButtonHander
{

    final WebViewFragment this$0;
    final Uri val$uriSearch;

    public void onTitlebarButtonClicked(int i)
    {
        getActivity().startActivity((new Intent()).addFlags(0x18000000).setClass(getActivity(), com/valvesoftware/android/steam/community/activity/SteamMobileUriActivity).setAction("android.intent.action.VIEW").putExtra("title_resid", 0x7f070004).setData(val$uriSearch));
    }

    vity()
    {
        this$0 = final_webviewfragment;
        val$uriSearch = Uri.this;
        super();
    }
}
