// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.fragment;

import android.content.Intent;
import android.net.Uri;
import android.support.v4.app.FragmentActivity;
import android.view.View;
import android.widget.TextView;
import com.valvesoftware.android.steam.community.Config;
import com.valvesoftware.android.steam.community.GroupInfo;
import com.valvesoftware.android.steam.community.GroupInfoDB;
import com.valvesoftware.android.steam.community.activity.SearchGroupsActivity;
import com.valvesoftware.android.steam.community.activity.SteamMobileUriActivity;

// Referenced classes of package com.valvesoftware.android.steam.community.fragment:
//            GroupListFragment

class this._cls0
    implements android.view.
{

    final GroupListFragment this$0;

    public void onClick(View view)
    {
        TextView textview = (TextView)view.findViewById(0x7f090018);
        String s = "0";
        if (textview != null)
        {
            s = textview.getText().toString();
        }
        if (s.equals("0"))
        {
            Intent intent1 = (new Intent()).setClass(getActivity(), com/valvesoftware/android/steam/community/activity/SearchGroupsActivity).addFlags(0x20000000).addFlags(0x10000000).setData(Uri.parse((new StringBuilder()).append("searchgroup://").append(System.currentTimeMillis()).append(getSearchModeText()).toString())).putExtra("query", getSearchModeText());
            getActivity().startActivity(intent1);
        } else
        {
            GroupInfo groupinfo = ((GroupInfoDB)myListDb()).GetGroupInfo(Long.valueOf(s));
            if (groupinfo != null)
            {
                Intent intent = (new Intent()).addFlags(0x18000000).setClass(getActivity(), com/valvesoftware/android/steam/community/activity/SteamMobileUriActivity).setData(Uri.parse((new StringBuilder()).append("steammobile://").append(com.valvesoftware.android.steam.community.and.openurl).append("?url=").append(Config.URL_COMMUNITY_BASE).append(groupinfo.m_profileURL).toString())).setAction("android.intent.action.VIEW");
                getActivity().startActivity(intent);
                return;
            }
        }
    }

    ty()
    {
        this$0 = GroupListFragment.this;
        super();
    }
}
