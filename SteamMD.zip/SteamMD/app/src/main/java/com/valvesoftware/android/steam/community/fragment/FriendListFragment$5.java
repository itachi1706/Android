// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.fragment;

import com.valvesoftware.android.steam.community.FriendInfo;
import java.util.Comparator;

// Referenced classes of package com.valvesoftware.android.steam.community.fragment:
//            FriendListFragment

class this._cls0
    implements Comparator
{

    static final boolean $assertionsDisabled;
    final FriendListFragment this$0;

    public int compare(FriendInfo friendinfo, FriendInfo friendinfo1)
    {
        if (friendinfo.m_categoryInList == friendinfo1.m_categoryInList) goto _L2; else goto _L1
_L1:
        if (friendinfo.m_categoryInList.ordinal() >= friendinfo1.m_categoryInList.ordinal()) goto _L4; else goto _L3
_L3:
        return -1;
_L4:
        return 1;
_L2:
        switch (.SwitchMap.com.valvesoftware.android.steam.community.FriendInfo.PersonaStateCategoryInList[friendinfo.m_categoryInList.ordinal()])
        {
        default:
            return friendinfo.m_personaName.compareToIgnoreCase(friendinfo1.m_personaName);

        case 1: // '\001'
            break;
        }
        if (!$assertionsDisabled && friendinfo.m_chatInfo.latestMsgId == friendinfo1.m_chatInfo.latestMsgId)
        {
            throw new AssertionError();
        }
        if (friendinfo.m_chatInfo.latestMsgId <= friendinfo1.m_chatInfo.latestMsgId)
        {
            return 1;
        }
        if (true) goto _L3; else goto _L5
_L5:
    }

    public volatile int compare(Object obj, Object obj1)
    {
        return compare((FriendInfo)obj, (FriendInfo)obj1);
    }

    static 
    {
        boolean flag;
        if (!com/valvesoftware/android/steam/community/fragment/FriendListFragment.desiredAssertionStatus())
        {
            flag = true;
        } else
        {
            flag = false;
        }
        $assertionsDisabled = flag;
    }

    .UserConversationInfo()
    {
        this$0 = FriendListFragment.this;
        super();
    }
}
