// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;


// Referenced classes of package com.valvesoftware.android.steam.community:
//            SteamWebApi

public static class LogOut
{

    public String m_accessToken;
    public m_accessToken m_loginState;
    public String m_steamID;

    void LogOut()
    {
        m_loginState = eUsernameAndPassword;
        m_steamID = null;
        m_accessToken = null;
    }

    public ()
    {
        LogOut();
    }
}
