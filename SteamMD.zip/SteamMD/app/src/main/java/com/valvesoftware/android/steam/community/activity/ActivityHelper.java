// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.activity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.widget.ToggleButton;
import com.valvesoftware.android.steam.community.SteamCommunityApplication;
import com.valvesoftware.android.steam.community.SteamDBResponseListener;
import com.valvesoftware.android.steam.community.SteamWebApi;
import com.valvesoftware.android.steam.community.fragment.NavigationFragment;
import com.valvesoftware.android.steam.community.fragment.TitlebarFragment;
import java.lang.ref.WeakReference;
import java.util.ArrayList;

// Referenced classes of package com.valvesoftware.android.steam.community.activity:
//            LoginActivity

public class ActivityHelper
{
    class SteamDBCallback extends BroadcastReceiver
    {

        final ActivityHelper this$0;

        public void onReceive(Context context, Intent intent)
        {
            ((SteamDBResponseListener)m_owner).OnRequestCompleted(Integer.valueOf(intent.getIntExtra("intent_id", -1)));
        }

        SteamDBCallback()
        {
            this$0 = ActivityHelper.this;
            super();
        }
    }


    private static AlertDialog m_commErrorDlg = null;
    private final SteamDBCallback m_intentReceiver;
    private Activity m_owner;

    private ActivityHelper()
    {
        m_intentReceiver = new SteamDBCallback();
        m_owner = null;
    }

    ActivityHelper(Activity activity)
    {
        m_intentReceiver = new SteamDBCallback();
        m_owner = null;
        m_owner = activity;
    }

    public static void DisplayCommunicationErrorMsg(Context context)
    {
        if (m_commErrorDlg == null)
        {
            android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(context);
            builder.setMessage(0x7f07002d);
            builder.setIcon(0x1080027);
            m_commErrorDlg = builder.create();
        }
        if (!m_commErrorDlg.isShowing())
        {
            m_commErrorDlg.show();
        }
    }

    public static Fragment GetFragmentForActivityById(Activity activity, int i)
    {
        FragmentManager fragmentmanager;
        if (activity instanceof FragmentActivity)
        {
            if ((fragmentmanager = ((FragmentActivity)activity).getSupportFragmentManager()) != null)
            {
                return fragmentmanager.findFragmentById(i);
            }
        }
        return null;
    }

    public static NavigationFragment GetNavigationFragmentForActivity(Activity activity)
    {
        Fragment fragment = GetFragmentForActivityById(activity, 0x7f090004);
        if (fragment == null)
        {
            return null;
        }
        if (!(fragment instanceof NavigationFragment))
        {
            return null;
        } else
        {
            return (NavigationFragment)fragment;
        }
    }

    public static TitlebarFragment GetTitlebarFragmentForActivity(Activity activity)
    {
        Fragment fragment = GetFragmentForActivityById(activity, 0x7f090001);
        if (fragment == null)
        {
            return null;
        }
        if (!(fragment instanceof TitlebarFragment))
        {
            return null;
        } else
        {
            return (TitlebarFragment)fragment;
        }
    }

    public static void PresentLoginActivity(Activity activity, LoginActivity.LoginAction loginaction)
    {
        PresentLoginActivity(activity, loginaction, null);
    }

    public static void PresentLoginActivity(Activity activity, LoginActivity.LoginAction loginaction, LoginActivity.LoginChangedListener loginchangedlistener)
    {
        Intent intent;
label0:
        {
            if (loginaction == LoginActivity.LoginAction.LOGOUT)
            {
                SteamWebApi.LogOut();
            }
            if (!SteamWebApi.IsLoggedIn() || loginaction == LoginActivity.LoginAction.LOGIN_EVEN_IF_LOGGED_IN)
            {
                intent = new Intent();
                Object obj;
                if (activity != null)
                {
                    obj = activity;
                } else
                {
                    obj = SteamCommunityApplication.GetInstance().getApplicationContext();
                }
                intent.setClass(((Context) (obj)), com/valvesoftware/android/steam/community/activity/LoginActivity);
                intent.setAction("android.intent.action.VIEW");
                intent.setData(LoginActivity.URI_LoginPage);
                intent.putExtra("eLoginAction", loginaction.toString());
                LoginActivity.m_callBacksBeforeCreate.add(new WeakReference(loginchangedlistener));
                if (activity == null)
                {
                    break label0;
                }
                activity.startActivityForResult(intent, 0);
            }
            return;
        }
        SteamCommunityApplication.GetInstance().getApplicationContext().startActivity(intent.addFlags(0x10000000));
    }

    public static void UpdateToggleButtonStyles(ToggleButton togglebutton)
    {
        int i = 0x7f060020;
        int j = 0x7f060022;
        boolean flag = togglebutton.isChecked();
        int k = 0;
        if (flag)
        {
            i = 0x7f06001f;
            j = 0x7f060021;
            k = 1;
        }
        togglebutton.setTextColor(SteamCommunityApplication.GetInstance().getResources().getColor(i));
        togglebutton.setBackgroundColor(SteamCommunityApplication.GetInstance().getResources().getColor(j));
        togglebutton.setTypeface(null, k);
    }

    public boolean SubmitRequest(com.valvesoftware.android.steam.community.SteamWebApi.RequestBase requestbase)
    {
        requestbase.SetCallerIntent(TAG());
        SteamCommunityApplication.GetInstance().SubmitSteamDBRequest(requestbase);
        return true;
    }

    protected final String TAG()
    {
        return m_owner.getClass().getName();
    }

    public void onCreate(Bundle bundle)
    {
        m_owner.registerReceiver(m_intentReceiver, new IntentFilter(TAG()));
    }

    protected void onDestroy()
    {
        m_owner.unregisterReceiver(m_intentReceiver);
    }


}
