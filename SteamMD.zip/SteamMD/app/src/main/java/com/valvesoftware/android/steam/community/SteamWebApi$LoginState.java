// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;


// Referenced classes of package com.valvesoftware.android.steam.community:
//            SteamWebApi

public static final class  extends Enum
{

    private static final .VALUES $VALUES[];
    public static final .VALUES LoggedIn;
    public static final .VALUES RequireSteamGuardEmailToken;
    public static final .VALUES RequireUsernameAndPassword;

    public static  valueOf(String s)
    {
        return ()Enum.valueOf(com/valvesoftware/android/steam/community/SteamWebApi$LoginState, s);
    }

    public static [] values()
    {
        return ([])$VALUES.clone();
    }

    static 
    {
        RequireUsernameAndPassword = new <init>("RequireUsernameAndPassword", 0);
        RequireSteamGuardEmailToken = new <init>("RequireSteamGuardEmailToken", 1);
        LoggedIn = new <init>("LoggedIn", 2);
        e_3B_.clone aclone[] = new <init>[3];
        aclone[0] = RequireUsernameAndPassword;
        aclone[1] = RequireSteamGuardEmailToken;
        aclone[2] = LoggedIn;
        $VALUES = aclone;
    }

    private (String s, int i)
    {
        super(s, i);
    }
}
