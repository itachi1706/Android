// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;


// Referenced classes of package com.valvesoftware.android.steam.community:
//            SteamDBService

public static class tate.RequestError
{

    public static final int RESULT_HTTP_EXCEPTION = 2;
    public static final int RESULT_INVALID_CONTENT = 1;
    public int m_httpResult;
    private byte m_resultByteData[];
    private String m_resultDocument;
    public tate m_state;

    public byte[] GetByteData()
    {
        if (m_resultByteData == null && m_resultDocument != null)
        {
            m_resultByteData = m_resultDocument.getBytes();
        }
        return m_resultByteData;
    }

    public String GetDocument()
    {
        if (m_resultDocument == null && m_resultByteData != null)
        {
            m_resultDocument = new String(m_resultByteData);
        }
        return m_resultDocument;
    }

    public State GetRequestCacheState()
    {
        if (m_state == tate.RequestIsLive)
        {
            return State.CacheIsLive;
        }
        if (m_resultDocument != null || m_resultByteData != null)
        {
            return State.CacheIsStale;
        } else
        {
            return State.CacheIsMissing;
        }
    }

    public boolean IsRequestLive()
    {
        return m_state == tate.RequestIsLive;
    }

    public void SetRequestError(int i)
    {
        m_state = tate.RequestError;
        m_httpResult = i;
    }

    public void SetRequestIsLive(String s)
    {
        m_state = tate.RequestIsLive;
        m_httpResult = 200;
        m_resultDocument = s;
        m_resultByteData = null;
    }

    public void SetRequestIsLive(byte abyte0[])
    {
        m_state = tate.RequestIsLive;
        m_httpResult = 200;
        m_resultDocument = null;
        m_resultByteData = abyte0;
    }

    public State()
    {
        m_state = tate.RequestError;
    }
}
