// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.fragment;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.view.View;
import android.widget.DatePicker;
import android.widget.TextView;
import com.valvesoftware.android.steam.community.SettingInfo;
import java.util.Calendar;

// Referenced classes of package com.valvesoftware.android.steam.community.fragment:
//            SettingsFragment

class this._cls2
    implements android.app.ttingsFragment.SettingsListAdapter._cls5._cls1
{

    final ._cls0 this$2;

    public void onDateSet(DatePicker datepicker, int i, int j, int k)
    {
        myDOB.set(i, j, k);
        String s = com.valvesoftware.android.steam.community.pter._cls5.val.myDOB(i, j, k);
        if (s != null && !s.equals(""))
        {
            valueView.setText(com.valvesoftware.android.steam.community.pter._cls5.val.valueView(s));
        }
        settingInfo.setValueAndCommit(SettingsFragment.access$400(_fld0).getApplicationContext(), s);
    }

    l.settingInfo()
    {
        this$2 = this._cls2.this;
        super();
    }

    // Unreferenced inner class com/valvesoftware/android/steam/community/fragment/SettingsFragment$SettingsListAdapter$5

/* anonymous class */
    class SettingsFragment.SettingsListAdapter._cls5
        implements android.view.View.OnClickListener
    {

        final SettingsFragment.SettingsListAdapter this$1;
        final Calendar val$myDOB;
        final SettingInfo val$settingInfo;
        final TextView val$valueView;

        public void onClick(View view)
        {
            (new com.valvesoftware.android.steam.community.SettingInfo.CustomDatePickerDialog(SettingsFragment.access$400(this$0), new SettingsFragment.SettingsListAdapter._cls5._cls1(), myDOB, 0x7f07004f)).show();
        }

            
            {
                this$1 = final_settingslistadapter;
                myDOB = calendar;
                valueView = textview;
                settingInfo = SettingInfo.this;
                super();
            }
    }

}
