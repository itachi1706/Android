// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;

import android.app.Notification;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import java.io.IOException;

// Referenced classes of package com.valvesoftware.android.steam.community:
//            C2DMReceiverService, SteamCommunityApplication, SettingInfoDB, C2DMessaging, 
//            SteamWebApi, SteamDBService

public class C2DMProcessor extends C2DMReceiverService
{

    static final String C2DM_EXTRA_MSG_IM_ACTION = "a";
    static final String C2DM_EXTRA_MSG_IM_ID = "id";
    static final String C2DM_EXTRA_MSG_IM_TEXT = "s2";
    static final String C2DM_EXTRA_MSG_IM_TITLE = "s1";
    static final String C2DM_EXTRA_MSG_TYPE = "type";
    static final String C2DM_NOTIFICATION_IM = "im";
    static final String C2DM_SENDER = "valvesoftwaresteampowered@gmail.com";
    public static final String INTENT_C2DM_REGISTRATION_READY = "com.valvesoftware.android.steam.community.INTENT_C2DM_REGISTRATION_READY";
    public static final String INTENT_C2DM_REGISTRATION_READY_EXTRA_ID = "registration.id";
    static final String PREFERENCE = "com.valvesoftware.android.steam.community.c2dm";
    static final String STORED_IM_ID = "im_id";

    public C2DMProcessor()
    {
        super("valvesoftwaresteampowered@gmail.com");
    }

    public static int getIMID(Context context)
    {
        return context.getSharedPreferences("com.valvesoftware.android.steam.community.c2dm", 0).getInt("im_id", 0);
    }

    private void onServerPushNotification(Context context, SteamCommunityApplication.UriNotification urinotification)
    {
        NotificationManager notificationmanager;
        Notification notification;
        String s;
        String s1;
        try
        {
            notificationmanager = (NotificationManager)context.getSystemService("notification");
        }
        catch (Exception exception)
        {
            return;
        }
        if (notificationmanager == null)
        {
            break MISSING_BLOCK_LABEL_125;
        }
        notification = new Notification(urinotification.actionDrawable, urinotification.text, System.currentTimeMillis());
        notification.flags = 0x10 | notification.flags;
        SteamCommunityApplication.GetInstance().GetSettingInfoDB().configureNotificationObject(notification, true);
        s = urinotification.title;
        if (s != null)
        {
            break MISSING_BLOCK_LABEL_83;
        }
        s = context.getText(0x7f070038).toString();
        s1 = urinotification.text;
        if (s1 == null)
        {
            s1 = "";
        }
        notification.setLatestEventInfo(context, s, s1, urinotification.actionPendingIntent);
        notificationmanager.notify("URINOTIFICATION", urinotification.id, notification);
    }

    public static void refreshAppC2DMRegistrationState(Context context)
    {
label0:
        {
            boolean flag;
            if (!C2DMessaging.getRegistrationId(context).equals(""))
            {
                flag = true;
            } else
            {
                flag = false;
            }
            if (!flag)
            {
                if (false)
                {
                    break label0;
                }
                C2DMessaging.register(context, "valvesoftwaresteampowered@gmail.com");
            }
            return;
        }
        C2DMessaging.unregister(context);
    }

    public void onError(Context context, String s)
    {
    }

    protected void onMessage(Context context, Intent intent)
    {
        if (!"im".equals(intent.getExtras().getString("type"))) goto _L2; else goto _L1
_L1:
        SteamCommunityApplication.UriNotification urinotification = new SteamCommunityApplication.UriNotification();
        String s1 = intent.getStringExtra("id");
        if (s1 == null) goto _L4; else goto _L3
_L3:
        int k = Integer.valueOf(s1).intValue();
_L7:
        urinotification.id = k;
_L11:
        int i;
        urinotification.title = intent.getStringExtra("s1");
        urinotification.text = intent.getStringExtra("s2");
        i = 0;
_L10:
        String s = intent.getStringExtra((new StringBuilder()).append("a").append(i).toString());
        if (s != null) goto _L6; else goto _L5
_L5:
        urinotification.setDefaultActionInfo();
_L9:
        if (urinotification.id > 0 && urinotification.text != null)
        {
            SharedPreferences sharedpreferences = context.getSharedPreferences("com.valvesoftware.android.steam.community.c2dm", 0);
            int j = sharedpreferences.getInt("im_id", 0);
            if (urinotification.id > j)
            {
                onServerPushNotification(context, urinotification);
                android.content.SharedPreferences.Editor editor = sharedpreferences.edit();
                editor.putInt("im_id", urinotification.id);
                editor.commit();
            }
        }
_L2:
        SteamWebApi.SubmitSimpleActionRequest("UmqActivity", new SteamDBService.REQ_ACT_UMQACTIVITY_DATA());
        return;
_L4:
        k = 0;
          goto _L7
_L6:
        if (urinotification.setActionInfo(s)) goto _L9; else goto _L8
_L8:
        i++;
          goto _L10
        Exception exception;
        exception;
          goto _L11
    }

    public void onRegistered(Context context, String s)
        throws IOException
    {
        Intent intent = new Intent("com.valvesoftware.android.steam.community.INTENT_C2DM_REGISTRATION_READY");
        intent.putExtra("registration.id", s);
        SteamCommunityApplication steamcommunityapplication = SteamCommunityApplication.GetInstance();
        if (steamcommunityapplication != null)
        {
            SteamDBService steamdbservice = steamcommunityapplication.GetSteamDB();
            if (steamdbservice != null)
            {
                steamdbservice.sendBroadcast(intent);
            }
        }
    }
}
