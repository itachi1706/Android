// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;


// Referenced classes of package com.valvesoftware.android.steam.community:
//            GenericListDB

public class SetUriAndDocumentType extends SetUriAndDocumentType
{

    private GenericListDB m_db;
    private String m_sOriginalRequestURI;
    final this._cls0 this$0;

    private void SubmitNextRequest()
    {
        if (m_db != null)
        {
            GenericListDB.access$100(m_db);
        }
    }

    public void RequestFailedOnResponseWorkerThread()
    {
        SubmitNextRequest();
    }

    public void RequestSucceededOnResponseWorkerThread()
    {
        SubmitNextRequest();
    }

    SubmitNextRequest getItem()
    {
        return this._cls0.this;
    }


    public (String s, GenericListDB genericlistdb, String s1)
    {
        this$0 = this._cls0.this;
        super(s);
        m_db = genericlistdb;
        m_sOriginalRequestURI = s1;
        SetRequestAction(questAndCacheResults);
        SetUriAndDocumentType(s1, SetUriAndDocumentType);
    }
}
