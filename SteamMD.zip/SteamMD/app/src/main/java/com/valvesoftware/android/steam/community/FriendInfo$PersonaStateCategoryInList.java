// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;


// Referenced classes of package com.valvesoftware.android.steam.community:
//            FriendInfo

public static final class  extends Enum
{

    private static final .VALUES $VALUES[];
    public static final .VALUES CHATS;
    public static final .VALUES INGAME;
    public static final .VALUES OFFLINE;
    public static final .VALUES ONLINE;
    public static final .VALUES REQUEST_INCOMING;
    public static final .VALUES REQUEST_SENT;
    public static final .VALUES SEARCH_ALL;

    public static  valueOf(String s)
    {
        return ()Enum.valueOf(com/valvesoftware/android/steam/community/FriendInfo$PersonaStateCategoryInList, s);
    }

    public static [] values()
    {
        return ([])$VALUES.clone();
    }

    public int GetDisplayString()
    {
        switch (are.android.steam.community.FriendInfo.PersonaStateCategoryInList[ordinal()])
        {
        default:
            return 0x7f070027;

        case 1: // '\001'
            return 0x7f07005e;

        case 2: // '\002'
            return 0x7f07005f;

        case 3: // '\003'
            return 0x7f070023;

        case 4: // '\004'
            return 0x7f070020;

        case 5: // '\005'
        case 6: // '\006'
            return 0x7f070021;

        case 7: // '\007'
            return 0x7f070004;
        }
    }

    static 
    {
        REQUEST_INCOMING = new <init>("REQUEST_INCOMING", 0);
        CHATS = new <init>("CHATS", 1);
        INGAME = new <init>("INGAME", 2);
        ONLINE = new <init>("ONLINE", 3);
        OFFLINE = new <init>("OFFLINE", 4);
        REQUEST_SENT = new <init>("REQUEST_SENT", 5);
        SEARCH_ALL = new <init>("SEARCH_ALL", 6);
        ordinal aordinal[] = new <init>[7];
        aordinal[0] = REQUEST_INCOMING;
        aordinal[1] = CHATS;
        aordinal[2] = INGAME;
        aordinal[3] = ONLINE;
        aordinal[4] = OFFLINE;
        aordinal[5] = REQUEST_SENT;
        aordinal[6] = SEARCH_ALL;
        $VALUES = aordinal;
    }

    private (String s, int i)
    {
        super(s, i);
    }
}
