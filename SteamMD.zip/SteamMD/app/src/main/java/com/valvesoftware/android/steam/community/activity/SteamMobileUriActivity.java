// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import com.valvesoftware.android.steam.community.SteamDBResponseListener;
import com.valvesoftware.android.steam.community.SteamUriHandler;
import com.valvesoftware.android.steam.community.SteamWebApi;
import com.valvesoftware.android.steam.community.fragment.WebViewFragment;
import java.util.ArrayList;
import org.apache.http.client.methods.HttpRequestBase;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

// Referenced classes of package com.valvesoftware.android.steam.community.activity:
//            FragmentActivityWithNavigationSupport, ActivityHelper, ChatActivity

public class SteamMobileUriActivity extends FragmentActivityWithNavigationSupport
    implements com.valvesoftware.android.steam.community.fragment.WebViewFragment.WebViewFragmentOwner, SteamDBResponseListener
{
    private static class CategoryRequest extends com.valvesoftware.android.steam.community.SteamWebApi.RequestBase
    {

        protected HttpRequestBase GetDefaultHttpRequestBase()
            throws Exception
        {
            HttpRequestBase httprequestbase = super.GetDefaultHttpRequestBase();
            String s = SteamWebApi.GetCookieHeaderString(false);
            if (s != null)
            {
                httprequestbase.addHeader("Cookie", s);
            }
            return httprequestbase;
        }

        public CategoryRequest(String s)
        {
            super(s);
        }
    }


    private static int s_NextActivityID = 0;
    private String m_CategoriesUrl;
    private ActivityHelper m_activityHelper;
    private ArrayList m_categoryList;
    private CategoryRequest m_reqTOC;
    protected int m_residActivityLayout;
    private String m_url;

    public SteamMobileUriActivity()
    {
        m_url = null;
        m_CategoriesUrl = null;
        m_categoryList = null;
        m_activityHelper = new ActivityHelper(this);
        m_residActivityLayout = 0x7f030018;
        m_reqTOC = null;
    }

    public static String GetNextActivityID()
    {
        StringBuilder stringbuilder = (new StringBuilder()).append("SteamMobileUriActivity_");
        int i = s_NextActivityID;
        s_NextActivityID = i + 1;
        return stringbuilder.append(i).toString();
    }

    private void HandleTOCDocument()
        throws JSONException
    {
        JSONObject jsonobject = m_reqTOC.GetJSONDocument();
        if (jsonobject.getBoolean("success")) goto _L2; else goto _L1
_L1:
        return;
_L2:
        String s;
        m_categoryList.clear();
        JSONArray jsonarray = jsonobject.getJSONArray("categories");
        int i;
        int j;
        if (jsonarray != null)
        {
            i = jsonarray.length();
        } else
        {
            i = 0;
        }
        for (j = 0; j < i; j++)
        {
            JSONObject jsonobject2 = jsonarray.getJSONObject(j);
            com.valvesoftware.android.steam.community.fragment.WebViewFragment.WebViewFragmentOwner.URLCategory urlcategory = new com.valvesoftware.android.steam.community.fragment.WebViewFragment.WebViewFragmentOwner.URLCategory();
            urlcategory.title = jsonobject2.getString("label");
            urlcategory.url = jsonobject2.getString("url");
            m_categoryList.add(urlcategory);
        }

        s = null;
        JSONArray jsonarray1;
        int k;
        JSONObject jsonobject1;
        String s1;
        String s2;
        try
        {
            jsonarray1 = jsonobject.getJSONArray("options");
        }
        catch (Exception exception)
        {
            break; /* Loop/switch isn't completed */
        }
        k = 0;
        if (k >= i)
        {
            break; /* Loop/switch isn't completed */
        }
        jsonobject1 = jsonarray1.getJSONObject(k);
        s1 = jsonobject1.optString("label");
        if (s1 == null)
        {
            break MISSING_BLOCK_LABEL_178;
        }
        if (!s1.equals("search"))
        {
            break MISSING_BLOCK_LABEL_178;
        }
        s2 = jsonobject1.optString("url");
        s = s2;
        k++;
        continue; /* Loop/switch isn't completed */
        if (true) goto _L4; else goto _L3
_L4:
        break MISSING_BLOCK_LABEL_126;
_L3:
        WebViewFragment webviewfragment = (WebViewFragment)getSupportFragmentManager().findFragmentById(0x7f090023);
        if (webviewfragment != null)
        {
            webviewfragment.setCategories(m_categoryList, s);
            return;
        }
        if (true) goto _L1; else goto _L5
_L5:
    }

    private void HandleTOCDocumentFailure()
    {
        ((WebViewFragment)getSupportFragmentManager().findFragmentById(0x7f090023)).setCategoriesFailed();
    }

    private void PerformCategoryUrlWebApiRequest()
    {
        m_reqTOC = new CategoryRequest("JobQueueCatalog");
        m_reqTOC.SetUriAndDocumentType(m_CategoriesUrl, com.valvesoftware.android.steam.community.SteamWebApi.RequestDocumentType.JSON);
        m_reqTOC.SetRequestAction(com.valvesoftware.android.steam.community.SteamWebApi.RequestActionType.DoHttpRequestNoCache);
        m_activityHelper.SubmitRequest(m_reqTOC);
    }

    public String GetRootURL()
    {
        return m_url;
    }

    public void OnRequestCompleted(Integer integer)
    {
        if (m_reqTOC != null && m_reqTOC.GetIntentId() == integer.intValue())
        {
            if (m_reqTOC.GetJSONDocument() != null)
            {
                try
                {
                    HandleTOCDocument();
                }
                catch (JSONException jsonexception)
                {
                    HandleTOCDocumentFailure();
                }
            } else
            {
                HandleTOCDocumentFailure();
            }
            m_reqTOC = null;
        }
    }

    public void ReloadPage()
    {
        Intent intent = getIntent();
        if ("android.intent.action.VIEW".equals(intent.getAction()))
        {
            com.valvesoftware.android.steam.community.SteamUriHandler.Result result = SteamUriHandler.HandleSteamURI(intent.getData());
            if (result.command == com.valvesoftware.android.steam.community.SteamUriHandler.Command.opencategoryurl)
            {
                PerformCategoryUrlWebApiRequest();
            } else
            if (result.command == com.valvesoftware.android.steam.community.SteamUriHandler.Command.openurl)
            {
                ((WebViewFragment)getSupportFragmentManager().findFragmentById(0x7f090023)).loadUrl(m_url);
                return;
            }
        }
    }

    public boolean isCategoriesUrl()
    {
        return m_CategoriesUrl != null;
    }

    protected void onActivityResult(int i, int j, Intent intent)
    {
        if (intent != null)
        {
            String s = intent.getStringExtra(com.valvesoftware.android.steam.community.SteamUriHandler.CommandProperty.call.toString());
            if (s != null && s.length() > 0)
            {
                ((WebViewFragment)getSupportFragmentManager().findFragmentById(0x7f090023)).loadUrl((new StringBuilder()).append("javascript:(function(){").append(s).append(";})()").toString());
                return;
            }
            String s1 = intent.getStringExtra(com.valvesoftware.android.steam.community.SteamUriHandler.CommandProperty.url.toString());
            if (s1 != null && s1.length() > 0)
            {
                ((WebViewFragment)getSupportFragmentManager().findFragmentById(0x7f090023)).loadUrl(s1);
                return;
            }
            String s2 = intent.getStringExtra("dialogtext");
            if (s2 != null && s2.length() > 0)
            {
                (new android.app.AlertDialog.Builder(this)).setMessage(s2).show();
                return;
            }
        }
    }

    public void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        m_activityHelper.onCreate(bundle);
        Intent intent = getIntent();
        boolean flag = "android.intent.action.VIEW".equals(intent.getAction());
        com.valvesoftware.android.steam.community.SteamUriHandler.Result result = null;
        if (flag)
        {
            result = SteamUriHandler.HandleSteamURI(intent.getData());
            if (result.command == com.valvesoftware.android.steam.community.SteamUriHandler.Command.opencategoryurl)
            {
                m_categoryList = new ArrayList();
                m_CategoriesUrl = result.getProperty(com.valvesoftware.android.steam.community.SteamUriHandler.CommandProperty.url);
            } else
            if (result.command == com.valvesoftware.android.steam.community.SteamUriHandler.Command.openurl)
            {
                m_url = result.getProperty(com.valvesoftware.android.steam.community.SteamUriHandler.CommandProperty.url);
            } else
            if (result.command == com.valvesoftware.android.steam.community.SteamUriHandler.Command.chat)
            {
                String s = result.getProperty(com.valvesoftware.android.steam.community.SteamUriHandler.CommandProperty.steamid);
                Intent intent1 = (new Intent()).setClass(this, com/valvesoftware/android/steam/community/activity/ChatActivity).addFlags(0x18000000);
                intent1.putExtra(com.valvesoftware.android.steam.community.SteamUriHandler.CommandProperty.steamid.toString(), s);
                intent1.setAction("android.intent.action.VIEW");
                startActivity(intent1);
                finish();
            }
        }
        if (result != null && result.handled)
        {
            if (com.valvesoftware.android.steam.community.SteamUriHandler.Command.opencategoryurl == result.command)
            {
                PerformCategoryUrlWebApiRequest();
            }
            setContentView(m_residActivityLayout);
            return;
        } else
        {
            finish();
            return;
        }
    }

    protected void onDestroy()
    {
        super.onDestroy();
        m_activityHelper.onDestroy();
    }

}
