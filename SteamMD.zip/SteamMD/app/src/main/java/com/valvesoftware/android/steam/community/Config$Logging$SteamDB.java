// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;


// Referenced classes of package com.valvesoftware.android.steam.community:
//            Config

public static class 
{

    public static final boolean cache_files;
    public static final boolean cache_read_hit;
    public static final boolean cache_read_miss;
    public static final boolean cache_write;
    public static final boolean disk_errors;
    public static final boolean http_request;
    public static final boolean http_response_fail;
    public static final boolean http_response_ok;
    public static final boolean parse_errors;
    public static final boolean text_full_docs;

    public ()
    {
    }
}
