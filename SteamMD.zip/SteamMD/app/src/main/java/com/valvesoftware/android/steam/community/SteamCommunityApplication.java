// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;

import android.app.Application;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Build;
import android.webkit.CookieManager;
import android.webkit.CookieSyncManager;
import com.valvesoftware.android.steam.community.activity.ChatActivity;
import com.valvesoftware.android.steam.community.activity.CommunityActivity;
import com.valvesoftware.android.steam.community.activity.CommunityGroupsActivity;
import com.valvesoftware.android.steam.community.activity.LoginActivity;
import com.valvesoftware.android.steam.community.activity.SettingsActivity;
import com.valvesoftware.android.steam.community.activity.SteamMobileUriActivity;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Calendar;
import java.util.Date;

// Referenced classes of package com.valvesoftware.android.steam.community:
//            SteamDBService, SteamDBServiceConnection, Config, SteamWebApi, 
//            FriendInfoDB, GroupInfoDB, SettingInfoDB, ISteamDebugUtil

public class SteamCommunityApplication extends Application
{
    public static class CrashHandler
        implements Thread.UncaughtExceptionHandler
    {

        public ISteamDebugUtil m_dbgUtil;
        private Thread.UncaughtExceptionHandler m_defaultUEH;

        private ISteamDebugUtil GetSteamDebugUtil()
        {
            if (m_dbgUtil != null)
            {
                return m_dbgUtil;
            } else
            {
                return SteamCommunityApplication.GetSteamDebugUtil();
            }
        }

        public void register()
        {
            Thread.UncaughtExceptionHandler uncaughtexceptionhandler = Thread.getDefaultUncaughtExceptionHandler();
            if (uncaughtexceptionhandler != this)
            {
                m_defaultUEH = uncaughtexceptionhandler;
                Thread.setDefaultUncaughtExceptionHandler(this);
            }
        }

        public void uncaughtException(Thread thread, Throwable throwable)
        {
            StringWriter stringwriter = new StringWriter();
            throwable.printStackTrace(new PrintWriter(stringwriter));
            Calendar calendar = Calendar.getInstance();
            String s = (new StringBuilder()).append("VERSION: ").append(Config.APP_VERSION_ID).append("\n").append("APPNAME: com.valvesoftware.android.steam.community\n").append("APPVERSION: ").append(Config.APP_VERSION).append("\n").append("TIMESTAMP: ").append(calendar.getTimeInMillis() / 1000L).append("\n").append("DATETIME: ").append(calendar.getTime().toGMTString()).append("\n").append("USERID: ").append(android.os.Build.VERSION.CODENAME).append(android.os.Build.VERSION.INCREMENTAL).append(" (").append(Build.DEVICE).append("/").append(Build.PRODUCT).append(") ").append(Build.BRAND).append(" - ").append(Build.MANUFACTURER).append(" - ").append(Build.DISPLAY).append("\n").append("CONTACT: ").append(SteamWebApi.GetLoginSteamID()).append("\n").append("SYSTEMVER: ").append(android.os.Build.VERSION.RELEASE).append(" : ").append(android.os.Build.VERSION.SDK).append("\n").append("SYSTEMOS: ").append(Build.MODEL).append("\n").append("STACKTRACE: ").append("\n").append(stringwriter.toString()).append("\n//ENDOFSTACKTRACE//").toString();
            ISteamDebugUtil.IDebugUtilRecord idebugutilrecord = GetSteamDebugUtil().newDebugUtilRecord(null, null, s);
            GetSteamDebugUtil().newDebugUtilRecord(idebugutilrecord, null, (String)null);
            ISteamDebugUtil.IDebugUtilRecord idebugutilrecord1 = GetSteamDebugUtil().newDebugUtilRecord(idebugutilrecord, null, (String)null);
            for (long l = System.currentTimeMillis(); idebugutilrecord1.getId() == 0L && System.currentTimeMillis() - l < 5000L;)
            {
                try
                {
                    Thread.sleep(450L);
                }
                catch (InterruptedException interruptedexception) { }
            }

            if (m_defaultUEH != null)
            {
                m_defaultUEH.uncaughtException(thread, throwable);
            }
        }

        public CrashHandler()
        {
            m_dbgUtil = null;
            m_defaultUEH = null;
        }
    }

    private class UmqDBCallback extends BroadcastReceiver
    {

        final SteamCommunityApplication this$0;

        public void onReceive(Context context, Intent intent)
        {
            String s = intent.getStringExtra("type");
            if (!s.equalsIgnoreCase("chatmsg")) goto _L2; else goto _L1
_L1:
            String s1 = intent.getStringExtra("action");
            if (!"incoming".equals(s1)) goto _L4; else goto _L3
_L3:
            int j = intent.getIntExtra("msgidLast", -1);
            if (j > 0)
            {
                GetFriendInfoDB().ChatsWithUserUpdate(intent.getStringExtra("steamid"), j, FriendInfoDB.ChatsUpdateType.msg_incoming, intent.getIntExtra("incoming", 0) + intent.getIntExtra("my_incoming", 0));
            }
_L6:
            return;
_L4:
            if ("read".equals(s1))
            {
                GetFriendInfoDB().ChatsWithUserUpdate(intent.getStringExtra("steamid"), -1, FriendInfoDB.ChatsUpdateType.mark_read, 0);
                return;
            }
            if ("clear".equals(s1))
            {
                GetFriendInfoDB().ChatsWithUserUpdate(intent.getStringExtra("steamid"), -1, FriendInfoDB.ChatsUpdateType.clear, 0);
                return;
            }
            if ("send".equals(s1))
            {
                int i = intent.getIntExtra("msgid", -1);
                if (i > 0)
                {
                    GetFriendInfoDB().ChatsWithUserUpdate(intent.getStringExtra("steamid"), i, FriendInfoDB.ChatsUpdateType.msg_sent, 1);
                    return;
                }
            }
            continue; /* Loop/switch isn't completed */
_L2:
            if (s.equalsIgnoreCase("personastate"))
            {
                GetFriendInfoDB().onReceive(context, intent);
                return;
            }
            if (s.equalsIgnoreCase("personarelationship"))
            {
                GetFriendInfoDB().onReceive(context, intent);
                GetGroupInfoDB().onReceive(context, intent);
                return;
            }
            if (s.equalsIgnoreCase("umqstate"))
            {
                GetFriendInfoDB().onReceive(context, intent);
                GetGroupInfoDB().onReceive(context, intent);
                return;
            }
            if (true) goto _L6; else goto _L5
_L5:
        }

        private UmqDBCallback()
        {
            this$0 = SteamCommunityApplication.this;
            super();
        }

    }

    public static class UriNotification
    {

        public static final String NOTIFICATION_TAG = "URINOTIFICATION";
        public int actionDrawable;
        public PendingIntent actionPendingIntent;
        public String actionString;
        public int id;
        public String text;
        public String title;

        public boolean setActionInfo(String s)
        {
            if (s == null || s.equals(""))
            {
                return false;
            }
            actionString = s;
            String as[] = s.split(":");
            if (as.length < 1)
            {
                return false;
            }
            if (as[0].equals("CF"))
            {
                actionDrawable = 0x7f020018;
                actionPendingIntent = SteamCommunityApplication.GetInstance().GetIntentForActivityClass(com/valvesoftware/android/steam/community/activity/CommunityActivity);
                return true;
            }
            if (as[0].equals("CG"))
            {
                actionDrawable = 0x7f020019;
                actionPendingIntent = SteamCommunityApplication.GetInstance().GetIntentForActivityClass(com/valvesoftware/android/steam/community/activity/CommunityGroupsActivity);
                return true;
            }
            if (as[0].equals("SS"))
            {
                actionDrawable = 0x7f02001b;
                actionPendingIntent = SteamCommunityApplication.GetInstance().GetIntentForActivityClass(com/valvesoftware/android/steam/community/activity/SettingsActivity);
                return true;
            }
            if (as[0].equals("M") && as.length >= 2 && as[1].length() > 0)
            {
                actionDrawable = 0x7f020023;
                actionPendingIntent = SteamCommunityApplication.GetInstance().GetIntentToChatWithSteamID(as[1]);
                return true;
            }
            if (as[0].length() > 0 && as[0].startsWith("U") && as.length >= 3 && as[1].length() > 0 && as[2].length() > 0)
            {
                actionDrawable = 0x7f02001c;
                boolean flag;
                boolean flag1;
                SteamCommunityApplication steamcommunityapplication;
                StringBuilder stringbuilder;
                String s1;
                StringBuilder stringbuilder1;
                String s2;
                if (as[1].equals("CF"))
                {
                    actionDrawable = 0x7f020018;
                } else
                if (as[1].equals("CG"))
                {
                    actionDrawable = 0x7f020019;
                } else
                if (as[1].equals("SS"))
                {
                    actionDrawable = 0x7f02001b;
                } else
                if (as[1].equals("SC"))
                {
                    actionDrawable = 0x7f02001c;
                } else
                if (as[1].equals("SW"))
                {
                    actionDrawable = 0x7f02001d;
                } else
                if (as[1].equals("ST"))
                {
                    actionDrawable = 0x7f020015;
                } else
                if (as[1].equals("SF"))
                {
                    actionDrawable = 0x7f02001a;
                } else
                if (as[1].equals("FF"))
                {
                    actionDrawable = 0x7f020017;
                } else
                if (as[1].equals("MM"))
                {
                    actionDrawable = 0x7f020023;
                }
                if (as[0].indexOf("C", 1) > 0)
                {
                    flag = true;
                } else
                {
                    flag = false;
                }
                if (as[0].indexOf("S", 1) > 0)
                {
                    flag1 = true;
                } else
                {
                    flag1 = false;
                }
                steamcommunityapplication = SteamCommunityApplication.GetInstance();
                stringbuilder = (new StringBuilder()).append("steammobile://");
                if (flag)
                {
                    s1 = SteamUriHandler.Command.opencategoryurl.toString();
                } else
                {
                    s1 = SteamUriHandler.Command.openurl.toString();
                }
                stringbuilder1 = stringbuilder.append(s1).append("?").append(SteamUriHandler.CommandProperty.url.toString()).append("=");
                if (flag1)
                {
                    if (flag)
                    {
                        s2 = Config.URL_STORE_BASE_INSECURE;
                    } else
                    {
                        s2 = Config.URL_STORE_BASE;
                    }
                } else
                if (flag)
                {
                    s2 = Config.URL_COMMUNITY_BASE_INSECURE;
                } else
                {
                    s2 = Config.URL_COMMUNITY_BASE;
                }
                actionPendingIntent = steamcommunityapplication.GetIntentForUriString(stringbuilder1.append(s2).append("/").append(as[2]).toString());
                return true;
            } else
            {
                return false;
            }
        }

        public void setDefaultActionInfo()
        {
            actionString = "";
            actionDrawable = 0x7f020028;
            actionPendingIntent = SteamCommunityApplication.GetInstance().GetIntentForActivityClass(com/valvesoftware/android/steam/community/activity/CommunityActivity);
        }

        public UriNotification()
        {
        }
    }


    public static final String INTENT_ACTION_WEBVIEW_RESULT = "com.valvesoftware.android.steam.community.intent.action.WEBVIEW_RESULT";
    public static CrashHandler m_CrashHandler = new CrashHandler();
    private static SteamCommunityApplication m_singleton = null;
    public boolean m_bApplicationExiting;
    private boolean m_bOverTheAirVersion;
    private SteamDBDiskCache.IndefiniteCache m_diskCacheIndefinite;
    private SteamDBDiskCache.WebCache m_diskCacheWeb;
    private FriendInfoDB m_friendInfoDB;
    private GroupInfoDB m_groupInfoDB;
    private SettingInfoDB m_settingInfoDB;
    private SteamDBServiceConnection m_steamDBConnection;
    private final UmqDBCallback m_umqdbIntentReceiver = new UmqDBCallback();

    public SteamCommunityApplication()
    {
        m_diskCacheWeb = null;
        m_diskCacheIndefinite = null;
        m_steamDBConnection = null;
        m_friendInfoDB = null;
        m_groupInfoDB = null;
        m_settingInfoDB = null;
        m_bOverTheAirVersion = false;
        m_bApplicationExiting = false;
    }

    public static SteamCommunityApplication GetInstance()
    {
        return m_singleton;
    }

    public static ISteamDebugUtil GetSteamDebugUtil()
    {
        SteamCommunityApplication steamcommunityapplication = m_singleton;
        SteamDBService steamdbservice = null;
        if (steamcommunityapplication != null)
        {
            steamdbservice = m_singleton.GetSteamDB();
        }
        if (steamdbservice != null)
        {
            return steamdbservice.getDebugUtil();
        } else
        {
            return new SteamDebugUtil.Dummy_ISteamDebugUtil();
        }
    }

    public SteamDBDiskCache.IndefiniteCache GetDiskCacheIndefinite()
    {
        return m_diskCacheIndefinite;
    }

    public SteamDBDiskCache.WebCache GetDiskCacheWeb()
    {
        return m_diskCacheWeb;
    }

    public FriendInfoDB GetFriendInfoDB()
    {
        return m_friendInfoDB;
    }

    public GroupInfoDB GetGroupInfoDB()
    {
        return m_groupInfoDB;
    }

    public PendingIntent GetIntentForActivityClass(Class class1)
    {
        Intent intent = new Intent();
        intent.setClass(getApplicationContext(), class1);
        intent.setFlags(0x30000000);
        return PendingIntent.getActivity(getApplicationContext(), 0, intent, 0);
    }

    public PendingIntent GetIntentForActivityClassFromService(Class class1)
    {
        Intent intent = new Intent();
        intent.setClass(getApplicationContext(), class1);
        intent.setFlags(0x30000000);
        return PendingIntent.getActivity(getApplicationContext(), 0, intent, 0);
    }

    public PendingIntent GetIntentForUriString(Uri uri)
    {
        return GetIntentForUriString(uri, 0);
    }

    public PendingIntent GetIntentForUriString(Uri uri, int i)
    {
        Intent intent = new Intent();
        intent.setAction("android.intent.action.VIEW");
        intent.setData(uri);
        intent.setFlags(0x18000000);
        intent.setClass(getApplicationContext(), com/valvesoftware/android/steam/community/activity/SteamMobileUriActivity);
        if (i != 0)
        {
            intent.putExtra("title_resid", i);
        }
        return PendingIntent.getActivity(getApplicationContext(), uri.hashCode(), intent, 0);
    }

    public PendingIntent GetIntentForUriString(String s)
    {
        return GetIntentForUriString(Uri.parse(s));
    }

    public PendingIntent GetIntentToChatWithSteamID(String s)
    {
        Intent intent = new Intent();
        intent.setAction("android.intent.action.MAIN");
        intent.setData(Uri.parse((new StringBuilder()).append("steammobile://").append(SteamUriHandler.Command.chat.toString()).append("?").append(SteamUriHandler.CommandProperty.steamid.toString()).append("=").append(s).toString()));
        intent.putExtra("steamid", s);
        intent.setFlags(0x18000000);
        intent.setClass(getApplicationContext(), com/valvesoftware/android/steam/community/activity/ChatActivity);
        return PendingIntent.getActivity(getApplicationContext(), s.hashCode(), intent, 0);
    }

    public SettingInfoDB GetSettingInfoDB()
    {
        return m_settingInfoDB;
    }

    public SteamDBService GetSteamDB()
    {
        return m_steamDBConnection.GetService();
    }

    public boolean IsOverTheAirVersion()
    {
        return m_bOverTheAirVersion;
    }

    public void SubmitSteamDBRequest(SteamWebApi.RequestBase requestbase)
    {
        m_steamDBConnection.SubmitRequest(requestbase);
    }

    public final void onConfigurationChanged(Configuration configuration)
    {
        super.onConfigurationChanged(configuration);
    }

    public final void onCreate()
    {
        super.onCreate();
        m_singleton = this;
        Exception exception;
        Intent intent;
        boolean flag;
        try
        {
            PackageInfo packageinfo = getPackageManager().getPackageInfo(getPackageName(), 0);
            Config.APP_VERSION = packageinfo.versionName;
            Config.APP_VERSION_ID = packageinfo.versionCode;
        }
        catch (android.content.pm.PackageManager.NameNotFoundException namenotfoundexception) { }
        if (Class.forName("net.hockeyapp.android.UpdateActivity") != null)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        try
        {
            m_bOverTheAirVersion = flag;
        }
        // Misplaced declaration of an exception variable
        catch (Exception exception) { }
        m_CrashHandler.register();
        registerReceiver(m_umqdbIntentReceiver, new IntentFilter("com.valvesoftware.android.steam.community.SteamUmqCommunicationIntent"));
        CookieSyncManager.createInstance(this);
        CookieManager.getInstance().setAcceptCookie(true);
        SteamWebApi.ResetAllCookies();
        m_diskCacheWeb = new SteamDBDiskCache.WebCache(getBaseContext().getDir("cache_w", 0));
        m_diskCacheIndefinite = new SteamDBDiskCache.IndefiniteCache(getBaseContext().getDir("cache_i", 0));
        m_friendInfoDB = new FriendInfoDB();
        m_groupInfoDB = new GroupInfoDB();
        m_settingInfoDB = new SettingInfoDB();
        m_steamDBConnection = new SteamDBServiceConnection();
        intent = new Intent(GetInstance(), com/valvesoftware/android/steam/community/SteamDBService);
        GetInstance().bindService(intent, m_steamDBConnection, 1);
        LoginActivity.PreemptivelyLoginBasedOnCachedLoginDocument();
        SteamWebApi.SyncAllCookies();
        return;
    }

    public final void onLowMemory()
    {
        super.onLowMemory();
    }

    public final void onTerminate()
    {
        unregisterReceiver(m_umqdbIntentReceiver);
        super.onTerminate();
    }

}
