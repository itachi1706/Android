// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;


// Referenced classes of package com.valvesoftware.android.steam.community:
//            SteamDBService

private static abstract class m_cache
    implements m_cache
{

    protected Info m_cache;

    public String GetRequestQueue()
    {
        return "JobQueueDiskCache";
    }

    protected Info(Info info)
    {
        m_cache = info;
    }
}
