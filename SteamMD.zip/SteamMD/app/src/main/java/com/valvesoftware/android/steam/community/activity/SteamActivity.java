// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.activity;


final class SteamActivity
{

    static final int COMMUNITY = 1;
    static final int LOGIN = 0;
    static final int NEWS = 3;
    static final int STORE = 2;

    SteamActivity()
    {
    }
}
