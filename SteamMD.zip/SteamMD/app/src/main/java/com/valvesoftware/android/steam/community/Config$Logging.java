// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;


// Referenced classes of package com.valvesoftware.android.steam.community:
//            Config

public static class UMQ
{
    public static class Activities
    {

        public static final boolean chat;
        public static final boolean listdbrefresh;
        public static final boolean login;
        public static final boolean tabgroup;
        public static final boolean tabs;
        public static final boolean uri;

        public Activities()
        {
        }
    }

    public static class C2DM
    {

        public static final boolean app2google;
        public static final boolean pushnotifications;
        public static final boolean service;
        public static final boolean unsupported;

        public C2DM()
        {
        }
    }

    public static class DebugUtil
    {

        public static final boolean log_collected_info;
        public static final boolean log_sql;
        public static final boolean log_uploaded_dumps;
        public static final boolean retain_collected_after_upload;
        public static final boolean verbose_collection;

        public DebugUtil()
        {
        }
    }

    public static class SteamDB
    {

        public static final boolean cache_files;
        public static final boolean cache_read_hit;
        public static final boolean cache_read_miss;
        public static final boolean cache_write;
        public static final boolean disk_errors;
        public static final boolean http_request;
        public static final boolean http_response_fail;
        public static final boolean http_response_ok;
        public static final boolean parse_errors;
        public static final boolean text_full_docs;

        public SteamDB()
        {
        }
    }

    public static class ThreadPool
    {

        public static final boolean start_stop;

        public ThreadPool()
        {
        }
    }

    public static class UMQ
    {

        public static final boolean log_exceptions;
        public static final boolean log_sql;
        public static final boolean messages;
        public static final boolean parse_errors;
        public static final boolean relationship;
        public static final boolean state;

        public UMQ()
        {
        }
    }


    public UMQ()
    {
    }
}
