// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.fragment;

import android.view.View;
import com.valvesoftware.android.steam.community.activity.ActivityHelper;

// Referenced classes of package com.valvesoftware.android.steam.community.fragment:
//            TitlebarFragment, NavigationFragment

class this._cls0
    implements android.view.r
{

    final TitlebarFragment this$0;

    public void onClick(View view)
    {
        NavigationFragment navigationfragment = ActivityHelper.GetNavigationFragmentForActivity(getActivity());
        if (navigationfragment != null)
        {
            navigationfragment.onNavActivationButtonClicked();
        }
    }

    ()
    {
        this$0 = TitlebarFragment.this;
        super();
    }
}
