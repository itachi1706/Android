// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;


// Referenced classes of package com.valvesoftware.android.steam.community:
//            R

public static final class 
{

    public static final int splitview_content_hide = 0x7f040000;
    public static final int splitview_content_show = 0x7f040001;
    public static final int splitview_navigation_hide = 0x7f040002;
    public static final int splitview_navigation_show = 0x7f040003;
    public static final int titlebar_refreshing = 0x7f040004;

    public ()
    {
    }
}
