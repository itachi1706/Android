// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;


// Referenced classes of package com.valvesoftware.android.steam.community:
//            SteamDBService

private static class fo extends fo
{

    public void Run()
    {
        if (!(m_cache.disk instanceof fo.disk))
        {
            return;
        } else
        {
            ((fo.disk)m_cache.disk).lete(m_cache.uri);
            return;
        }
    }

    fo(fo fo)
    {
        super(fo);
    }
}
