// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;


// Referenced classes of package com.valvesoftware.android.steam.community:
//            R

public static final class 
{

    public static final int avatar = 0x7f09000e;
    public static final int avatar_frame = 0x7f090012;
    public static final int chat = 0x7f090002;
    public static final int chatButton = 0x7f090016;
    public static final int chat_options_clear_history_button = 0x7f090007;
    public static final int chat_options_layout = 0x7f090006;
    public static final int chat_say_layout = 0x7f09000a;
    public static final int chat_view_contents = 0x7f090008;
    public static final int chat_view_entry_other = 0x7f090033;
    public static final int chat_view_entry_other_text = 0x7f09000f;
    public static final int chat_view_entry_user_text = 0x7f090010;
    public static final int chat_view_layout = 0x7f090005;
    public static final int chat_view_say_button = 0x7f09000c;
    public static final int chat_view_say_text = 0x7f09000b;
    public static final int chat_view_status = 0x7f090009;
    public static final int community_list = 0x7f090011;
    public static final int friendItemAreaAroundChatButton = 0x7f090015;
    public static final int groupMembersOnline = 0x7f090021;
    public static final int groupMembersTotal = 0x7f090020;
    public static final int imageChevron = 0x7f090017;
    public static final int imageView1 = 0x7f090022;
    public static final int info = 0x7f090031;
    public static final int label = 0x7f09000d;
    public static final int list_search_bar = 0x7f09001d;
    public static final int list_search_bar_button = 0x7f09001f;
    public static final int list_search_bar_text = 0x7f09001e;
    public static final int loggedIn = 0x7f09001c;
    public static final int login = 0x7f09001b;
    public static final int name = 0x7f090013;
    public static final int navFragment_ContentButton = 0x7f090026;
    public static final int navFragment_TitleButton = 0x7f090024;
    public static final int navFragment_TitleItem = 0x7f090025;
    public static final int navigation = 0x7f090004;
    public static final int navigation_section_name_underline = 0x7f090029;
    public static final int navigation_section_title_layout = 0x7f090027;
    public static final int navigation_section_title_layout_content = 0x7f090028;
    public static final int notLoggedIn = 0x7f090019;
    public static final int search_footer_button_next = 0x7f09002d;
    public static final int search_footer_button_prev = 0x7f09002c;
    public static final int search_footer_buttons = 0x7f09002b;
    public static final int search_progress_label = 0x7f09002a;
    public static final int setting_checkbox = 0x7f090032;
    public static final int settingsFragment_AccountControl_ChangeUser = 0x7f090030;
    public static final int settingsFragment_TitleItem = 0x7f09002f;
    public static final int settings_fragment = 0x7f09002e;
    public static final int splitView_Contents = 0x7f090000;
    public static final int splitView_Navigation = 0x7f090003;
    public static final int status = 0x7f090014;
    public static final int steamid = 0x7f090018;
    public static final int tab_title = 0x7f090034;
    public static final int textView1 = 0x7f09001a;
    public static final int titleLabel = 0x7f090036;
    public static final int titleNavActivationButton = 0x7f090035;
    public static final int titleNavRefreshButton = 0x7f090038;
    public static final int titleNavRefreshQuarter = 0x7f090039;
    public static final int titleNavSearchButton = 0x7f090037;
    public static final int titlebar = 0x7f090001;
    public static final int toggleGroup = 0x7f09003c;
    public static final int webView = 0x7f090045;
    public static final int web_select_1 = 0x7f09003d;
    public static final int web_select_2 = 0x7f09003e;
    public static final int web_select_3 = 0x7f09003f;
    public static final int web_select_4 = 0x7f090040;
    public static final int web_select_5 = 0x7f090041;
    public static final int web_select_6 = 0x7f090042;
    public static final int web_select_7 = 0x7f090043;
    public static final int web_select_8 = 0x7f090044;
    public static final int web_select_layout = 0x7f09003b;
    public static final int web_view = 0x7f09003a;
    public static final int webview = 0x7f090023;

    public ()
    {
    }
}
