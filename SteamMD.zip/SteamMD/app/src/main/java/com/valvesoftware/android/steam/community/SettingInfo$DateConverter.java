// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;

import java.text.DateFormat;
import java.util.Calendar;

// Referenced classes of package com.valvesoftware.android.steam.community:
//            SettingInfo

public static class I
{

    public static String formatDate(String s)
    {
        Calendar calendar = makeCalendar(s);
        return DateFormat.getDateInstance(0).format(calendar.getTime());
    }

    public static Calendar makeCalendar(String s)
    {
        Calendar calendar = Calendar.getInstance();
        if (s != null && !s.equals(""))
        {
            int i = Integer.valueOf(s).intValue();
            calendar.set(i / 10000, (i - 10000 * (i / 10000)) / 100, i % 100);
        }
        return calendar;
    }

    public static String makeUnixTime(String s)
    {
        Calendar calendar = makeCalendar(s);
        return (new StringBuilder()).append("").append(calendar.getTimeInMillis() / 1000L).toString();
    }

    public static String makeValue(int i, int j, int k)
    {
        int l = k + (i * 10000 + j * 100);
        return (new StringBuilder()).append("").append(l).toString();
    }

    public I()
    {
    }
}
