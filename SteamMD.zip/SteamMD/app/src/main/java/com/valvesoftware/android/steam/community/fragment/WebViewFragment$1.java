// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.fragment;

import android.widget.RadioGroup;
import android.widget.ToggleButton;

// Referenced classes of package com.valvesoftware.android.steam.community.fragment:
//            WebViewFragment

class this._cls0
    implements android.widget.edChangeListener
{

    final WebViewFragment this$0;

    public void onCheckedChanged(RadioGroup radiogroup, int i)
    {
        int j = 0;
        while (j < radiogroup.getChildCount()) 
        {
            ToggleButton togglebutton = (ToggleButton)radiogroup.getChildAt(j);
            boolean flag;
            if (togglebutton.getId() == i)
            {
                flag = true;
            } else
            {
                flag = false;
            }
            togglebutton.setChecked(flag);
            if (togglebutton.getId() == i)
            {
                WebViewFragment.access$302(WebViewFragment.this, j);
            }
            j++;
        }
    }

    ()
    {
        this$0 = WebViewFragment.this;
        super();
    }
}
