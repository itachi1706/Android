// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.fragment;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.widget.TextView;
import com.valvesoftware.android.steam.community.SettingInfo;

// Referenced classes of package com.valvesoftware.android.steam.community.fragment:
//            SettingsFragment

class this._cls0
    implements android.content.RadioSelectorItemOnClickListener._cls1
{

    final SettingChanged this$0;

    public void onClick(DialogInterface dialoginterface, int i)
    {
        com.valvesoftware.android.steam.community.stener._cls1 a_lcls1[] = (com.valvesoftware.android.steam.community.stener._cls1[])(com.valvesoftware.android.steam.community.stener._cls1[])ttingInfo.m_extraData;
        if (i >= 0 && i < a_lcls1.length)
        {
            if (lueView != null)
            {
                lueView.setText(a_lcls1[i].valueView);
            }
            ttingInfo.setValueAndCommit(tivity.getApplicationContext(), String.valueOf(a_lcls1[i].activity));
            ert.dismiss();
            SettingChanged(a_lcls1[i]);
        }
    }

    ()
    {
        this$0 = this._cls0.this;
        super();
    }
}
