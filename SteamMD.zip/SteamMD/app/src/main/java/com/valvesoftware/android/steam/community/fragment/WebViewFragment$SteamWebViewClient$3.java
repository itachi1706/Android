// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.fragment;

import android.app.Activity;
import android.webkit.SslErrorHandler;
import android.widget.TextView;
import com.valvesoftware.android.steam.community.SettingInfo;

// Referenced classes of package com.valvesoftware.android.steam.community.fragment:
//            WebViewFragment

class val.hdlrDelayed extends lickListener
{

    private SslErrorHandler m_hdlrDelayed;
    final m_hdlrDelayed this$1;
    final SslErrorHandler val$hdlrDelayed;

    public void onSettingChanged(com.valvesoftware.android.steam.community.Client._cls3 _pcls3)
    {
        if (_pcls3._fld3 != 1)
        {
            m_hdlrDelayed.proceed();
            return;
        } else
        {
            setCategoriesFailed();
            m_hdlrDelayed.cancel();
            return;
        }
    }

    lickListener(SettingInfo settinginfo, TextView textview, SslErrorHandler sslerrorhandler)
    {
        this$1 = final_licklistener;
        val$hdlrDelayed = sslerrorhandler;
        super(Activity.this, settinginfo, textview);
        m_hdlrDelayed = val$hdlrDelayed;
    }
}
