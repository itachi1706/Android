// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.fragment;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.ListFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import com.valvesoftware.android.steam.community.AndroidUtils;
import com.valvesoftware.android.steam.community.Config;
import com.valvesoftware.android.steam.community.FriendInfo;
import com.valvesoftware.android.steam.community.FriendInfoDB;
import com.valvesoftware.android.steam.community.SteamCommunityApplication;
import com.valvesoftware.android.steam.community.SteamDBService;
import com.valvesoftware.android.steam.community.SteamWebApi;
import com.valvesoftware.android.steam.community.activity.ActivityHelper;
import com.valvesoftware.android.steam.community.activity.CommunityActivity;
import com.valvesoftware.android.steam.community.activity.CommunityGroupsActivity;
import com.valvesoftware.android.steam.community.activity.FragmentActivityWithNavigationSupport;
import com.valvesoftware.android.steam.community.activity.SettingsActivity;
import com.valvesoftware.android.steam.community.activity.SteamMobileUriActivity;
import java.util.ArrayList;
import java.util.Iterator;

public class NavigationFragment extends ListFragment
{
    private static class ExitingProgressDialog extends ProgressDialog
    {

        public void onBackPressed()
        {
        }

        public ExitingProgressDialog(Context context)
        {
            super(context);
        }
    }

    public static abstract class NavigationItem
    {

        public boolean m_bShowIfNotSignedIn;
        public int resid_category;
        public int resid_icon;

        public abstract String getDetails();

        public abstract int getName();

        public abstract void onClick();

        public NavigationItem()
        {
        }
    }

    private class NavigationItemListAdapter extends ArrayAdapter
    {

        final NavigationFragment this$0;

        public View getView(int i, View view, ViewGroup viewgroup)
        {
            View view1 = view;
            SteamCommunityApplication steamcommunityapplication = SteamCommunityApplication.GetInstance();
            if (view1 == null)
            {
                view1 = ((LayoutInflater)steamcommunityapplication.getSystemService("layout_inflater")).inflate(0x7f03000e, null);
                view1.setClickable(true);
                view1.setOnClickListener(m_navItemClickListener);
            }
            NavigationItem navigationitem = (NavigationItem)m_items.get(i);
            if (navigationitem != null)
            {
                setupView(view1, navigationitem, i);
            }
            return view1;
        }

        public NavigationItemListAdapter()
        {
            this$0 = NavigationFragment.this;
            super(getActivity(), 0x7f03000e, m_items);
        }
    }

    public class NavigationItem_ClassActivity extends NavigationItem
    {

        public Class activity;
        public String info;
        public int resid_name;
        final NavigationFragment this$0;

        public String getDetails()
        {
            return "";
        }

        public int getName()
        {
            return resid_name;
        }

        public Intent getNewActivityIntent()
        {
            return (new Intent()).addFlags(0x18000000).setClass(getActivity(), activity);
        }

        public void onClick()
        {
            getActivity().startActivity(getNewActivityIntent());
        }

        public NavigationItem_ClassActivity()
        {
            this$0 = NavigationFragment.this;
            super();
        }
    }

    public class NavigationItem_ClassActivity_SingleTop extends NavigationItem_ClassActivity
    {

        final NavigationFragment this$0;

        public Intent getNewActivityIntent()
        {
            Intent intent = super.getNewActivityIntent().addFlags(0x20000000);
            intent.setFlags(0xf7ffffff & intent.getFlags());
            return intent;
        }

        public NavigationItem_ClassActivity_SingleTop()
        {
            this$0 = NavigationFragment.this;
            super();
        }
    }

    public class NavigationItem_ExitApplication extends NavigationItem
    {

        final NavigationFragment this$0;

        public String getDetails()
        {
            return "";
        }

        public int getName()
        {
            return 0x7f070016;
        }

        public void onClick()
        {
            FragmentActivityWithNavigationSupport.finishAllExceptOne((FragmentActivityWithNavigationSupport)getActivity());
            if (SteamCommunityApplication.GetInstance().GetSteamDB() == null)
            {
                break MISSING_BLOCK_LABEL_98;
            }
            SteamCommunityApplication.GetInstance().m_bApplicationExiting = true;
            com.valvesoftware.android.steam.community.SteamDBService.REQ_ACT_LOGININFO_DATA req_act_logininfo_data = new com.valvesoftware.android.steam.community.SteamDBService.REQ_ACT_LOGININFO_DATA();
            req_act_logininfo_data.sOAuthToken = null;
            req_act_logininfo_data.sSteamID = null;
            SteamWebApi.SubmitSimpleActionRequest("SetLoginInformation", req_act_logininfo_data);
            ExitingProgressDialog exitingprogressdialog = new ExitingProgressDialog(getActivity());
            exitingprogressdialog.setMessage(getActivity().getString(0x7f07001a));
            exitingprogressdialog.setIndeterminate(true);
            exitingprogressdialog.setCancelable(false);
            exitingprogressdialog.show();
            return;
            Exception exception;
            exception;
        }

        public NavigationItem_ExitApplication()
        {
            this$0 = NavigationFragment.this;
            super();
        }
    }

    public class NavigationItem_UriActivity_AccountDetails extends NavigationItem_UriActivity_Base
    {

        final NavigationFragment this$0;

        public Intent getNewActivityIntent()
        {
            return super.getNewActivityIntent().setData(NavigationFragment.URI_AccountDetails);
        }

        public NavigationItem_UriActivity_AccountDetails()
        {
            this$0 = NavigationFragment.this;
            super();
        }
    }

    public class NavigationItem_UriActivity_Base extends NavigationItem_ClassActivity
    {

        final NavigationFragment this$0;

        public Intent getNewActivityIntent()
        {
            return super.getNewActivityIntent().setAction("android.intent.action.VIEW").putExtra("title_resid", resid_name);
        }

        public NavigationItem_UriActivity_Base()
        {
            this$0 = NavigationFragment.this;
            super();
            activity = com/valvesoftware/android/steam/community/activity/SteamMobileUriActivity;
        }
    }

    public class NavigationItem_UriActivity_Blotter extends NavigationItem_UriActivity_Base
    {

        final NavigationFragment this$0;

        public Intent getNewActivityIntent()
        {
            return super.getNewActivityIntent().setData(NavigationFragment.URI_Blotter);
        }

        public NavigationItem_UriActivity_Blotter()
        {
            this$0 = NavigationFragment.this;
            super();
        }
    }

    public class NavigationItem_UriActivity_Cart extends NavigationItem_UriActivity_Base
    {

        final NavigationFragment this$0;

        public Intent getNewActivityIntent()
        {
            return super.getNewActivityIntent().setData(NavigationFragment.URI_Cart);
        }

        public NavigationItem_UriActivity_Cart()
        {
            this$0 = NavigationFragment.this;
            super();
        }
    }

    public class NavigationItem_UriActivity_Catalog extends NavigationItem_UriActivity_Base
    {

        final NavigationFragment this$0;

        public Intent getNewActivityIntent()
        {
            return super.getNewActivityIntent().setData(NavigationFragment.URI_Catalog);
        }

        public NavigationItem_UriActivity_Catalog()
        {
            this$0 = NavigationFragment.this;
            super();
        }
    }

    public class NavigationItem_UriActivity_Feeds_SteamNews extends NavigationItem_UriActivity_Base
    {

        final NavigationFragment this$0;

        public Intent getNewActivityIntent()
        {
            return super.getNewActivityIntent().setData(NavigationFragment.URI_Feeds_SteamNews);
        }

        public NavigationItem_UriActivity_Feeds_SteamNews()
        {
            this$0 = NavigationFragment.this;
            super();
        }
    }

    public class NavigationItem_UriActivity_Feeds_SteamSpecials extends NavigationItem_UriActivity_Base
    {

        final NavigationFragment this$0;

        public Intent getNewActivityIntent()
        {
            return super.getNewActivityIntent().setData(NavigationFragment.URI_Feeds_SteamSpecials);
        }

        public NavigationItem_UriActivity_Feeds_SteamSpecials()
        {
            this$0 = NavigationFragment.this;
            super();
        }
    }

    public class NavigationItem_UriActivity_Feeds_Syndicated extends NavigationItem_UriActivity_Base
    {

        final NavigationFragment this$0;

        public Intent getNewActivityIntent()
        {
            return super.getNewActivityIntent().setData(NavigationFragment.URI_Feeds_Syndicated);
        }

        public NavigationItem_UriActivity_Feeds_Syndicated()
        {
            this$0 = NavigationFragment.this;
            super();
        }
    }

    public class NavigationItem_UriActivity_Profile extends NavigationItem_UriActivity_Base
    {

        final NavigationFragment this$0;

        public Intent getNewActivityIntent()
        {
            return super.getNewActivityIntent().setData(Uri.parse((new StringBuilder()).append("steammobile://openurl?url=").append(Config.URL_COMMUNITY_BASE).append("/profiles/").append(SteamWebApi.GetLoginSteamID()).toString()));
        }

        public void onClick()
        {
            if (!SteamWebApi.IsLoggedIn())
            {
                ActivityHelper.PresentLoginActivity(getActivity(), com.valvesoftware.android.steam.community.activity.LoginActivity.LoginAction.LOGIN_DEFAULT);
                return;
            } else
            {
                super.onClick();
                return;
            }
        }

        public NavigationItem_UriActivity_Profile()
        {
            this$0 = NavigationFragment.this;
            super();
        }
    }

    public class NavigationItem_UriActivity_StoreSearch extends NavigationItem_UriActivity_Base
    {

        final NavigationFragment this$0;

        public Intent getNewActivityIntent()
        {
            return super.getNewActivityIntent().setData(NavigationFragment.URI_Store_Search);
        }

        public NavigationItem_UriActivity_StoreSearch()
        {
            this$0 = NavigationFragment.this;
            super();
        }
    }

    public class NavigationItem_UriActivity_Wishlist extends NavigationItem_UriActivity_Base
    {

        final NavigationFragment this$0;

        public Intent getNewActivityIntent()
        {
            return super.getNewActivityIntent().setData(NavigationFragment.URI_Wishlist);
        }

        public NavigationItem_UriActivity_Wishlist()
        {
            this$0 = NavigationFragment.this;
            super();
        }
    }


    public static final Uri URI_AccountDetails;
    private static final Uri URI_Blotter;
    public static final Uri URI_Cart;
    public static final Uri URI_Catalog;
    public static final Uri URI_Feeds_SteamNews;
    public static final Uri URI_Feeds_SteamSpecials;
    public static final Uri URI_Feeds_Syndicated;
    public static final Uri URI_Store_Search;
    public static final Uri URI_Wishlist;
    private NavigationItemListAdapter m_adapter;
    private android.view.animation.Animation.AnimationListener m_animListener;
    private boolean m_bNavActive;
    private boolean m_bNavAnimating;
    private boolean m_bRequestToHideNavWhileAnimating;
    public android.view.View.OnClickListener m_dummyClickListener;
    public NavigationItem_UriActivity_Profile m_itemProfile;
    private ArrayList m_items;
    private ArrayList m_itemsAvailable;
    private ListView m_listView;
    public android.view.View.OnClickListener m_navItemClickListener;
    private View m_splitViewContents;
    private View m_splitViewNavigation;

    public NavigationFragment()
    {
        m_itemProfile = new NavigationItem_UriActivity_Profile();
        m_itemsAvailable = new ArrayList();
        m_items = new ArrayList();
        m_listView = null;
        m_adapter = null;
        m_splitViewNavigation = null;
        m_splitViewContents = null;
        m_navItemClickListener = new android.view.View.OnClickListener() {

            final NavigationFragment this$0;

            public void onClick(View view)
            {
                TextView textview;
                int i;
                if (!m_bNavAnimating && m_bNavActive)
                {
                    if ((textview = (TextView)view.findViewById(0x7f090018)) != null && ((i = Integer.valueOf(textview.getText().toString()).intValue()) >= -1 && i < m_items.size()))
                    {
                        onNavActivationButtonClicked();
                        if (i >= 0)
                        {
                            ((NavigationItem)m_items.get(i)).onClick();
                            return;
                        } else
                        {
                            m_itemProfile.onClick();
                            return;
                        }
                    }
                }
            }

            
            {
                this$0 = NavigationFragment.this;
                super();
            }
        };
        m_dummyClickListener = new android.view.View.OnClickListener() {

            final NavigationFragment this$0;

            public void onClick(View view)
            {
            }

            
            {
                this$0 = NavigationFragment.this;
                super();
            }
        };
        m_bNavActive = false;
        m_bNavAnimating = false;
        m_bRequestToHideNavWhileAnimating = false;
        m_animListener = new android.view.animation.Animation.AnimationListener() {

            final NavigationFragment this$0;

            public void onAnimationEnd(Animation animation)
            {
                m_bNavAnimating = false;
                if (!m_bNavActive)
                {
                    m_splitViewNavigation.setVisibility(8);
                } else
                if (m_bRequestToHideNavWhileAnimating)
                {
                    m_bRequestToHideNavWhileAnimating = false;
                    onNavActivationButtonClicked();
                    return;
                }
            }

            public void onAnimationRepeat(Animation animation)
            {
            }

            public void onAnimationStart(Animation animation)
            {
            }

            
            {
                this$0 = NavigationFragment.this;
                super();
            }
        };
    }

    private void onNavSidebarPrepareForActivation()
    {
        m_items.clear();
        boolean flag = SteamWebApi.IsLoggedIn();
        Iterator iterator = m_itemsAvailable.iterator();
        do
        {
            if (!iterator.hasNext())
            {
                break;
            }
            NavigationItem navigationitem = (NavigationItem)iterator.next();
            if (flag || navigationitem.m_bShowIfNotSignedIn)
            {
                m_items.add(navigationitem);
            }
        } while (true);
        m_adapter.notifyDataSetChanged();
        setupView(getActivity().findViewById(0x7f090025), m_itemProfile, -1);
    }

    private void setupView(View view, NavigationItem navigationitem, int i)
    {
        View view1 = view.findViewById(0x7f090027);
        View view2 = view.findViewById(0x7f090029);
        TextView textview = (TextView)view.findViewById(0x7f09000d);
        TextView textview1 = (TextView)view.findViewById(0x7f090013);
        TextView textview2 = (TextView)view.findViewById(0x7f090014);
        TextView textview3 = (TextView)view.findViewById(0x7f090018);
        ImageView imageview = (ImageView)view.findViewById(0x7f09000e);
        ImageView imageview1 = (ImageView)view.findViewById(0x7f090012);
        int j;
        if (i >= 0 && (i == 0 || navigationitem.resid_category != ((NavigationItem)m_items.get(i - 1)).resid_category))
        {
            boolean flag;
            Resources resources;
            int k;
            boolean flag1;
            SteamDBService steamdbservice;
            boolean flag2;
            if (navigationitem.resid_category != 0)
            {
                textview.setText(navigationitem.resid_category);
            } else
            {
                textview.setText(" ");
            }
            view1.setVisibility(0);
            view1.setOnClickListener(m_dummyClickListener);
        } else
        {
            view1.setVisibility(8);
        }
        textview3.setText(String.valueOf(i));
        imageview.setImageResource(navigationitem.resid_icon);
        textview1.setText(navigationitem.getName());
        textview2.setText(navigationitem.getDetails());
        if (i >= 0 && i + 1 < m_items.size() && navigationitem.resid_category == ((NavigationItem)m_items.get(i + 1)).resid_category)
        {
            view2.setVisibility(0);
        } else
        {
            view2.setVisibility(8);
        }
        flag = false;
        if (i < 0)
        {
            imageview1.setVisibility(0);
            imageview1.setImageResource(0x7f020001);
            imageview.setImageResource(0x7f020026);
            FriendInfo friendinfo;
            if (SteamWebApi.IsLoggedIn())
            {
                friendinfo = SteamCommunityApplication.GetInstance().GetFriendInfoDB().GetFriendInfo(Long.valueOf(SteamWebApi.GetLoginSteamID()));
            } else
            {
                textview1.setText(0x7f070008);
                friendinfo = null;
            }
            flag = false;
            if (friendinfo != null)
            {
                flag1 = friendinfo.HasPresentationData();
                flag = false;
                if (flag1)
                {
                    AndroidUtils.setTextViewText(textview1, friendinfo.m_personaName);
                    friendinfo.IsAvatarSmallLoaded();
                    imageview.setImageBitmap(friendinfo.GetAvatarSmall());
                    steamdbservice = SteamCommunityApplication.GetInstance().GetSteamDB();
                    flag = false;
                    if (steamdbservice != null)
                    {
                        flag2 = steamdbservice.getSteamUmqConnectionState().isConnected();
                        flag = false;
                        if (flag2)
                        {
                            imageview1.setImageResource(0x7f020002);
                            flag = true;
                        }
                    }
                }
            }
        }
        resources = getActivity().getResources();
        if (flag)
        {
            j = 0x7f060014;
        } else
        {
            j = 0x7f060012;
        }
        k = resources.getColor(j);
        textview1.setTextColor(k);
        textview2.setTextColor(k);
    }

    public void onActivityCreated(Bundle bundle)
    {
        super.onActivityCreated(bundle);
        m_splitViewNavigation = getActivity().findViewById(0x7f090003);
        m_splitViewContents = getActivity().findViewById(0x7f090000);
        View view = getActivity().findViewById(0x7f090026);
        if (view != null)
        {
            view.setOnClickListener(new android.view.View.OnClickListener() {

                final NavigationFragment this$0;

                public void onClick(View view2)
                {
                    onNavActivationButtonClicked();
                }

            
            {
                this$0 = NavigationFragment.this;
                super();
            }
            });
        }
        View view1 = getActivity().findViewById(0x7f090024);
        if (view1 != null)
        {
            view1.setOnClickListener(new android.view.View.OnClickListener() {

                final NavigationFragment this$0;

                public void onClick(View view2)
                {
                    m_navItemClickListener.onClick(getActivity().findViewById(0x7f090025));
                }

            
            {
                this$0 = NavigationFragment.this;
                super();
            }
            });
        }
        if (m_listView == null)
        {
            m_listView = getListView();
            m_listView.setTextFilterEnabled(false);
        }
        if (m_itemsAvailable.isEmpty())
        {
            NavigationItem_UriActivity_Profile navigationitem_uriactivity_profile = m_itemProfile;
            navigationitem_uriactivity_profile.resid_category = 0x7f07000d;
            navigationitem_uriactivity_profile.resid_icon = 0x7f020018;
            navigationitem_uriactivity_profile.resid_name = 0x7f07001e;
            navigationitem_uriactivity_profile.info = "";
            NavigationItem_ClassActivity_SingleTop navigationitem_classactivity_singletop = new NavigationItem_ClassActivity_SingleTop();
            navigationitem_classactivity_singletop.activity = com/valvesoftware/android/steam/community/activity/CommunityActivity;
            navigationitem_classactivity_singletop.resid_category = 0x7f07000d;
            navigationitem_classactivity_singletop.resid_icon = 0x7f020018;
            navigationitem_classactivity_singletop.resid_name = 0x7f07000e;
            navigationitem_classactivity_singletop.info = "";
            m_itemsAvailable.add(navigationitem_classactivity_singletop);
            NavigationItem_ClassActivity_SingleTop navigationitem_classactivity_singletop1 = new NavigationItem_ClassActivity_SingleTop();
            navigationitem_classactivity_singletop1.activity = com/valvesoftware/android/steam/community/activity/CommunityGroupsActivity;
            navigationitem_classactivity_singletop1.resid_category = 0x7f07000d;
            navigationitem_classactivity_singletop1.resid_icon = 0x7f020019;
            navigationitem_classactivity_singletop1.resid_name = 0x7f070029;
            navigationitem_classactivity_singletop1.info = "";
            m_itemsAvailable.add(navigationitem_classactivity_singletop1);
            NavigationItem_UriActivity_Blotter navigationitem_uriactivity_blotter = new NavigationItem_UriActivity_Blotter();
            navigationitem_uriactivity_blotter.resid_category = 0x7f07000d;
            navigationitem_uriactivity_blotter.resid_icon = 0x7f020014;
            navigationitem_uriactivity_blotter.resid_name = 0x7f07003a;
            navigationitem_uriactivity_blotter.info = "";
            m_itemsAvailable.add(navigationitem_uriactivity_blotter);
            NavigationItem_UriActivity_Catalog navigationitem_uriactivity_catalog = new NavigationItem_UriActivity_Catalog();
            navigationitem_uriactivity_catalog.m_bShowIfNotSignedIn = true;
            navigationitem_uriactivity_catalog.resid_category = 0x7f070002;
            navigationitem_uriactivity_catalog.resid_icon = 0x7f02001c;
            navigationitem_uriactivity_catalog.resid_name = 0x7f07002b;
            navigationitem_uriactivity_catalog.info = "";
            m_itemsAvailable.add(navigationitem_uriactivity_catalog);
            NavigationItem_UriActivity_Wishlist navigationitem_uriactivity_wishlist = new NavigationItem_UriActivity_Wishlist();
            navigationitem_uriactivity_wishlist.resid_category = 0x7f070002;
            navigationitem_uriactivity_wishlist.resid_icon = 0x7f02001d;
            navigationitem_uriactivity_wishlist.resid_name = 0x7f070005;
            navigationitem_uriactivity_wishlist.info = "";
            m_itemsAvailable.add(navigationitem_uriactivity_wishlist);
            NavigationItem_UriActivity_Cart navigationitem_uriactivity_cart = new NavigationItem_UriActivity_Cart();
            navigationitem_uriactivity_cart.resid_category = 0x7f070002;
            navigationitem_uriactivity_cart.resid_icon = 0x7f020015;
            navigationitem_uriactivity_cart.resid_name = 0x7f070003;
            navigationitem_uriactivity_cart.info = "";
            m_itemsAvailable.add(navigationitem_uriactivity_cart);
            NavigationItem_UriActivity_StoreSearch navigationitem_uriactivity_storesearch = new NavigationItem_UriActivity_StoreSearch();
            navigationitem_uriactivity_storesearch.m_bShowIfNotSignedIn = true;
            navigationitem_uriactivity_storesearch.resid_category = 0x7f070002;
            navigationitem_uriactivity_storesearch.resid_icon = 0x7f02001a;
            navigationitem_uriactivity_storesearch.resid_name = 0x7f070004;
            navigationitem_uriactivity_storesearch.info = "";
            m_itemsAvailable.add(navigationitem_uriactivity_storesearch);
            if (SteamCommunityApplication.GetInstance().IsOverTheAirVersion())
            {
                NavigationItem_UriActivity_Feeds_SteamSpecials navigationitem_uriactivity_feeds_steamspecials = new NavigationItem_UriActivity_Feeds_SteamSpecials();
                navigationitem_uriactivity_feeds_steamspecials.m_bShowIfNotSignedIn = true;
                navigationitem_uriactivity_feeds_steamspecials.resid_category = 0x7f070039;
                navigationitem_uriactivity_feeds_steamspecials.resid_icon = 0x7f020017;
                navigationitem_uriactivity_feeds_steamspecials.resid_name = 0x7f0700a4;
                navigationitem_uriactivity_feeds_steamspecials.info = "";
                m_itemsAvailable.add(navigationitem_uriactivity_feeds_steamspecials);
            }
            NavigationItem_UriActivity_Feeds_SteamNews navigationitem_uriactivity_feeds_steamnews = new NavigationItem_UriActivity_Feeds_SteamNews();
            navigationitem_uriactivity_feeds_steamnews.m_bShowIfNotSignedIn = true;
            navigationitem_uriactivity_feeds_steamnews.resid_category = 0x7f070039;
            navigationitem_uriactivity_feeds_steamnews.resid_icon = 0x7f020017;
            navigationitem_uriactivity_feeds_steamnews.resid_name = 0x7f07000f;
            navigationitem_uriactivity_feeds_steamnews.info = "";
            m_itemsAvailable.add(navigationitem_uriactivity_feeds_steamnews);
            NavigationItem_UriActivity_Feeds_Syndicated navigationitem_uriactivity_feeds_syndicated = new NavigationItem_UriActivity_Feeds_Syndicated();
            navigationitem_uriactivity_feeds_syndicated.m_bShowIfNotSignedIn = true;
            navigationitem_uriactivity_feeds_syndicated.resid_category = 0x7f070039;
            navigationitem_uriactivity_feeds_syndicated.resid_icon = 0x7f020017;
            navigationitem_uriactivity_feeds_syndicated.resid_name = 0x7f070010;
            navigationitem_uriactivity_feeds_syndicated.info = "";
            m_itemsAvailable.add(navigationitem_uriactivity_feeds_syndicated);
            NavigationItem_ClassActivity_SingleTop navigationitem_classactivity_singletop2 = new NavigationItem_ClassActivity_SingleTop();
            navigationitem_classactivity_singletop2.m_bShowIfNotSignedIn = true;
            navigationitem_classactivity_singletop2.activity = com/valvesoftware/android/steam/community/activity/SettingsActivity;
            navigationitem_classactivity_singletop2.resid_category = 0x7f070006;
            navigationitem_classactivity_singletop2.resid_icon = 0x7f02001b;
            navigationitem_classactivity_singletop2.resid_name = 0x7f070007;
            navigationitem_classactivity_singletop2.info = "";
            m_itemsAvailable.add(navigationitem_classactivity_singletop2);
            NavigationItem_UriActivity_AccountDetails navigationitem_uriactivity_accountdetails = new NavigationItem_UriActivity_AccountDetails();
            navigationitem_uriactivity_accountdetails.m_bShowIfNotSignedIn = false;
            navigationitem_uriactivity_accountdetails.resid_category = 0x7f070006;
            navigationitem_uriactivity_accountdetails.resid_icon = 0x7f02001b;
            navigationitem_uriactivity_accountdetails.resid_name = 0x7f07000a;
            navigationitem_uriactivity_accountdetails.info = "";
            m_itemsAvailable.add(navigationitem_uriactivity_accountdetails);
            NavigationItem_ExitApplication navigationitem_exitapplication = new NavigationItem_ExitApplication();
            navigationitem_exitapplication.m_bShowIfNotSignedIn = true;
            navigationitem_exitapplication.resid_category = 0x7f070015;
            navigationitem_exitapplication.resid_icon = 0x7f020016;
            m_itemsAvailable.add(navigationitem_exitapplication);
        }
        m_adapter = new NavigationItemListAdapter();
        setListAdapter(m_adapter);
    }

    public View onCreateView(LayoutInflater layoutinflater, ViewGroup viewgroup, Bundle bundle)
    {
        return layoutinflater.inflate(0x7f03000d, viewgroup, false);
    }

    public void onNavActivationButtonClicked()
    {
        if (!m_bNavAnimating && (SteamWebApi.IsLoggedIn() || m_bNavActive))
        {
            m_bNavAnimating = true;
            View view;
            if (!m_bNavActive)
            {
                m_bNavActive = true;
                Animation animation1 = AnimationUtils.loadAnimation(getActivity(), 0x7f040003);
                animation1.setAnimationListener(m_animListener);
                m_splitViewNavigation.setVisibility(0);
                m_splitViewNavigation.startAnimation(animation1);
                m_splitViewContents.startAnimation(AnimationUtils.loadAnimation(getActivity(), 0x7f040000));
                onNavSidebarPrepareForActivation();
            } else
            {
                m_bNavActive = false;
                Animation animation = AnimationUtils.loadAnimation(getActivity(), 0x7f040002);
                animation.setAnimationListener(m_animListener);
                m_splitViewNavigation.startAnimation(animation);
                m_splitViewContents.startAnimation(AnimationUtils.loadAnimation(getActivity(), 0x7f040001));
            }
            view = getActivity().findViewById(0x7f090035);
            if (view != null)
            {
                int i;
                if (m_bNavActive)
                {
                    i = 0x7f020004;
                } else
                {
                    i = 0x7f020003;
                }
                view.setBackgroundResource(i);
                return;
            }
        }
    }

    public void onPause()
    {
        super.onPause();
        overrideActivityOnConfigurationChanged();
    }

    public void onResume()
    {
        super.onResume();
        onNavSidebarPrepareForActivation();
    }

    public boolean overrideActivityOnBackPressed()
    {
        if (m_bNavAnimating)
        {
            return true;
        }
        if (m_bNavActive)
        {
            onNavActivationButtonClicked();
            return true;
        } else
        {
            return false;
        }
    }

    public void overrideActivityOnConfigurationChanged()
    {
        if (!m_bNavActive)
        {
            return;
        }
        if (!m_bNavAnimating)
        {
            onNavActivationButtonClicked();
            return;
        } else
        {
            m_bRequestToHideNavWhileAnimating = true;
            return;
        }
    }

    static 
    {
        URI_Catalog = Uri.parse((new StringBuilder()).append("steammobile://opencategoryurl?url=").append(Config.URL_STORE_BASE_INSECURE).append("/api/mobilestorefrontcategories/v0001").toString());
        URI_Store_Search = Uri.parse((new StringBuilder()).append("steammobile://opencategoryurl?url=").append(Config.URL_STORE_BASE_INSECURE).append("/api/mobilestorefrontindexcategories/v0001").toString());
        URI_AccountDetails = Uri.parse((new StringBuilder()).append("steammobile://opencategoryurl?url=").append(Config.URL_STORE_BASE_INSECURE).append("/api/mobilestorefrontaccountdetailscategories/v0001").toString());
        URI_Feeds_SteamNews = Uri.parse((new StringBuilder()).append("steammobile://openurl?url=").append(Config.URL_STORE_BASE).append("/mobilenews/steamnews").toString());
        URI_Feeds_SteamSpecials = Uri.parse((new StringBuilder()).append("steammobile://openurl?url=").append(Config.URL_STORE_BASE).append("/mobilenews/newsposts?feed=steam_specials").toString());
        URI_Feeds_Syndicated = Uri.parse((new StringBuilder()).append("steammobile://openurl?url=").append(Config.URL_STORE_BASE).append("/mobilenews/syndicatednews").toString());
        URI_Wishlist = Uri.parse((new StringBuilder()).append("steammobile://openurl?url=").append(Config.URL_COMMUNITY_BASE).append("/my/wishlist/").toString());
        URI_Cart = Uri.parse((new StringBuilder()).append("steammobile://openurl?url=").append(Config.URL_STORE_BASE).append("/mobilecart/").toString());
        URI_Blotter = Uri.parse((new StringBuilder()).append("steammobile://openurl?url=").append(Config.URL_COMMUNITY_BASE).append("/my/blotter/").toString());
    }




/*
    static boolean access$102(NavigationFragment navigationfragment, boolean flag)
    {
        navigationfragment.m_bNavAnimating = flag;
        return flag;
    }

*/







/*
    static boolean access$602(NavigationFragment navigationfragment, boolean flag)
    {
        navigationfragment.m_bRequestToHideNavWhileAnimating = flag;
        return flag;
    }

*/
}
