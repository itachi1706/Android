// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

// Referenced classes of package com.valvesoftware.android.steam.community:
//            SteamUmqCommunicationService

private class <init> extends BroadcastReceiver
{

    public boolean m_bIsScreenActive;
    public long m_timeLastApplicationActivity;
    public long m_timeScreenStateChanged;
    final SteamUmqCommunicationService this$0;

    public void onReceive(Context context, Intent intent)
    {
        if (intent.getAction().equals("android.intent.action.SCREEN_OFF"))
        {
            m_bIsScreenActive = false;
            m_timeScreenStateChanged = System.currentTimeMillis();
        } else
        if (intent.getAction().equals("android.intent.action.SCREEN_ON"))
        {
            m_bIsScreenActive = true;
            m_timeScreenStateChanged = System.currentTimeMillis();
            SvcReq_UmqActivity(null);
            return;
        }
    }

    private ()
    {
        this$0 = SteamUmqCommunicationService.this;
        super();
        m_bIsScreenActive = true;
        m_timeScreenStateChanged = System.currentTimeMillis();
        m_timeLastApplicationActivity = System.currentTimeMillis();
    }

    m_timeLastApplicationActivity(m_timeLastApplicationActivity m_timelastapplicationactivity)
    {
        this();
    }
}
