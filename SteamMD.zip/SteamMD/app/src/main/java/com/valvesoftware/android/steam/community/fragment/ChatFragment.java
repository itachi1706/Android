// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.fragment;

import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.text.ClipboardManager;
import android.text.Editable;
import android.text.SpannableString;
import android.text.TextWatcher;
import android.text.method.LinkMovementMethod;
import android.text.style.URLSpan;
import android.text.util.Linkify;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.AbsListView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import com.valvesoftware.android.steam.community.AndroidUtils;
import com.valvesoftware.android.steam.community.FriendInfo;
import com.valvesoftware.android.steam.community.FriendInfoDB;
import com.valvesoftware.android.steam.community.ISteamUmqCommunicationDatabase;
import com.valvesoftware.android.steam.community.SettingInfo;
import com.valvesoftware.android.steam.community.SettingInfoDB;
import com.valvesoftware.android.steam.community.SteamCommunityApplication;
import com.valvesoftware.android.steam.community.SteamDBService;
import com.valvesoftware.android.steam.community.SteamWebApi;
import com.valvesoftware.android.steam.community.activity.ActivityHelper;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import org.json.JSONException;
import org.json.JSONObject;

// Referenced classes of package com.valvesoftware.android.steam.community.fragment:
//            TitlebarFragment

public class ChatFragment extends Fragment
    implements android.view.View.OnClickListener
{
    private class ChatViewAdapter extends ArrayAdapter
    {

        private boolean m_bFilledUpFullView;
        private boolean m_bTyping;
        private LayoutInflater m_layoutInflater;
        private ArrayList m_list;
        private android.view.View.OnLongClickListener m_longClickHandler;
        private android.view.View.OnLongClickListener m_longClickLoadMore;
        private com.valvesoftware.android.steam.community.ISteamUmqCommunicationDatabase.Message m_msgLastLoaded;
        private int m_numMessagesFromConversationInfoFetched;
        private android.widget.AbsListView.OnScrollListener m_scrollLoadMore;
        final ChatFragment this$0;

        public boolean LoadMoreMessages()
        {
            SteamDBService steamdbservice = SteamCommunityApplication.GetInstance().GetSteamDB();
            if (steamdbservice == null)
            {
                return false;
            }
            m_chatViewMessages.remove(ChatFragment.GetLoadMoreMessage());
            if (m_numMessagesFromConversationInfoFetched < m_userConversationInfo.numMsgsTotal)
            {
                m_numMessagesFromConversationInfoFetched = 10 + m_numMessagesFromConversationInfoFetched;
                m_chatViewMessages.addAll(steamdbservice.getSteamUmqCommunicationServiceDB().selectMessagesWithUser(SteamWebApi.GetLoginSteamID(), m_partnerSteamId, 10, m_msgLastLoaded));
                if (m_numMessagesFromConversationInfoFetched < m_userConversationInfo.numMsgsTotal)
                {
                    m_msgLastLoaded = (com.valvesoftware.android.steam.community.ISteamUmqCommunicationDatabase.Message)m_chatViewMessages.get(-1 + m_chatViewMessages.size());
                    m_chatViewMessages.add(ChatFragment.GetLoadMoreMessage());
                    return true;
                }
            }
            m_chatViewMessages.add(ChatFragment.GetHeadlineMessage());
            return false;
        }

        public boolean LoadMoreMessagesInView()
        {
            int i = m_chatViewContents.getFirstVisiblePosition();
            int j = m_chatViewMessages.size();
            if (m_bFilledUpFullView)
            {
                m_chatViewContents.setStackFromBottom(false);
            }
            boolean flag = LoadMoreMessages();
            notifyDataSetChanged();
            if (m_bFilledUpFullView)
            {
                int k = (i + m_chatViewMessages.size()) - j;
                m_chatViewContents.setSelection(k);
                m_chatViewContents.setStackFromBottom(true);
            }
            return flag;
        }

        public void MarkTyping(boolean flag)
        {
            if (m_bTyping != flag)
            {
                if (m_bTyping)
                {
                    m_list.remove(ChatFragment.GetTypingMessage());
                } else
                {
                    m_list.add(0, ChatFragment.GetTypingMessage());
                }
                m_bTyping = flag;
            }
        }

        public void attach(ListView listview)
        {
            listview.setAdapter(this);
            m_scrollLoadMore = listview. new android.widget.AbsListView.OnScrollListener() {

                final ChatViewAdapter this$1;
                final ListView val$lv;

                public void onScroll(AbsListView abslistview, int i, int j, int k)
                {
                    if (i == 0)
                    {
                        lv.postDelayed(new Runnable() {

                            final ChatViewAdapter._cls3 this$2;

                            public void run()
                            {
                                if (!m_chatViewMessages.isEmpty() && m_chatViewMessages.get(-1 + m_chatViewMessages.size()) == ChatFragment.GetLoadMoreMessage() && m_chatViewContents.getFirstVisiblePosition() == 0)
                                {
                                    m_chatViewAdapter.LoadMoreMessagesInView();
                                }
                            }

            
            {
                this$2 = ChatViewAdapter._cls3.this;
                super();
            }
                        }, 100L);
                    } else
                    if (i > 0)
                    {
                        m_bFilledUpFullView = true;
                        return;
                    }
                }

                public void onScrollStateChanged(AbsListView abslistview, int i)
                {
                }

            
            {
                this$1 = final_chatviewadapter;
                lv = ListView.this;
                super();
            }
            };
            listview.setOnScrollListener(m_scrollLoadMore);
        }

        public View getDropDownView(int i, View view, ViewGroup viewgroup)
        {
            return getView(i, view, viewgroup);
        }

        public View getView(int i, View view, ViewGroup viewgroup)
        {
            com.valvesoftware.android.steam.community.ISteamUmqCommunicationDatabase.Message message;
            TextView textview;
            TextView textview1;
            DateFormat dateformat;
            message = (com.valvesoftware.android.steam.community.ISteamUmqCommunicationDatabase.Message)m_list.get((-1 + m_list.size()) - i);
            textview = null;
            if (view != null)
            {
                if (message.bIncoming)
                {
                    textview = (TextView)view.findViewById(0x7f09000f);
                    if (textview == null)
                    {
                        view = null;
                    }
                } else
                {
                    textview = (TextView)view.findViewById(0x7f090010);
                    if (textview == null)
                    {
                        view = null;
                    }
                }
            }
            if (view == null)
            {
                if (message.bIncoming)
                {
                    LayoutInflater layoutinflater1 = m_layoutInflater;
                    int k;
                    if (m_eKnownLayout == Layout.TextOnly)
                    {
                        k = 0x7f030003;
                    } else
                    {
                        k = 0x7f030002;
                    }
                    view = (LinearLayout)layoutinflater1.inflate(k, null);
                    textview = (TextView)view.findViewById(0x7f09000f);
                } else
                {
                    LayoutInflater layoutinflater = m_layoutInflater;
                    int j;
                    if (m_eKnownLayout == Layout.TextOnly)
                    {
                        j = 0x7f030006;
                    } else
                    if (m_eKnownLayout == Layout.Bubbles)
                    {
                        j = 0x7f030004;
                    } else
                    {
                        j = 0x7f030005;
                    }
                    view = (LinearLayout)layoutinflater.inflate(j, null);
                    textview = (TextView)view.findViewById(0x7f090010);
                }
            }
            textview1 = (TextView)view.findViewById(0x7f09000d);
            if (textview1 == null) goto _L2; else goto _L1
_L1:
            boolean flag;
            boolean flag1;
            if (message != ChatFragment.GetLoadMoreMessage() && message != ChatFragment.GetHeadlineMessage())
            {
                flag = true;
            } else
            {
                flag = false;
            }
            if (i == 0)
            {
                flag1 = flag;
            } else
            {
                flag1 = false;
                if (flag)
                {
                    com.valvesoftware.android.steam.community.ISteamUmqCommunicationDatabase.Message message1 = (com.valvesoftware.android.steam.community.ISteamUmqCommunicationDatabase.Message)m_list.get((-1 + m_list.size()) - (i - 1));
                    if (message1 == ChatFragment.GetLoadMoreMessage() || message1 == ChatFragment.GetHeadlineMessage())
                    {
                        if (message.msgtime != null)
                        {
                            flag1 = true;
                        } else
                        {
                            flag1 = false;
                        }
                    } else
                    {
                        Calendar calendar = message.msgtime;
                        flag1 = false;
                        if (calendar != null)
                        {
                            Calendar calendar1 = message1.msgtime;
                            flag1 = false;
                            if (calendar1 != null)
                            {
                                long l = message.msgtime.getTimeInMillis() - message1.msgtime.getTimeInMillis();
                                Calendar calendar2 = Calendar.getInstance();
                                calendar2.setTimeInMillis(message1.msgtime.getTimeInMillis());
                                calendar2.set(11, 0);
                                calendar2.set(12, 0);
                                calendar2.set(13, 0);
                                calendar2.set(14, 0);
                                Calendar calendar3 = Calendar.getInstance();
                                calendar3.setTimeInMillis(message.msgtime.getTimeInMillis());
                                calendar3.set(11, 0);
                                calendar3.set(12, 0);
                                calendar3.set(13, 0);
                                calendar3.set(14, 0);
                                boolean flag2;
                                if (calendar2.getTimeInMillis() != calendar3.getTimeInMillis())
                                {
                                    flag2 = true;
                                } else
                                {
                                    flag2 = false;
                                }
                                if (m_numSecondsTimestamps <= 0)
                                {
                                    flag1 = flag2;
                                } else
                                if (l > (long)(1000 * m_numSecondsTimestamps) || m_numSecondsTimestamps == 0x15180 && flag2)
                                {
                                    flag1 = true;
                                } else
                                {
                                    flag1 = false;
                                }
                            }
                        }
                    }
                }
            }
            if (!flag1 || message.msgtime == null)
            {
                break MISSING_BLOCK_LABEL_728;
            }
            m_numSecondsTimestamps;
            JVM INSTR lookupswitch 2: default 204
        //                       0: 719
        //                       86400: 719;
               goto _L3 _L4 _L4
_L3:
            dateformat = SimpleDateFormat.getDateTimeInstance(1, 3);
_L5:
            textview1.setText(dateformat.format(message.msgtime.getTime()));
            textview1.setVisibility(0);
_L2:
            ImageView imageview = (ImageView)view.findViewById(0x7f09000e);
            if (imageview != null)
            {
                if (message == ChatFragment.GetHeadlineMessage())
                {
                    imageview.setImageResource(0x7f020024);
                } else
                {
                    FriendInfo friendinfo;
                    if (message.bIncoming)
                    {
                        friendinfo = m_partner;
                    } else
                    {
                        friendinfo = m_myself;
                    }
                    imageview.setImageBitmap(friendinfo.GetAvatarSmall());
                }
            }
            FormatMessageText(message, textview);
            if (message == ChatFragment.GetLoadMoreMessage())
            {
                textview.setOnLongClickListener(m_longClickLoadMore);
                return view;
            } else
            {
                textview.setOnLongClickListener(m_longClickHandler);
                return view;
            }
_L4:
            dateformat = SimpleDateFormat.getDateInstance(1);
              goto _L5
            textview1.setVisibility(8);
              goto _L2
        }


/*
        static boolean access$802(ChatViewAdapter chatviewadapter, boolean flag)
        {
            chatviewadapter.m_bFilledUpFullView = flag;
            return flag;
        }

*/

        public ChatViewAdapter(Context context, ArrayList arraylist, LayoutInflater layoutinflater)
        {
            this$0 = ChatFragment.this;
            super(context, -1, arraylist);
            m_numMessagesFromConversationInfoFetched = 0;
            m_msgLastLoaded = null;
            m_bTyping = false;
            m_longClickHandler = null;
            m_longClickLoadMore = null;
            m_scrollLoadMore = null;
            m_bFilledUpFullView = false;
            m_list = arraylist;
            m_layoutInflater = layoutinflater;
            m_longClickHandler = new _cls1();
            m_longClickLoadMore = new _cls2();
        }
    }

    public static final class Layout extends Enum
    {

        private static final Layout $VALUES[];
        public static final Layout Bubbles;
        public static final Layout BubblesLeft;
        public static final Layout TextOnly;

        public static Layout valueOf(String s)
        {
            return (Layout)Enum.valueOf(com/valvesoftware/android/steam/community/fragment/ChatFragment$Layout, s);
        }

        public static Layout[] values()
        {
            return (Layout[])$VALUES.clone();
        }

        static 
        {
            Bubbles = new Layout("Bubbles", 0);
            BubblesLeft = new Layout("BubblesLeft", 1);
            TextOnly = new Layout("TextOnly", 2);
            Layout alayout[] = new Layout[3];
            alayout[0] = Bubbles;
            alayout[1] = BubblesLeft;
            alayout[2] = TextOnly;
            $VALUES = alayout;
        }

        private Layout(String s, int i)
        {
            super(s, i);
        }
    }

    private static class ParsedMessageData
    {

        String text;
        String type;

        private ParsedMessageData()
        {
        }

    }

    private class UnsafeClickableURL extends URLSpan
    {

        private boolean m_bShowUnsafeWarning;
        final ChatFragment this$0;

        public void HandleUserProcceedSelected(View view)
        {
            try
            {
                super.onClick(view);
                return;
            }
            catch (Exception exception)
            {
                return;
            }
        }

        public void onClick(View view)
        {
            if (!m_bShowUnsafeWarning)
            {
                HandleUserProcceedSelected(view);
                return;
            } else
            {
                android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(getActivity());
                builder.setTitle(0x7f0700a0);
                builder.setMessage((new StringBuilder()).append(getActivity().getString(0x7f0700a1)).append("\n\n").append(getURL()).toString());
                builder.setPositiveButton(0x7f07009f, view. new android.content.DialogInterface.OnClickListener() {

                    final UnsafeClickableURL this$1;
                    final View val$finalView;

                    public void onClick(DialogInterface dialoginterface, int i)
                    {
                        HandleUserProcceedSelected(finalView);
                    }

            
            {
                this$1 = final_unsafeclickableurl;
                finalView = View.this;
                super();
            }
                });
                builder.setNegativeButton(0x7f07001f, null);
                builder.create().show();
                return;
            }
        }

        public UnsafeClickableURL(URLSpan urlspan, boolean flag)
        {
            this$0 = ChatFragment.this;
            super(urlspan.getURL());
            m_bShowUnsafeWarning = false;
            m_bShowUnsafeWarning = flag;
        }
    }


    private static com.valvesoftware.android.steam.community.ISteamUmqCommunicationDatabase.Message m_msgHeadline = null;
    private static com.valvesoftware.android.steam.community.ISteamUmqCommunicationDatabase.Message m_msgLoadMore = null;
    private static com.valvesoftware.android.steam.community.ISteamUmqCommunicationDatabase.Message m_msgTyping = null;
    private static final String s_safeURIs[] = {
        "steampowered.com", "steamgames.com", "steamcommunity.com", "valvesoftware.com", "youtube.com", "live.com", "msn.com", "myspace.com", "facebook.com", "hi5.com", 
        "wikipedia.org", "orkut.com", "rapidshare.com", "blogger.com", "megaupload.com", "friendster.com", "fotolog.net", "google.fr", "baidu.com", "microsoft.com", 
        "ebay.com", "shacknews.com", "bbc.co.uk", "cnn.com", "foxsports.com", "pcmag.com", "nytimes.com", "flickr.com", "amazon.com", "veoh.com", 
        "pcgamer.com", "metacritic.com", "fileplanet.com", "gamespot.com", "gametap.com", "ign.com", "kotaku.com", "xfire.com", "pcgames.gwn.com", "gamezone.com", 
        "gamesradar.com", "digg.com", "engadget.com", "gizmodo.com", "gamesforwindows.com", "xbox.com", "cnet.com", "l4d.com", "teamfortress.com", "tf2.com", 
        "half-life2.com", "aperturescience.com", "dayofdefeat.com", "dota2.com", "steamtranslation.ru", "playdota.com"
    };
    private boolean m_bCanSendMessages;
    private boolean m_bCanSendTypingNotification;
    private boolean m_bChatOptionsVisible;
    private boolean m_bPaused;
    private boolean m_bRequiresMarkMessagesAsRead;
    private ChatViewAdapter m_chatViewAdapter;
    private ListView m_chatViewContents;
    private Button m_chatViewMessageButton;
    private EditText m_chatViewMessageText;
    private ArrayList m_chatViewMessages;
    private TextView m_chatViewStatus;
    private Layout m_eKnownLayout;
    private com.valvesoftware.android.steam.community.GenericListDB.ListItemUpdatedListener m_friendsListener;
    InputMethodManager m_inputMethodManager;
    private BroadcastReceiver m_intentReceiver;
    private LayoutInflater m_layoutInflater;
    private FriendInfo m_myself;
    private int m_numSecondsTimestamps;
    private TitlebarFragment.TitlebarButtonHander m_optionsHandler;
    private FriendInfo m_partner;
    private String m_partnerSteamId;
    private ArrayList m_sentMsgs;
    private com.valvesoftware.android.steam.community.ISteamUmqCommunicationDatabase.UserConversationInfo m_userConversationInfo;

    public ChatFragment()
    {
        m_eKnownLayout = Layout.Bubbles;
        m_numSecondsTimestamps = 900;
        m_layoutInflater = null;
        m_inputMethodManager = null;
        m_chatViewContents = null;
        m_chatViewAdapter = null;
        m_userConversationInfo = null;
        m_chatViewMessages = null;
        m_chatViewStatus = null;
        m_chatViewMessageText = null;
        m_chatViewMessageButton = null;
        m_bCanSendMessages = false;
        m_bCanSendTypingNotification = true;
        m_bPaused = true;
        m_bRequiresMarkMessagesAsRead = false;
        m_intentReceiver = new BroadcastReceiver() {

            final ChatFragment this$0;

            public void onReceive(Context context, Intent intent)
            {
                if (getActivity() == null)
                {
                    return;
                } else
                {
                    OnChatUpdated(intent);
                    return;
                }
            }

            
            {
                this$0 = ChatFragment.this;
                super();
            }
        };
        m_sentMsgs = new ArrayList();
        m_optionsHandler = new TitlebarFragment.TitlebarButtonHander() {

            final ChatFragment this$0;

            public void onTitlebarButtonClicked(int i)
            {
                if (!SteamWebApi.IsLoggedIn())
                {
                    return;
                } else
                {
                    toggleOptions();
                    return;
                }
            }

            
            {
                this$0 = ChatFragment.this;
                super();
            }
        };
        m_bChatOptionsVisible = false;
        m_friendsListener = new com.valvesoftware.android.steam.community.GenericListDB.ListItemUpdatedListener() {

            final ChatFragment this$0;

            public void OnListItemInfoUpdateError(com.valvesoftware.android.steam.community.SteamWebApi.RequestBase requestbase)
            {
            }

            public void OnListItemInfoUpdated(ArrayList arraylist, boolean flag)
            {
                UpdateStatusBar();
            }

            public void OnListRefreshError(com.valvesoftware.android.steam.community.SteamWebApi.RequestBase requestbase, boolean flag)
            {
            }

            public void OnListRequestsInProgress(boolean flag)
            {
            }

            
            {
                this$0 = ChatFragment.this;
                super();
            }
        };
    }

    private void ClearMessageBox()
    {
        m_chatViewMessageText.setText("");
        m_chatViewMessageButton.setEnabled(false);
    }

    private void ControlsSetup()
    {
        FragmentActivity fragmentactivity = getActivity();
        m_chatViewMessages = new ArrayList();
        if (fragmentactivity != null)
        {
            m_chatViewAdapter = new ChatViewAdapter(fragmentactivity, m_chatViewMessages, m_layoutInflater);
            m_chatViewAdapter.attach(m_chatViewContents);
        }
        View view;
        if (fragmentactivity != null)
        {
            view = fragmentactivity.findViewById(0x7f090007);
        } else
        {
            view = null;
        }
        if (view != null)
        {
            view.setOnClickListener(new android.view.View.OnClickListener() {

                final ChatFragment this$0;

                public void onClick(View view1)
                {
                    clearChatHistory();
                }

            
            {
                this$0 = ChatFragment.this;
                super();
            }
            });
        }
        m_chatViewMessageButton.setOnClickListener(this);
        m_chatViewMessageText.addTextChangedListener(new TextWatcher() {

            final ChatFragment this$0;

            public void afterTextChanged(Editable editable)
            {
                UpdateSendButton();
                SendTypingNotification();
            }

            public void beforeTextChanged(CharSequence charsequence, int i, int j, int k)
            {
            }

            public void onTextChanged(CharSequence charsequence, int i, int j, int k)
            {
            }

            
            {
                this$0 = ChatFragment.this;
                super();
            }
        });
        m_chatViewMessageText.setOnEditorActionListener(new android.widget.TextView.OnEditorActionListener() {

            final ChatFragment this$0;

            public boolean onEditorAction(TextView textview, int i, KeyEvent keyevent)
            {
                if (i == 4 || i == 6 || i == 0)
                {
                    onClick(m_chatViewMessageButton);
                }
                return true;
            }

            
            {
                this$0 = ChatFragment.this;
                super();
            }
        });
        m_chatViewMessageText.post(new Runnable() {

            final ChatFragment this$0;

            public void run()
            {
                m_chatViewMessageText.requestFocusFromTouch();
            }

            
            {
                this$0 = ChatFragment.this;
                super();
            }
        });
    }

    private void FormatMessageText(com.valvesoftware.android.steam.community.ISteamUmqCommunicationDatabase.Message message, TextView textview)
    {
        int k1 = m_numSecondsTimestamps;
        String s;
        s = null;
        if (k1 > 0)
        {
            break MISSING_BLOCK_LABEL_95;
        }
        com.valvesoftware.android.steam.community.ISteamUmqCommunicationDatabase.Message message1 = GetLoadMoreMessage();
        s = null;
        if (message == message1)
        {
            break MISSING_BLOCK_LABEL_95;
        }
        com.valvesoftware.android.steam.community.ISteamUmqCommunicationDatabase.Message message2 = GetHeadlineMessage();
        s = null;
        if (message == message2)
        {
            break MISSING_BLOCK_LABEL_95;
        }
        Calendar calendar = message.msgtime;
        s = null;
        if (calendar == null)
        {
            break MISSING_BLOCK_LABEL_95;
        }
        String s1 = (new StringBuilder()).append(SimpleDateFormat.getTimeInstance(3).format(message.msgtime.getTime())).append(" : ").toString();
        s = s1;
_L18:
        if (s == null) goto _L2; else goto _L1
_L1:
        SpannableString spannablestring = SpannableString.valueOf((new StringBuilder()).append(s).append(message.bindata).toString());
_L11:
        Object aobj[];
        Linkify.addLinks(spannablestring, 15);
        aobj = spannablestring.getSpans(0, spannablestring.length(), java/lang/Object);
        if (aobj == null) goto _L4; else goto _L3
_L3:
        if (aobj.length <= 0) goto _L4; else goto _L5
_L5:
        boolean flag = SteamCommunityApplication.GetInstance().GetSettingInfoDB().m_settingChatsAlertLinks.getBooleanValue(SteamCommunityApplication.GetInstance().getApplicationContext());
        int j = 0;
_L19:
        if (j >= aobj.length) goto _L4; else goto _L6
_L6:
        Object obj;
        int k;
        int l;
        int i1;
        obj = aobj[j];
        k = spannablestring.getSpanStart(obj);
        l = spannablestring.getSpanEnd(obj);
        i1 = spannablestring.getSpanFlags(obj);
        if (!(obj instanceof URLSpan)) goto _L8; else goto _L7
_L7:
        spannablestring.removeSpan(obj);
        if (s == null)
        {
            break MISSING_BLOCK_LABEL_264;
        }
        if (k < s.length())
        {
            k = s.length();
        }
        if (l <= k) goto _L10; else goto _L9
_L9:
        URLSpan urlspan = (URLSpan)obj;
        if (!flag)
        {
            break MISSING_BLOCK_LABEL_609;
        }
        if (!isUrlUnsafe((URLSpan)obj))
        {
            break MISSING_BLOCK_LABEL_609;
        }
        boolean flag1 = true;
_L20:
        spannablestring.setSpan(new UnsafeClickableURL(urlspan, flag1), k, l, i1);
          goto _L10
_L2:
        spannablestring = SpannableString.valueOf(message.bindata);
          goto _L11
_L8:
        if (s == null) goto _L10; else goto _L12
_L12:
        if (k >= s.length()) goto _L10; else goto _L13
_L13:
        int j1;
        j1 = s.length();
        spannablestring.removeSpan(obj);
        if (l <= j1) goto _L10; else goto _L14
_L14:
        Exception exception1;
        spannablestring.setSpan(obj, j1, l, i1);
          goto _L10
_L17:
        if (!message.bIncoming)
        {
            if (message != GetHeadlineMessage());
            int i;
            Exception exception2;
            android.text.method.MovementMethod movementmethod;
            if (message == GetLoadMoreMessage())
            {
                i = 0x7f06001e;
            } else
            if (message.msgtime == null)
            {
                if (!message.bUnread)
                {
                    if (m_eKnownLayout == Layout.TextOnly)
                    {
                        i = 0x7f06001c;
                    } else
                    {
                        i = 0x7f060018;
                    }
                } else
                {
                    i = 0x7f06001a;
                }
            } else
            if (m_eKnownLayout == Layout.TextOnly)
            {
                i = 0x7f06001d;
            } else
            {
                i = 0x7f060019;
            }
            textview.setTextColor(SteamCommunityApplication.GetInstance().getApplicationContext().getResources().getColor(i));
        }
        return;
_L4:
        textview.setText(spannablestring);
        movementmethod = textview.getMovementMethod();
        if (movementmethod == null) goto _L16; else goto _L15
_L15:
        if (movementmethod instanceof LinkMovementMethod) goto _L17; else goto _L16
_L16:
        textview.setMovementMethod(LinkMovementMethod.getInstance());
          goto _L17
        exception2;
        try
        {
            textview.setText("");
        }
        // Misplaced declaration of an exception variable
        catch (Exception exception1)
        {
            if (s != null)
            {
                AndroidUtils.setTextViewText(textview, (new StringBuilder()).append(s).append(message.bindata).toString());
            } else
            {
                AndroidUtils.setTextViewText(textview, message.bindata);
            }
        }
          goto _L17
        Exception exception;
        exception;
        s = null;
          goto _L18
_L10:
        j++;
          goto _L19
        flag1 = false;
          goto _L20
    }

    private String GetDebugName()
    {
        StringBuilder stringbuilder = (new StringBuilder()).append(getClass().getSimpleName()).append("/").append(m_partnerSteamId).append("(");
        String s;
        if (m_partner != null)
        {
            s = m_partner.GetPersonaNameSafe();
        } else
        {
            s = "<null>";
        }
        return stringbuilder.append(s).append(")").toString();
    }

    private static com.valvesoftware.android.steam.community.ISteamUmqCommunicationDatabase.Message GetHeadlineMessage()
    {
        if (m_msgHeadline == null)
        {
            m_msgHeadline = new com.valvesoftware.android.steam.community.ISteamUmqCommunicationDatabase.Message();
            m_msgHeadline.bIncoming = true;
            m_msgHeadline.bindata = SteamCommunityApplication.GetInstance().getString(0x7f070069);
            m_msgHeadline.bUnread = false;
            m_msgHeadline.msgtype = "";
            m_msgHeadline.id = 0;
            m_msgHeadline.msgtime = null;
            m_msgHeadline.sMySteamID = null;
            m_msgHeadline.sWithSteamID = null;
        }
        return m_msgHeadline;
    }

    private static com.valvesoftware.android.steam.community.ISteamUmqCommunicationDatabase.Message GetLoadMoreMessage()
    {
        if (m_msgLoadMore == null)
        {
            m_msgLoadMore = new com.valvesoftware.android.steam.community.ISteamUmqCommunicationDatabase.Message();
            m_msgLoadMore.bIncoming = false;
            m_msgLoadMore.bindata = SteamCommunityApplication.GetInstance().getString(0x7f070068);
            m_msgLoadMore.bUnread = false;
            m_msgLoadMore.msgtype = "";
            m_msgLoadMore.id = 0;
            m_msgLoadMore.msgtime = null;
            m_msgLoadMore.sMySteamID = null;
            m_msgLoadMore.sWithSteamID = null;
        }
        return m_msgLoadMore;
    }

    private static com.valvesoftware.android.steam.community.ISteamUmqCommunicationDatabase.Message GetTypingMessage()
    {
        if (m_msgTyping == null)
        {
            m_msgTyping = new com.valvesoftware.android.steam.community.ISteamUmqCommunicationDatabase.Message();
            m_msgTyping.bIncoming = true;
            m_msgTyping.bindata = "...";
            m_msgTyping.bUnread = false;
            m_msgTyping.msgtype = "typing";
            m_msgTyping.id = 0;
            m_msgTyping.msgtime = null;
            m_msgTyping.sMySteamID = null;
            m_msgTyping.sWithSteamID = null;
        }
        return m_msgTyping;
    }

    private void MarkMessagesAsReadWithUser()
    {
        com.valvesoftware.android.steam.community.SteamDBService.REQ_ACT_MARKREADMESSAGES_DATA req_act_markreadmessages_data = new com.valvesoftware.android.steam.community.SteamDBService.REQ_ACT_MARKREADMESSAGES_DATA();
        req_act_markreadmessages_data.mysteamid = SteamWebApi.GetLoginSteamID();
        req_act_markreadmessages_data.withsteamid = m_partnerSteamId;
        SteamWebApi.SubmitSimpleActionRequest("MarkReadMessages", req_act_markreadmessages_data);
        Intent intent = new Intent("com.valvesoftware.android.steam.community.SteamUmqCommunicationIntent");
        intent.putExtra("type", "chatmsg");
        intent.putExtra("action", "read");
        intent.putExtra("steamid", m_partnerSteamId);
        SteamCommunityApplication.GetInstance().getApplicationContext().sendBroadcast(intent);
    }

    private void MarkMessagesAsReadWithUserIfNotPaused()
    {
        if (!m_bPaused)
        {
            MarkMessagesAsReadWithUser();
            return;
        } else
        {
            m_bRequiresMarkMessagesAsRead = true;
            return;
        }
    }

    private boolean ParseMessageFromTextView(ParsedMessageData parsedmessagedata)
    {
        String s = m_chatViewMessageText.getText().toString().trim();
        String s1 = "saytext";
        if (s.startsWith("/me "))
        {
            s = s.substring(4).trim();
            s1 = "emote";
        }
        if (s.length() <= 0)
        {
            return false;
        }
        if (parsedmessagedata != null)
        {
            parsedmessagedata.text = s;
            parsedmessagedata.type = s1;
        }
        return true;
    }

    private void PrepareParticipantsInformation()
    {
        String s = m_partnerSteamId;
        Long long1 = Long.valueOf(s);
        FriendInfo friendinfo = SteamCommunityApplication.GetInstance().GetFriendInfoDB().GetFriendInfo(long1);
        if (friendinfo != null && friendinfo.HasPresentationData())
        {
            m_partner = friendinfo;
        }
        if (m_partner == null)
        {
            m_partner = new FriendInfo();
            m_partner.m_steamID = long1;
            m_partner.m_relationship = com.valvesoftware.android.steam.community.FriendInfo.FriendRelationship.friend;
            m_partner.m_personaState = com.valvesoftware.android.steam.community.FriendInfo.PersonaState.ONLINE;
            SteamDBService steamdbservice = SteamCommunityApplication.GetInstance().GetSteamDB();
            if (steamdbservice != null)
            {
                com.valvesoftware.android.steam.community.ISteamUmqCommunicationDatabase.UmqInfo umqinfo = steamdbservice.getSteamUmqCommunicationServiceDB().selectInfo(s);
                if (umqinfo != null && umqinfo.name != null)
                {
                    m_partner.m_personaName = umqinfo.name;
                }
            }
            SetPartnerDataFromCachedJSON(s);
        }
        if (m_partner.IsAvatarSmallLoaded());
        Long long2 = Long.valueOf(SteamWebApi.GetLoginSteamID());
        m_myself = SteamCommunityApplication.GetInstance().GetFriendInfoDB().GetFriendInfo(long2);
        if (m_myself == null)
        {
            m_myself = new FriendInfo();
            m_partner.m_steamID = long2;
            m_partner.m_relationship = com.valvesoftware.android.steam.community.FriendInfo.FriendRelationship.myself;
        }
        if (m_myself.IsAvatarSmallLoaded());
    }

    private void ScrollToBottom()
    {
        ScrollToBottom(false);
    }

    private void ScrollToBottom(boolean flag)
    {
        m_chatViewContents.setSelection(-1 + m_chatViewMessages.size());
    }

    private void SendTypingNotification()
    {
        if (!m_bCanSendTypingNotification)
        {
            return;
        } else
        {
            m_bCanSendTypingNotification = false;
            com.valvesoftware.android.steam.community.SteamDBService.REQ_ACT_SENDMESSAGE_DATA req_act_sendmessage_data = new com.valvesoftware.android.steam.community.SteamDBService.REQ_ACT_SENDMESSAGE_DATA();
            req_act_sendmessage_data.mylogin = new com.valvesoftware.android.steam.community.SteamDBService.REQ_ACT_LOGININFO_DATA();
            req_act_sendmessage_data.mylogin.sOAuthToken = SteamWebApi.GetLoginAccessToken();
            req_act_sendmessage_data.mylogin.sSteamID = SteamWebApi.GetLoginSteamID();
            req_act_sendmessage_data.msg = new com.valvesoftware.android.steam.community.ISteamUmqCommunicationDatabase.Message();
            req_act_sendmessage_data.msg.sMySteamID = req_act_sendmessage_data.mylogin.sSteamID;
            req_act_sendmessage_data.msg.sWithSteamID = m_partnerSteamId;
            req_act_sendmessage_data.msg.bIncoming = false;
            req_act_sendmessage_data.msg.bUnread = false;
            req_act_sendmessage_data.msg.msgtime = null;
            req_act_sendmessage_data.msg.msgtype = "typing";
            req_act_sendmessage_data.msg.bindata = "";
            req_act_sendmessage_data.intentcontext = String.valueOf(System.identityHashCode(req_act_sendmessage_data.msg));
            SteamWebApi.SubmitSimpleActionRequest("SendMessage", req_act_sendmessage_data);
            return;
        }
    }

    private void SetPartnerDataFromCachedJSON(String s)
    {
        byte abyte0[] = SteamCommunityApplication.GetInstance().GetDiskCacheIndefinite().Read(s);
        if (abyte0 == null);
        if (abyte0 == null)
        {
            break MISSING_BLOCK_LABEL_101;
        }
        JSONObject jsonobject;
        String s1;
        String s2;
        try
        {
            jsonobject = new JSONObject(new String(abyte0));
            s1 = jsonobject.optString("personaname");
        }
        catch (JSONException jsonexception)
        {
            return;
        }
        if (s1 == null)
        {
            break MISSING_BLOCK_LABEL_68;
        }
        if (m_partner.m_personaName == null)
        {
            m_partner.m_personaName = s1;
        }
        s2 = jsonobject.optString("avatar");
        if (s2 == null)
        {
            break MISSING_BLOCK_LABEL_101;
        }
        if (m_partner.m_avatarSmallURL == null)
        {
            m_partner.m_avatarSmallURL = s2;
        }
    }

    private void UpdateKnownLayoutFromSettings()
    {
        Layout layout;
        int i;
        layout = Layout.Bubbles;
        i = SteamCommunityApplication.GetInstance().GetSettingInfoDB().m_settingChatsLayout.getRadioSelectorItemValue(SteamCommunityApplication.GetInstance().getApplicationContext()).value;
        if (i != Layout.BubblesLeft.ordinal()) goto _L2; else goto _L1
_L1:
        layout = Layout.BubblesLeft;
_L4:
        m_eKnownLayout = layout;
        m_numSecondsTimestamps = SteamCommunityApplication.GetInstance().GetSettingInfoDB().m_settingChatsTimestamp.getRadioSelectorItemValue(SteamCommunityApplication.GetInstance().getApplicationContext()).value;
        return;
_L2:
        if (i == Layout.TextOnly.ordinal())
        {
            layout = Layout.TextOnly;
        }
        if (true) goto _L4; else goto _L3
_L3:
    }

    private void UpdateSendButton()
    {
        Button button = m_chatViewMessageButton;
        boolean flag;
        if (m_bCanSendMessages && ParseMessageFromTextView(null))
        {
            flag = true;
        } else
        {
            flag = false;
        }
        button.setEnabled(flag);
    }

    private void UpdateStatusBar()
    {
        SteamDBService steamdbservice = SteamCommunityApplication.GetInstance().GetSteamDB();
        if (steamdbservice != null) goto _L2; else goto _L1
_L1:
        return;
_L2:
        com.valvesoftware.android.steam.community.SteamUmqCommunicationService.UmqConnectionState umqconnectionstate = steamdbservice.getSteamUmqConnectionState();
        if (!umqconnectionstate.isConnected()) goto _L4; else goto _L3
_L3:
        if (m_partner.m_personaState != com.valvesoftware.android.steam.community.FriendInfo.PersonaState.OFFLINE)
        {
            m_chatViewStatus.setVisibility(8);
            m_bCanSendMessages = true;
        } else
        {
            m_chatViewStatus.setText(0x7f070022);
        }
_L6:
        UpdateSendButton();
        return;
_L4:
        m_chatViewStatus.setVisibility(0);
        m_bCanSendMessages = false;
        static class _cls8
        {

            static final int $SwitchMap$com$valvesoftware$android$steam$community$SteamUmqCommunicationService$UmqConnectionState[];

            static 
            {
                $SwitchMap$com$valvesoftware$android$steam$community$SteamUmqCommunicationService$UmqConnectionState = new int[com.valvesoftware.android.steam.community.SteamUmqCommunicationService.UmqConnectionState.values().length];
                try
                {
                    $SwitchMap$com$valvesoftware$android$steam$community$SteamUmqCommunicationService$UmqConnectionState[com.valvesoftware.android.steam.community.SteamUmqCommunicationService.UmqConnectionState.offline.ordinal()] = 1;
                }
                catch (NoSuchFieldError nosuchfielderror) { }
            }
        }

        switch (_cls8..SwitchMap.com.valvesoftware.android.steam.community.SteamUmqCommunicationService.UmqConnectionState[umqconnectionstate.ordinal()])
        {
        default:
            m_chatViewStatus.setText(umqconnectionstate.getStringResid());
            break;

        case 1: // '\001'
            m_chatViewStatus.setText(0x7f070021);
            break; /* Loop/switch isn't completed */
        }
        if (true) goto _L6; else goto _L5
_L5:
        UpdateSendButton();
        if (getActivity() != null)
        {
            getActivity().finish();
            return;
        }
        if (true) goto _L1; else goto _L7
_L7:
    }

    private void UpdateView()
    {
        SteamDBService steamdbservice = SteamCommunityApplication.GetInstance().GetSteamDB();
        FragmentActivity fragmentactivity;
        if (steamdbservice != null)
        {
            if ((fragmentactivity = getActivity()) != null)
            {
                SteamWebApi.SubmitSimpleActionRequest("UmqActivity", new com.valvesoftware.android.steam.community.SteamDBService.REQ_ACT_UMQACTIVITY_DATA());
                if (!m_chatViewMessages.isEmpty())
                {
                    m_chatViewMessages.clear();
                    m_chatViewAdapter = new ChatViewAdapter(fragmentactivity, m_chatViewMessages, m_layoutInflater);
                    m_chatViewAdapter.attach(m_chatViewContents);
                }
                UpdateStatusBar();
                m_userConversationInfo = steamdbservice.getSteamUmqCommunicationServiceDB().selectUserConversationInfo(SteamWebApi.GetLoginSteamID(), m_partnerSteamId);
                m_chatViewAdapter.LoadMoreMessages();
                m_chatViewAdapter.notifyDataSetChanged();
                ScrollToBottom(true);
                TitlebarFragment titlebarfragment = ActivityHelper.GetTitlebarFragmentForActivity(fragmentactivity);
                if (titlebarfragment != null)
                {
                    titlebarfragment.setTitleLabel(m_partner.GetPersonaNameSafe());
                    titlebarfragment.setRefreshHandler(m_optionsHandler);
                    View view = fragmentactivity.findViewById(0x7f090038);
                    if (view != null)
                    {
                        view.setBackgroundResource(0x7f02000d);
                    }
                }
                MarkMessagesAsReadWithUserIfNotPaused();
                return;
            }
        }
    }

    private void clearChatHistory()
    {
        com.valvesoftware.android.steam.community.SteamDBService.REQ_ACT_MARKREADMESSAGES_DATA req_act_markreadmessages_data = new com.valvesoftware.android.steam.community.SteamDBService.REQ_ACT_MARKREADMESSAGES_DATA();
        req_act_markreadmessages_data.mysteamid = SteamWebApi.GetLoginSteamID();
        req_act_markreadmessages_data.withsteamid = m_partnerSteamId;
        req_act_markreadmessages_data.deleteAllMessages = true;
        SteamWebApi.SubmitSimpleActionRequest("MarkReadMessages", req_act_markreadmessages_data);
        Intent intent = new Intent("com.valvesoftware.android.steam.community.SteamUmqCommunicationIntent");
        intent.putExtra("type", "chatmsg");
        intent.putExtra("action", "clear");
        intent.putExtra("steamid", m_partnerSteamId);
        SteamCommunityApplication.GetInstance().getApplicationContext().sendBroadcast(intent);
    }

    public static boolean isUrlUnsafe(URLSpan urlspan)
    {
        String s;
        s = urlspan.getURL();
        break MISSING_BLOCK_LABEL_5;
        while (true) 
        {
            do
            {
                return false;
            } while (s.startsWith("tel:") || s.startsWith("mailto:") || s.startsWith("geo:"));
            byte byte0;
            char ac[];
            int i;
            if (s.startsWith("http://") || s.startsWith("rtsp://"))
            {
                byte0 = 7;
            } else
            if (s.startsWith("https://"))
            {
                byte0 = 8;
            } else
            {
                return true;
            }
            ac = (new char[] {
                ':', '?', '/'
            });
            i = s.length();
            for (int j = 0; j < ac.length; j++)
            {
                int l = s.indexOf(ac[j], byte0);
                if (l >= 0 && l < i)
                {
                    i = l;
                }
            }

            String s1 = s.substring(byte0, i);
            int k = 0;
label0:
            do
            {
label1:
                {
                    if (k >= s_safeURIs.length)
                    {
                        break label1;
                    }
                    if (s1.endsWith(s_safeURIs[k]) && (s1.length() <= s_safeURIs[k].length() || s1.charAt(-1 + (s1.length() - s_safeURIs[k].length())) == '.'))
                    {
                        break label0;
                    }
                    k++;
                }
            } while (true);
        }
        return true;
    }

    private void toggleOptions()
    {
        boolean flag;
        FragmentActivity fragmentactivity;
        if (!m_bChatOptionsVisible)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        m_bChatOptionsVisible = flag;
        fragmentactivity = getActivity();
        if (fragmentactivity != null)
        {
            View view = fragmentactivity.findViewById(0x7f090038);
            if (view != null)
            {
                View view1;
                boolean flag1;
                int j;
                if (m_bChatOptionsVisible)
                {
                    j = 0x7f02000c;
                } else
                {
                    j = 0x7f02000d;
                }
                view.setBackgroundResource(j);
            }
            view1 = fragmentactivity.findViewById(0x7f090006);
            if (view1 != null)
            {
                flag1 = m_bChatOptionsVisible;
                int i = 0;
                if (!flag1)
                {
                    i = 8;
                }
                view1.setVisibility(i);
            }
        }
    }

    public void OnChatUpdated(Intent intent)
    {
        if (!"com.valvesoftware.android.steam.community.SteamUmqCommunicationIntent".equals(intent.getAction())) goto _L2; else goto _L1
_L1:
        String s = intent.getStringExtra("type");
        if (!s.equalsIgnoreCase("umqstate")) goto _L4; else goto _L3
_L3:
        UpdateStatusBar();
_L2:
        return;
_L4:
        String s1;
        if (!s.equalsIgnoreCase("chatmsg") || !m_partnerSteamId.equals(intent.getStringExtra("steamid")))
        {
            continue; /* Loop/switch isn't completed */
        }
        s1 = intent.getStringExtra("action");
        if (!"read".equals(s1))
        {
            break; /* Loop/switch isn't completed */
        }
_L8:
        if ("incoming".equals(s1))
        {
            int i1 = intent.getIntExtra("msgidFirst", -1);
            if (i1 > 0)
            {
                SteamDBService steamdbservice1 = SteamCommunityApplication.GetInstance().GetSteamDB();
                if (steamdbservice1 != null)
                {
                    m_chatViewMessages.addAll(0, steamdbservice1.getSteamUmqCommunicationServiceDB().selectMessagesWithUserLatest(SteamWebApi.GetLoginSteamID(), m_partnerSteamId, i1));
                    if (intent.getIntExtra("incoming", 0) + intent.getIntExtra("my_incoming", 0) > 0)
                    {
                        MarkMessagesAsReadWithUserIfNotPaused();
                    }
                }
            }
            if (intent.hasExtra("typing"))
            {
                m_chatViewAdapter.MarkTyping(false);
                if (intent.getIntExtra("typing", 0) > 0)
                {
                    m_chatViewAdapter.MarkTyping(true);
                }
            }
            m_chatViewAdapter.notifyDataSetChanged();
            ScrollToBottom();
            return;
        }
        if (true) goto _L2; else goto _L5
_L5:
        if (!"clear".equals(s1)) goto _L7; else goto _L6
_L6:
        if (getActivity() != null)
        {
            getActivity().finish();
        }
          goto _L8
_L7:
        if (!"send".equals(s1)) goto _L8; else goto _L9
_L9:
        String s2 = intent.getStringExtra("send");
        if (!"OK".equals(s2) && !"error".equals(s2)) goto _L8; else goto _L10
_L10:
        int i;
        int j;
        i = Integer.valueOf(intent.getStringExtra("intentcontext")).intValue();
        j = 0;
_L11:
label0:
        {
            int k = m_sentMsgs.size();
            boolean flag = false;
            if (j < k)
            {
                com.valvesoftware.android.steam.community.ISteamUmqCommunicationDatabase.Message message = (com.valvesoftware.android.steam.community.ISteamUmqCommunicationDatabase.Message)m_sentMsgs.get(j);
                if (System.identityHashCode(message) != i)
                {
                    break label0;
                }
                if ("error".equals(s2))
                {
                    message.bUnread = true;
                }
                m_sentMsgs.remove(j);
                m_chatViewAdapter.notifyDataSetChanged();
                flag = true;
            }
            if (!flag)
            {
                int l = intent.getIntExtra("msgid", -1);
                if (l > 0)
                {
                    SteamDBService steamdbservice = SteamCommunityApplication.GetInstance().GetSteamDB();
                    if (steamdbservice != null)
                    {
                        m_chatViewMessages.addAll(0, steamdbservice.getSteamUmqCommunicationServiceDB().selectMessagesByID(l));
                        m_chatViewAdapter.notifyDataSetChanged();
                    }
                }
            }
        }
          goto _L8
        j++;
          goto _L11
    }

    public void onActivityCreated(Bundle bundle)
    {
        super.onActivityCreated(bundle);
        FragmentActivity fragmentactivity = getActivity();
        if (fragmentactivity != null)
        {
            UpdateKnownLayoutFromSettings();
            m_partnerSteamId = fragmentactivity.getIntent().getStringExtra(com.valvesoftware.android.steam.community.SteamUriHandler.CommandProperty.steamid.toString());
            m_layoutInflater = (LayoutInflater)fragmentactivity.getSystemService("layout_inflater");
            m_inputMethodManager = (InputMethodManager)fragmentactivity.getSystemService("input_method");
            m_chatViewContents = (ListView)fragmentactivity.findViewById(0x7f090008);
            m_chatViewContents.setTranscriptMode(2);
            m_chatViewContents.setStackFromBottom(true);
            m_chatViewStatus = (TextView)fragmentactivity.findViewById(0x7f090009);
            m_chatViewMessageText = (EditText)fragmentactivity.findViewById(0x7f09000b);
            m_chatViewMessageButton = (Button)fragmentactivity.findViewById(0x7f09000c);
        }
        ControlsSetup();
    }

    public void onClick(View view)
    {
        view.getId();
        JVM INSTR tableswitch 2131296268 2131296268: default 24
    //                   2131296268 25;
           goto _L1 _L2
_L1:
        return;
_L2:
        ParsedMessageData parsedmessagedata = new ParsedMessageData();
        if (m_bCanSendMessages && ParseMessageFromTextView(parsedmessagedata))
        {
            com.valvesoftware.android.steam.community.SteamDBService.REQ_ACT_SENDMESSAGE_DATA req_act_sendmessage_data = new com.valvesoftware.android.steam.community.SteamDBService.REQ_ACT_SENDMESSAGE_DATA();
            req_act_sendmessage_data.mylogin = new com.valvesoftware.android.steam.community.SteamDBService.REQ_ACT_LOGININFO_DATA();
            req_act_sendmessage_data.mylogin.sOAuthToken = SteamWebApi.GetLoginAccessToken();
            req_act_sendmessage_data.mylogin.sSteamID = SteamWebApi.GetLoginSteamID();
            req_act_sendmessage_data.msg = new com.valvesoftware.android.steam.community.ISteamUmqCommunicationDatabase.Message();
            req_act_sendmessage_data.msg.sMySteamID = req_act_sendmessage_data.mylogin.sSteamID;
            req_act_sendmessage_data.msg.sWithSteamID = m_partnerSteamId;
            req_act_sendmessage_data.msg.bIncoming = false;
            req_act_sendmessage_data.msg.bUnread = false;
            req_act_sendmessage_data.msg.msgtime = null;
            req_act_sendmessage_data.msg.msgtype = parsedmessagedata.type;
            req_act_sendmessage_data.msg.bindata = parsedmessagedata.text;
            req_act_sendmessage_data.intentcontext = String.valueOf(System.identityHashCode(req_act_sendmessage_data.msg));
            m_sentMsgs.add(req_act_sendmessage_data.msg);
            m_chatViewMessages.add(0, req_act_sendmessage_data.msg);
            m_chatViewAdapter.notifyDataSetChanged();
            ScrollToBottom(true);
            SteamWebApi.SubmitSimpleActionRequest("SendMessage", req_act_sendmessage_data);
            ClearMessageBox();
            m_bCanSendTypingNotification = true;
            return;
        }
        if (true) goto _L1; else goto _L3
_L3:
    }

    public void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
    }

    public View onCreateView(LayoutInflater layoutinflater, ViewGroup viewgroup, Bundle bundle)
    {
        return layoutinflater.inflate(0x7f030001, viewgroup, false);
    }

    public void onDestroy()
    {
        super.onDestroy();
    }

    public void onPause()
    {
        SteamCommunityApplication.GetInstance().GetFriendInfoDB().setActiveChatPartnerSteamId(null);
        super.onPause();
        if (!m_bPaused)
        {
            m_bPaused = true;
            SteamCommunityApplication.GetInstance().GetFriendInfoDB().DeregisterCallback(m_friendsListener);
            if (getActivity() != null)
            {
                getActivity().unregisterReceiver(m_intentReceiver);
            }
        }
    }

    public void onResume()
    {
        super.onResume();
        if (!SteamWebApi.IsLoggedIn())
        {
            if (getActivity() != null)
            {
                getActivity().finish();
            }
            return;
        }
        UpdateKnownLayoutFromSettings();
        PrepareParticipantsInformation();
        SteamWebApi.SubmitSimpleActionRequest("UmqActivity", new com.valvesoftware.android.steam.community.SteamDBService.REQ_ACT_UMQACTIVITY_DATA());
        m_bPaused = false;
        if (m_bRequiresMarkMessagesAsRead)
        {
            m_bRequiresMarkMessagesAsRead = false;
            MarkMessagesAsReadWithUser();
        }
        if (getActivity() != null)
        {
            getActivity().registerReceiver(m_intentReceiver, new IntentFilter("com.valvesoftware.android.steam.community.SteamUmqCommunicationIntent"));
        }
        SteamCommunityApplication.GetInstance().GetFriendInfoDB().RegisterCallback(m_friendsListener);
        UpdateView();
        SteamCommunityApplication.GetInstance().GetFriendInfoDB().setActiveChatPartnerSteamId(m_partnerSteamId);
    }

    public boolean overrideActivityOnBackPressed()
    {
        if (m_bChatOptionsVisible)
        {
            toggleOptions();
            return true;
        } else
        {
            return false;
        }
    }






















    // Unreferenced inner class com/valvesoftware/android/steam/community/fragment/ChatFragment$ChatViewAdapter$1

/* anonymous class */
    class ChatViewAdapter._cls1
        implements android.view.View.OnLongClickListener
    {

        final ChatViewAdapter this$1;
        final ChatFragment val$this$0;

        public boolean onLongClick(View view)
        {
            ClipboardManager clipboardmanager = (ClipboardManager)getActivity().getSystemService("clipboard");
            if (clipboardmanager == null)
            {
                break MISSING_BLOCK_LABEL_101;
            }
            if (!(view instanceof TextView))
            {
                break MISSING_BLOCK_LABEL_101;
            }
            clipboardmanager.setText(((TextView)view).getText().toString());
            int ai[] = {
                0, 0
            };
            view.getLocationOnScreen(ai);
            Toast toast = Toast.makeText(getActivity(), 0x7f070066, 0);
            toast.setGravity(49, 0, ai[1]);
            toast.show();
            return true;
            Exception exception;
            exception;
            return false;
        }

            
            {
                this$1 = final_chatviewadapter;
                this$0 = ChatFragment.this;
                super();
            }
    }


    // Unreferenced inner class com/valvesoftware/android/steam/community/fragment/ChatFragment$ChatViewAdapter$2

/* anonymous class */
    class ChatViewAdapter._cls2
        implements android.view.View.OnLongClickListener
    {

        final ChatViewAdapter this$1;
        final ChatFragment val$this$0;

        public boolean onLongClick(View view)
        {
            LoadMoreMessagesInView();
            return true;
        }

            
            {
                this$1 = final_chatviewadapter;
                this$0 = ChatFragment.this;
                super();
            }
    }

}
