// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;


// Referenced classes of package com.valvesoftware.android.steam.community:
//            SteamWebApi

public static final class  extends Enum
{

    private static final .VALUES $VALUES[];
    public static final .VALUES DoHttpRequestAndCacheResults;
    public static final .VALUES DoHttpRequestNoCache;
    public static final .VALUES GetFromCacheOnly;
    public static final .VALUES GetFromCacheOrDoHttpRequestAndCacheResults;

    public static  valueOf(String s)
    {
        return ()Enum.valueOf(com/valvesoftware/android/steam/community/SteamWebApi$RequestActionType, s);
    }

    public static [] values()
    {
        return ([])$VALUES.clone();
    }

    static 
    {
        DoHttpRequestAndCacheResults = new <init>("DoHttpRequestAndCacheResults", 0);
        GetFromCacheOnly = new <init>("GetFromCacheOnly", 1);
        GetFromCacheOrDoHttpRequestAndCacheResults = new <init>("GetFromCacheOrDoHttpRequestAndCacheResults", 2);
        DoHttpRequestNoCache = new <init>("DoHttpRequestNoCache", 3);
        e_3B_.clone aclone[] = new <init>[4];
        aclone[0] = DoHttpRequestAndCacheResults;
        aclone[1] = GetFromCacheOnly;
        aclone[2] = GetFromCacheOrDoHttpRequestAndCacheResults;
        aclone[3] = DoHttpRequestNoCache;
        $VALUES = aclone;
    }

    private (String s, int i)
    {
        super(s, i);
    }
}
