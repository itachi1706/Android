// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.fragment;

import android.view.View;
import com.valvesoftware.android.steam.community.activity.ActivityHelper;
import com.valvesoftware.android.steam.community.activity.FragmentActivityWithNavigationSupport;

// Referenced classes of package com.valvesoftware.android.steam.community.fragment:
//            SettingsFragment

class this._cls0
    implements android.view.r
{

    final SettingsFragment this$0;

    public void onClick(View view)
    {
        FragmentActivityWithNavigationSupport.finishAll();
        ActivityHelper.PresentLoginActivity(null, com.valvesoftware.android.steam.community.activity.Action.LOGOUT);
    }

    Action()
    {
        this$0 = SettingsFragment.this;
        super();
    }
}
