// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;


// Referenced classes of package com.valvesoftware.android.steam.community:
//            SteamUmqCommunicationService, SteamDBService

private class <init>
{

    private int m_nThreadPoolQueueId;
    private String m_sThreadPoolQueueId;
    final SteamUmqCommunicationService this$0;

    public String GetThreadPoolQueueId()
    {
        return m_sThreadPoolQueueId;
    }

    public void SwitchToNextThreadPoolQueueId()
    {
        m_sThreadPoolQueueId m_sthreadpoolqueueid = new m_sThreadPoolQueueId(GetThreadPoolQueueId());
        m_sthreadpoolqueueid.GetThreadPoolQueueId("JOB_INTENT_SHUTDOWN_JOB_QUEUE");
        SteamUmqCommunicationService.access$700(SteamUmqCommunicationService.this).SubmitRequest(m_sthreadpoolqueueid);
        m_nThreadPoolQueueId = 1 + m_nThreadPoolQueueId;
        m_sThreadPoolQueueId = (new StringBuilder()).append("JobQueueUMQpoll").append(m_nThreadPoolQueueId).toString();
    }

    private ()
    {
        this$0 = SteamUmqCommunicationService.this;
        super();
        m_nThreadPoolQueueId = 0;
        m_sThreadPoolQueueId = "JobQueueUMQpoll";
    }

    m_sThreadPoolQueueId(m_sThreadPoolQueueId m_sthreadpoolqueueid)
    {
        this();
    }
}
