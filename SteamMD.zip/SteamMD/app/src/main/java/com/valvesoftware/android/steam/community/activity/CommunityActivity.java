// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.activity;

import android.content.Context;
import android.os.Bundle;
import com.valvesoftware.android.steam.community.Config;
import com.valvesoftware.android.steam.community.SteamCommunityApplication;
import com.valvesoftware.android.steam.community.SteamWebApi;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

// Referenced classes of package com.valvesoftware.android.steam.community.activity:
//            FragmentActivityWithNavigationSupport, ActivityHelper

public class CommunityActivity extends FragmentActivityWithNavigationSupport
{

    private static long s_lastCheckForUpdates = 0L;

    public CommunityActivity()
    {
    }

    private void checkForUpdates()
    {
        if (SteamCommunityApplication.GetInstance().IsOverTheAirVersion() && Config.APP_VERSION_ID != 0)
        {
            long l = System.currentTimeMillis();
            if (s_lastCheckForUpdates == 0L || l - s_lastCheckForUpdates >= 0x1b7740L)
            {
                s_lastCheckForUpdates = l;
                try
                {
                    Class.forName("net.hockeyapp.android.UpdateActivity").getDeclaredField("iconDrawableId").setInt(null, 0x7f020028);
                    Class class1 = Class.forName("net.hockeyapp.android.CheckUpdateTask");
                    Object obj = class1.getDeclaredConstructor(new Class[] {
                        android/content/Context, java/lang/String
                    }).newInstance(new Object[] {
                        this, "http://m.valvesoftware.com/"
                    });
                    Method method = class1.getSuperclass().getDeclaredMethod("execute", new Class[] {
                        [Ljava/lang/Object;
                    });
                    Object aobj[] = new Object[1];
                    aobj[0] = (String)null;
                    method.invoke(obj, aobj);
                    return;
                }
                catch (Exception exception)
                {
                    return;
                }
            }
        }
    }

    public void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        setContentView(0x7f030007);
        if (!SteamWebApi.IsLoggedIn())
        {
            ActivityHelper.PresentLoginActivity(this, LoginActivity.LoginAction.LOGIN_DEFAULT);
        }
    }

    protected void onDestroy()
    {
        super.onDestroy();
    }

    protected void onResume()
    {
        SteamWebApi.SubmitSimpleActionRequest("UmqActivity", new com.valvesoftware.android.steam.community.SteamDBService.REQ_ACT_UMQACTIVITY_DATA());
        super.onResume();
        checkForUpdates();
    }

}
