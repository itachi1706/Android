// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.fragment;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.net.Uri;
import android.support.v4.app.FragmentActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import com.valvesoftware.android.steam.community.AndroidUtils;
import com.valvesoftware.android.steam.community.Config;
import com.valvesoftware.android.steam.community.GenericListDB;
import com.valvesoftware.android.steam.community.GroupInfo;
import com.valvesoftware.android.steam.community.GroupInfoDB;
import com.valvesoftware.android.steam.community.SteamCommunityApplication;
import com.valvesoftware.android.steam.community.SteamWebApi;
import com.valvesoftware.android.steam.community.activity.SteamMobileUriActivity;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

// Referenced classes of package com.valvesoftware.android.steam.community.fragment:
//            BaseSearchResultsListFragment

public class SearchGroupListFragment extends BaseSearchResultsListFragment
{
    private class GroupsListAdapter extends BasePresentationListFragment.HelperDbListAdapter
    {

        final SearchGroupListFragment this$0;

        public View getView(int i, View view, ViewGroup viewgroup)
        {
            View view1 = view;
            SteamCommunityApplication steamcommunityapplication = SteamCommunityApplication.GetInstance();
            if (view1 == null)
            {
                view1 = ((LayoutInflater)steamcommunityapplication.getSystemService("layout_inflater")).inflate(0x7f03000b, null);
                view1.setClickable(true);
                view1.setOnClickListener(groupListClickListener);
            }
            GroupInfo groupinfo = (GroupInfo)m_presentationArray.get(i);
            if (groupinfo != null)
            {
                if (!groupinfo.IsAvatarSmallLoaded())
                {
                    RequestVisibleAvatars();
                }
                ((TextView)view1.findViewById(0x7f09000d)).setVisibility(8);
                TextView textview = (TextView)view1.findViewById(0x7f090013);
                TextView textview1 = (TextView)view1.findViewById(0x7f090020);
                TextView textview2 = (TextView)view1.findViewById(0x7f090021);
                ImageView imageview = (ImageView)view1.findViewById(0x7f09000e);
                ImageView imageview1 = (ImageView)view1.findViewById(0x7f090012);
                ((TextView)view1.findViewById(0x7f090018)).setText(Long.toString(groupinfo.m_steamID.longValue()));
                AndroidUtils.setTextViewText(textview, groupinfo.m_groupName);
                imageview.setImageBitmap(groupinfo.GetAvatarSmall());
                imageview1.setVisibility(0);
                textview1.setText((new StringBuilder()).append(Integer.toString(groupinfo.m_numMembersTotal)).append(" ").append(steamcommunityapplication.getResources().getString(0x7f07006f)).toString());
                textview2.setText((new StringBuilder()).append(Integer.toString(groupinfo.m_numMembersOnline)).append(" ").append(steamcommunityapplication.getResources().getString(0x7f070070)).toString());
            }
            return view1;
        }

        public GroupsListAdapter()
        {
            this$0 = SearchGroupListFragment.this;
            super(SearchGroupListFragment.this, 0x7f03000b);
        }
    }

    public class SearchGroupInfoDB extends GroupInfoDB
    {

        final SearchGroupListFragment this$0;

        protected void HandleListRefreshDocument(com.valvesoftware.android.steam.community.SteamWebApi.RequestBase requestbase, boolean flag)
        {
            ArrayList arraylist;
            JSONObject jsonobject = requestbase.GetJSONDocument();
            if (jsonobject == null)
            {
                return;
            }
            JSONArray jsonarray;
            int i;
            int j;
            String s;
            GroupInfo groupinfo;
            try
            {
                jsonarray = jsonobject.getJSONArray("results");
                m_queryTotalResults = jsonobject.optInt("total");
                m_queryActualResults = jsonobject.optInt("count");
            }
            catch (JSONException jsonexception)
            {
                return;
            }
            i = jsonarray.length();
            arraylist = new ArrayList();
            m_searchResultsOrderMap.clear();
            j = 0;
            if (j >= i)
            {
                break; /* Loop/switch isn't completed */
            }
            s = jsonarray.getJSONObject(j).getString("steamid");
            arraylist.add(s);
            groupinfo = GetOrAllocateNewGroupInfo(s);
            groupinfo.m_relationship = com.valvesoftware.android.steam.community.GroupInfo.GroupRelationship.Member;
            m_searchResultsOrderMap.put(groupinfo.m_steamID, Integer.valueOf(j));
_L4:
            j++;
            if (true) goto _L2; else goto _L1
_L1:
            break; /* Loop/switch isn't completed */
_L2:
            break MISSING_BLOCK_LABEL_73;
            Exception exception;
            exception;
            if (true) goto _L4; else goto _L3
_L3:
            String as[] = new String[arraylist.size()];
            arraylist.toArray(as);
            IssueItemSummaryRequest(as, flag);
            refreshListView();
            return;
        }

        protected com.valvesoftware.android.steam.community.SteamWebApi.RequestBase IssueFullListRefreshRequest(boolean flag)
        {
            com.valvesoftware.android.steam.community.SteamWebApi.RequestBase requestbase = new com.valvesoftware.android.steam.community.SteamWebApi.RequestBase("JobQueueFriendsDB");
            String s = SteamWebApi.GetLoginAccessToken();
            String s1 = Uri.encode(m_queryText);
            int i = 32 + SearchGroupListFragment.SearchFriendInfoDB_URI.length();
            int j;
            StringBuilder stringbuilder;
            if (s != null)
            {
                j = s.length();
            } else
            {
                j = 0;
            }
            stringbuilder = new StringBuilder(128 + (32 + (j + i) + s1.length()));
            stringbuilder.append(SearchGroupListFragment.SearchFriendInfoDB_URI);
            stringbuilder.append("?access_token=");
            stringbuilder.append(s);
            stringbuilder.append("&keywords=");
            stringbuilder.append(s1);
            stringbuilder.append("&offset=");
            stringbuilder.append(m_queryOffset);
            stringbuilder.append("&count=");
            stringbuilder.append(m_queryPageSize);
            stringbuilder.append("&targets=groups&fields=all");
            requestbase.SetUriAndDocumentType(stringbuilder.toString(), com.valvesoftware.android.steam.community.SteamWebApi.RequestDocumentType.JSON);
            requestbase.SetRequestAction(com.valvesoftware.android.steam.community.SteamWebApi.RequestActionType.DoHttpRequestNoCache);
            return requestbase;
        }

        public void SetAutoRefreshIfDataMightBeStale(boolean flag)
        {
        }

        public SearchGroupInfoDB()
        {
            this$0 = SearchGroupListFragment.this;
            super();
        }
    }


    private static final String SearchFriendInfoDB_URI;
    private android.view.View.OnClickListener groupListClickListener;

    public SearchGroupListFragment()
    {
        groupListClickListener = new android.view.View.OnClickListener() {

            final SearchGroupListFragment this$0;

            public void onClick(View view)
            {
                TextView textview = (TextView)view.findViewById(0x7f090018);
                String s = "0";
                if (textview != null)
                {
                    s = textview.getText().toString();
                }
                GroupInfo groupinfo;
                if (!s.equals("0"))
                {
                    if ((groupinfo = ((GroupInfoDB)myListDb()).GetGroupInfo(Long.valueOf(s))) != null)
                    {
                        Intent intent = (new Intent()).addFlags(0x18000000).setClass(getActivity(), com/valvesoftware/android/steam/community/activity/SteamMobileUriActivity).setData(Uri.parse((new StringBuilder()).append("steammobile://").append(com.valvesoftware.android.steam.community.SteamUriHandler.Command.openurl).append("?url=").append(Config.URL_COMMUNITY_BASE).append(groupinfo.m_profileURL).toString())).setAction("android.intent.action.VIEW");
                        getActivity().startActivity(intent);
                        return;
                    }
                }
            }

            
            {
                this$0 = SearchGroupListFragment.this;
                super();
            }
        };
    }

    protected volatile GenericListDB AllocateNewSearchDB()
    {
        return AllocateNewSearchDB();
    }

    protected SearchGroupInfoDB AllocateNewSearchDB()
    {
        return new SearchGroupInfoDB();
    }

    protected int GetTitlebarFormatStringForQuery()
    {
        return 0x7f070079;
    }

    protected volatile boolean myCbckShouldDisplayItemInList(com.valvesoftware.android.steam.community.GenericListDB.GenericListItem genericlistitem)
    {
        return myCbckShouldDisplayItemInList((GroupInfo)genericlistitem);
    }

    protected boolean myCbckShouldDisplayItemInList(GroupInfo groupinfo)
    {
        return groupinfo.HasPresentationData();
    }

    protected BasePresentationListFragment.HelperDbListAdapter myCreateListAdapter()
    {
        return new GroupsListAdapter();
    }

    static 
    {
        SearchFriendInfoDB_URI = (new StringBuilder()).append(Config.URL_WEBAPI_BASE).append("/ISteamUserOAuth/Search/v0001").toString();
    }


}
