// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.fragment;

import android.content.DialogInterface;
import android.view.View;

// Referenced classes of package com.valvesoftware.android.steam.community.fragment:
//            ChatFragment

class val.finalView
    implements android.content..ChatFragment.UnsafeClickableURL._cls1
{

    final val.finalView this$1;
    final View val$finalView;

    public void onClick(DialogInterface dialoginterface, int i)
    {
        ndleUserProcceedSelected(val$finalView);
    }

    ()
    {
        this$1 = final_;
        val$finalView = View.this;
        super();
    }
}
