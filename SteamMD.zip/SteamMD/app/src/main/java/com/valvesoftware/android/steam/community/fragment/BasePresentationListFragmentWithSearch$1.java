// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.fragment;

import com.valvesoftware.android.steam.community.SteamWebApi;

// Referenced classes of package com.valvesoftware.android.steam.community.fragment:
//            BasePresentationListFragmentWithSearch

class this._cls0
    implements this._cls0
{

    final BasePresentationListFragmentWithSearch this$0;

    public void onTitlebarButtonClicked(int i)
    {
        if (!SteamWebApi.IsLoggedIn())
        {
            return;
        } else
        {
            activateSearch(true);
            return;
        }
    }

    a()
    {
        this$0 = BasePresentationListFragmentWithSearch.this;
        super();
    }
}
