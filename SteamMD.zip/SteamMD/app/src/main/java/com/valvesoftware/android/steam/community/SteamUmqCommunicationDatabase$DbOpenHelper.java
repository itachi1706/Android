// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

// Referenced classes of package com.valvesoftware.android.steam.community:
//            SteamUmqCommunicationDatabase

private class this._cls0 extends SQLiteOpenHelper
{

    final SteamUmqCommunicationDatabase this$0;

    public void onCreate(SQLiteDatabase sqlitedatabase)
    {
        sqlitedatabase.execSQL("CREATE TABLE UmqMsg (   _id integer primary key autoincrement , myuser1 integer not null , myuser2 integer not null , wuser1 integer not null , wuser2 integer not null , msgincoming integer not null , msgunread integer not null , msgtime integer not null , msgtype text not null , bindata text not null  )");
        sqlitedatabase.execSQL("CREATE INDEX idxMyUser ON UmqMsg ( myuser1,myuser2 )");
        sqlitedatabase.execSQL("CREATE INDEX idxWUser ON UmqMsg ( wuser1,wuser2 )");
        sqlitedatabase.execSQL("CREATE INDEX idxUnread ON UmqMsg ( msgunread )");
        sqlitedatabase.execSQL("CREATE INDEX idxTime ON UmqMsg ( msgtime )");
        sqlitedatabase.execSQL("CREATE TABLE UmqInfo (   id1 integer not null , id2 integer not null , name text not null  )");
        sqlitedatabase.execSQL("CREATE UNIQUE INDEX idxUserInfoId ON UmqInfo ( id1,id2 )");
    }

    public void onUpgrade(SQLiteDatabase sqlitedatabase, int i, int j)
    {
        sqlitedatabase.execSQL("DROP TABLE if exists UmqMsg");
        onCreate(sqlitedatabase);
    }

    public (Context context)
    {
        this$0 = SteamUmqCommunicationDatabase.this;
        super(context, "umqcomm.db", null, 2);
    }
}
