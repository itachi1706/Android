// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;


// Referenced classes of package com.valvesoftware.android.steam.community:
//            GroupInfo

public static final class  extends Enum
{

    private static final .VALUES $VALUES[];
    public static final .VALUES DISABLED;
    public static final .VALUES LOCKED;
    public static final .VALUES OFFICIAL;
    public static final .VALUES PRIVATE;
    public static final .VALUES PUBLIC;

    public static  FromInteger(int i)
    {
        switch (i)
        {
        default:
            return PRIVATE;

        case 0: // '\0'
            return PRIVATE;

        case 1: // '\001'
            return PUBLIC;

        case 2: // '\002'
            return LOCKED;

        case 3: // '\003'
            return DISABLED;

        case 4: // '\004'
            return OFFICIAL;
        }
    }

    public static OFFICIAL valueOf(String s)
    {
        return (OFFICIAL)Enum.valueOf(com/valvesoftware/android/steam/community/GroupInfo$GroupType, s);
    }

    public static OFFICIAL[] values()
    {
        return (OFFICIAL[])$VALUES.clone();
    }

    static 
    {
        PRIVATE = new <init>("PRIVATE", 0);
        PUBLIC = new <init>("PUBLIC", 1);
        LOCKED = new <init>("LOCKED", 2);
        DISABLED = new <init>("DISABLED", 3);
        OFFICIAL = new <init>("OFFICIAL", 4);
        e_3B_.clone aclone[] = new <init>[5];
        aclone[0] = PRIVATE;
        aclone[1] = PUBLIC;
        aclone[2] = LOCKED;
        aclone[3] = DISABLED;
        aclone[4] = OFFICIAL;
        $VALUES = aclone;
    }

    private (String s, int i)
    {
        super(s, i);
    }
}
