// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;

import java.io.File;

// Referenced classes of package com.valvesoftware.android.steam.community:
//            SteamDBDiskCache

public static class  extends SteamDBDiskCache
{

    public void Delete(String s)
    {
        this;
        JVM INSTR monitorenter ;
        (new File(m_dir, getFileNameFromUri(s))).delete();
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public (File file)
    {
        super(file);
    }
}
