// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.fragment;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Resources;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.ListFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import com.valvesoftware.android.steam.community.AndroidUtils;
import com.valvesoftware.android.steam.community.FriendInfo;
import com.valvesoftware.android.steam.community.FriendInfoDB;
import com.valvesoftware.android.steam.community.ISteamUmqCommunicationDatabase;
import com.valvesoftware.android.steam.community.SettingInfo;
import com.valvesoftware.android.steam.community.SettingInfoDB;
import com.valvesoftware.android.steam.community.SteamCommunityApplication;
import com.valvesoftware.android.steam.community.SteamDBService;
import com.valvesoftware.android.steam.community.SteamWebApi;
import com.valvesoftware.android.steam.community.activity.ActivityHelper;
import com.valvesoftware.android.steam.community.activity.FragmentActivityWithNavigationSupport;
import com.valvesoftware.android.steam.community.activity.SteamMobileUriActivity;
import java.util.ArrayList;
import java.util.Calendar;

// Referenced classes of package com.valvesoftware.android.steam.community.fragment:
//            TitlebarFragment, NavigationFragment

public class SettingsFragment extends ListFragment
{
    public static class RadioSelectorItemOnClickListener
        implements android.view.View.OnClickListener
    {

        Activity activity;
        AlertDialog alert;
        android.content.DialogInterface.OnClickListener m_onRadioButtonSelected;
        SettingInfo settingInfo;
        TextView valueView;

        public void onClick(View view)
        {
            android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(activity);
            builder.setTitle(settingInfo.m_resid);
            com.valvesoftware.android.steam.community.SettingInfo.RadioSelectorItem aradioselectoritem[] = (com.valvesoftware.android.steam.community.SettingInfo.RadioSelectorItem[])(com.valvesoftware.android.steam.community.SettingInfo.RadioSelectorItem[])settingInfo.m_extraData;
            CharSequence acharsequence[] = new CharSequence[aradioselectoritem.length];
            com.valvesoftware.android.steam.community.SettingInfo.RadioSelectorItem radioselectoritem = settingInfo.getRadioSelectorItemValue(activity.getApplicationContext());
            int i = -1;
            for (int j = 0; j < aradioselectoritem.length; j++)
            {
                acharsequence[j] = activity.getString(aradioselectoritem[j].resid_text);
                if (radioselectoritem == aradioselectoritem[j])
                {
                    i = j;
                }
            }

            builder.setSingleChoiceItems(acharsequence, i, m_onRadioButtonSelected);
            alert = builder.create();
            alert.show();
        }

        public void onSettingChanged(com.valvesoftware.android.steam.community.SettingInfo.RadioSelectorItem radioselectoritem)
        {
        }

        public RadioSelectorItemOnClickListener(Activity activity1, SettingInfo settinginfo, TextView textview)
        {
            m_onRadioButtonSelected = new _cls1();
            activity = activity1;
            settingInfo = settinginfo;
            valueView = textview;
        }
    }

    private class SettingsListAdapter extends ArrayAdapter
    {

        private ArrayList items;
        final SettingsFragment this$0;

        public View getView(int i, View view, ViewGroup viewgroup)
        {
            View view1;
            final SettingInfo settingInfo;
            TextView textview;
            final TextView valueView;
            ImageView imageview;
            CheckBox checkbox;
            view1 = view;
            settingInfo = (SettingInfo)items.get(i);
            if (settingInfo == null)
            {
                return view1;
            }
            if (view1 == null)
            {
                view1 = ((LayoutInflater)m_owner.getSystemService("layout_inflater")).inflate(0x7f030013, null);
                view1.setClickable(true);
            }
            view1.setOnClickListener(null);
            textview = (TextView)view1.findViewById(0x7f09000d);
            textview.setText(settingInfo.m_resid);
            valueView = (TextView)view1.findViewById(0x7f090031);
            valueView.setText("");
            if (settingInfo.m_resid_detailed != 0)
            {
                valueView.setText(settingInfo.m_resid_detailed);
            }
            imageview = (ImageView)view1.findViewById(0x7f090017);
            imageview.setVisibility(8);
            checkbox = (CheckBox)view1.findViewById(0x7f090032);
            checkbox.setVisibility(8);
            static class _cls4
            {

                static final int $SwitchMap$com$valvesoftware$android$steam$community$SettingInfo$AccessRight[];
                static final int $SwitchMap$com$valvesoftware$android$steam$community$SettingInfo$SettingType[];

                static 
                {
                    $SwitchMap$com$valvesoftware$android$steam$community$SettingInfo$SettingType = new int[com.valvesoftware.android.steam.community.SettingInfo.SettingType.values().length];
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$SettingInfo$SettingType[com.valvesoftware.android.steam.community.SettingInfo.SettingType.INFO.ordinal()] = 1;
                    }
                    catch (NoSuchFieldError nosuchfielderror) { }
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$SettingInfo$SettingType[com.valvesoftware.android.steam.community.SettingInfo.SettingType.CHECK.ordinal()] = 2;
                    }
                    catch (NoSuchFieldError nosuchfielderror1) { }
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$SettingInfo$SettingType[com.valvesoftware.android.steam.community.SettingInfo.SettingType.DATE.ordinal()] = 3;
                    }
                    catch (NoSuchFieldError nosuchfielderror2) { }
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$SettingInfo$SettingType[com.valvesoftware.android.steam.community.SettingInfo.SettingType.URI.ordinal()] = 4;
                    }
                    catch (NoSuchFieldError nosuchfielderror3) { }
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$SettingInfo$SettingType[com.valvesoftware.android.steam.community.SettingInfo.SettingType.MARKET.ordinal()] = 5;
                    }
                    catch (NoSuchFieldError nosuchfielderror4) { }
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$SettingInfo$SettingType[com.valvesoftware.android.steam.community.SettingInfo.SettingType.RADIOSELECTOR.ordinal()] = 6;
                    }
                    catch (NoSuchFieldError nosuchfielderror5) { }
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$SettingInfo$SettingType[com.valvesoftware.android.steam.community.SettingInfo.SettingType.RINGTONESELECTOR.ordinal()] = 7;
                    }
                    catch (NoSuchFieldError nosuchfielderror6) { }
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$SettingInfo$SettingType[com.valvesoftware.android.steam.community.SettingInfo.SettingType.UNREADMSG.ordinal()] = 8;
                    }
                    catch (NoSuchFieldError nosuchfielderror7) { }
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$SettingInfo$SettingType[com.valvesoftware.android.steam.community.SettingInfo.SettingType.SECTION.ordinal()] = 9;
                    }
                    catch (NoSuchFieldError nosuchfielderror8) { }
                    $SwitchMap$com$valvesoftware$android$steam$community$SettingInfo$AccessRight = new int[com.valvesoftware.android.steam.community.SettingInfo.AccessRight.values().length];
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$SettingInfo$AccessRight[com.valvesoftware.android.steam.community.SettingInfo.AccessRight.USER.ordinal()] = 1;
                    }
                    catch (NoSuchFieldError nosuchfielderror9) { }
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$SettingInfo$AccessRight[com.valvesoftware.android.steam.community.SettingInfo.AccessRight.VALID_ACCOUNT.ordinal()] = 2;
                    }
                    catch (NoSuchFieldError nosuchfielderror10) { }
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$SettingInfo$AccessRight[com.valvesoftware.android.steam.community.SettingInfo.AccessRight.CODE.ordinal()] = 3;
                    }
                    catch (NoSuchFieldError nosuchfielderror11)
                    {
                        return;
                    }
                }
            }

            _cls4..SwitchMap.com.valvesoftware.android.steam.community.SettingInfo.SettingType[settingInfo.m_type.ordinal()];
            JVM INSTR tableswitch 1 8: default 220
        //                       1 405
        //                       2 418
        //                       3 489
        //                       4 580
        //                       5 223
        //                       6 608
        //                       7 667
        //                       8 305;
               goto _L1 _L2 _L3 _L4 _L5 _L6 _L7 _L8 _L9
_L1:
            return view1;
_L6:
            if (SteamCommunityApplication.GetInstance().IsOverTheAirVersion())
            {
                valueView.setText((new StringBuilder()).append(settingInfo.m_defaultValue).append(" / INTERNAL BUILD").toString());
            } else
            {
                imageview.setVisibility(0);
                valueView.setText(settingInfo.m_defaultValue);
                android.view.View.OnClickListener onclicklistener5 = imageview. new android.view.View.OnClickListener() {

                    final SettingsListAdapter this$1;
                    final ImageView val$chevronView;
                    final SettingInfo val$settingInfo;
                    final TextView val$valueView;

                    public void onClick(View view)
                    {
                        try
                        {
                            getActivity().startActivity((new Intent("android.intent.action.VIEW")).setData(Uri.parse("market://details?id=com.valvesoftware.android.steam.community")));
                            return;
                        }
                        catch (Exception exception)
                        {
                            valueView.setText((new StringBuilder()).append(settingInfo.m_defaultValue).append(" / ").append(getActivity().getString(0x7f070088)).toString());
                        }
                        try
                        {
                            getActivity().startActivity((new Intent("android.intent.action.VIEW")).setData(Uri.parse("http://store.steampowered.com/mobile")));
                            return;
                        }
                        catch (Exception exception1)
                        {
                            chevronView.setVisibility(8);
                        }
                    }

            
            {
                this$1 = final_settingslistadapter;
                valueView = textview;
                settingInfo = settinginfo;
                chevronView = ImageView.this;
                super();
            }
                };
                view1.setOnClickListener(onclicklistener5);
            }
            continue; /* Loop/switch isn't completed */
_L9:
            imageview.setVisibility(0);
            SteamDBService steamdbservice = SteamCommunityApplication.GetInstance().GetSteamDB();
            int j = 0;
            if (steamdbservice != null)
            {
                boolean flag1 = SteamWebApi.IsLoggedIn();
                j = 0;
                if (flag1)
                {
                    j = steamdbservice.getSteamUmqCommunicationServiceDB().selectCountOfUnreadMessages(SteamWebApi.GetLoginSteamID());
                }
            }
            textview.setText(getActivity().getString(settingInfo.m_resid).replace("#", String.valueOf(j)));
            android.view.View.OnClickListener onclicklistener4 = new android.view.View.OnClickListener() {

                final SettingsListAdapter this$1;

                public void onClick(View view)
                {
                    com.valvesoftware.android.steam.community.SteamDBService.REQ_ACT_MARKREADMESSAGES_DATA req_act_markreadmessages_data = new com.valvesoftware.android.steam.community.SteamDBService.REQ_ACT_MARKREADMESSAGES_DATA();
                    req_act_markreadmessages_data.mysteamid = SteamWebApi.GetLoginSteamID();
                    req_act_markreadmessages_data.withsteamid = null;
                    req_act_markreadmessages_data.deleteAllMessages = false;
                    SteamWebApi.SubmitSimpleActionRequest("MarkReadMessages", req_act_markreadmessages_data);
                    Intent intent = new Intent("com.valvesoftware.android.steam.community.SteamUmqCommunicationIntent");
                    intent.putExtra("type", "chatmsg");
                    intent.putExtra("action", "read");
                    intent.putExtra("steamid", "0");
                    SteamCommunityApplication.GetInstance().getApplicationContext().sendBroadcast(intent);
                    refreshListView();
                }

            
            {
                this$1 = SettingsListAdapter.this;
                super();
            }
            };
            view1.setOnClickListener(onclicklistener4);
            continue; /* Loop/switch isn't completed */
_L2:
            valueView.setText(settingInfo.m_defaultValue);
            continue; /* Loop/switch isn't completed */
_L3:
            boolean flag = settingInfo.getBooleanValue(m_owner.getApplicationContext());
            checkbox.setVisibility(0);
            checkbox.setChecked(flag);
            android.widget.CompoundButton.OnCheckedChangeListener oncheckedchangelistener = settingInfo. new android.widget.CompoundButton.OnCheckedChangeListener() {

                final SettingsListAdapter this$1;
                final SettingInfo val$settingInfo;

                public void onCheckedChanged(CompoundButton compoundbutton, boolean flag)
                {
                    SettingInfo settinginfo = settingInfo;
                    Context context = m_owner.getApplicationContext();
                    String s;
                    if (flag)
                    {
                        s = "1";
                    } else
                    {
                        s = "";
                    }
                    settinginfo.setValueAndCommit(context, s);
                }

            
            {
                this$1 = final_settingslistadapter;
                settingInfo = SettingInfo.this;
                super();
            }
            };
            checkbox.setOnCheckedChangeListener(oncheckedchangelistener);
            android.view.View.OnClickListener onclicklistener3 = checkbox. new android.view.View.OnClickListener() {

                final SettingsListAdapter this$1;
                final CheckBox val$checkBox;

                public void onClick(View view)
                {
                    CheckBox checkbox = checkBox;
                    boolean flag;
                    if (!checkBox.isChecked())
                    {
                        flag = true;
                    } else
                    {
                        flag = false;
                    }
                    checkbox.setChecked(flag);
                }

            
            {
                this$1 = final_settingslistadapter;
                checkBox = CheckBox.this;
                super();
            }
            };
            view1.setOnClickListener(onclicklistener3);
            continue; /* Loop/switch isn't completed */
_L4:
            imageview.setVisibility(0);
            String s1 = settingInfo.getValue(m_owner.getApplicationContext());
            final Calendar myDOB = com.valvesoftware.android.steam.community.SettingInfo.DateConverter.makeCalendar(s1);
            android.view.View.OnClickListener onclicklistener2;
            if (s1 != null && !s1.equals(""))
            {
                valueView.setText(com.valvesoftware.android.steam.community.SettingInfo.DateConverter.formatDate(s1));
            } else
            {
                valueView.setText(0x7f070057);
            }
            onclicklistener2 = settingInfo. new android.view.View.OnClickListener() {

                final SettingsListAdapter this$1;
                final Calendar val$myDOB;
                final SettingInfo val$settingInfo;
                final TextView val$valueView;

                public void onClick(View view)
                {
                    (new com.valvesoftware.android.steam.community.SettingInfo.CustomDatePickerDialog(m_owner, new android.app.DatePickerDialog.OnDateSetListener() {

                        final SettingsListAdapter._cls5 this$2;

                        public void onDateSet(DatePicker datepicker, int i, int j, int k)
                        {
                            myDOB.set(i, j, k);
                            String s = com.valvesoftware.android.steam.community.SettingInfo.DateConverter.makeValue(i, j, k);
                            if (s != null && !s.equals(""))
                            {
                                valueView.setText(com.valvesoftware.android.steam.community.SettingInfo.DateConverter.formatDate(s));
                            }
                            settingInfo.setValueAndCommit(m_owner.getApplicationContext(), s);
                        }

            
            {
                this$2 = SettingsListAdapter._cls5.this;
                super();
            }
                    }, myDOB, 0x7f07004f)).show();
                }

            
            {
                this$1 = final_settingslistadapter;
                myDOB = calendar;
                valueView = textview;
                settingInfo = SettingInfo.this;
                super();
            }
            };
            view1.setOnClickListener(onclicklistener2);
            continue; /* Loop/switch isn't completed */
_L5:
            imageview.setVisibility(0);
            android.view.View.OnClickListener onclicklistener1 = settingInfo. new android.view.View.OnClickListener() {

                final SettingsListAdapter this$1;
                final SettingInfo val$settingInfo;

                public void onClick(View view)
                {
                    getActivity().startActivity((new Intent()).addFlags(0x18000000).setClass(getActivity(), com/valvesoftware/android/steam/community/activity/SteamMobileUriActivity).setAction("android.intent.action.VIEW").putExtra("title_resid", settingInfo.m_resid).setData(Uri.parse(settingInfo.m_defaultValue)));
                }

            
            {
                this$1 = final_settingslistadapter;
                settingInfo = SettingInfo.this;
                super();
            }
            };
            view1.setOnClickListener(onclicklistener1);
            continue; /* Loop/switch isn't completed */
_L7:
            imageview.setVisibility(0);
            valueView.setText(settingInfo.getRadioSelectorItemValue(m_owner.getApplicationContext()).resid_text);
            RadioSelectorItemOnClickListener radioselectoritemonclicklistener = new RadioSelectorItemOnClickListener(getActivity(), settingInfo, valueView);
            view1.setOnClickListener(radioselectoritemonclicklistener);
            continue; /* Loop/switch isn't completed */
_L8:
            imageview.setVisibility(0);
            String s = settingInfo.getValue(m_owner.getApplicationContext());
            if (s == null)
            {
                break; /* Loop/switch isn't completed */
            }
            android.view.View.OnClickListener onclicklistener;
            try
            {
                if (!settingInfo.m_defaultValue.equals(s))
                {
                    break; /* Loop/switch isn't completed */
                }
                valueView.setText(0x7f070043);
            }
            catch (Exception exception)
            {
                valueView.setText(0x7f070044);
            }
            onclicklistener = i. new android.view.View.OnClickListener() {

                final SettingsListAdapter this$1;
                final int val$positionWhenStartingActivityForResult;
                final SettingInfo val$settingInfo;

                public void onClick(View view)
                {
                    Intent intent;
                    Exception exception1;
                    try
                    {
                        intent = new Intent("android.intent.action.RINGTONE_PICKER");
                        intent.putExtra("android.intent.extra.ringtone.TYPE", 2);
                        intent.putExtra("android.intent.extra.ringtone.TITLE", getActivity().getString(settingInfo.m_resid));
                    }
                    catch (Exception exception)
                    {
                        return;
                    }
                    intent.putExtra("android.intent.extra.ringtone.EXISTING_URI", Uri.parse(settingInfo.getValue(m_owner.getApplicationContext())));
_L1:
                    intent.putExtra("android.intent.extra.ringtone.DEFAULT_URI", Uri.parse(settingInfo.m_defaultValue));
                    intent.putExtra("android.intent.extra.ringtone.SHOW_DEFAULT", true);
                    intent.putExtra("android.intent.extra.ringtone.SHOW_SILENT", false);
                    getActivity().startActivityForResult(intent, positionWhenStartingActivityForResult);
                    return;
                    exception1;
                    intent.putExtra("android.intent.extra.ringtone.EXISTING_URI", (Uri)null);
                      goto _L1
                }

            
            {
                this$1 = final_settingslistadapter;
                settingInfo = settinginfo;
                positionWhenStartingActivityForResult = I.this;
                super();
            }
            };
            view1.setOnClickListener(onclicklistener);
            if (true) goto _L1; else goto _L10
_L10:
            valueView.setText(RingtoneManager.getRingtone(getActivity(), Uri.parse(s)).getTitle(getActivity()));
            break MISSING_BLOCK_LABEL_716;
        }

        public SettingsListAdapter(Context context, int i, ArrayList arraylist)
        {
            this$0 = SettingsFragment.this;
            super(context, i, arraylist);
            items = arraylist;
        }
    }

    private class UmqDBCallback extends BroadcastReceiver
    {

        final SettingsFragment this$0;

        public void onReceive(Context context, Intent intent)
        {
            while (getActivity() == null || !intent.getStringExtra("type").equalsIgnoreCase("umqstate")) 
            {
                return;
            }
            if (SteamWebApi.IsLoggedIn() != m_bLoggedOnPresentation)
            {
                refreshListView();
                return;
            } else
            {
                setupUserAccountView(m_viewProfile);
                return;
            }
        }

        private UmqDBCallback()
        {
            this$0 = SettingsFragment.this;
            super();
        }

    }


    private SettingsListAdapter m_SettingsAdapter;
    private android.view.View.OnClickListener m_accountControlChangeUser;
    private boolean m_bLoggedOnPresentation;
    private ListView m_listView;
    private Activity m_owner;
    private android.view.View.OnClickListener m_profileClickListener;
    private final com.valvesoftware.android.steam.community.GenericListDB.ListItemUpdatedListener m_profileUpdateListener = new com.valvesoftware.android.steam.community.GenericListDB.ListItemUpdatedListener() {

        final SettingsFragment this$0;

        public void OnListItemInfoUpdateError(com.valvesoftware.android.steam.community.SteamWebApi.RequestBase requestbase)
        {
        }

        public void OnListItemInfoUpdated(ArrayList arraylist, boolean flag)
        {
            if (getActivity() == null)
            {
                return;
            } else
            {
                setupUserAccountView(m_viewProfile);
                return;
            }
        }

        public void OnListRefreshError(com.valvesoftware.android.steam.community.SteamWebApi.RequestBase requestbase, boolean flag)
        {
        }

        public void OnListRequestsInProgress(boolean flag)
        {
        }

            
            {
                this$0 = SettingsFragment.this;
                super();
            }
    };
    private ArrayList m_settingsInfoArray;
    private final UmqDBCallback m_umqdbIntentReceiver = new UmqDBCallback();
    private View m_viewProfile;

    public SettingsFragment()
    {
        m_owner = null;
        m_settingsInfoArray = new ArrayList();
        m_listView = null;
        m_SettingsAdapter = null;
        m_viewProfile = null;
        m_profileClickListener = new android.view.View.OnClickListener() {

            final SettingsFragment this$0;

            public void onClick(View view)
            {
                if (getActivity() != null)
                {
                    setupUserAccountView(m_viewProfile);
                    NavigationFragment navigationfragment = ActivityHelper.GetNavigationFragmentForActivity(getActivity());
                    if (navigationfragment != null)
                    {
                        navigationfragment.m_itemProfile.onClick();
                        return;
                    }
                }
            }

            
            {
                this$0 = SettingsFragment.this;
                super();
            }
        };
        m_accountControlChangeUser = new android.view.View.OnClickListener() {

            final SettingsFragment this$0;

            public void onClick(View view)
            {
                FragmentActivityWithNavigationSupport.finishAll();
                ActivityHelper.PresentLoginActivity(null, com.valvesoftware.android.steam.community.activity.LoginActivity.LoginAction.LOGOUT);
            }

            
            {
                this$0 = SettingsFragment.this;
                super();
            }
        };
        m_bLoggedOnPresentation = false;
    }

    private void setupUserAccountView(View view)
    {
        if (view == null)
        {
            return;
        }
        ((TextView)view.findViewById(0x7f09000d)).setVisibility(8);
        ((ImageView)view.findViewById(0x7f090017)).setVisibility(8);
        ((Button)view.findViewById(0x7f090016)).setVisibility(8);
        TextView textview = (TextView)view.findViewById(0x7f090013);
        TextView textview1 = (TextView)view.findViewById(0x7f090014);
        ImageView imageview = (ImageView)view.findViewById(0x7f09000e);
        ImageView imageview1 = (ImageView)view.findViewById(0x7f090012);
        FriendInfo friendinfo;
        boolean flag;
        int i;
        Resources resources;
        int j;
        int k;
        if (SteamWebApi.IsLoggedIn())
        {
            friendinfo = SteamCommunityApplication.GetInstance().GetFriendInfoDB().GetFriendInfo(Long.valueOf(SteamWebApi.GetLoginSteamID()));
            textview.setText(0x7f07001e);
        } else
        {
            textview.setText(0x7f070008);
            friendinfo = null;
        }
        textview1.setText("");
        imageview.setImageResource(0x7f020026);
        flag = false;
        if (friendinfo != null)
        {
            boolean flag1 = friendinfo.HasPresentationData();
            flag = false;
            if (flag1)
            {
                AndroidUtils.setTextViewText(textview, friendinfo.m_personaName);
                friendinfo.IsAvatarSmallLoaded();
                imageview.setImageBitmap(friendinfo.GetAvatarSmall());
                SteamDBService steamdbservice = SteamCommunityApplication.GetInstance().GetSteamDB();
                com.valvesoftware.android.steam.community.SteamUmqCommunicationService.UmqConnectionState umqconnectionstate = com.valvesoftware.android.steam.community.SteamUmqCommunicationService.UmqConnectionState.offline;
                if (steamdbservice != null)
                {
                    umqconnectionstate = steamdbservice.getSteamUmqConnectionState();
                }
                textview1.setText(umqconnectionstate.getStringResid());
                boolean flag2 = umqconnectionstate.isConnected();
                flag = false;
                if (flag2)
                {
                    flag = true;
                    imageview1.setImageResource(0x7f020002);
                }
            }
        }
        if (flag)
        {
            i = 0x7f020002;
        } else
        {
            i = 0x7f020001;
        }
        imageview1.setImageResource(i);
        resources = getActivity().getResources();
        if (flag)
        {
            j = 0x7f060014;
        } else
        {
            j = 0x7f060012;
        }
        k = resources.getColor(j);
        textview.setTextColor(k);
        textview1.setTextColor(k);
    }

    public void onActivityCreated(Bundle bundle)
    {
        super.onActivityCreated(bundle);
        m_owner = getActivity();
        if (m_SettingsAdapter == null)
        {
            m_SettingsAdapter = new SettingsListAdapter(m_owner, 0x7f030013, m_settingsInfoArray);
        }
        if (m_listView == null)
        {
            m_listView = getListView();
        }
        if (m_viewProfile == null)
        {
            m_viewProfile = getActivity().findViewById(0x7f09002f);
            m_viewProfile.setOnClickListener(m_profileClickListener);
        }
        getActivity().findViewById(0x7f090030).setOnClickListener(m_accountControlChangeUser);
        setListAdapter(m_SettingsAdapter);
        TitlebarFragment titlebarfragment = ActivityHelper.GetTitlebarFragmentForActivity(getActivity());
        if (titlebarfragment != null)
        {
            titlebarfragment.setTitleLabel(0x7f070007);
            titlebarfragment.setRefreshHandler(null);
        }
    }

    public void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
    }

    public View onCreateView(LayoutInflater layoutinflater, ViewGroup viewgroup, Bundle bundle)
    {
        return layoutinflater.inflate(0x7f030012, viewgroup, false);
    }

    public void onFragmentActivityResult(int i, int j, Intent intent)
    {
        if (getActivity() == null)
        {
            return;
        }
        if (j == -1)
        {
            Uri uri = (Uri)intent.getParcelableExtra("android.intent.extra.ringtone.PICKED_URI");
            if (uri != null)
            {
                String s = uri.toString();
                if (i >= 0 && i < m_settingsInfoArray.size())
                {
                    SettingInfo settinginfo = (SettingInfo)m_settingsInfoArray.get(i);
                    if (settinginfo.m_type == com.valvesoftware.android.steam.community.SettingInfo.SettingType.RINGTONESELECTOR)
                    {
                        if (uri.equals(android.provider.Settings.System.DEFAULT_NOTIFICATION_URI))
                        {
                            s = settinginfo.m_defaultValue;
                        }
                        settinginfo.setValueAndCommit(m_owner.getApplicationContext(), s);
                    }
                }
            }
        }
        refreshListView();
    }

    public void onPause()
    {
        super.onPause();
        SteamCommunityApplication.GetInstance().GetFriendInfoDB().DeregisterCallback(m_profileUpdateListener);
        getActivity().unregisterReceiver(m_umqdbIntentReceiver);
    }

    public void onResume()
    {
        super.onResume();
        if (getActivity() == null)
        {
            return;
        } else
        {
            refreshListView();
            getActivity().registerReceiver(m_umqdbIntentReceiver, new IntentFilter("com.valvesoftware.android.steam.community.SteamUmqCommunicationIntent"));
            SteamCommunityApplication.GetInstance().GetFriendInfoDB().RegisterCallback(m_profileUpdateListener);
            return;
        }
    }

    public void refreshListView()
    {
        SteamDBService steamdbservice;
        SettingInfoDB settinginfodb;
        SettingInfo settinginfo;
        boolean flag;
        m_bLoggedOnPresentation = SteamWebApi.IsLoggedIn();
        m_settingsInfoArray.clear();
        setupUserAccountView(m_viewProfile);
        Button button = (Button)getActivity().findViewById(0x7f090030);
        int i;
        int j;
        int k;
        int l;
        if (m_bLoggedOnPresentation)
        {
            i = 0x7f070014;
        } else
        {
            i = 0x7f070008;
        }
        button.setText(i);
        steamdbservice = SteamCommunityApplication.GetInstance().GetSteamDB();
        settinginfodb = SteamCommunityApplication.GetInstance().GetSettingInfoDB();
        m_settingsInfoArray.addAll(settinginfodb.GetSettingsList());
        j = m_settingsInfoArray.size();
_L13:
        k = j - 1;
        if (j <= 0) goto _L2; else goto _L1
_L1:
        settinginfo = (SettingInfo)m_settingsInfoArray.get(k);
        l = _cls4..SwitchMap.com.valvesoftware.android.steam.community.SettingInfo.AccessRight[settinginfo.m_access.ordinal()];
        flag = false;
        l;
        JVM INSTR tableswitch 1 3: default 160
    //                   1 255
    //                   2 261
    //                   3 270;
           goto _L3 _L4 _L5 _L6
_L3:
        if (!flag) goto _L8; else goto _L7
_L7:
        _cls4..SwitchMap.com.valvesoftware.android.steam.community.SettingInfo.SettingType[settinginfo.m_type.ordinal()];
        JVM INSTR tableswitch 1 8: default 224
    //                   1 227
    //                   2 227
    //                   3 227
    //                   4 227
    //                   5 227
    //                   6 227
    //                   7 227
    //                   8 318;
           goto _L9 _L10 _L10 _L10 _L10 _L10 _L10 _L10 _L11
_L10:
        break; /* Loop/switch isn't completed */
_L9:
        flag = false;
_L8:
        if (!flag)
        {
            m_settingsInfoArray.remove(k);
        }
        j = k;
        continue; /* Loop/switch isn't completed */
_L4:
        flag = true;
          goto _L3
_L5:
        flag = m_bLoggedOnPresentation;
          goto _L3
_L6:
        SettingInfo settinginfo1 = settinginfodb.m_settingSslUntrustedPrompt;
        flag = false;
        if (settinginfo == settinginfo1)
        {
            if (settinginfo.getRadioSelectorItemValue(m_owner.getApplicationContext()).value == -1)
            {
                flag = true;
            } else
            {
                flag = false;
            }
        }
          goto _L3
_L11:
        if (steamdbservice != null && SteamWebApi.IsLoggedIn() && steamdbservice.getSteamUmqCommunicationServiceDB().selectCountOfUnreadMessages(SteamWebApi.GetLoginSteamID()) > 0)
        {
            flag = true;
        } else
        {
            flag = false;
        }
          goto _L8
_L2:
        m_SettingsAdapter.notifyDataSetChanged();
        return;
        if (true) goto _L13; else goto _L12
_L12:
    }





    // Unreferenced inner class com/valvesoftware/android/steam/community/fragment/SettingsFragment$RadioSelectorItemOnClickListener$1

/* anonymous class */
    class RadioSelectorItemOnClickListener._cls1
        implements android.content.DialogInterface.OnClickListener
    {

        final RadioSelectorItemOnClickListener this$0;

        public void onClick(DialogInterface dialoginterface, int i)
        {
            com.valvesoftware.android.steam.community.SettingInfo.RadioSelectorItem aradioselectoritem[] = (com.valvesoftware.android.steam.community.SettingInfo.RadioSelectorItem[])(com.valvesoftware.android.steam.community.SettingInfo.RadioSelectorItem[])settingInfo.m_extraData;
            if (i >= 0 && i < aradioselectoritem.length)
            {
                if (valueView != null)
                {
                    valueView.setText(aradioselectoritem[i].resid_text);
                }
                settingInfo.setValueAndCommit(activity.getApplicationContext(), String.valueOf(aradioselectoritem[i].value));
                alert.dismiss();
                onSettingChanged(aradioselectoritem[i]);
            }
        }

            
            {
                this$0 = RadioSelectorItemOnClickListener.this;
                super();
            }
    }

}
