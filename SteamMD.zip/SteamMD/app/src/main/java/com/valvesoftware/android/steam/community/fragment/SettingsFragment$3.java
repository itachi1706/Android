// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.fragment;

import java.util.ArrayList;

// Referenced classes of package com.valvesoftware.android.steam.community.fragment:
//            SettingsFragment

class this._cls0
    implements com.valvesoftware.android.steam.community.temUpdatedListener
{

    final SettingsFragment this$0;

    public void OnListItemInfoUpdateError(com.valvesoftware.android.steam.community.Base base)
    {
    }

    public void OnListItemInfoUpdated(ArrayList arraylist, boolean flag)
    {
        if (getActivity() == null)
        {
            return;
        } else
        {
            SettingsFragment.access$100(SettingsFragment.this, SettingsFragment.access$000(SettingsFragment.this));
            return;
        }
    }

    public void OnListRefreshError(com.valvesoftware.android.steam.community.Base base, boolean flag)
    {
    }

    public void OnListRequestsInProgress(boolean flag)
    {
    }

    dListener()
    {
        this$0 = SettingsFragment.this;
        super();
    }
}
