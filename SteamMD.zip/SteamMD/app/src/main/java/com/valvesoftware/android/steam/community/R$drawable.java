// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;


// Referenced classes of package com.valvesoftware.android.steam.community:
//            R

public static final class 
{

    public static final int avatar_frame_ingame = 0x7f020000;
    public static final int avatar_frame_offline = 0x7f020001;
    public static final int avatar_frame_online = 0x7f020002;
    public static final int button_navigation = 0x7f020003;
    public static final int button_navigation_highlighted = 0x7f020004;
    public static final int chat_bubble_left = 0x7f020005;
    public static final int chat_bubble_left_blue = 0x7f020006;
    public static final int chat_bubble_right = 0x7f020007;
    public static final int chat_button_available = 0x7f020008;
    public static final int chat_button_offline = 0x7f020009;
    public static final int chat_button_unread = 0x7f02000a;
    public static final int icon_coverup = 0x7f02000b;
    public static final int icon_options_hide = 0x7f02000c;
    public static final int icon_options_show = 0x7f02000d;
    public static final int icon_quarter = 0x7f02000e;
    public static final int icon_refresh = 0x7f02000f;
    public static final int icon_search = 0x7f020010;
    public static final int icon_search_add = 0x7f020011;
    public static final int icon_up = 0x7f020012;
    public static final int login_gradient = 0x7f020013;
    public static final int nav_item_blotter = 0x7f020014;
    public static final int nav_item_cart = 0x7f020015;
    public static final int nav_item_exit = 0x7f020016;
    public static final int nav_item_feed = 0x7f020017;
    public static final int nav_item_friends = 0x7f020018;
    public static final int nav_item_groups = 0x7f020019;
    public static final int nav_item_search = 0x7f02001a;
    public static final int nav_item_settings = 0x7f02001b;
    public static final int nav_item_store_catalog = 0x7f02001c;
    public static final int nav_item_store_wishlist = 0x7f02001d;
    public static final int navbar_pattern = 0x7f02001e;
    public static final int navbar_repeat = 0x7f02001f;
    public static final int navigation_bg_pattern = 0x7f020020;
    public static final int navigation_bg_repeat = 0x7f020021;
    public static final int navigation_gradient = 0x7f020022;
    public static final int notification_chat = 0x7f020023;
    public static final int notification_default = 0x7f020024;
    public static final int notification_offline = 0x7f020025;
    public static final int placeholder_contact = 0x7f020026;
    public static final int search = 0x7f020027;
    public static final int steam = 0x7f020028;
    public static final int steam_btn_default = 0x7f020029;
    public static final int steam_btn_default_normal = 0x7f02002a;
    public static final int steam_btn_default_normal_disable = 0x7f02002b;
    public static final int steam_btn_default_normal_disable_focused = 0x7f02002c;
    public static final int steam_btn_default_pressed = 0x7f02002d;
    public static final int steam_btn_default_selected = 0x7f02002e;
    public static final int steam_edit_text = 0x7f02002f;
    public static final int steam_textfield_default = 0x7f020030;
    public static final int steam_textfield_disabled = 0x7f020031;
    public static final int steam_textfield_disabled_selected = 0x7f020032;
    public static final int steam_textfield_pressed = 0x7f020033;
    public static final int steam_textfield_search_default = 0x7f020034;
    public static final int steam_textfield_search_pressed = 0x7f020035;
    public static final int steam_textfield_search_selected = 0x7f020036;
    public static final int steam_textfield_selected = 0x7f020037;
    public static final int table_cell_background = 0x7f020038;
    public static final int table_cell_chevron = 0x7f020039;
    public static final int table_cell_chevron_white = 0x7f02003a;
    public static final int table_cell_section = 0x7f02003b;
    public static final int unknown = 0x7f02003c;

    public ()
    {
    }
}
