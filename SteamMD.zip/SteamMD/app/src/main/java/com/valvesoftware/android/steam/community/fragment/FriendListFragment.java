// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.fragment;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import com.valvesoftware.android.steam.community.AndroidUtils;
import com.valvesoftware.android.steam.community.Config;
import com.valvesoftware.android.steam.community.FriendInfo;
import com.valvesoftware.android.steam.community.GenericListDB;
import com.valvesoftware.android.steam.community.SteamCommunityApplication;
import com.valvesoftware.android.steam.community.SteamWebApi;
import com.valvesoftware.android.steam.community.activity.ActivityHelper;
import com.valvesoftware.android.steam.community.activity.SearchFriendsActivity;
import com.valvesoftware.android.steam.community.activity.SteamMobileUriActivity;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;

// Referenced classes of package com.valvesoftware.android.steam.community.fragment:
//            BasePresentationListFragmentWithSearch, BaseFragmentWithLogin, TitlebarFragment

public class FriendListFragment extends BasePresentationListFragmentWithSearch
{
    private class FriendsListAdapter extends BasePresentationListFragment.HelperDbListAdapter
    {

        final FriendListFragment this$0;

        public View getView(int i, View view, ViewGroup viewgroup)
        {
            View view1;
            SteamCommunityApplication steamcommunityapplication;
            FriendInfo friendinfo;
            view1 = view;
            steamcommunityapplication = SteamCommunityApplication.GetInstance();
            if (view1 == null)
            {
                view1 = ((LayoutInflater)steamcommunityapplication.getSystemService("layout_inflater")).inflate(0x7f030009, null);
                view1.setClickable(true);
                view1.setOnClickListener(friendListClickListener);
            }
            friendinfo = null;
            friendinfo = (FriendInfo)m_presentationArray.get(i);
            if (i <= 0) goto _L2; else goto _L1
_L1:
            FriendInfo friendinfo2 = (FriendInfo)m_presentationArray.get(i - 1);
            FriendInfo friendinfo1 = friendinfo2;
_L4:
            if (friendinfo != null)
            {
                if (!friendinfo.IsAvatarSmallLoaded())
                {
                    RequestVisibleAvatars();
                }
                TextView textview = (TextView)view1.findViewById(0x7f09000d);
                TextView textview1 = (TextView)view1.findViewById(0x7f090013);
                TextView textview2 = (TextView)view1.findViewById(0x7f090014);
                ImageView imageview = (ImageView)view1.findViewById(0x7f09000e);
                ImageView imageview1 = (ImageView)view1.findViewById(0x7f090012);
                TextView textview3 = (TextView)view1.findViewById(0x7f090018);
                ImageView imageview2 = (ImageView)view1.findViewById(0x7f090017);
                Button button = (Button)view1.findViewById(0x7f090016);
                button.setOnClickListener(friendChatClickListener);
                String s;
                View view2;
                if (i == 0 || friendinfo1 == null || friendinfo.m_categoryInList != friendinfo1.m_categoryInList)
                {
                    textview.setText(friendinfo.m_categoryInList.GetDisplayString());
                    textview.setVisibility(0);
                } else
                {
                    textview.setVisibility(8);
                }
                textview.setOnClickListener(dummyClickListener);
                textview3.setText(Long.toString(friendinfo.m_steamID.longValue()));
                AndroidUtils.setTextViewText(textview1, friendinfo.m_personaName);
                if (friendinfo != GetSearchItem())
                {
                    imageview.setImageBitmap(friendinfo.GetAvatarSmall());
                    imageview1.setVisibility(0);
                } else
                {
                    imageview.setImageResource(0x7f020010);
                    imageview1.setVisibility(8);
                }
                if (friendinfo == GetSearchItem())
                {
                    AndroidUtils.setTextViewText(textview2, getSearchModeText());
                } else
                if (friendinfo.m_personaState == com.valvesoftware.android.steam.community.FriendInfo.PersonaState.OFFLINE && friendinfo.m_lastOnlineString != null)
                {
                    textview2.setText(friendinfo.m_lastOnlineString);
                } else
                {
                    textview2.setText(friendinfo.m_personaState.GetDisplayString());
                }
                if (friendinfo.m_chatInfo.numUnreadMsgs > 0)
                {
                    s = Integer.valueOf(friendinfo.m_chatInfo.numUnreadMsgs).toString();
                } else
                {
                    s = "";
                }
                button.setText(s);
                if (friendinfo.m_chatInfo.numUnreadMsgs > 0)
                {
                    button.setBackgroundResource(0x7f02000a);
                } else
                if (friendinfo.m_personaState == com.valvesoftware.android.steam.community.FriendInfo.PersonaState.OFFLINE)
                {
                    button.setBackgroundResource(0x7f020009);
                } else
                {
                    button.setBackgroundResource(0x7f020008);
                }
                if (friendinfo.m_currentGameString.length() > 0)
                {
                    imageview1.setImageResource(0x7f020000);
                    textview1.setTextColor(steamcommunityapplication.getResources().getColor(0x7f060013));
                    textview2.setTextColor(steamcommunityapplication.getResources().getColor(0x7f060013));
                    String s1 = steamcommunityapplication.getResources().getString(0x7f070028);
                    textview2.setText((new StringBuilder()).append(s1).append(" ").append(friendinfo.m_currentGameString).toString());
                    button.setVisibility(0);
                    imageview2.setVisibility(8);
                } else
                if (friendinfo.m_personaState == com.valvesoftware.android.steam.community.FriendInfo.PersonaState.OFFLINE)
                {
                    imageview1.setImageResource(0x7f020001);
                    textview1.setTextColor(steamcommunityapplication.getResources().getColor(0x7f060012));
                    textview2.setTextColor(steamcommunityapplication.getResources().getColor(0x7f060012));
                    int j;
                    byte byte0;
                    if (friendinfo.m_chatInfo.numMsgsTotal > 0)
                    {
                        j = 0;
                    } else
                    {
                        j = 8;
                    }
                    button.setVisibility(j);
                    if (friendinfo.m_chatInfo.numMsgsTotal > 0)
                    {
                        byte0 = 8;
                    } else
                    {
                        byte0 = 0;
                    }
                    imageview2.setVisibility(byte0);
                } else
                {
                    imageview1.setImageResource(0x7f020002);
                    textview1.setTextColor(steamcommunityapplication.getResources().getColor(0x7f060014));
                    textview2.setTextColor(steamcommunityapplication.getResources().getColor(0x7f060014));
                    imageview2.setVisibility(8);
                    button.setVisibility(0);
                }
                if (com.valvesoftware.android.steam.community.FriendInfo.FriendRelationship.friend != friendinfo.m_relationship)
                {
                    button.setVisibility(8);
                    imageview2.setVisibility(0);
                }
                view2 = view1.findViewById(0x7f090015);
                if (view2 != null)
                {
                    android.view.View.OnClickListener onclicklistener;
                    if (button.getVisibility() == 0)
                    {
                        onclicklistener = friendChatClickListener;
                    } else
                    {
                        onclicklistener = friendListClickListener;
                    }
                    view2.setOnClickListener(onclicklistener);
                }
            }
            return view1;
_L2:
            friendinfo1 = null;
            continue; /* Loop/switch isn't completed */
            Exception exception;
            exception;
            friendinfo1 = null;
            if (true) goto _L4; else goto _L3
_L3:
        }

        public FriendsListAdapter()
        {
            this$0 = FriendListFragment.this;
            super(FriendListFragment.this, 0x7f030009);
        }
    }


    private android.view.View.OnClickListener dummyClickListener;
    public android.view.View.OnClickListener friendChatClickListener;
    private android.view.View.OnClickListener friendListClickListener;
    private BaseFragmentWithLogin m_login;
    private TitlebarFragment.TitlebarButtonHander m_refreshHandler;
    private Comparator m_sorter;

    public FriendListFragment()
    {
        m_login = new BaseFragmentWithLogin(this);
        m_refreshHandler = new TitlebarFragment.TitlebarButtonHander() {

            final FriendListFragment this$0;

            public void onTitlebarButtonClicked(int i)
            {
                if (!SteamWebApi.IsLoggedIn())
                {
                    return;
                } else
                {
                    myListDb().RefreshFromHttpOnly();
                    return;
                }
            }

            
            {
                this$0 = FriendListFragment.this;
                super();
            }
        };
        friendListClickListener = new android.view.View.OnClickListener() {

            final FriendListFragment this$0;

            public void onClick(View view)
            {
                String s;
label0:
                {
                    TextView textview = (TextView)view.findViewById(0x7f090018);
                    if (textview != null)
                    {
                        s = textview.getText().toString();
                        if (!s.equals("0"))
                        {
                            break label0;
                        }
                        Intent intent1 = (new Intent()).setClass(getActivity(), com/valvesoftware/android/steam/community/activity/SearchFriendsActivity).addFlags(0x20000000).addFlags(0x10000000).setData(Uri.parse((new StringBuilder()).append("searchfriend://").append(System.currentTimeMillis()).append(getSearchModeText()).toString())).putExtra("query", getSearchModeText());
                        getActivity().startActivity(intent1);
                    }
                    return;
                }
                Intent intent = (new Intent()).addFlags(0x18000000).setClass(getActivity(), com/valvesoftware/android/steam/community/activity/SteamMobileUriActivity).setData(Uri.parse((new StringBuilder()).append("steammobile://").append(com.valvesoftware.android.steam.community.SteamUriHandler.Command.openurl).append("?url=").append(Config.URL_COMMUNITY_BASE).append("/profiles/").append(s).toString())).setAction("android.intent.action.VIEW");
                getActivity().startActivity(intent);
            }

            
            {
                this$0 = FriendListFragment.this;
                super();
            }
        };
        friendChatClickListener = new android.view.View.OnClickListener() {

            final FriendListFragment this$0;

            public void onClick(View view)
            {
                TextView textview;
                PendingIntent pendingintent;
                if (view instanceof Button)
                {
                    textview = (TextView)((View)view.getParent()).findViewById(0x7f090018);
                } else
                {
                    textview = (TextView)view.findViewById(0x7f090018);
                }
                if (textview == null)
                {
                    break MISSING_BLOCK_LABEL_45;
                }
                pendingintent = SteamCommunityApplication.GetInstance().GetIntentToChatWithSteamID(textview.getText().toString());
                pendingintent.send();
                return;
                android.app.PendingIntent.CanceledException canceledexception;
                canceledexception;
            }

            
            {
                this$0 = FriendListFragment.this;
                super();
            }
        };
        dummyClickListener = new android.view.View.OnClickListener() {

            final FriendListFragment this$0;

            public void onClick(View view)
            {
            }

            
            {
                this$0 = FriendListFragment.this;
                super();
            }
        };
        m_sorter = new Comparator() {

            static final boolean $assertionsDisabled;
            final FriendListFragment this$0;

            public int compare(FriendInfo friendinfo, FriendInfo friendinfo1)
            {
                if (friendinfo.m_categoryInList == friendinfo1.m_categoryInList) goto _L2; else goto _L1
_L1:
                if (friendinfo.m_categoryInList.ordinal() >= friendinfo1.m_categoryInList.ordinal()) goto _L4; else goto _L3
_L3:
                return -1;
_L4:
                return 1;
_L2:
                static class _cls6
                {

                    static final int $SwitchMap$com$valvesoftware$android$steam$community$FriendInfo$PersonaStateCategoryInList[];

                    static 
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$FriendInfo$PersonaStateCategoryInList = new int[com.valvesoftware.android.steam.community.FriendInfo.PersonaStateCategoryInList.values().length];
                        try
                        {
                            $SwitchMap$com$valvesoftware$android$steam$community$FriendInfo$PersonaStateCategoryInList[com.valvesoftware.android.steam.community.FriendInfo.PersonaStateCategoryInList.CHATS.ordinal()] = 1;
                        }
                        catch (NoSuchFieldError nosuchfielderror) { }
                    }
                }

                switch (_cls6..SwitchMap.com.valvesoftware.android.steam.community.FriendInfo.PersonaStateCategoryInList[friendinfo.m_categoryInList.ordinal()])
                {
                default:
                    return friendinfo.m_personaName.compareToIgnoreCase(friendinfo1.m_personaName);

                case 1: // '\001'
                    break;
                }
                if (!$assertionsDisabled && friendinfo.m_chatInfo.latestMsgId == friendinfo1.m_chatInfo.latestMsgId)
                {
                    throw new AssertionError();
                }
                if (friendinfo.m_chatInfo.latestMsgId <= friendinfo1.m_chatInfo.latestMsgId)
                {
                    return 1;
                }
                if (true) goto _L3; else goto _L5
_L5:
            }

            public volatile int compare(Object obj, Object obj1)
            {
                return compare((FriendInfo)obj, (FriendInfo)obj1);
            }

            static 
            {
                boolean flag;
                if (!com/valvesoftware/android/steam/community/fragment/FriendListFragment.desiredAssertionStatus())
                {
                    flag = true;
                } else
                {
                    flag = false;
                }
                $assertionsDisabled = flag;
            }

            
            {
                this$0 = FriendListFragment.this;
                super();
            }
        };
    }

    private boolean hasRecentChatsHistory(FriendInfo friendinfo)
    {
        return friendinfo.m_chatInfo.numUnreadMsgs > 0 || friendinfo.m_chatInfo.numMsgsTotal > 0 && friendinfo.m_chatInfo.latestTimestamp != null && friendinfo.m_chatInfo.latestTimestamp.after(m_calRecentChatsThreshold);
    }

    protected void UpdateGlobalInformationPreSort()
    {
        super.UpdateGlobalInformationPreSort();
        m_login.UpdateGlobalInformationPreSort();
    }

    protected void activateSearch(boolean flag)
    {
        super.activateSearch(flag);
        TitlebarFragment titlebarfragment = ActivityHelper.GetTitlebarFragmentForActivity(getActivity());
        if (titlebarfragment != null)
        {
            TitlebarFragment.TitlebarButtonHander titlebarbuttonhander;
            if (flag)
            {
                titlebarbuttonhander = null;
            } else
            {
                titlebarbuttonhander = m_refreshHandler;
            }
            titlebarfragment.setRefreshHandler(titlebarbuttonhander);
        }
    }

    protected void myCbckProcessPresentationArray()
    {
        Iterator iterator = m_presentationArray.iterator();
        while (iterator.hasNext()) 
        {
            FriendInfo friendinfo = (FriendInfo)iterator.next();
            if (friendinfo.m_relationship == com.valvesoftware.android.steam.community.FriendInfo.FriendRelationship.requestrecipient)
            {
                friendinfo.m_categoryInList = com.valvesoftware.android.steam.community.FriendInfo.PersonaStateCategoryInList.REQUEST_INCOMING;
            } else
            if (hasRecentChatsHistory(friendinfo))
            {
                friendinfo.m_categoryInList = com.valvesoftware.android.steam.community.FriendInfo.PersonaStateCategoryInList.CHATS;
            } else
            if (friendinfo.m_currentGameString.length() > 0)
            {
                friendinfo.m_categoryInList = com.valvesoftware.android.steam.community.FriendInfo.PersonaStateCategoryInList.INGAME;
            } else
            if (friendinfo.m_personaState == com.valvesoftware.android.steam.community.FriendInfo.PersonaState.OFFLINE)
            {
                friendinfo.m_categoryInList = com.valvesoftware.android.steam.community.FriendInfo.PersonaStateCategoryInList.OFFLINE;
            } else
            {
                friendinfo.m_categoryInList = com.valvesoftware.android.steam.community.FriendInfo.PersonaStateCategoryInList.ONLINE;
            }
            friendinfo.UpdateLastOnlineTime(m_umqCurrentServerTime);
        }
        super.myCbckProcessPresentationArray();
        Collections.sort(m_presentationArray, m_sorter);
    }

    protected boolean myCbckShouldDisplayItemInList(FriendInfo friendinfo)
    {
        return friendinfo.m_relationship != com.valvesoftware.android.steam.community.FriendInfo.FriendRelationship.myself && friendinfo.HasPresentationData() && ApplySearchFilterBeforeDisplay(friendinfo.m_personaName);
    }

    protected volatile boolean myCbckShouldDisplayItemInList(com.valvesoftware.android.steam.community.GenericListDB.GenericListItem genericlistitem)
    {
        return myCbckShouldDisplayItemInList((FriendInfo)genericlistitem);
    }

    protected BasePresentationListFragment.HelperDbListAdapter myCreateListAdapter()
    {
        return new FriendsListAdapter();
    }

    protected FriendInfo myDbItemCreateSearchItem()
    {
        FriendInfo friendinfo = new FriendInfo();
        friendinfo.m_steamID = new Long(0L);
        friendinfo.m_personaState = com.valvesoftware.android.steam.community.FriendInfo.PersonaState.OFFLINE;
        friendinfo.m_categoryInList = com.valvesoftware.android.steam.community.FriendInfo.PersonaStateCategoryInList.SEARCH_ALL;
        friendinfo.m_relationship = com.valvesoftware.android.steam.community.FriendInfo.FriendRelationship.friend;
        String s = SteamCommunityApplication.GetInstance().getResources().getString(0x7f070076);
        friendinfo.m_realName = s;
        friendinfo.m_personaName = s;
        friendinfo.m_chatInfo = new com.valvesoftware.android.steam.community.ISteamUmqCommunicationDatabase.UserConversationInfo();
        return friendinfo;
    }

    protected volatile com.valvesoftware.android.steam.community.GenericListDB.GenericListItem myDbItemCreateSearchItem()
    {
        return myDbItemCreateSearchItem();
    }

    protected GenericListDB myListDb()
    {
        return SteamCommunityApplication.GetInstance().GetFriendInfoDB();
    }

    public void onActivityCreated(Bundle bundle)
    {
        super.onActivityCreated(bundle);
        m_login.onActivityCreated(bundle);
        TitlebarFragment titlebarfragment = ActivityHelper.GetTitlebarFragmentForActivity(getActivity());
        if (titlebarfragment != null)
        {
            titlebarfragment.setTitleLabel(0x7f07000e);
            titlebarfragment.setRefreshHandler(m_refreshHandler);
        }
    }

    public void onResume()
    {
        super.onResume();
        m_login.onResume();
    }


}
