// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.activity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import com.valvesoftware.android.steam.community.Config;
import com.valvesoftware.android.steam.community.SteamCommunityApplication;
import com.valvesoftware.android.steam.community.SteamWebApi;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

// Referenced classes of package com.valvesoftware.android.steam.community.activity:
//            SteamMobileUriActivity, FragmentActivityWithNavigationSupport, CommunityActivity

public class LoginActivity extends SteamMobileUriActivity
{
    public static final class LoginAction extends Enum
    {

        private static final LoginAction $VALUES[];
        public static final LoginAction LOGIN_DEFAULT;
        public static final LoginAction LOGIN_EVEN_IF_LOGGED_IN;
        public static final LoginAction LOGOUT;

        public static LoginAction valueOf(String s)
        {
            return (LoginAction)Enum.valueOf(com/valvesoftware/android/steam/community/activity/LoginActivity$LoginAction, s);
        }

        public static LoginAction[] values()
        {
            return (LoginAction[])$VALUES.clone();
        }

        static 
        {
            LOGOUT = new LoginAction("LOGOUT", 0);
            LOGIN_DEFAULT = new LoginAction("LOGIN_DEFAULT", 1);
            LOGIN_EVEN_IF_LOGGED_IN = new LoginAction("LOGIN_EVEN_IF_LOGGED_IN", 2);
            LoginAction aloginaction[] = new LoginAction[3];
            aloginaction[0] = LOGOUT;
            aloginaction[1] = LOGIN_DEFAULT;
            aloginaction[2] = LOGIN_EVEN_IF_LOGGED_IN;
            $VALUES = aloginaction;
        }

        private LoginAction(String s, int i)
        {
            super(s, i);
        }
    }

    public static interface LoginChangedListener
    {

        public abstract void onLoginChangedSuccessfully();
    }


    public static final Uri URI_LoginPage;
    public static ArrayList m_callBacksBeforeCreate = new ArrayList();
    private ArrayList m_callBacks;

    public LoginActivity()
    {
        m_callBacks = new ArrayList();
    }

    private boolean HandleLoginDocument(JSONObject jsonobject)
        throws JSONException
    {
        if (jsonobject.has("access_token") && jsonobject.has("x_steamid"))
        {
            if (SteamWebApi.IsLoggedIn())
            {
                SteamWebApi.LogOut();
            }
            SteamCommunityApplication.GetInstance().GetDiskCacheIndefinite().Write("login.json", jsonobject.toString().getBytes());
            com.valvesoftware.android.steam.community.SteamWebApi.LoginInformation logininformation = com.valvesoftware.android.steam.community.SteamWebApi.RequestForLogin.GetLoginInformation();
            logininformation.m_loginState = com.valvesoftware.android.steam.community.SteamWebApi.LoginState.LoggedIn;
            logininformation.m_accessToken = jsonobject.getString("access_token");
            logininformation.m_steamID = jsonobject.getString("x_steamid");
            SteamWebApi.SetLoginInformation(logininformation);
            setResult(-1);
            dispatchOnLoginChangedSuccessfully();
            finish();
            return true;
        } else
        {
            return false;
        }
    }

    public static void PreemptivelyLoginBasedOnCachedLoginDocument()
    {
        byte abyte0[] = SteamCommunityApplication.GetInstance().GetDiskCacheIndefinite().Read("login.json");
        if (abyte0 != null) goto _L2; else goto _L1
_L1:
        return;
_L2:
        String s = new String(abyte0);
        Object obj;
        boolean flag;
        obj = (new JSONTokener(s)).nextValue();
        flag = org/json/JSONObject.isInstance(obj);
        com.valvesoftware.android.steam.community.SteamWebApi.LoginInformation logininformation;
        logininformation = null;
        if (!flag)
        {
            break MISSING_BLOCK_LABEL_138;
        }
        JSONObject jsonobject;
        boolean flag1;
        jsonobject = (JSONObject)obj;
        flag1 = jsonobject.has("access_token");
        logininformation = null;
        if (!flag1)
        {
            break MISSING_BLOCK_LABEL_138;
        }
        boolean flag2 = jsonobject.has("x_steamid");
        logininformation = null;
        if (!flag2)
        {
            break MISSING_BLOCK_LABEL_138;
        }
        com.valvesoftware.android.steam.community.SteamWebApi.LoginInformation logininformation1;
        logininformation1 = new com.valvesoftware.android.steam.community.SteamWebApi.LoginInformation();
        logininformation1.m_loginState = com.valvesoftware.android.steam.community.SteamWebApi.LoginState.LoggedIn;
        logininformation1.m_accessToken = jsonobject.getString("access_token");
        logininformation1.m_steamID = jsonobject.getString("x_steamid");
        logininformation = logininformation1;
_L4:
        if (logininformation != null)
        {
            SteamWebApi.SetLoginInformation(logininformation);
            return;
        }
        if (true) goto _L1; else goto _L3
_L3:
        JSONException jsonexception;
        jsonexception;
        logininformation = null;
          goto _L4
    }

    private void dispatchOnLoginChangedSuccessfully()
    {
        ArrayList arraylist = m_callBacks;
        m_callBacks = new ArrayList();
        Iterator iterator = arraylist.iterator();
        do
        {
            if (!iterator.hasNext())
            {
                break;
            }
            LoginChangedListener loginchangedlistener = (LoginChangedListener)((WeakReference)iterator.next()).get();
            if (loginchangedlistener != null)
            {
                loginchangedlistener.onLoginChangedSuccessfully();
            }
        } while (true);
    }

    public void OnMobileLoginSucceeded(com.valvesoftware.android.steam.community.SteamUriHandler.Result result)
    {
        boolean flag1;
        JSONObject jsonobject = new JSONObject();
        jsonobject.put("x_steamid", result.getProperty(com.valvesoftware.android.steam.community.SteamUriHandler.CommandProperty.steamid));
        jsonobject.put("access_token", result.getProperty(com.valvesoftware.android.steam.community.SteamUriHandler.CommandProperty.oauth_token));
        jsonobject.put("x_webcookie", result.getProperty(com.valvesoftware.android.steam.community.SteamUriHandler.CommandProperty.webcookie));
        flag1 = HandleLoginDocument(jsonobject);
        boolean flag = flag1;
_L2:
        if (!flag)
        {
            ReloadPage();
        }
        return;
        Exception exception;
        exception;
        flag = false;
        if (true) goto _L2; else goto _L1
_L1:
    }

    public void finish()
    {
        super.finish();
        if (!FragmentActivityWithNavigationSupport.hasValidActivities() && SteamWebApi.IsLoggedIn())
        {
            SteamCommunityApplication.GetInstance().startActivity((new Intent()).setClass(SteamCommunityApplication.GetInstance(), com/valvesoftware/android/steam/community/activity/CommunityActivity).setFlags(0x30000000));
        }
    }

    public void onBackPressed()
    {
        if (!FragmentActivityWithNavigationSupport.hasValidActivities())
        {
            finish();
            return;
        } else
        {
            super.onBackPressed();
            return;
        }
    }

    public void onCreate(Bundle bundle)
    {
        m_residActivityLayout = 0x7f03000c;
        super.onCreate(bundle);
        m_callBacks.addAll(m_callBacksBeforeCreate);
        m_callBacksBeforeCreate.clear();
    }

    static 
    {
        URI_LoginPage = Uri.parse((new StringBuilder()).append("steammobile://openurl?url=").append(Config.URL_COMMUNITY_BASE).append("/mobilelogin").append("?oauth_client_id=").append(com.valvesoftware.android.steam.community.Config.WebAPI.OAUTH_CLIENT_ID).append("&oauth_scope=read_profile%20write_profile%20read_client%20write_client").toString());
    }
}
