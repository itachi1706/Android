// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

// Referenced classes of package com.valvesoftware.android.steam.community:
//            C2DMReceiverService

public class C2DMReceiver extends BroadcastReceiver
{

    public C2DMReceiver()
    {
    }

    public final void onReceive(Context context, Intent intent)
    {
        C2DMReceiverService.runIntentInService(context, intent);
        setResult(-1, null, null);
    }
}
