// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;

import java.io.File;
import java.util.TreeMap;

// Referenced classes of package com.valvesoftware.android.steam.community:
//            SteamDBDiskCache

public static class m_ageMap extends SteamDBDiskCache
{

    private TreeMap m_ageMap;
    private final int m_numFilesLimit = 1024;

    protected String getFileNameFromUri(String s)
    {
        int i = s.hashCode();
        int j = s.length();
        int ai[] = new int[2];
        ai[0] = 1 + s.lastIndexOf('=');
        ai[1] = 1 + s.lastIndexOf('/');
        int k = Math.max(ai[0], ai[1]);
        if (k <= 0)
        {
            k = j;
        }
        StringBuilder stringbuilder = new StringBuilder((j + 13) - k);
        stringbuilder.append(i);
        stringbuilder.append("_");
        stringbuilder.append(s.substring(k));
        return stringbuilder.toString();
    }

    protected void onAfterWriteToFile(File file)
    {
        if (m_ageMap != null)
        {
            m_ageMap.put(Long.valueOf(System.currentTimeMillis()), file);
        }
        if (m_ageMap == null)
        {
            m_ageMap = new TreeMap();
            File afile[] = m_dir.listFiles();
            int i = afile.length;
            for (int j = 0; j < i; j++)
            {
                File file1 = afile[j];
                long l = file1.lastModified();
                m_ageMap.put(Long.valueOf(l), file1);
            }

        }
        while (m_ageMap.size() > 1024) 
        {
            if (((File)m_ageMap.remove(m_ageMap.firstKey())).delete());
        }
    }

    public I(File file)
    {
        super(file);
        m_ageMap = null;
    }
}
