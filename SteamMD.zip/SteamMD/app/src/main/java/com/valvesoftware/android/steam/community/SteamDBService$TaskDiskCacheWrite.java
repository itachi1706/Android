// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;


// Referenced classes of package com.valvesoftware.android.steam.community:
//            SteamDBDiskCache, SteamDBService

private static class m_data extends m_data
{

    private byte m_data[];

    public void Run()
    {
        m_cache.disk.Write(m_cache.uri, m_data);
    }

    nfo(nfo nfo, byte abyte0[])
    {
        super(nfo);
        m_data = null;
        m_data = abyte0;
    }
}
