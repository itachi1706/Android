// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;

import android.content.Context;
import android.content.Intent;
import java.util.ArrayList;
import java.util.concurrent.ConcurrentHashMap;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

// Referenced classes of package com.valvesoftware.android.steam.community:
//            GenericListDB, GroupInfo, SteamWebApi

public class GroupInfoDB extends GenericListDB
{

    public GroupInfoDB()
    {
    }

    public GroupInfo GetGroupInfo(Long long1)
    {
        return (GroupInfo)m_itemsMap.get(long1);
    }

    protected GroupInfo GetOrAllocateNewGroupInfo(String s)
    {
        Long long1 = Long.valueOf(s);
        GroupInfo groupinfo = (GroupInfo)m_itemsMap.get(long1);
        if (groupinfo == null)
        {
            groupinfo = new GroupInfo();
            groupinfo.m_steamID = long1;
            m_itemsMap.put(long1, groupinfo);
        }
        return groupinfo;
    }

    protected void HandleItemSummaryDocument(SteamWebApi.RequestBase requestbase)
    {
        JSONObject jsonobject = requestbase.GetJSONDocument();
        if (jsonobject != null)
        {
            JSONArray jsonarray;
            ArrayList arraylist;
            int i;
            try
            {
                jsonarray = jsonobject.getJSONArray("groups");
            }
            catch (Exception exception)
            {
                return;
            }
            arraylist = new ArrayList();
            i = 0;
            while (i < jsonarray.length()) 
            {
                try
                {
                    JSONObject jsonobject1 = jsonarray.getJSONObject(i);
                    String s = jsonobject1.getString("steamid");
                    StoreItemSummaryDocumentInCache(s, jsonobject1.toString());
                    HandleItemSummaryDocument(jsonobject1, s);
                    arraylist.add(Long.valueOf(s));
                }
                catch (Exception exception1) { }
                i++;
            }
            if (!arraylist.isEmpty())
            {
                m_eventBroadcaster.OnListItemInfoUpdated(arraylist, true);
                return;
            }
        }
    }

    protected void HandleItemSummaryDocument(JSONObject jsonobject, String s)
    {
        GroupInfo groupinfo = GetOrAllocateNewGroupInfo(s);
        groupinfo.m_groupName = jsonobject.optString("name");
        groupinfo.m_numMembersTotal = jsonobject.optInt("users");
        groupinfo.m_numMembersOnline = jsonobject.optInt("usersonline");
        groupinfo.m_groupType = GroupInfo.GroupType.FromInteger(jsonobject.optInt("type"));
        groupinfo.m_avatarSmallURL = jsonobject.optString("avatar");
        groupinfo.m_avatarMediumURL = jsonobject.optString("avatarmedium");
        groupinfo.m_profileURL = jsonobject.optString("profileurl");
        if (groupinfo.m_profileURL != null && !groupinfo.m_profileURL.equals(""))
        {
            StringBuilder stringbuilder = new StringBuilder();
            String s1;
            if (groupinfo.m_groupType == GroupInfo.GroupType.OFFICIAL)
            {
                s1 = "/games/";
            } else
            {
                s1 = "/groups/";
            }
            groupinfo.m_profileURL = stringbuilder.append(s1).append(groupinfo.m_profileURL).toString();
        }
        groupinfo.m_appidFavorite = jsonobject.optInt("favoriteappid");
    }

    protected void HandleListRefreshDocument(SteamWebApi.RequestBase requestbase, boolean flag)
    {
        JSONObject jsonobject = requestbase.GetJSONDocument();
        if (jsonobject == null)
        {
            return;
        }
        JSONArray jsonarray;
        int i;
        ArrayList arraylist;
        ArrayList arraylist1;
        int j;
        try
        {
            jsonarray = jsonobject.getJSONArray("groups");
        }
        catch (JSONException jsonexception)
        {
            return;
        }
        i = jsonarray.length();
        arraylist = new ArrayList();
        arraylist1 = new ArrayList(m_itemsMap.keySet());
        j = 0;
label0:
        do
        {
label1:
            {
                if (j >= i)
                {
                    break label0;
                }
                String s;
                GroupInfo.GroupRelationship grouprelationship;
                try
                {
                    s = jsonarray.getJSONObject(j).getString("steamid");
                    grouprelationship = GroupInfo.GroupRelationship.valueOf(jsonarray.getJSONObject(j).getString("relationship"));
                }
                catch (Exception exception)
                {
                    break label1;
                }
                if (grouprelationship == GroupInfo.GroupRelationship.Member || grouprelationship == GroupInfo.GroupRelationship.Invited)
                {
                    arraylist.add(s);
                    GroupInfo groupinfo = GetOrAllocateNewGroupInfo(s);
                    arraylist1.remove(Long.valueOf(s));
                    groupinfo.m_relationship = grouprelationship;
                }
            }
            j++;
        } while (true);
        RemoveOldItemList(arraylist1);
        String as[] = new String[arraylist.size()];
        arraylist.toArray(as);
        IssueItemSummaryRequest(as, flag);
    }

    protected SteamWebApi.RequestBase IssueFullListRefreshRequest(boolean flag)
    {
        return SteamWebApi.GetRequestForGroupListByOwnerSteamID(SteamWebApi.GetLoginSteamID(), flag);
    }

    protected SteamWebApi.RequestBase IssueSingleItemSummaryRequest(String as[])
    {
        return SteamWebApi.GetRequestForGroupsBySteamIDs(as);
    }

    public void onReceive(Context context, Intent intent)
    {
        String s;
        if (!"com.valvesoftware.android.steam.community.SteamUmqCommunicationIntent".equals(intent.getAction()))
        {
            break MISSING_BLOCK_LABEL_125;
        }
        s = intent.getStringExtra("type");
        if (!s.equalsIgnoreCase("personarelationship") || !HasLiveItemData()) goto _L2; else goto _L1
_L1:
        m_bDataMightBeStale = true;
        if (m_bAutoRefreshIfDataMightBeStale)
        {
            RefreshFromHttpOnly();
        }
_L4:
        return;
_L2:
        if (!s.equalsIgnoreCase("umqstate")) goto _L4; else goto _L3
_L3:
        if ("active".equals(intent.getStringExtra("old_state")))
        {
            m_bDataMightBeStale = true;
            return;
        }
        if (!m_bDataMightBeStale || !m_bAutoRefreshIfDataMightBeStale || !"active".equals(intent.getStringExtra("state"))) goto _L4; else goto _L5
_L5:
        m_bDataMightBeStale = false;
        RefreshFromHttpOnly();
        return;
        super.onReceive(context, intent);
        return;
    }
}
