// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;


// Referenced classes of package com.valvesoftware.android.steam.community:
//            Config

public static class 
{

    public static final boolean AggressiveActivityKilling;
    public static final boolean DisableOverTheAir;
    public static final boolean DiskCacheForceMiss;
    public static final boolean HockeyUpdaterForceTest;
    public static final int HttpFakeLatencyMilliseconds;
    public static final boolean JobQueuesDebug;
    public static final int UmqFakePollFailurePercentage;

    public ()
    {
    }
}
