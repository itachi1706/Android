// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;


// Referenced classes of package com.valvesoftware.android.steam.community:
//            Config

public static class 
{

    public static final boolean log_exceptions;
    public static final boolean log_sql;
    public static final boolean messages;
    public static final boolean parse_errors;
    public static final boolean relationship;
    public static final boolean state;

    public ()
    {
    }
}
