// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.fragment;

import android.widget.AbsListView;
import android.widget.ListView;
import java.util.ArrayList;

// Referenced classes of package com.valvesoftware.android.steam.community.fragment:
//            ChatFragment

class this._cls2
    implements Runnable
{

    final MoreMessagesInView this$2;

    public void run()
    {
        if (!ChatFragment.access$200(_fld0).isEmpty() && ChatFragment.access$200(_fld0).get(-1 + ChatFragment.access$200(_fld0).size()) == ChatFragment.access$100() && ChatFragment.access$600(_fld0).getFirstVisiblePosition() == 0)
        {
            ChatFragment.access$700(_fld0).MoreMessagesInView();
        }
    }

    l.lv()
    {
        this$2 = this._cls2.this;
        super();
    }

    // Unreferenced inner class com/valvesoftware/android/steam/community/fragment/ChatFragment$ChatViewAdapter$3

/* anonymous class */
    class ChatFragment.ChatViewAdapter._cls3
        implements android.widget.AbsListView.OnScrollListener
    {

        final ChatFragment.ChatViewAdapter this$1;
        final ListView val$lv;

        public void onScroll(AbsListView abslistview, int i, int j, int k)
        {
            if (i == 0)
            {
                lv.postDelayed(new ChatFragment.ChatViewAdapter._cls3._cls1(), 100L);
            } else
            if (i > 0)
            {
                ChatFragment.ChatViewAdapter.access$802(ChatFragment.ChatViewAdapter.this, true);
                return;
            }
        }

        public void onScrollStateChanged(AbsListView abslistview, int i)
        {
        }

            
            {
                this$1 = final_chatviewadapter;
                lv = ListView.this;
                super();
            }
    }

}
