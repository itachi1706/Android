// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;


// Referenced classes of package com.valvesoftware.android.steam.community:
//            SteamUmqCommunicationService

public static final class Y extends Enum
{

    private static final .VALUES $VALUES[];
    public static final .VALUES UMQ_LOGOFF;
    public static final .VALUES UMQ_LOGON;
    public static final .VALUES UMQ_LOGON_RETRY;
    public static final .VALUES UMQ_NONE;
    public static final .VALUES UMQ_POLL;
    public static final .VALUES UMQ_POLL_STATUS;

    public static Y valueOf(String s)
    {
        return (Y)Enum.valueOf(com/valvesoftware/android/steam/community/SteamUmqCommunicationService$UmqCommState, s);
    }

    public static Y[] values()
    {
        return (Y[])$VALUES.clone();
    }

    static 
    {
        UMQ_NONE = new <init>("UMQ_NONE", 0);
        UMQ_LOGON = new <init>("UMQ_LOGON", 1);
        UMQ_LOGON_RETRY = new <init>("UMQ_LOGON_RETRY", 2);
        UMQ_POLL_STATUS = new <init>("UMQ_POLL_STATUS", 3);
        UMQ_POLL = new <init>("UMQ_POLL", 4);
        UMQ_LOGOFF = new <init>("UMQ_LOGOFF", 5);
        e_3B_.clone aclone[] = new <init>[6];
        aclone[0] = UMQ_NONE;
        aclone[1] = UMQ_LOGON;
        aclone[2] = UMQ_LOGON_RETRY;
        aclone[3] = UMQ_POLL_STATUS;
        aclone[4] = UMQ_POLL;
        aclone[5] = UMQ_LOGOFF;
        $VALUES = aclone;
    }

    private Y(String s, int i)
    {
        super(s, i);
    }
}
