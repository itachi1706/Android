// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.fragment;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.net.Uri;
import android.support.v4.app.FragmentActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import com.valvesoftware.android.steam.community.AndroidUtils;
import com.valvesoftware.android.steam.community.Config;
import com.valvesoftware.android.steam.community.FriendInfo;
import com.valvesoftware.android.steam.community.FriendInfoDB;
import com.valvesoftware.android.steam.community.GenericListDB;
import com.valvesoftware.android.steam.community.SteamCommunityApplication;
import com.valvesoftware.android.steam.community.SteamWebApi;
import com.valvesoftware.android.steam.community.activity.SteamMobileUriActivity;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

// Referenced classes of package com.valvesoftware.android.steam.community.fragment:
//            BaseSearchResultsListFragment

public class SearchFriendListFragment extends BaseSearchResultsListFragment
{
    private class FriendsListAdapter extends BasePresentationListFragment.HelperDbListAdapter
    {

        final SearchFriendListFragment this$0;

        public View getView(int i, View view, ViewGroup viewgroup)
        {
            View view1;
            SteamCommunityApplication steamcommunityapplication;
            FriendInfo friendinfo;
            TextView textview;
            TextView textview1;
            ImageView imageview1;
label0:
            {
                view1 = view;
                steamcommunityapplication = SteamCommunityApplication.GetInstance();
                if (view1 == null)
                {
                    view1 = ((LayoutInflater)steamcommunityapplication.getSystemService("layout_inflater")).inflate(0x7f030009, null);
                    view1.setClickable(true);
                    view1.setOnClickListener(friendListClickListener);
                }
                friendinfo = (FriendInfo)m_presentationArray.get(i);
                if (friendinfo != null)
                {
                    if (!friendinfo.IsAvatarSmallLoaded())
                    {
                        RequestVisibleAvatars();
                    }
                    ((TextView)view1.findViewById(0x7f09000d)).setVisibility(8);
                    textview = (TextView)view1.findViewById(0x7f090013);
                    textview1 = (TextView)view1.findViewById(0x7f090014);
                    ImageView imageview = (ImageView)view1.findViewById(0x7f09000e);
                    imageview1 = (ImageView)view1.findViewById(0x7f090012);
                    TextView textview2 = (TextView)view1.findViewById(0x7f090018);
                    ((ImageView)view1.findViewById(0x7f090017)).setVisibility(0);
                    ((Button)view1.findViewById(0x7f090016)).setVisibility(8);
                    textview2.setText(Long.toString(friendinfo.m_steamID.longValue()));
                    AndroidUtils.setTextViewText(textview, friendinfo.m_personaName);
                    imageview.setImageBitmap(friendinfo.GetAvatarSmall());
                    imageview1.setVisibility(0);
                    String s;
                    if (friendinfo.m_personaState == com.valvesoftware.android.steam.community.FriendInfo.PersonaState.OFFLINE && friendinfo.m_lastOnlineString != null)
                    {
                        textview1.setText(friendinfo.m_lastOnlineString);
                    } else
                    {
                        textview1.setText(friendinfo.m_personaState.GetDisplayString());
                    }
                    if (friendinfo.m_currentGameString.length() <= 0)
                    {
                        break label0;
                    }
                    imageview1.setImageResource(0x7f020000);
                    textview.setTextColor(steamcommunityapplication.getResources().getColor(0x7f060013));
                    textview1.setTextColor(steamcommunityapplication.getResources().getColor(0x7f060013));
                    s = steamcommunityapplication.getResources().getString(0x7f070028);
                    textview1.setText((new StringBuilder()).append(s).append(" ").append(friendinfo.m_currentGameString).toString());
                }
                return view1;
            }
            if (friendinfo.m_personaState == com.valvesoftware.android.steam.community.FriendInfo.PersonaState.OFFLINE)
            {
                imageview1.setImageResource(0x7f020001);
                textview.setTextColor(steamcommunityapplication.getResources().getColor(0x7f060012));
                textview1.setTextColor(steamcommunityapplication.getResources().getColor(0x7f060012));
                return view1;
            } else
            {
                imageview1.setImageResource(0x7f020002);
                textview.setTextColor(steamcommunityapplication.getResources().getColor(0x7f060014));
                textview1.setTextColor(steamcommunityapplication.getResources().getColor(0x7f060014));
                return view1;
            }
        }

        public FriendsListAdapter()
        {
            this$0 = SearchFriendListFragment.this;
            super(SearchFriendListFragment.this, 0x7f030009);
        }
    }

    public class SearchFriendInfoDB extends FriendInfoDB
    {

        final SearchFriendListFragment this$0;

        protected void HandleListRefreshDocument(com.valvesoftware.android.steam.community.SteamWebApi.RequestBase requestbase, boolean flag)
        {
            ArrayList arraylist;
            JSONObject jsonobject = requestbase.GetJSONDocument();
            if (jsonobject == null)
            {
                return;
            }
            JSONArray jsonarray;
            int i;
            int j;
            String s;
            FriendInfo friendinfo;
            try
            {
                jsonarray = jsonobject.getJSONArray("results");
                m_queryTotalResults = jsonobject.optInt("total");
                m_queryActualResults = jsonobject.optInt("count");
            }
            catch (JSONException jsonexception)
            {
                return;
            }
            i = jsonarray.length();
            arraylist = new ArrayList();
            m_searchResultsOrderMap.clear();
            j = 0;
            if (j >= i)
            {
                break; /* Loop/switch isn't completed */
            }
            s = jsonarray.getJSONObject(j).getString("steamid");
            arraylist.add(s);
            friendinfo = GetOrAllocateNewFriendInfo(s);
            friendinfo.m_relationship = com.valvesoftware.android.steam.community.FriendInfo.FriendRelationship.friend;
            m_searchResultsOrderMap.put(friendinfo.m_steamID, Integer.valueOf(j));
_L4:
            j++;
            if (true) goto _L2; else goto _L1
_L1:
            break; /* Loop/switch isn't completed */
_L2:
            break MISSING_BLOCK_LABEL_73;
            Exception exception;
            exception;
            if (true) goto _L4; else goto _L3
_L3:
            String as[] = new String[arraylist.size()];
            arraylist.toArray(as);
            IssueItemSummaryRequest(as, flag);
            refreshListView();
            return;
        }

        protected com.valvesoftware.android.steam.community.SteamWebApi.RequestBase IssueFullListRefreshRequest(boolean flag)
        {
            com.valvesoftware.android.steam.community.SteamWebApi.RequestBase requestbase = new com.valvesoftware.android.steam.community.SteamWebApi.RequestBase("JobQueueFriendsDB");
            String s = SteamWebApi.GetLoginAccessToken();
            String s1 = Uri.encode(m_queryText);
            int i = 32 + SearchFriendListFragment.SearchFriendInfoDB_URI.length();
            int j;
            StringBuilder stringbuilder;
            if (s != null)
            {
                j = s.length();
            } else
            {
                j = 0;
            }
            stringbuilder = new StringBuilder(128 + (32 + (j + i) + s1.length()));
            stringbuilder.append(SearchFriendListFragment.SearchFriendInfoDB_URI);
            stringbuilder.append("?access_token=");
            stringbuilder.append(s);
            stringbuilder.append("&keywords=");
            stringbuilder.append(s1);
            stringbuilder.append("&offset=");
            stringbuilder.append(m_queryOffset);
            stringbuilder.append("&count=");
            stringbuilder.append(m_queryPageSize);
            stringbuilder.append("&targets=users&fields=all");
            requestbase.SetUriAndDocumentType(stringbuilder.toString(), com.valvesoftware.android.steam.community.SteamWebApi.RequestDocumentType.JSON);
            requestbase.SetRequestAction(com.valvesoftware.android.steam.community.SteamWebApi.RequestActionType.DoHttpRequestNoCache);
            return requestbase;
        }

        public void SetAutoRefreshIfDataMightBeStale(boolean flag)
        {
        }

        public SearchFriendInfoDB()
        {
            this$0 = SearchFriendListFragment.this;
            super();
        }
    }


    private static final String SearchFriendInfoDB_URI;
    private android.view.View.OnClickListener friendListClickListener;

    public SearchFriendListFragment()
    {
        friendListClickListener = new android.view.View.OnClickListener() {

            final SearchFriendListFragment this$0;

            public void onClick(View view)
            {
                String s;
label0:
                {
                    TextView textview = (TextView)view.findViewById(0x7f090018);
                    if (textview != null)
                    {
                        s = textview.getText().toString();
                        if (!s.equals("0"))
                        {
                            break label0;
                        }
                    }
                    return;
                }
                Intent intent = (new Intent()).addFlags(0x18000000).setClass(getActivity(), com/valvesoftware/android/steam/community/activity/SteamMobileUriActivity).setData(Uri.parse((new StringBuilder()).append("steammobile://").append(com.valvesoftware.android.steam.community.SteamUriHandler.Command.openurl).append("?url=").append(Config.URL_COMMUNITY_BASE).append("/profiles/").append(s).toString())).setAction("android.intent.action.VIEW");
                getActivity().startActivity(intent);
            }

            
            {
                this$0 = SearchFriendListFragment.this;
                super();
            }
        };
    }

    protected volatile GenericListDB AllocateNewSearchDB()
    {
        return AllocateNewSearchDB();
    }

    protected SearchFriendInfoDB AllocateNewSearchDB()
    {
        return new SearchFriendInfoDB();
    }

    protected int GetTitlebarFormatStringForQuery()
    {
        return 0x7f070078;
    }

    protected void myCbckProcessPresentationArray()
    {
        for (Iterator iterator = m_presentationArray.iterator(); iterator.hasNext(); ((FriendInfo)iterator.next()).UpdateLastOnlineTime(m_umqCurrentServerTime)) { }
        super.myCbckProcessPresentationArray();
    }

    protected boolean myCbckShouldDisplayItemInList(FriendInfo friendinfo)
    {
        return friendinfo.HasPresentationData();
    }

    protected volatile boolean myCbckShouldDisplayItemInList(com.valvesoftware.android.steam.community.GenericListDB.GenericListItem genericlistitem)
    {
        return myCbckShouldDisplayItemInList((FriendInfo)genericlistitem);
    }

    protected BasePresentationListFragment.HelperDbListAdapter myCreateListAdapter()
    {
        return new FriendsListAdapter();
    }

    static 
    {
        SearchFriendInfoDB_URI = (new StringBuilder()).append(Config.URL_WEBAPI_BASE).append("/ISteamUserOAuth/Search/v0001").toString();
    }


}
