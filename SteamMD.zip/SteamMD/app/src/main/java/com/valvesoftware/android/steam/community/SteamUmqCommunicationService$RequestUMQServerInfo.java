// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;

import org.json.JSONObject;

// Referenced classes of package com.valvesoftware.android.steam.community:
//            SteamUmqCommunicationService

private class  extends 
{

    private int localTime;
    final SteamUmqCommunicationService this$0;

    public void RequestFailedOnResponseWorkerThread()
    {
        synchronized (SteamUmqCommunicationService.access$2700(SteamUmqCommunicationService.this))
        {
            SteamUmqCommunicationService.access$2700(SteamUmqCommunicationService.this).amServerInfoRequired = true;
        }
        return;
        exception;
        ;
        JVM INSTR monitorexit ;
        throw exception;
    }

    public void RequestSucceededOnResponseWorkerThread()
    {
        int i = m_jsonDocument.optInt("servertime");
        if (i == 0)
        {
            RequestFailedOnResponseWorkerThread();
            return;
        } else
        {
            SteamUmqCommunicationService.access$2700(SteamUmqCommunicationService.this).eServerInfo(localTime, i);
            return;
        }
    }

    public a()
    {
        this$0 = SteamUmqCommunicationService.this;
        super(SteamUmqCommunicationService.this, "JobQueueUMQdeviceinfo");
        localTime = (int)(System.currentTimeMillis() / 1000L);
        SetUriAndDocumentType(SteamUmqCommunicationService.access$2600(), SetUriAndDocumentType);
        SetRequestAction();
    }
}
