// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;

import android.os.Binder;

// Referenced classes of package com.valvesoftware.android.steam.community:
//            SteamDBService

public class this._cls0 extends Binder
{

    final SteamDBService this$0;

    SteamDBService getService()
    {
        return SteamDBService.this;
    }

    public ()
    {
        this$0 = SteamDBService.this;
        super();
    }
}
