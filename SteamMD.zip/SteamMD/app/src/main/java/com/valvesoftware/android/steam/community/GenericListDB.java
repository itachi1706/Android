// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;
import org.json.JSONException;
import org.json.JSONObject;

// Referenced classes of package com.valvesoftware.android.steam.community:
//            SteamCommunityApplication, SteamWebApi, SteamDBService, WorkerThreadPool, 
//            SteamDBDiskCache

public abstract class GenericListDB extends BroadcastReceiver
{
    class EventBroadcaster
        implements ListItemUpdatedListener
    {

        final GenericListDB this$0;

        public void OnListItemInfoUpdateError(SteamWebApi.RequestBase requestbase)
        {
            for (Iterator iterator = m_callBacks.iterator(); iterator.hasNext();)
            {
                WeakReference weakreference = (WeakReference)iterator.next();
                ListItemUpdatedListener listitemupdatedlistener = (ListItemUpdatedListener)weakreference.get();
                if (listitemupdatedlistener != null)
                {
                    listitemupdatedlistener.OnListItemInfoUpdateError(requestbase);
                } else
                {
                    m_callBacks.remove(weakreference);
                }
            }

        }

        public void OnListItemInfoUpdated(ArrayList arraylist, boolean flag)
        {
            for (Iterator iterator = m_callBacks.iterator(); iterator.hasNext();)
            {
                WeakReference weakreference = (WeakReference)iterator.next();
                ListItemUpdatedListener listitemupdatedlistener = (ListItemUpdatedListener)weakreference.get();
                if (listitemupdatedlistener != null)
                {
                    listitemupdatedlistener.OnListItemInfoUpdated(arraylist, flag);
                } else
                {
                    m_callBacks.remove(weakreference);
                }
            }

        }

        public void OnListRefreshError(SteamWebApi.RequestBase requestbase, boolean flag)
        {
            for (Iterator iterator = m_callBacks.iterator(); iterator.hasNext();)
            {
                WeakReference weakreference = (WeakReference)iterator.next();
                ListItemUpdatedListener listitemupdatedlistener = (ListItemUpdatedListener)weakreference.get();
                if (listitemupdatedlistener != null)
                {
                    listitemupdatedlistener.OnListRefreshError(requestbase, flag);
                } else
                {
                    m_callBacks.remove(weakreference);
                }
            }

        }

        public void OnListRequestsInProgress(boolean flag)
        {
            for (Iterator iterator = m_callBacks.iterator(); iterator.hasNext();)
            {
                WeakReference weakreference = (WeakReference)iterator.next();
                ListItemUpdatedListener listitemupdatedlistener = (ListItemUpdatedListener)weakreference.get();
                if (listitemupdatedlistener != null)
                {
                    listitemupdatedlistener.OnListRequestsInProgress(flag);
                } else
                {
                    m_callBacks.remove(weakreference);
                }
            }

        }

        EventBroadcaster()
        {
            this$0 = GenericListDB.this;
            super();
        }
    }

    public static abstract class GenericListItem
    {

        private static Bitmap m_avatarSmallPlaceholder = null;
        private String m_LoadedAvatarSmallURI;
        private Bitmap m_avatarSmall;
        public String m_avatarSmallURL;
        private String m_sTriedLoadingBitmapFromCache;
        public Long m_steamID;

        private boolean HandleAvatarImageResponse(RequestForAvatarImage requestforavatarimage)
        {
            if (requestforavatarimage.GetBitmap() != null)
            {
                SetAvatarSmall(requestforavatarimage.GetBitmap(), requestforavatarimage.m_sOriginalRequestURI);
                return true;
            }
            if (requestforavatarimage.GetHttpResponseUriData().m_httpResult == 1)
            {
                SetAvatarSmall(GetAvatarSmall(), requestforavatarimage.m_sOriginalRequestURI);
                return true;
            } else
            {
                return false;
            }
        }

        private void SetAvatarSmall(Bitmap bitmap, String s)
        {
            m_avatarSmall = bitmap;
            m_LoadedAvatarSmallURI = s;
        }

        private boolean TryLoadingAvatarFromCache()
        {
            if (m_sTriedLoadingBitmapFromCache == null || !m_sTriedLoadingBitmapFromCache.equals(m_avatarSmallURL))
            {
                m_sTriedLoadingBitmapFromCache = m_avatarSmallURL;
                RequestForAvatarImage requestforavatarimage = RequestAvatarImage(null);
                requestforavatarimage.SetRequestAction(SteamWebApi.RequestActionType.GetFromCacheOnly);
                WorkerThreadPool.RunTask(new SteamDBService.TaskDoRequest(requestforavatarimage));
                return HandleAvatarImageResponse(requestforavatarimage);
            } else
            {
                return false;
            }
        }

        public Bitmap GetAvatarSmall()
        {
            if (m_avatarSmall != null)
            {
                return m_avatarSmall;
            } else
            {
                return GetPlaceholderAvatar();
            }
        }

        protected Bitmap GetPlaceholderAvatar()
        {
            if (m_avatarSmallPlaceholder == null)
            {
                m_avatarSmallPlaceholder = BitmapFactory.decodeResource(SteamCommunityApplication.GetInstance().getApplicationContext().getResources(), GetPlaceholderAvatarResourceId());
            }
            return m_avatarSmallPlaceholder;
        }

        protected int GetPlaceholderAvatarResourceId()
        {
            return 0x7f020026;
        }

        public RequestForAvatarImage GetRequestForAvatarImage(String s, String s1, String s2, GenericListDB genericlistdb)
        {
            return new RequestForAvatarImage(s, genericlistdb, s1);
        }

        public abstract boolean HasPresentationData();

        public boolean IsAvatarSmallLoaded()
        {
            while (m_LoadedAvatarSmallURI != null && m_LoadedAvatarSmallURI.equals(m_avatarSmallURL) && m_avatarSmall != null || m_avatarSmallURL == null) 
            {
                return true;
            }
            return TryLoadingAvatarFromCache();
        }

        protected abstract RequestForAvatarImage RequestAvatarImage(GenericListDB genericlistdb);



        public GenericListItem()
        {
        }
    }

    public class GenericListItem.RequestForAvatarImage extends SteamWebApi.RequestBase
    {

        private GenericListDB m_db;
        private String m_sOriginalRequestURI;
        final GenericListItem this$0;

        private void SubmitNextRequest()
        {
            if (m_db != null)
            {
                m_db.RequestForAvatarImageFinishedOnWorkerThread();
            }
        }

        public void RequestFailedOnResponseWorkerThread()
        {
            SubmitNextRequest();
        }

        public void RequestSucceededOnResponseWorkerThread()
        {
            SubmitNextRequest();
        }

        GenericListItem getItem()
        {
            return GenericListItem.this;
        }


        public GenericListItem.RequestForAvatarImage(String s, GenericListDB genericlistdb, String s1)
        {
            this$0 = GenericListItem.this;
            super(s);
            m_db = genericlistdb;
            m_sOriginalRequestURI = s1;
            SetRequestAction(SteamWebApi.RequestActionType.GetFromCacheOrDoHttpRequestAndCacheResults);
            SetUriAndDocumentType(s1, com.valvesoftware.android.steam.community.SteamWebApi.RequestDocumentType.Bitmap);
        }
    }

    public static interface ListItemUpdatedListener
    {

        public abstract void OnListItemInfoUpdateError(SteamWebApi.RequestBase requestbase);

        public abstract void OnListItemInfoUpdated(ArrayList arraylist, boolean flag);

        public abstract void OnListRefreshError(SteamWebApi.RequestBase requestbase, boolean flag);

        public abstract void OnListRequestsInProgress(boolean flag);
    }

    protected static class WriteItemSummaryDocumentToCache extends SteamWebApi.RequestBase
    {

        byte m_data[];

        public boolean OnTaskReadyToRunOnJobQueue()
        {
            SteamWebApi.RequestBase.DiskCacheInfo diskcacheinfo = GetDiskCacheInfo();
            diskcacheinfo.disk.Write(diskcacheinfo.uri, m_data);
            return false;
        }

        public WriteItemSummaryDocumentToCache(String s, byte abyte0[])
        {
            super("JobQueueDiskCache");
            SetIndefiniteCacheFilename(s);
            m_data = abyte0;
        }
    }


    protected boolean m_bAutoRefreshIfDataMightBeStale;
    protected boolean m_bDataMightBeStale;
    private boolean m_bHasLiveItemData;
    protected boolean m_bRefreshListCached;
    private final ArrayList m_callBacks = new ArrayList();
    protected EventBroadcaster m_eventBroadcaster;
    protected final ConcurrentHashMap m_itemsMap = new ConcurrentHashMap();
    private Object m_mtxAvatarRequests;
    private int m_numIssuedAvatarRequests;
    private GenericListItem m_pendingAvatarRequests[];
    protected final TreeMap m_reqItemDetails = new TreeMap();
    protected SteamWebApi.RequestBase m_reqRefreshList;
    private final TreeMap m_submittedAvatarRequests = new TreeMap();

    GenericListDB()
    {
        m_bHasLiveItemData = false;
        m_reqRefreshList = null;
        m_bRefreshListCached = true;
        m_mtxAvatarRequests = new Object();
        m_pendingAvatarRequests = null;
        m_numIssuedAvatarRequests = 0;
        m_eventBroadcaster = new EventBroadcaster();
        m_bAutoRefreshIfDataMightBeStale = false;
        m_bDataMightBeStale = false;
        SteamCommunityApplication.GetInstance().registerReceiver(this, new IntentFilter(getClass().getName()));
    }

    private void HandleAvatarImageResponse(GenericListItem.RequestForAvatarImage requestforavatarimage)
    {
        GenericListItem genericlistitem = requestforavatarimage.getItem();
        if (genericlistitem != null && genericlistitem.HandleAvatarImageResponse(requestforavatarimage))
        {
            ArrayList arraylist = new ArrayList();
            arraylist.add(genericlistitem.m_steamID);
            m_eventBroadcaster.OnListItemInfoUpdated(arraylist, false);
        }
        IssueQueuedAvatarImageRequests(false);
    }

    private void IssueRefreshRequest(boolean flag)
    {
        if (SteamWebApi.IsLoggedIn())
        {
            m_bRefreshListCached = flag;
            m_reqRefreshList = IssueFullListRefreshRequest(m_bRefreshListCached);
            if (m_reqRefreshList == null && m_bRefreshListCached)
            {
                m_bRefreshListCached = false;
                m_reqRefreshList = IssueFullListRefreshRequest(m_bRefreshListCached);
            }
            if (m_reqRefreshList != null)
            {
                m_reqRefreshList.SetCallerIntent(getClass().getName());
                SteamCommunityApplication.GetInstance().SubmitSteamDBRequest(m_reqRefreshList);
                m_eventBroadcaster.OnListRequestsInProgress(true);
                return;
            }
        }
    }

    private void RequestForAvatarImageFinishedOnWorkerThread()
    {
        IssueQueuedAvatarImageRequests(true);
    }

    private void checkIfNoLongerRefreshingAndNotifyListeners()
    {
        if (m_reqRefreshList == null && m_reqItemDetails.isEmpty())
        {
            m_eventBroadcaster.OnListRequestsInProgress(false);
        }
    }

    public void ClearItems()
    {
        m_itemsMap.clear();
        m_pendingAvatarRequests = null;
        m_numIssuedAvatarRequests = 0;
        m_eventBroadcaster.OnListItemInfoUpdated(null, true);
    }

    public void DeregisterCallback(ListItemUpdatedListener listitemupdatedlistener)
    {
        Iterator iterator = m_callBacks.iterator();
        do
        {
            if (!iterator.hasNext())
            {
                break;
            }
            WeakReference weakreference = (WeakReference)iterator.next();
            if (listitemupdatedlistener != (ListItemUpdatedListener)weakreference.get())
            {
                continue;
            }
            m_callBacks.remove(weakreference);
            break;
        } while (true);
    }

    public ConcurrentHashMap GetItemsMap()
    {
        return m_itemsMap;
    }

    public GenericListItem GetListItem(Long long1)
    {
        return (GenericListItem)m_itemsMap.get(long1);
    }

    protected abstract void HandleItemSummaryDocument(SteamWebApi.RequestBase requestbase);

    protected abstract void HandleItemSummaryDocument(JSONObject jsonobject, String s);

    protected abstract void HandleListRefreshDocument(SteamWebApi.RequestBase requestbase, boolean flag);

    public boolean HasLiveItemData()
    {
        return m_bHasLiveItemData;
    }

    protected abstract SteamWebApi.RequestBase IssueFullListRefreshRequest(boolean flag);

    protected void IssueItemSummaryRequest(String as[], boolean flag)
    {
        if (SteamWebApi.IsLoggedIn())
        {
            if (flag)
            {
                ArrayList arraylist = new ArrayList();
                int i = as.length;
                int j = 0;
                while (j < i) 
                {
                    String s = as[j];
                    byte abyte0[] = SteamCommunityApplication.GetInstance().GetDiskCacheIndefinite().Read(s);
                    if (abyte0 == null);
                    boolean flag1;
                    String as1[];
                    int k;
                    int l;
                    SteamWebApi.RequestBase requestbase;
                    String s1;
                    int j1;
                    SteamWebApi.RequestBase requestbase1;
                    if (abyte0 != null)
                    {
                        try
                        {
                            HandleItemSummaryDocument(new JSONObject(new String(abyte0)), s);
                            arraylist.add(Long.valueOf(s));
                        }
                        catch (JSONException jsonexception) { }
                    }
                    j++;
                }
                if (!arraylist.isEmpty())
                {
                    m_eventBroadcaster.OnListItemInfoUpdated(arraylist, true);
                    return;
                }
            }
            while (false) 
            {
                flag1 = false;
                as1 = new String[100];
                k = as.length;
                l = 0;
                int i1 = 0;
                while (l < k) 
                {
                    s1 = as[l];
                    if (!m_itemsMap.containsKey(Long.valueOf(s1)))
                    {
                        j1 = i1;
                    } else
                    {
                        j1 = i1 + 1;
                        as1[i1] = s1;
                        if (j1 >= 100)
                        {
                            requestbase1 = IssueSingleItemSummaryRequest(as1);
                            if (requestbase1 != null)
                            {
                                requestbase1.SetCallerIntent(getClass().getName());
                                SteamCommunityApplication.GetInstance().SubmitSteamDBRequest(requestbase1);
                                m_reqItemDetails.put(Integer.valueOf(requestbase1.GetIntentId()), requestbase1);
                                flag1 = true;
                            }
                            j1 = 0;
                        }
                    }
                    l++;
                    i1 = j1;
                }
                if (i1 > 0)
                {
                    if (i1 < 100)
                    {
                        as1[i1] = null;
                    }
                    requestbase = IssueSingleItemSummaryRequest(as1);
                    if (requestbase != null)
                    {
                        requestbase.SetCallerIntent(getClass().getName());
                        SteamCommunityApplication.GetInstance().SubmitSteamDBRequest(requestbase);
                        m_reqItemDetails.put(Integer.valueOf(requestbase.GetIntentId()), requestbase);
                        flag1 = true;
                    }
                } else
                {
                    int _tmp = i1;
                }
                if (flag1)
                {
                    m_eventBroadcaster.OnListRequestsInProgress(true);
                    return;
                }
            }
        }
    }

    protected void IssueQueuedAvatarImageRequests(boolean flag)
    {
        Object obj = m_mtxAvatarRequests;
        obj;
        JVM INSTR monitorenter ;
        if (flag)
        {
            break MISSING_BLOCK_LABEL_24;
        }
        if (m_submittedAvatarRequests.isEmpty())
        {
            break MISSING_BLOCK_LABEL_24;
        }
        obj;
        JVM INSTR monitorexit ;
        return;
        GenericListItem agenericlistitem[] = m_pendingAvatarRequests;
        GenericListItem.RequestForAvatarImage requestforavatarimage;
        requestforavatarimage = null;
        if (agenericlistitem != null)
        {
            break MISSING_BLOCK_LABEL_46;
        }
        obj;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        obj;
        JVM INSTR monitorexit ;
        throw exception;
_L2:
        GenericListItem genericlistitem;
        if (m_numIssuedAvatarRequests < 0 || m_numIssuedAvatarRequests >= m_pendingAvatarRequests.length)
        {
            break; /* Loop/switch isn't completed */
        }
        GenericListItem agenericlistitem1[] = m_pendingAvatarRequests;
        int i = m_numIssuedAvatarRequests;
        m_numIssuedAvatarRequests = i + 1;
        genericlistitem = agenericlistitem1[i];
        if (genericlistitem == null)
        {
            continue; /* Loop/switch isn't completed */
        }
        requestforavatarimage = genericlistitem.RequestAvatarImage(this);
        if (requestforavatarimage == null)
        {
            continue; /* Loop/switch isn't completed */
        }
        m_submittedAvatarRequests.put(Integer.valueOf(requestforavatarimage.GetIntentId()), requestforavatarimage);
        break; /* Loop/switch isn't completed */
        if (true) goto _L2; else goto _L1
_L1:
        obj;
        JVM INSTR monitorexit ;
        if (requestforavatarimage != null)
        {
            requestforavatarimage.SetCallerIntent(getClass().getName());
            requestforavatarimage.SetRequestAction(SteamWebApi.RequestActionType.DoHttpRequestAndCacheResults);
            SteamCommunityApplication.GetInstance().SubmitSteamDBRequest(requestforavatarimage);
        }
        return;
    }

    protected abstract SteamWebApi.RequestBase IssueSingleItemSummaryRequest(String as[]);

    public void RefreshFromCacheAndHttp()
    {
        IssueRefreshRequest(true);
    }

    protected void RefreshFromHttpIfDataMightBeStale()
    {
        if (!m_bDataMightBeStale || !SteamWebApi.IsLoggedIn())
        {
            return;
        }
        SteamDBService steamdbservice = SteamCommunityApplication.GetInstance().GetSteamDB();
        if (steamdbservice != null)
        {
            boolean flag;
            if (!steamdbservice.getSteamUmqConnectionState().isConnected())
            {
                flag = true;
            } else
            {
                flag = false;
            }
            m_bDataMightBeStale = flag;
        }
        RefreshFromHttpOnly();
    }

    public void RefreshFromHttpOnly()
    {
        IssueRefreshRequest(false);
    }

    public void RegisterCallback(ListItemUpdatedListener listitemupdatedlistener)
    {
        DeregisterCallback(listitemupdatedlistener);
        m_callBacks.add(new WeakReference(listitemupdatedlistener));
    }

    protected void RemoveOldItemList(ArrayList arraylist)
    {
        if (arraylist.isEmpty())
        {
            return;
        }
        Long long1;
        for (Iterator iterator = arraylist.iterator(); iterator.hasNext(); m_itemsMap.remove(long1))
        {
            long1 = (Long)iterator.next();
        }

        m_eventBroadcaster.OnListItemInfoUpdated(arraylist, true);
    }

    public void RequestAvatarImage(GenericListItem agenericlistitem[])
    {
        synchronized (m_mtxAvatarRequests)
        {
            m_pendingAvatarRequests = agenericlistitem;
            m_numIssuedAvatarRequests = 0;
        }
        IssueQueuedAvatarImageRequests(false);
        return;
        exception;
        obj;
        JVM INSTR monitorexit ;
        throw exception;
    }

    protected void RequestAvatarImageImmediately(GenericListItem genericlistitem)
    {
        if (genericlistitem != null) goto _L2; else goto _L1
_L1:
        return;
_L2:
        Object obj = m_mtxAvatarRequests;
        obj;
        JVM INSTR monitorenter ;
        GenericListItem.RequestForAvatarImage requestforavatarimage = genericlistitem.RequestAvatarImage(this);
        if (requestforavatarimage != null)
        {
            break MISSING_BLOCK_LABEL_32;
        }
        obj;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        obj;
        JVM INSTR monitorexit ;
        throw exception;
        m_submittedAvatarRequests.put(Integer.valueOf(requestforavatarimage.GetIntentId()), requestforavatarimage);
        obj;
        JVM INSTR monitorexit ;
        if (requestforavatarimage != null)
        {
            requestforavatarimage.SetCallerIntent(getClass().getName());
            requestforavatarimage.SetRequestAction(SteamWebApi.RequestActionType.DoHttpRequestAndCacheResults);
            SteamCommunityApplication.GetInstance().SubmitSteamDBRequest(requestforavatarimage);
            return;
        }
        if (true) goto _L1; else goto _L3
_L3:
    }

    public void SetAutoRefreshIfDataMightBeStale(boolean flag)
    {
        m_bAutoRefreshIfDataMightBeStale = flag;
        if (flag)
        {
            RefreshFromHttpIfDataMightBeStale();
        }
    }

    protected void StoreItemSummaryDocumentInCache(String s, String s1)
    {
        SteamCommunityApplication.GetInstance().SubmitSteamDBRequest(new WriteItemSummaryDocumentToCache(s, s1.getBytes()));
    }

    public void onReceive(Context context, Intent intent)
    {
        if (getClass().getName().equals(intent.getAction())) goto _L2; else goto _L1
_L1:
        return;
_L2:
        GenericListItem.RequestForAvatarImage requestforavatarimage;
        Integer integer = Integer.valueOf(intent.getIntExtra("intent_id", -1));
        if (m_reqRefreshList != null && m_reqRefreshList.GetIntentId() == integer.intValue())
        {
            SteamWebApi.RequestBase requestbase1 = m_reqRefreshList;
            m_reqRefreshList = null;
            if (requestbase1.IsRequestLive())
            {
                try
                {
                    HandleListRefreshDocument(requestbase1, m_bRefreshListCached);
                }
                catch (Exception exception2)
                {
                    m_eventBroadcaster.OnListRefreshError(requestbase1, m_bRefreshListCached);
                }
            } else
            {
                m_eventBroadcaster.OnListRefreshError(requestbase1, m_bRefreshListCached);
            }
            if (m_bRefreshListCached)
            {
                m_bDataMightBeStale = true;
                RefreshFromHttpIfDataMightBeStale();
            }
            checkIfNoLongerRefreshingAndNotifyListeners();
            return;
        }
        SteamWebApi.RequestBase requestbase = (SteamWebApi.RequestBase)m_reqItemDetails.remove(integer);
        if (requestbase != null)
        {
            if (requestbase.IsRequestLive())
            {
                try
                {
                    if (requestbase.GetRequestAction() != SteamWebApi.RequestActionType.GetFromCacheOnly)
                    {
                        m_bHasLiveItemData = true;
                    }
                    HandleItemSummaryDocument(requestbase);
                }
                catch (Exception exception1)
                {
                    m_eventBroadcaster.OnListItemInfoUpdateError(requestbase);
                }
            } else
            {
                m_eventBroadcaster.OnListItemInfoUpdateError(requestbase);
            }
            checkIfNoLongerRefreshingAndNotifyListeners();
            return;
        }
        synchronized (m_mtxAvatarRequests)
        {
            requestforavatarimage = (GenericListItem.RequestForAvatarImage)m_submittedAvatarRequests.remove(integer);
        }
        if (requestforavatarimage == null) goto _L1; else goto _L3
_L3:
        HandleAvatarImageResponse(requestforavatarimage);
        return;
        exception;
        obj;
        JVM INSTR monitorexit ;
        throw exception;
    }


}
