// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.activity;

import android.content.res.Configuration;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.Window;
import com.valvesoftware.android.steam.community.SettingInfo;
import com.valvesoftware.android.steam.community.SettingInfoDB;
import com.valvesoftware.android.steam.community.SteamCommunityApplication;
import com.valvesoftware.android.steam.community.SteamWebApi;
import com.valvesoftware.android.steam.community.fragment.BasePresentationListFragmentWithSearch;
import com.valvesoftware.android.steam.community.fragment.ChatFragment;
import com.valvesoftware.android.steam.community.fragment.NavigationFragment;
import com.valvesoftware.android.steam.community.fragment.TitlebarFragment;
import java.util.ArrayList;

// Referenced classes of package com.valvesoftware.android.steam.community.activity:
//            LoginActivity, ActivityHelper, SteamMobileUriActivity, CommunityActivity, 
//            CommunityGroupsActivity, SearchFriendsActivity, SearchGroupsActivity, SettingsActivity

public class FragmentActivityWithNavigationSupport extends FragmentActivity
{

    private static ArrayList s_allActivities = new ArrayList();

    public FragmentActivityWithNavigationSupport()
    {
    }

    public static void finishAll()
    {
        finishAllExceptOne(null);
    }

    public static void finishAllExceptOne(FragmentActivityWithNavigationSupport fragmentactivitywithnavigationsupport)
    {
        do
        {
            if (s_allActivities.isEmpty())
            {
                break;
            }
            FragmentActivityWithNavigationSupport fragmentactivitywithnavigationsupport1 = (FragmentActivityWithNavigationSupport)s_allActivities.remove(0);
            if (fragmentactivitywithnavigationsupport1 != fragmentactivitywithnavigationsupport)
            {
                fragmentactivitywithnavigationsupport1.finish();
            }
        } while (true);
    }

    public static boolean hasValidActivities()
    {
        return !s_allActivities.isEmpty();
    }

    private boolean shouldBeExcludedFromTracking()
    {
        return this instanceof LoginActivity;
    }

    public void onBackPressed()
    {
        NavigationFragment navigationfragment = ActivityHelper.GetNavigationFragmentForActivity(this);
        android.support.v4.app.Fragment fragment;
        android.support.v4.app.Fragment fragment1;
        if (navigationfragment == null || !navigationfragment.overrideActivityOnBackPressed())
        {
            if (((fragment = ActivityHelper.GetFragmentForActivityById(this, 0x7f090011)) == null || !(fragment instanceof BasePresentationListFragmentWithSearch) || !((BasePresentationListFragmentWithSearch)fragment).overrideActivityOnBackPressed()) && ((fragment1 = ActivityHelper.GetFragmentForActivityById(this, 0x7f090002)) == null || !(fragment1 instanceof ChatFragment) || !((ChatFragment)fragment1).overrideActivityOnBackPressed()))
            {
                try
                {
                    super.onBackPressed();
                    return;
                }
                catch (Exception exception)
                {
                    return;
                }
            }
        }
    }

    public void onConfigurationChanged(Configuration configuration)
    {
        super.onConfigurationChanged(configuration);
        NavigationFragment navigationfragment = ActivityHelper.GetNavigationFragmentForActivity(this);
        if (navigationfragment != null)
        {
            navigationfragment.overrideActivityOnConfigurationChanged();
        }
    }

    protected void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        if (!shouldBeExcludedFromTracking())
        {
            s_allActivities.add(this);
        }
        SettingInfo settinginfo = SteamCommunityApplication.GetInstance().GetSettingInfoDB().m_settingHardwareAcceleration;
        if (settinginfo != null && !(this instanceof SteamMobileUriActivity) && settinginfo.getBooleanValue(SteamCommunityApplication.GetInstance().getApplicationContext()))
        {
            getWindow().setFlags(0x1000000, 0x1000000);
        }
    }

    protected void onDestroy()
    {
        super.onDestroy();
        if (!shouldBeExcludedFromTracking())
        {
            s_allActivities.remove(this);
        }
    }

    public boolean onKeyDown(int i, KeyEvent keyevent)
    {
        i;
        JVM INSTR tableswitch 84 84: default 20
    //                   84 27;
           goto _L1 _L2
_L1:
        TitlebarFragment titlebarfragment;
        return super.onKeyDown(i, keyevent);
_L2:
        if ((titlebarfragment = ActivityHelper.GetTitlebarFragmentForActivity(this)) != null && titlebarfragment.overrideActivityOnSearchPressed())
        {
            return true;
        }
        if (true) goto _L1; else goto _L3
_L3:
    }

    public boolean onPrepareOptionsMenu(Menu menu)
    {
        NavigationFragment navigationfragment = ActivityHelper.GetNavigationFragmentForActivity(this);
        if (navigationfragment != null)
        {
            navigationfragment.onNavActivationButtonClicked();
        }
        return false;
    }

    protected void onResume()
    {
        super.onResume();
        if (s_allActivities.remove(this))
        {
            s_allActivities.add(this);
        }
        int i = 0;
        while (i < s_allActivities.size() - 15) 
        {
            FragmentActivityWithNavigationSupport fragmentactivitywithnavigationsupport = (FragmentActivityWithNavigationSupport)s_allActivities.get(i);
            if (!(fragmentactivitywithnavigationsupport instanceof CommunityActivity) && !(fragmentactivitywithnavigationsupport instanceof CommunityGroupsActivity) && !(fragmentactivitywithnavigationsupport instanceof SearchFriendsActivity) && !(fragmentactivitywithnavigationsupport instanceof SearchGroupsActivity) && !(fragmentactivitywithnavigationsupport instanceof SettingsActivity) && !(fragmentactivitywithnavigationsupport instanceof LoginActivity))
            {
                s_allActivities.remove(i);
                int j = s_allActivities.size();
                fragmentactivitywithnavigationsupport.finish();
                if (s_allActivities.size() <= j)
                {
                    i--;
                }
            }
            i++;
        }
        SteamWebApi.SubmitSimpleActionRequest("UmqActivity", new com.valvesoftware.android.steam.community.SteamDBService.REQ_ACT_UMQACTIVITY_DATA());
    }

}
