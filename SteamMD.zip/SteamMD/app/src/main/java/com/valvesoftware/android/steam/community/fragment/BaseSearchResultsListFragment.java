// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.fragment;

import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.View;
import android.widget.TextView;
import com.valvesoftware.android.steam.community.GenericListDB;
import com.valvesoftware.android.steam.community.SteamCommunityApplication;
import com.valvesoftware.android.steam.community.activity.ActivityHelper;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;

// Referenced classes of package com.valvesoftware.android.steam.community.fragment:
//            BasePresentationListFragment, TitlebarFragment

public abstract class BaseSearchResultsListFragment extends BasePresentationListFragment
{

    private GenericListDB m_db;
    private TextView m_footerBtnNext;
    private TextView m_footerBtnPrev;
    private View m_footerButtons;
    private android.view.View.OnClickListener m_pagingOnClickListener;
    private TextView m_progressLabel;
    protected int m_queryActualResults;
    protected int m_queryOffset;
    protected int m_queryPageSize;
    protected String m_queryText;
    protected int m_queryTotalResults;
    protected final HashMap m_searchResultsOrderMap = new HashMap();
    private Comparator m_sorter;

    public BaseSearchResultsListFragment()
    {
        m_progressLabel = null;
        m_footerButtons = null;
        m_footerBtnPrev = null;
        m_footerBtnNext = null;
        m_db = null;
        m_queryText = "";
        m_queryOffset = 0;
        m_queryPageSize = 50;
        m_queryActualResults = -1;
        m_queryTotalResults = -1;
        m_pagingOnClickListener = new android.view.View.OnClickListener() {

            final BaseSearchResultsListFragment this$0;

            public void onClick(View view)
            {
                BaseSearchResultsListFragment basesearchresultslistfragment = BaseSearchResultsListFragment.this;
                int i = basesearchresultslistfragment.m_queryOffset;
                int j = m_queryPageSize;
                byte byte0;
                if (view == m_footerBtnPrev)
                {
                    byte0 = -1;
                } else
                {
                    byte0 = 1;
                }
                basesearchresultslistfragment.m_queryOffset = i + byte0 * j;
                if (m_queryOffset < 0)
                {
                    m_queryOffset = 0;
                }
                if (m_queryOffset > m_queryTotalResults - m_queryPageSize)
                {
                    m_queryOffset = m_queryTotalResults - m_queryPageSize;
                }
                m_queryActualResults = -1;
                m_queryTotalResults = -1;
                SwitchConfiguration(m_queryText);
            }

            
            {
                this$0 = BaseSearchResultsListFragment.this;
                super();
            }
        };
        m_sorter = new Comparator() {

            final BaseSearchResultsListFragment this$0;

            public int compare(com.valvesoftware.android.steam.community.GenericListDB.GenericListItem genericlistitem, com.valvesoftware.android.steam.community.GenericListDB.GenericListItem genericlistitem1)
            {
                Integer integer = (Integer)m_searchResultsOrderMap.get(genericlistitem.m_steamID);
                Integer integer1 = (Integer)m_searchResultsOrderMap.get(genericlistitem1.m_steamID);
                if (integer != null && integer1 != null)
                {
                    return integer.compareTo(integer1);
                }
                if (integer == null && integer1 == null)
                {
                    return 0;
                }
                return integer == null ? 1 : -1;
            }

            public volatile int compare(Object obj, Object obj1)
            {
                return compare((com.valvesoftware.android.steam.community.GenericListDB.GenericListItem)obj, (com.valvesoftware.android.steam.community.GenericListDB.GenericListItem)obj1);
            }

            
            {
                this$0 = BaseSearchResultsListFragment.this;
                super();
            }
        };
    }

    protected abstract GenericListDB AllocateNewSearchDB();

    protected abstract int GetTitlebarFormatStringForQuery();

    public void SwitchConfiguration(String s)
    {
        boolean flag = true;
        if (myListDb() != null)
        {
            flag = false;
            SteamCommunityApplication.GetInstance().unregisterReceiver(myListDb());
            myListDb().DeregisterCallback(m_listDbListener);
            m_presentationArray.clear();
        }
        m_queryText = s;
        m_db = AllocateNewSearchDB();
        myListDb().RefreshFromHttpOnly();
        if (m_progressLabel != null)
        {
            m_progressLabel.setText(0x7f07007a);
        }
        if (m_footerButtons != null)
        {
            m_footerButtons.setVisibility(8);
        }
        if (!flag)
        {
            myListDb().RegisterCallback(m_listDbListener);
            refreshListView();
        }
        TitlebarFragment titlebarfragment = ActivityHelper.GetTitlebarFragmentForActivity(getActivity());
        if (titlebarfragment != null)
        {
            titlebarfragment.setTitleLabel(getActivity().getResources().getString(GetTitlebarFormatStringForQuery()).replace("#", s));
        }
    }

    protected void myCbckOnListRefreshError(com.valvesoftware.android.steam.community.SteamWebApi.RequestBase requestbase)
    {
        if (m_progressLabel != null)
        {
            m_progressLabel.setText(0x7f07007b);
        }
        if (m_footerButtons != null)
        {
            m_footerButtons.setVisibility(8);
        }
    }

    protected void myCbckProcessPresentationArray()
    {
        if (m_db != null && m_queryTotalResults >= 0 && m_queryActualResults >= 0 && m_queryTotalResults > m_queryPageSize && !m_presentationArray.isEmpty())
        {
            if (m_footerButtons != null)
            {
                m_footerButtons.setVisibility(0);
            }
            if (m_footerBtnPrev != null)
            {
                TextView textview;
                TextView textview1;
                android.view.View.OnClickListener onclicklistener;
                boolean flag1;
                TextView textview2;
                String s1;
                TextView textview3;
                android.view.View.OnClickListener onclicklistener1;
                if (m_queryOffset > 0)
                {
                    flag1 = true;
                } else
                {
                    flag1 = false;
                }
                textview2 = m_footerBtnPrev;
                if (flag1)
                {
                    s1 = "<<";
                } else
                {
                    s1 = " ";
                }
                textview2.setText(s1);
                textview3 = m_footerBtnPrev;
                if (flag1)
                {
                    onclicklistener1 = m_pagingOnClickListener;
                } else
                {
                    onclicklistener1 = null;
                }
                textview3.setOnClickListener(onclicklistener1);
            }
            if (m_footerBtnNext != null)
            {
                boolean flag;
                String s;
                if (m_queryOffset + m_queryPageSize < m_queryTotalResults)
                {
                    flag = true;
                } else
                {
                    flag = false;
                }
                textview = m_footerBtnNext;
                if (flag)
                {
                    s = ">>";
                } else
                {
                    s = " ";
                }
                textview.setText(s);
                textview1 = m_footerBtnNext;
                onclicklistener = null;
                if (flag)
                {
                    onclicklistener = m_pagingOnClickListener;
                }
                textview1.setOnClickListener(onclicklistener);
            }
        }
        Collections.sort(m_presentationArray, m_sorter);
    }

    protected GenericListDB myListDb()
    {
        return m_db;
    }

    public void onActivityCreated(Bundle bundle)
    {
        SwitchConfiguration(getActivity().getIntent().getStringExtra("query"));
        super.onActivityCreated(bundle);
        TitlebarFragment titlebarfragment = ActivityHelper.GetTitlebarFragmentForActivity(getActivity());
        if (titlebarfragment != null)
        {
            titlebarfragment.setRefreshHandler(null);
        }
        m_progressLabel = (TextView)getActivity().findViewById(0x7f09002a);
        if (m_progressLabel != null)
        {
            m_progressLabel.setText(0x7f07007a);
        }
        m_footerButtons = getActivity().findViewById(0x7f09002b);
        if (m_footerButtons != null)
        {
            m_footerButtons.setVisibility(8);
        }
        m_footerBtnPrev = (TextView)getActivity().findViewById(0x7f09002c);
        m_footerBtnNext = (TextView)getActivity().findViewById(0x7f09002d);
    }

    public void onDestroy()
    {
        super.onDestroy();
        SteamCommunityApplication.GetInstance().unregisterReceiver(m_db);
        m_presentationArray.clear();
        m_db = null;
    }

    public void refreshListView()
    {
        super.refreshListView();
        if (m_progressLabel != null && m_db != null && m_queryTotalResults >= 0 && m_queryActualResults >= 0)
        {
            int i = 0x7f07007c;
            TextView textview;
            String s;
            String s1;
            if (m_queryTotalResults <= 0)
            {
                i = 0x7f07007e;
            } else
            if (m_queryActualResults == m_queryTotalResults)
            {
                i = 0x7f07007d;
            }
            textview = m_progressLabel;
            s = getActivity().getResources().getString(i);
            if (m_queryActualResults == m_queryTotalResults)
            {
                s1 = String.valueOf(m_queryTotalResults);
            } else
            {
                s1 = (new StringBuilder()).append(String.valueOf(1 + m_queryOffset)).append("-").append(String.valueOf(m_queryOffset + m_queryActualResults)).toString();
            }
            textview.setText(s.replace("#", s1).replace("$", String.valueOf(m_queryTotalResults)));
        }
    }

}
