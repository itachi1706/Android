// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;


// Referenced classes of package com.valvesoftware.android.steam.community:
//            SteamDebugUtil

public static class DebugUtilRecord extends DebugUtilRecord
{
    private static class DebugUtilRecord
        implements ISteamDebugUtil.IDebugUtilRecord
    {

        public long getId()
        {
            return -1L;
        }

        private DebugUtilRecord()
        {
        }

        DebugUtilRecord(SteamDebugUtil._cls1 _pcls1)
        {
            this();
        }
    }


    public String getSessionId()
    {
        return "";
    }

    public DebugUtilRecord newDebugUtilRecord(DebugUtilRecord debugutilrecord, String s, String s1)
    {
        return new DebugUtilRecord(null);
    }

    public DebugUtilRecord()
    {
    }
}
