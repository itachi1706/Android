// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.fragment;


// Referenced classes of package com.valvesoftware.android.steam.community.fragment:
//            WebViewFragment

static class 
{

    static final int $SwitchMap$com$valvesoftware$android$steam$community$SteamUriHandler$Command[];

    static 
    {
        $SwitchMap$com$valvesoftware$android$steam$community$SteamUriHandler$Command = new int[com.valvesoftware.android.steam.community.mmand.values().length];
        try
        {
            $SwitchMap$com$valvesoftware$android$steam$community$SteamUriHandler$Command[com.valvesoftware.android.steam.community.mmand.opencategoryurl.ordinal()] = 1;
        }
        catch (NoSuchFieldError nosuchfielderror) { }
        try
        {
            $SwitchMap$com$valvesoftware$android$steam$community$SteamUriHandler$Command[com.valvesoftware.android.steam.community.mmand.openurl.ordinal()] = 2;
        }
        catch (NoSuchFieldError nosuchfielderror1) { }
        try
        {
            $SwitchMap$com$valvesoftware$android$steam$community$SteamUriHandler$Command[com.valvesoftware.android.steam.community.mmand.openexternalurl.ordinal()] = 3;
        }
        catch (NoSuchFieldError nosuchfielderror2) { }
        try
        {
            $SwitchMap$com$valvesoftware$android$steam$community$SteamUriHandler$Command[com.valvesoftware.android.steam.community.mmand.mobileloginsucceeded.ordinal()] = 4;
        }
        catch (NoSuchFieldError nosuchfielderror3) { }
        try
        {
            $SwitchMap$com$valvesoftware$android$steam$community$SteamUriHandler$Command[com.valvesoftware.android.steam.community.mmand.reloadpage.ordinal()] = 5;
        }
        catch (NoSuchFieldError nosuchfielderror4) { }
        try
        {
            $SwitchMap$com$valvesoftware$android$steam$community$SteamUriHandler$Command[com.valvesoftware.android.steam.community.mmand.errorrecovery.ordinal()] = 6;
        }
        catch (NoSuchFieldError nosuchfielderror5) { }
        try
        {
            $SwitchMap$com$valvesoftware$android$steam$community$SteamUriHandler$Command[com.valvesoftware.android.steam.community.mmand.login.ordinal()] = 7;
        }
        catch (NoSuchFieldError nosuchfielderror6) { }
        try
        {
            $SwitchMap$com$valvesoftware$android$steam$community$SteamUriHandler$Command[com.valvesoftware.android.steam.community.mmand.closethis.ordinal()] = 8;
        }
        catch (NoSuchFieldError nosuchfielderror7) { }
        try
        {
            $SwitchMap$com$valvesoftware$android$steam$community$SteamUriHandler$Command[com.valvesoftware.android.steam.community.mmand.notfound.ordinal()] = 9;
        }
        catch (NoSuchFieldError nosuchfielderror8) { }
        try
        {
            $SwitchMap$com$valvesoftware$android$steam$community$SteamUriHandler$Command[com.valvesoftware.android.steam.community.mmand.agecheckfailed.ordinal()] = 10;
        }
        catch (NoSuchFieldError nosuchfielderror9) { }
        try
        {
            $SwitchMap$com$valvesoftware$android$steam$community$SteamUriHandler$Command[com.valvesoftware.android.steam.community.mmand.agecheck.ordinal()] = 11;
        }
        catch (NoSuchFieldError nosuchfielderror10) { }
        try
        {
            $SwitchMap$com$valvesoftware$android$steam$community$SteamUriHandler$Command[com.valvesoftware.android.steam.community.mmand.settitle.ordinal()] = 12;
        }
        catch (NoSuchFieldError nosuchfielderror11) { }
        try
        {
            $SwitchMap$com$valvesoftware$android$steam$community$SteamUriHandler$Command[com.valvesoftware.android.steam.community.mmand.chat.ordinal()] = 13;
        }
        catch (NoSuchFieldError nosuchfielderror12)
        {
            return;
        }
    }
}
