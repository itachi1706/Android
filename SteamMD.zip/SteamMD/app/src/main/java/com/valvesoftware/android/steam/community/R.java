// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;


public final class R
{
    public static final class anim
    {

        public static final int splitview_content_hide = 0x7f040000;
        public static final int splitview_content_show = 0x7f040001;
        public static final int splitview_navigation_hide = 0x7f040002;
        public static final int splitview_navigation_show = 0x7f040003;
        public static final int titlebar_refreshing = 0x7f040004;

        public anim()
        {
        }
    }

    public static final class attr
    {

        public attr()
        {
        }
    }

    public static final class color
    {

        public static final int almost_fully_transparent = 0x7f060010;
        public static final int aqua = 0x7f060009;
        public static final int black = 0x7f06000f;
        public static final int blue = 0x7f06000d;
        public static final int category_label = 0x7f060011;
        public static final int chat_background = 0x7f060015;
        public static final int chat_load_more = 0x7f06001e;
        public static final int chat_my_failed = 0x7f06001a;
        public static final int chat_my_sending = 0x7f060018;
        public static final int chat_my_sending_text = 0x7f06001c;
        public static final int chat_my_sent = 0x7f060019;
        public static final int chat_my_sent_text = 0x7f06001d;
        public static final int chat_my_text_background = 0x7f060017;
        public static final int chat_other = 0x7f060016;
        public static final int chat_other_text = 0x7f06001b;
        public static final int fuchsia = 0x7f060002;
        public static final int gray = 0x7f060005;
        public static final int green = 0x7f06000c;
        public static final int ingame = 0x7f060013;
        public static final int lime = 0x7f06000a;
        public static final int maroon = 0x7f060008;
        public static final int navigation_section_title = 0x7f060023;
        public static final int navigation_section_title_underline = 0x7f060024;
        public static final int navy = 0x7f06000e;
        public static final int offline = 0x7f060012;
        public static final int olive = 0x7f060006;
        public static final int online = 0x7f060014;
        public static final int purple = 0x7f060007;
        public static final int red = 0x7f060003;
        public static final int settings_background = 0x7f060025;
        public static final int settings_changeuser = 0x7f060028;
        public static final int settings_item_detail = 0x7f060027;
        public static final int settings_item_title = 0x7f060026;
        public static final int silver = 0x7f060004;
        public static final int tab_selector_active = 0x7f06001f;
        public static final int tab_selector_bg_active = 0x7f060021;
        public static final int tab_selector_bg_default = 0x7f060022;
        public static final int tab_selector_default = 0x7f060020;
        public static final int teal = 0x7f06000b;
        public static final int white = 0x7f060000;
        public static final int yellow = 0x7f060001;

        public color()
        {
        }
    }

    public static final class drawable
    {

        public static final int avatar_frame_ingame = 0x7f020000;
        public static final int avatar_frame_offline = 0x7f020001;
        public static final int avatar_frame_online = 0x7f020002;
        public static final int button_navigation = 0x7f020003;
        public static final int button_navigation_highlighted = 0x7f020004;
        public static final int chat_bubble_left = 0x7f020005;
        public static final int chat_bubble_left_blue = 0x7f020006;
        public static final int chat_bubble_right = 0x7f020007;
        public static final int chat_button_available = 0x7f020008;
        public static final int chat_button_offline = 0x7f020009;
        public static final int chat_button_unread = 0x7f02000a;
        public static final int icon_coverup = 0x7f02000b;
        public static final int icon_options_hide = 0x7f02000c;
        public static final int icon_options_show = 0x7f02000d;
        public static final int icon_quarter = 0x7f02000e;
        public static final int icon_refresh = 0x7f02000f;
        public static final int icon_search = 0x7f020010;
        public static final int icon_search_add = 0x7f020011;
        public static final int icon_up = 0x7f020012;
        public static final int login_gradient = 0x7f020013;
        public static final int nav_item_blotter = 0x7f020014;
        public static final int nav_item_cart = 0x7f020015;
        public static final int nav_item_exit = 0x7f020016;
        public static final int nav_item_feed = 0x7f020017;
        public static final int nav_item_friends = 0x7f020018;
        public static final int nav_item_groups = 0x7f020019;
        public static final int nav_item_search = 0x7f02001a;
        public static final int nav_item_settings = 0x7f02001b;
        public static final int nav_item_store_catalog = 0x7f02001c;
        public static final int nav_item_store_wishlist = 0x7f02001d;
        public static final int navbar_pattern = 0x7f02001e;
        public static final int navbar_repeat = 0x7f02001f;
        public static final int navigation_bg_pattern = 0x7f020020;
        public static final int navigation_bg_repeat = 0x7f020021;
        public static final int navigation_gradient = 0x7f020022;
        public static final int notification_chat = 0x7f020023;
        public static final int notification_default = 0x7f020024;
        public static final int notification_offline = 0x7f020025;
        public static final int placeholder_contact = 0x7f020026;
        public static final int search = 0x7f020027;
        public static final int steam = 0x7f020028;
        public static final int steam_btn_default = 0x7f020029;
        public static final int steam_btn_default_normal = 0x7f02002a;
        public static final int steam_btn_default_normal_disable = 0x7f02002b;
        public static final int steam_btn_default_normal_disable_focused = 0x7f02002c;
        public static final int steam_btn_default_pressed = 0x7f02002d;
        public static final int steam_btn_default_selected = 0x7f02002e;
        public static final int steam_edit_text = 0x7f02002f;
        public static final int steam_textfield_default = 0x7f020030;
        public static final int steam_textfield_disabled = 0x7f020031;
        public static final int steam_textfield_disabled_selected = 0x7f020032;
        public static final int steam_textfield_pressed = 0x7f020033;
        public static final int steam_textfield_search_default = 0x7f020034;
        public static final int steam_textfield_search_pressed = 0x7f020035;
        public static final int steam_textfield_search_selected = 0x7f020036;
        public static final int steam_textfield_selected = 0x7f020037;
        public static final int table_cell_background = 0x7f020038;
        public static final int table_cell_chevron = 0x7f020039;
        public static final int table_cell_chevron_white = 0x7f02003a;
        public static final int table_cell_section = 0x7f02003b;
        public static final int unknown = 0x7f02003c;

        public drawable()
        {
        }
    }

    public static final class id
    {

        public static final int avatar = 0x7f09000e;
        public static final int avatar_frame = 0x7f090012;
        public static final int chat = 0x7f090002;
        public static final int chatButton = 0x7f090016;
        public static final int chat_options_clear_history_button = 0x7f090007;
        public static final int chat_options_layout = 0x7f090006;
        public static final int chat_say_layout = 0x7f09000a;
        public static final int chat_view_contents = 0x7f090008;
        public static final int chat_view_entry_other = 0x7f090033;
        public static final int chat_view_entry_other_text = 0x7f09000f;
        public static final int chat_view_entry_user_text = 0x7f090010;
        public static final int chat_view_layout = 0x7f090005;
        public static final int chat_view_say_button = 0x7f09000c;
        public static final int chat_view_say_text = 0x7f09000b;
        public static final int chat_view_status = 0x7f090009;
        public static final int community_list = 0x7f090011;
        public static final int friendItemAreaAroundChatButton = 0x7f090015;
        public static final int groupMembersOnline = 0x7f090021;
        public static final int groupMembersTotal = 0x7f090020;
        public static final int imageChevron = 0x7f090017;
        public static final int imageView1 = 0x7f090022;
        public static final int info = 0x7f090031;
        public static final int label = 0x7f09000d;
        public static final int list_search_bar = 0x7f09001d;
        public static final int list_search_bar_button = 0x7f09001f;
        public static final int list_search_bar_text = 0x7f09001e;
        public static final int loggedIn = 0x7f09001c;
        public static final int login = 0x7f09001b;
        public static final int name = 0x7f090013;
        public static final int navFragment_ContentButton = 0x7f090026;
        public static final int navFragment_TitleButton = 0x7f090024;
        public static final int navFragment_TitleItem = 0x7f090025;
        public static final int navigation = 0x7f090004;
        public static final int navigation_section_name_underline = 0x7f090029;
        public static final int navigation_section_title_layout = 0x7f090027;
        public static final int navigation_section_title_layout_content = 0x7f090028;
        public static final int notLoggedIn = 0x7f090019;
        public static final int search_footer_button_next = 0x7f09002d;
        public static final int search_footer_button_prev = 0x7f09002c;
        public static final int search_footer_buttons = 0x7f09002b;
        public static final int search_progress_label = 0x7f09002a;
        public static final int setting_checkbox = 0x7f090032;
        public static final int settingsFragment_AccountControl_ChangeUser = 0x7f090030;
        public static final int settingsFragment_TitleItem = 0x7f09002f;
        public static final int settings_fragment = 0x7f09002e;
        public static final int splitView_Contents = 0x7f090000;
        public static final int splitView_Navigation = 0x7f090003;
        public static final int status = 0x7f090014;
        public static final int steamid = 0x7f090018;
        public static final int tab_title = 0x7f090034;
        public static final int textView1 = 0x7f09001a;
        public static final int titleLabel = 0x7f090036;
        public static final int titleNavActivationButton = 0x7f090035;
        public static final int titleNavRefreshButton = 0x7f090038;
        public static final int titleNavRefreshQuarter = 0x7f090039;
        public static final int titleNavSearchButton = 0x7f090037;
        public static final int titlebar = 0x7f090001;
        public static final int toggleGroup = 0x7f09003c;
        public static final int webView = 0x7f090045;
        public static final int web_select_1 = 0x7f09003d;
        public static final int web_select_2 = 0x7f09003e;
        public static final int web_select_3 = 0x7f09003f;
        public static final int web_select_4 = 0x7f090040;
        public static final int web_select_5 = 0x7f090041;
        public static final int web_select_6 = 0x7f090042;
        public static final int web_select_7 = 0x7f090043;
        public static final int web_select_8 = 0x7f090044;
        public static final int web_select_layout = 0x7f09003b;
        public static final int web_view = 0x7f09003a;
        public static final int webview = 0x7f090023;

        public id()
        {
        }
    }

    public static final class layout
    {

        public static final int chat_activity = 0x7f030000;
        public static final int chat_fragment = 0x7f030001;
        public static final int chat_view_entry_other = 0x7f030002;
        public static final int chat_view_entry_other_text = 0x7f030003;
        public static final int chat_view_entry_user = 0x7f030004;
        public static final int chat_view_entry_user_left = 0x7f030005;
        public static final int chat_view_entry_user_text = 0x7f030006;
        public static final int community_activity = 0x7f030007;
        public static final int community_groups_activity = 0x7f030008;
        public static final int friend_list_item = 0x7f030009;
        public static final int friends_fragment = 0x7f03000a;
        public static final int group_list_item = 0x7f03000b;
        public static final int login = 0x7f03000c;
        public static final int navigation_fragment = 0x7f03000d;
        public static final int navigation_list_item = 0x7f03000e;
        public static final int search_friends_activity = 0x7f03000f;
        public static final int search_groups_activity = 0x7f030010;
        public static final int settings_activity = 0x7f030011;
        public static final int settings_fragment = 0x7f030012;
        public static final int settings_list_item_info = 0x7f030013;
        public static final int tabs = 0x7f030014;
        public static final int tabs_indicator = 0x7f030015;
        public static final int titlebar_fragment = 0x7f030016;
        public static final int web_view_list_item = 0x7f030017;
        public static final int webview_activity = 0x7f030018;
        public static final int webview_fragment = 0x7f030019;

        public layout()
        {
        }
    }

    public static final class raw
    {

        public static final int m = 0x7f050000;

        public raw()
        {
        }
    }

    public static final class string
    {

        public static final int Account_Details = 0x7f07000a;
        public static final int Account_name = 0x7f070009;
        public static final int Away = 0x7f070025;
        public static final int Blotter = 0x7f07003a;
        public static final int Busy = 0x7f070024;
        public static final int Cancel = 0x7f07001f;
        public static final int Cart = 0x7f070003;
        public static final int Catalog = 0x7f07002b;
        public static final int Chat = 0x7f07000c;
        public static final int Chat_Headline_Message = 0x7f070069;
        public static final int Chat_Load_More_Msgs = 0x7f070068;
        public static final int Chat_Tap_to_Compose_Hint = 0x7f07006a;
        public static final int Chat_clear_history = 0x7f070064;
        public static final int Chats = 0x7f07005f;
        public static final int Community_Caps = 0x7f07000d;
        public static final int DO_NOT_LOCALIZE_COOKIE_Steam_Language = 0x7f070000;
        public static final int Edit = 0x7f070056;
        public static final int Email_code = 0x7f070012;
        public static final int Exit_Application = 0x7f070016;
        public static final int Exit_Caps = 0x7f070015;
        public static final int Friend_Is_Offline = 0x7f070022;
        public static final int Friend_Requests = 0x7f07005e;
        public static final int Friend_Search_All = 0x7f070076;
        public static final int Friends = 0x7f07000e;
        public static final int Group_Invites = 0x7f070060;
        public static final int Group_Num_Members_Online = 0x7f070070;
        public static final int Group_Num_Members_Total = 0x7f07006f;
        public static final int Group_Search_All = 0x7f070077;
        public static final int Groups = 0x7f070029;
        public static final int In_Game = 0x7f070023;
        public static final int LastOnline_DaysAgo = 0x7f070072;
        public static final int LastOnline_HoursAgo = 0x7f070073;
        public static final int LastOnline_MinutesAgo = 0x7f070074;
        public static final int LastOnline_SecondsAgo = 0x7f070075;
        public static final int LastOnline_YearOrMore = 0x7f070071;
        public static final int Loading = 0x7f070036;
        public static final int Logging_Into_Steam = 0x7f070019;
        public static final int Logging_OutOf_Steam = 0x7f07001a;
        public static final int Login = 0x7f070008;
        public static final int Login_For_Friends = 0x7f07002c;
        public static final int Market_Unavailable = 0x7f070088;
        public static final int My_Profile = 0x7f07001e;
        public static final int News_Feeds_Caps = 0x7f070039;
        public static final int Official_Groups = 0x7f070061;
        public static final int Offline = 0x7f070021;
        public static final int Online = 0x7f070020;
        public static final int Password = 0x7f07000b;
        public static final int Playing = 0x7f070028;
        public static final int Private_Groups = 0x7f070063;
        public static final int Profile = 0x7f07001d;
        public static final int Public_Groups = 0x7f070062;
        public static final int Refresh = 0x7f07002a;
        public static final int Reload = 0x7f070067;
        public static final int SSA_Agree = 0x7f070083;
        public static final int Search = 0x7f070004;
        public static final int SearchBar_Tap_to_Search_Hint = 0x7f07006b;
        public static final int Search_Groups_Results = 0x7f070079;
        public static final int Search_Label_Failed = 0x7f07007b;
        public static final int Search_Label_Results = 0x7f07007c;
        public static final int Search_Label_ResultsAll = 0x7f07007d;
        public static final int Search_Label_ResultsNone = 0x7f07007e;
        public static final int Search_Label_Searching = 0x7f07007a;
        public static final int Search_Players_Results = 0x7f070078;
        public static final int Send = 0x7f070059;
        public static final int Settings = 0x7f070007;
        public static final int Settings_About = 0x7f07007f;
        public static final int Settings_Caps = 0x7f070006;
        public static final int Settings_Version = 0x7f070080;
        public static final int Sign_Out = 0x7f070014;
        public static final int Snooze = 0x7f070026;
        public static final int Steam = 0x7f070038;
        public static final int Steam_Guard = 0x7f070084;
        public static final int Steam_Guard_Copied = 0x7f070086;
        public static final int Steam_Guard_Error = 0x7f070085;
        public static final int Steam_Guard_Notification = 0x7f070087;
        public static final int Steam_News = 0x7f07000f;
        public static final int Steam_Specials = 0x7f0700a4;
        public static final int Store_Caps = 0x7f070002;
        public static final int Syndicated = 0x7f070010;
        public static final int Unknown = 0x7f070027;
        public static final int Username = 0x7f070013;
        public static final int Verification_Code = 0x7f070011;
        public static final int Web_Error_Reload = 0x7f07006d;
        public static final int Web_Error_Retry_Now = 0x7f07006e;
        public static final int Web_Error_Title = 0x7f07006c;
        public static final int Wishlist = 0x7f070005;
        public static final int account_does_not_own_app = 0x7f070081;
        public static final int account_does_not_own_app_EXPLAIN = 0x7f070082;
        public static final int agecheckfailed = 0x7f070058;
        public static final int app_name = 0x7f070001;
        public static final int date_not_set = 0x7f070057;
        public static final int download_failed_dialog_message = 0x7f07002f;
        public static final int download_failed_dialog_negative_button = 0x7f070030;
        public static final int download_failed_dialog_positive_button = 0x7f070031;
        public static final int download_failed_dialog_title = 0x7f07002e;
        public static final int incorrect_login = 0x7f070017;
        public static final int invalid_request = 0x7f07001b;
        public static final int invalid_steamguard_code = 0x7f07001c;
        public static final int nonsteam_link_ok = 0x7f07009f;
        public static final int nonsteam_link_text = 0x7f0700a1;
        public static final int nonsteam_link_title = 0x7f0700a0;
        public static final int notfound = 0x7f070037;
        public static final int notification_chat_copied = 0x7f070066;
        public static final int notification_chat_msgs = 0x7f070065;
        public static final int servers_unreachable = 0x7f07002d;
        public static final int service_umq_foreground = 0x7f07005a;
        public static final int service_umq_foreground_connecting = 0x7f07005b;
        public static final int service_umq_foreground_invalidcredentials = 0x7f07005d;
        public static final int service_umq_foreground_reconnecting = 0x7f07005c;
        public static final int settings_chat_layout = 0x7f070093;
        public static final int settings_chat_layout_bubbles = 0x7f070094;
        public static final int settings_chat_layout_bubbles_left = 0x7f070095;
        public static final int settings_chat_layout_text_only = 0x7f070096;
        public static final int settings_chat_links_nonsteam = 0x7f07009d;
        public static final int settings_chat_links_nonsteam_details = 0x7f07009e;
        public static final int settings_chat_recent = 0x7f07008d;
        public static final int settings_chat_recent_1hour = 0x7f070091;
        public static final int settings_chat_recent_24hours = 0x7f070090;
        public static final int settings_chat_recent_48hours = 0x7f07008f;
        public static final int settings_chat_recent_unread = 0x7f070092;
        public static final int settings_chat_recent_week = 0x7f07008e;
        public static final int settings_chat_summary = 0x7f070089;
        public static final int settings_chat_summary_details = 0x7f07008a;
        public static final int settings_chat_summary_details_done = 0x7f07008c;
        public static final int settings_chat_summary_done = 0x7f07008b;
        public static final int settings_chat_timestamps = 0x7f070097;
        public static final int settings_chat_timestamps_15min = 0x7f07009a;
        public static final int settings_chat_timestamps_1min = 0x7f07009b;
        public static final int settings_chat_timestamps_day = 0x7f070098;
        public static final int settings_chat_timestamps_hour = 0x7f070099;
        public static final int settings_chat_timestamps_msg = 0x7f07009c;
        public static final int settings_hw_acceleration = 0x7f0700a2;
        public static final int settings_hw_acceleration_details = 0x7f0700a3;
        public static final int settings_notifications = 0x7f07003b;
        public static final int settings_notifications_im2 = 0x7f07003e;
        public static final int settings_notifications_im_detailed = 0x7f070040;
        public static final int settings_notifications_im_off = 0x7f070041;
        public static final int settings_notifications_ongoing = 0x7f07003c;
        public static final int settings_notifications_ongoing_detailed = 0x7f07003f;
        public static final int settings_notifications_ongoing_detailed2 = 0x7f07003d;
        public static final int settings_notifications_ring = 0x7f070042;
        public static final int settings_notifications_ring_default = 0x7f070044;
        public static final int settings_notifications_ring_steam = 0x7f070043;
        public static final int settings_notifications_sound = 0x7f070045;
        public static final int settings_notifications_sound_all = 0x7f070046;
        public static final int settings_notifications_sound_first = 0x7f070047;
        public static final int settings_notifications_sound_never = 0x7f070048;
        public static final int settings_notifications_vibrate = 0x7f070049;
        public static final int settings_notifications_vibrate_all = 0x7f07004a;
        public static final int settings_notifications_vibrate_first = 0x7f07004b;
        public static final int settings_notifications_vibrate_never = 0x7f07004c;
        public static final int settings_personal = 0x7f07004d;
        public static final int settings_personal_dob = 0x7f07004e;
        public static final int settings_personal_dob_instr = 0x7f07004f;
        public static final int settings_personal_steam_preferences = 0x7f070050;
        public static final int settings_personal_steam_preferences_detailed = 0x7f070051;
        public static final int steamguard_code_required = 0x7f070018;
        public static final int update_dialog_message = 0x7f070033;
        public static final int update_dialog_negative_button = 0x7f070034;
        public static final int update_dialog_positive_button = 0x7f070035;
        public static final int update_dialog_title = 0x7f070032;
        public static final int webview_ssl_untrusted_prompt = 0x7f070052;
        public static final int webview_ssl_untrusted_prompt_cancel = 0x7f070053;
        public static final int webview_ssl_untrusted_prompt_ok_always = 0x7f070055;
        public static final int webview_ssl_untrusted_prompt_ok_once = 0x7f070054;

        public string()
        {
        }
    }

    public static final class style
    {

        public static final int steam_btn_default = 0x7f080001;
        public static final int steam_edittext = 0x7f080000;
        public static final int webview_category_btn = 0x7f080002;

        public style()
        {
        }
    }


    public R()
    {
    }
}
