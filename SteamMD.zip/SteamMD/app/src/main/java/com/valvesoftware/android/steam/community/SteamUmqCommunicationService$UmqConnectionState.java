// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;


// Referenced classes of package com.valvesoftware.android.steam.community:
//            SteamUmqCommunicationService

public static final class  extends Enum
{

    private static final .VALUES $VALUES[];
    public static final .VALUES active;
    public static final .VALUES connecting;
    public static final .VALUES idle;
    public static final .VALUES invalidcredentials;
    public static final .VALUES offline;
    public static final .VALUES reconnecting;

    public static  valueOf(String s)
    {
        return ()Enum.valueOf(com/valvesoftware/android/steam/community/SteamUmqCommunicationService$UmqConnectionState, s);
    }

    public static [] values()
    {
        return ([])$VALUES.clone();
    }

    public int getStringResid()
    {
        switch (lvesoftware.android.steam.community.SteamUmqCommunicationService.UmqConnectionState[ordinal()])
        {
        default:
            return 0x7f070021;

        case 2: // '\002'
            return 0x7f07005d;

        case 3: // '\003'
            return 0x7f07005b;

        case 4: // '\004'
            return 0x7f07005c;

        case 5: // '\005'
            return 0x7f070026;

        case 6: // '\006'
            return 0x7f070020;
        }
    }

    public boolean isConnected()
    {
        return this == active;
    }

    static 
    {
        offline = new <init>("offline", 0);
        invalidcredentials = new <init>("invalidcredentials", 1);
        connecting = new <init>("connecting", 2);
        reconnecting = new <init>("reconnecting", 3);
        idle = new <init>("idle", 4);
        active = new <init>("active", 5);
        active aactive[] = new <init>[6];
        aactive[0] = offline;
        aactive[1] = invalidcredentials;
        aactive[2] = connecting;
        aactive[3] = reconnecting;
        aactive[4] = idle;
        aactive[5] = active;
        $VALUES = aactive;
    }

    private (String s, int i)
    {
        super(s, i);
    }
}
