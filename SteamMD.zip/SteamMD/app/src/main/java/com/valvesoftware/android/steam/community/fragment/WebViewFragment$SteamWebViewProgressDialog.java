// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.fragment;

import android.app.ProgressDialog;
import android.content.Context;
import android.support.v4.app.FragmentActivity;
import android.webkit.WebView;

// Referenced classes of package com.valvesoftware.android.steam.community.fragment:
//            WebViewFragment

private class this._cls0 extends ProgressDialog
{

    final WebViewFragment this$0;

    public void onBackPressed()
    {
        WebViewFragment.access$200(WebViewFragment.this).setWebViewClient(null);
        WebViewFragment.access$200(WebViewFragment.this).stopLoading();
        super.onBackPressed();
        getActivity().finish();
    }

    public (Context context)
    {
        this$0 = WebViewFragment.this;
        super(context);
    }
}
