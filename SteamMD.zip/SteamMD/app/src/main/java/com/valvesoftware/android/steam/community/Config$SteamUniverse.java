// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;


// Referenced classes of package com.valvesoftware.android.steam.community:
//            Config

public static final class  extends Enum
{

    private static final .VALUES $VALUES[];
    public static final .VALUES Beta;
    public static final .VALUES Dev;
    public static final .VALUES Public;

    public static  valueOf(String s)
    {
        return ()Enum.valueOf(com/valvesoftware/android/steam/community/Config$SteamUniverse, s);
    }

    public static [] values()
    {
        return ([])$VALUES.clone();
    }

    static 
    {
        Public = new <init>("Public", 0);
        Beta = new <init>("Beta", 1);
        Dev = new <init>("Dev", 2);
        e_3B_.clone aclone[] = new <init>[3];
        aclone[0] = Public;
        aclone[1] = Beta;
        aclone[2] = Dev;
        $VALUES = aclone;
    }

    private (String s, int i)
    {
        super(s, i);
    }
}
