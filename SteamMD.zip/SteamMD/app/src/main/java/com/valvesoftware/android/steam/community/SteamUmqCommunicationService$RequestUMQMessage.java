// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;

import android.content.Context;
import android.content.Intent;
import java.util.Calendar;
import org.json.JSONException;
import org.json.JSONObject;

// Referenced classes of package com.valvesoftware.android.steam.community:
//            SteamUmqCommunicationService, SteamDBService, SteamUmqCommunicationDatabase

private class che extends che
{

    final SteamUmqCommunicationService this$0;

    private void onThisRequestFinished(String s)
    {
        che che = (che)GetObjData();
        Intent intent = new Intent("com.valvesoftware.android.steam.community.SteamUmqCommunicationIntent");
        intent.putExtra("type", "chatmsg");
        intent.putExtra("action", "send");
        intent.putExtra("send", s);
        intent.putExtra("steamid", che.GetObjData.amID);
        intent.putExtra("msgid", che.amID.amID);
        if (che.ontext != null)
        {
            intent.putExtra("intentcontext", che.ontext);
        }
        SteamUmqCommunicationService.access$700(SteamUmqCommunicationService.this).getApplicationContext().sendBroadcast(intent);
    }

    public void RequestFailedOnResponseWorkerThread()
    {
        onThisRequestFinished("error");
    }

    public void RequestSucceededOnResponseWorkerThread()
    {
        if (m_jsonDocument == null) goto _L2; else goto _L1
_L1:
        String s = "";
        String s1 = m_jsonDocument.getString("error");
        s = s1;
_L4:
        if ("OK".equals(s))
        {
            onThisRequestFinished onthisrequestfinished = (m_jsonDocument)GetObjData();
            onthisrequestfinished.GetObjData.ID = onthisrequestfinished..;
            onthisrequestfinished..g = false;
            onthisrequestfinished.g.g = false;
            onthisrequestfinished.g.g = Calendar.getInstance();
            if (!onthisrequestfinished.g.g.equals("typing"))
            {
                SteamUmqCommunicationService.access$2100(SteamUmqCommunicationService.this).insertMessage(onthisrequestfinished._fld0);
            }
            onThisRequestFinished("OK");
            return;
        }
_L2:
        onThisRequestFinished("error");
        return;
        JSONException jsonexception;
        jsonexception;
        if (true) goto _L4; else goto _L3
_L3:
    }

    public ()
    {
        this$0 = SteamUmqCommunicationService.this;
        super(SteamUmqCommunicationService.this, "JobQueueUMQsendmsg");
        SetUriAndDocumentType(SteamUmqCommunicationService.access$2300(), SetUriAndDocumentType);
        SetRequestAction(che);
    }
}
