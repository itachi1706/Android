// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;


// Referenced classes of package com.valvesoftware.android.steam.community:
//            SteamWebApi

static class questDocumentType
{

    static final int $SwitchMap$com$valvesoftware$android$steam$community$SteamWebApi$RequestDocumentType[];

    static 
    {
        $SwitchMap$com$valvesoftware$android$steam$community$SteamWebApi$RequestDocumentType = new int[questDocumentType.values().length];
        try
        {
            $SwitchMap$com$valvesoftware$android$steam$community$SteamWebApi$RequestDocumentType[questDocumentType.String.ordinal()] = 1;
        }
        catch (NoSuchFieldError nosuchfielderror) { }
        try
        {
            $SwitchMap$com$valvesoftware$android$steam$community$SteamWebApi$RequestDocumentType[questDocumentType.JSON.ordinal()] = 2;
        }
        catch (NoSuchFieldError nosuchfielderror1) { }
        try
        {
            $SwitchMap$com$valvesoftware$android$steam$community$SteamWebApi$RequestDocumentType[questDocumentType.Bitmap.ordinal()] = 3;
        }
        catch (NoSuchFieldError nosuchfielderror2)
        {
            return;
        }
    }
}
