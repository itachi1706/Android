// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;

import android.content.Intent;
import java.io.ByteArrayOutputStream;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;

// Referenced classes of package com.valvesoftware.android.steam.community:
//            SteamDBService, SteamDBDiskCache, SteamCommunityApplication

public static class m_request
    implements m_request
{

    protected dBroadcast m_request;

    private m_request FetchFromHttp()
        throws Exception
    {
        HttpResponse httpresponse = m_request.HttpResponseOnWorkerThread();
        HttpEntity httpentity = httpresponse.getEntity();
        StatusLine statusline = httpresponse.getStatusLine();
        if (statusline.getStatusCode() == 200 && httpentity != null)
        {
            java.io.InputStream inputstream = httpentity.getContent();
            m_request m_request2 = new ();
            ByteArrayOutputStream bytearrayoutputstream = SteamDBService.access$100(inputstream);
            if (m_request.uestForByteData())
            {
                m_request2.uestIsLive(bytearrayoutputstream.toByteArray());
                return m_request2;
            } else
            {
                m_request2.uestIsLive(bytearrayoutputstream.toString());
                return m_request2;
            }
        } else
        {
            m_request m_request1 = new ();
            m_request1.uestError(statusline.getStatusCode());
            return m_request1;
        }
    }

    private uestError ReadFromMemoryOrCache()
    {
        uestError uesterror = new ();
        acheInfo acheinfo = m_request.skCacheInfo();
        byte abyte0[] = acheinfo.disk.Read(acheinfo.uri);
        if (abyte0 != null)
        {
            uesterror.uestIsLive(abyte0);
        }
        if (abyte0 == null);
        return uesterror;
    }

    public String GetRequestQueue()
    {
        switch (om.valvesoftware.android.steam.community.SteamWebApi.RequestActionType[m_request.questAction().ordinal()])
        {
        default:
            return m_request.questQueue();

        case 1: // '\001'
        case 2: // '\002'
            return "JobQueueDiskCache";
        }
    }

    public void Run()
    {
        if (m_request.kReadyToRunOnJobQueue()) goto _L2; else goto _L1
_L1:
        return;
_L2:
        String s;
        int i;
         ;
        s = m_request.llerIntent();
        if (s != null && "JOB_INTENT_SHUTDOWN_JOB_QUEUE".equals(s))
        {
            throw new ueueException();
        }
        i = om.valvesoftware.android.steam.community.SteamWebApi.RequestActionType[m_request.questAction().ordinal()];
         = null;
        i;
        JVM INSTR tableswitch 1 2: default 80
    //                   1 199
    //                   2 207;
           goto _L3 _L4 _L5
_L3:
        om.valvesoftware.android.steam.community.SteamWebApi.RequestActionType[m_request.questAction().ordinal()];
        JVM INSTR tableswitch 3 4: default 116
    //                   3 240
    //                   4 248;
           goto _L6 _L7 _L8
_L6:
         2;
         3;
        2 = .uestCacheState();
        3 = CacheIsMissing;
        boolean flag = false;
        if (2 == 3) goto _L10; else goto _L9
_L9:
        m_request.ponseWorkerThread();
        flag = true;
_L10:
        if (!flag)
        {
            m_request.lureWorkerThread();
        }
        if (s != null)
        {
            Intent intent2 = new Intent(s);
            intent2.putExtra("intent_id", m_request.tentId());
            SteamCommunityApplication.GetInstance().sendBroadcast(intent2);
            return;
        }
          goto _L1
_L4:
         = ReadFromMemoryOrCache();
          goto _L3
_L5:
         = ReadFromMemoryOrCache();
        if (.uestCacheState() != CacheIsMissing) goto _L3; else goto _L11
_L11:
        m_request.questAction(.DoHttpRequestAndCacheResults);
        throw new lException();
_L7:
         = FetchFromHttp();
          goto _L6
_L8:
         = FetchFromHttp();
        if (.estLive())
        {
            WriteToCacheInBackground();
        }
          goto _L6
        Exception exception1;
        exception1;
         1 = ;
         = new ();
        .uestError(2);
        if (true)
        {
            m_request.lureWorkerThread();
        }
        if (s == null) goto _L1; else goto _L12
_L12:
        Intent intent1 = new Intent(s);
        intent1.putExtra("intent_id", m_request.tentId());
        SteamCommunityApplication.GetInstance().sendBroadcast(intent1);
        return;
        Exception exception;
        exception;
_L14:
        if (true)
        {
            m_request.lureWorkerThread();
        }
        if (s != null)
        {
            Intent intent = new Intent(s);
            intent.putExtra("intent_id", m_request.tentId());
            SteamCommunityApplication.GetInstance().sendBroadcast(intent);
        }
        throw exception;
        exception;
         = 1;
        if (true) goto _L14; else goto _L13
_L13:
    }

    protected void WriteToCacheInBackground(dBroadcast dbroadcast)
    {
    }

    public lException(lException lexception)
    {
        m_request = null;
        m_request = lexception;
    }
}
