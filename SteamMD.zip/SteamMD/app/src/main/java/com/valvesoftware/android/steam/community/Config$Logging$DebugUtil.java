// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;


// Referenced classes of package com.valvesoftware.android.steam.community:
//            Config

public static class 
{

    public static final boolean log_collected_info;
    public static final boolean log_sql;
    public static final boolean log_uploaded_dumps;
    public static final boolean retain_collected_after_upload;
    public static final boolean verbose_collection;

    public ()
    {
    }
}
