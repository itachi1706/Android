// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.fragment;

import android.content.Intent;
import android.support.v4.app.FragmentActivity;

// Referenced classes of package com.valvesoftware.android.steam.community.fragment:
//            NavigationFragment

public class this._cls0 extends this._cls0
{

    public Class activity;
    public String info;
    public int resid_name;
    final NavigationFragment this$0;

    public String getDetails()
    {
        return "";
    }

    public int getName()
    {
        return resid_name;
    }

    public Intent getNewActivityIntent()
    {
        return (new Intent()).addFlags(0x18000000).setClass(getActivity(), activity);
    }

    public void onClick()
    {
        getActivity().startActivity(getNewActivityIntent());
    }

    public ()
    {
        this$0 = NavigationFragment.this;
        super();
    }
}
