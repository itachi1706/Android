// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;


// Referenced classes of package com.valvesoftware.android.steam.community:
//            SteamDebugUtil

class val.bDbReadyNow extends Thread
{

    final SteamDebugUtil this$0;
    final boolean val$bDbReadyNow;

    public void run()
    {
        if (val$bDbReadyNow)
        {
            SteamDebugUtil.access$200(SteamDebugUtil.this);
        }
        while (SteamDebugUtil.access$300(SteamDebugUtil.this)) ;
    }

    ()
    {
        this$0 = final_steamdebugutil;
        val$bDbReadyNow = Z.this;
        super();
    }
}
