// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;

import android.content.res.Resources;

// Referenced classes of package com.valvesoftware.android.steam.community:
//            SteamCommunityApplication, GenericListDB

public class FriendInfo extends GenericListDB.GenericListItem
{
    public static final class FriendRelationship extends Enum
    {

        private static final FriendRelationship $VALUES[];
        public static final FriendRelationship blocked;
        public static final FriendRelationship friend;
        public static final FriendRelationship ignored;
        public static final FriendRelationship ignoredfriend;
        public static final FriendRelationship myself;
        public static final FriendRelationship none;
        public static final FriendRelationship requestinitiator;
        public static final FriendRelationship requestrecipient;
        public static final FriendRelationship suggested;

        public static FriendRelationship valueOf(String s)
        {
            return (FriendRelationship)Enum.valueOf(com/valvesoftware/android/steam/community/FriendInfo$FriendRelationship, s);
        }

        public static FriendRelationship[] values()
        {
            return (FriendRelationship[])$VALUES.clone();
        }

        static 
        {
            none = new FriendRelationship("none", 0);
            myself = new FriendRelationship("myself", 1);
            friend = new FriendRelationship("friend", 2);
            blocked = new FriendRelationship("blocked", 3);
            requestrecipient = new FriendRelationship("requestrecipient", 4);
            requestinitiator = new FriendRelationship("requestinitiator", 5);
            ignored = new FriendRelationship("ignored", 6);
            ignoredfriend = new FriendRelationship("ignoredfriend", 7);
            suggested = new FriendRelationship("suggested", 8);
            FriendRelationship afriendrelationship[] = new FriendRelationship[9];
            afriendrelationship[0] = none;
            afriendrelationship[1] = myself;
            afriendrelationship[2] = friend;
            afriendrelationship[3] = blocked;
            afriendrelationship[4] = requestrecipient;
            afriendrelationship[5] = requestinitiator;
            afriendrelationship[6] = ignored;
            afriendrelationship[7] = ignoredfriend;
            afriendrelationship[8] = suggested;
            $VALUES = afriendrelationship;
        }

        private FriendRelationship(String s, int i)
        {
            super(s, i);
        }
    }

    public static final class PersonaState extends Enum
    {

        private static final PersonaState $VALUES[];
        public static final PersonaState AWAY;
        public static final PersonaState BUSY;
        public static final PersonaState OFFLINE;
        public static final PersonaState ONLINE;
        public static final PersonaState SNOOZE;

        public static PersonaState FromInteger(int i)
        {
            switch (i)
            {
            default:
                return OFFLINE;

            case 0: // '\0'
                return OFFLINE;

            case 1: // '\001'
                return ONLINE;

            case 2: // '\002'
                return BUSY;

            case 3: // '\003'
                return AWAY;

            case 4: // '\004'
                return SNOOZE;
            }
        }

        public static PersonaState valueOf(String s)
        {
            return (PersonaState)Enum.valueOf(com/valvesoftware/android/steam/community/FriendInfo$PersonaState, s);
        }

        public static PersonaState[] values()
        {
            return (PersonaState[])$VALUES.clone();
        }

        public int GetDisplayString()
        {
            static class _cls1
            {

                static final int $SwitchMap$com$valvesoftware$android$steam$community$FriendInfo$PersonaState[];
                static final int $SwitchMap$com$valvesoftware$android$steam$community$FriendInfo$PersonaStateCategoryInList[];

                static 
                {
                    $SwitchMap$com$valvesoftware$android$steam$community$FriendInfo$PersonaStateCategoryInList = new int[PersonaStateCategoryInList.values().length];
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$FriendInfo$PersonaStateCategoryInList[PersonaStateCategoryInList.REQUEST_INCOMING.ordinal()] = 1;
                    }
                    catch (NoSuchFieldError nosuchfielderror) { }
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$FriendInfo$PersonaStateCategoryInList[PersonaStateCategoryInList.CHATS.ordinal()] = 2;
                    }
                    catch (NoSuchFieldError nosuchfielderror1) { }
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$FriendInfo$PersonaStateCategoryInList[PersonaStateCategoryInList.INGAME.ordinal()] = 3;
                    }
                    catch (NoSuchFieldError nosuchfielderror2) { }
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$FriendInfo$PersonaStateCategoryInList[PersonaStateCategoryInList.ONLINE.ordinal()] = 4;
                    }
                    catch (NoSuchFieldError nosuchfielderror3) { }
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$FriendInfo$PersonaStateCategoryInList[PersonaStateCategoryInList.REQUEST_SENT.ordinal()] = 5;
                    }
                    catch (NoSuchFieldError nosuchfielderror4) { }
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$FriendInfo$PersonaStateCategoryInList[PersonaStateCategoryInList.OFFLINE.ordinal()] = 6;
                    }
                    catch (NoSuchFieldError nosuchfielderror5) { }
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$FriendInfo$PersonaStateCategoryInList[PersonaStateCategoryInList.SEARCH_ALL.ordinal()] = 7;
                    }
                    catch (NoSuchFieldError nosuchfielderror6) { }
                    $SwitchMap$com$valvesoftware$android$steam$community$FriendInfo$PersonaState = new int[PersonaState.values().length];
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$FriendInfo$PersonaState[PersonaState.OFFLINE.ordinal()] = 1;
                    }
                    catch (NoSuchFieldError nosuchfielderror7) { }
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$FriendInfo$PersonaState[PersonaState.ONLINE.ordinal()] = 2;
                    }
                    catch (NoSuchFieldError nosuchfielderror8) { }
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$FriendInfo$PersonaState[PersonaState.BUSY.ordinal()] = 3;
                    }
                    catch (NoSuchFieldError nosuchfielderror9) { }
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$FriendInfo$PersonaState[PersonaState.AWAY.ordinal()] = 4;
                    }
                    catch (NoSuchFieldError nosuchfielderror10) { }
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$FriendInfo$PersonaState[PersonaState.SNOOZE.ordinal()] = 5;
                    }
                    catch (NoSuchFieldError nosuchfielderror11)
                    {
                        return;
                    }
                }
            }

            switch (_cls1..SwitchMap.com.valvesoftware.android.steam.community.FriendInfo.PersonaState[ordinal()])
            {
            default:
                return 0x7f070027;

            case 1: // '\001'
                return 0x7f070021;

            case 2: // '\002'
                return 0x7f070020;

            case 3: // '\003'
                return 0x7f070024;

            case 4: // '\004'
                return 0x7f070025;

            case 5: // '\005'
                return 0x7f070026;
            }
        }

        static 
        {
            OFFLINE = new PersonaState("OFFLINE", 0);
            ONLINE = new PersonaState("ONLINE", 1);
            BUSY = new PersonaState("BUSY", 2);
            AWAY = new PersonaState("AWAY", 3);
            SNOOZE = new PersonaState("SNOOZE", 4);
            PersonaState apersonastate[] = new PersonaState[5];
            apersonastate[0] = OFFLINE;
            apersonastate[1] = ONLINE;
            apersonastate[2] = BUSY;
            apersonastate[3] = AWAY;
            apersonastate[4] = SNOOZE;
            $VALUES = apersonastate;
        }

        private PersonaState(String s, int i)
        {
            super(s, i);
        }
    }

    public static final class PersonaStateCategoryInList extends Enum
    {

        private static final PersonaStateCategoryInList $VALUES[];
        public static final PersonaStateCategoryInList CHATS;
        public static final PersonaStateCategoryInList INGAME;
        public static final PersonaStateCategoryInList OFFLINE;
        public static final PersonaStateCategoryInList ONLINE;
        public static final PersonaStateCategoryInList REQUEST_INCOMING;
        public static final PersonaStateCategoryInList REQUEST_SENT;
        public static final PersonaStateCategoryInList SEARCH_ALL;

        public static PersonaStateCategoryInList valueOf(String s)
        {
            return (PersonaStateCategoryInList)Enum.valueOf(com/valvesoftware/android/steam/community/FriendInfo$PersonaStateCategoryInList, s);
        }

        public static PersonaStateCategoryInList[] values()
        {
            return (PersonaStateCategoryInList[])$VALUES.clone();
        }

        public int GetDisplayString()
        {
            switch (_cls1..SwitchMap.com.valvesoftware.android.steam.community.FriendInfo.PersonaStateCategoryInList[ordinal()])
            {
            default:
                return 0x7f070027;

            case 1: // '\001'
                return 0x7f07005e;

            case 2: // '\002'
                return 0x7f07005f;

            case 3: // '\003'
                return 0x7f070023;

            case 4: // '\004'
                return 0x7f070020;

            case 5: // '\005'
            case 6: // '\006'
                return 0x7f070021;

            case 7: // '\007'
                return 0x7f070004;
            }
        }

        static 
        {
            REQUEST_INCOMING = new PersonaStateCategoryInList("REQUEST_INCOMING", 0);
            CHATS = new PersonaStateCategoryInList("CHATS", 1);
            INGAME = new PersonaStateCategoryInList("INGAME", 2);
            ONLINE = new PersonaStateCategoryInList("ONLINE", 3);
            OFFLINE = new PersonaStateCategoryInList("OFFLINE", 4);
            REQUEST_SENT = new PersonaStateCategoryInList("REQUEST_SENT", 5);
            SEARCH_ALL = new PersonaStateCategoryInList("SEARCH_ALL", 6);
            PersonaStateCategoryInList apersonastatecategoryinlist[] = new PersonaStateCategoryInList[7];
            apersonastatecategoryinlist[0] = REQUEST_INCOMING;
            apersonastatecategoryinlist[1] = CHATS;
            apersonastatecategoryinlist[2] = INGAME;
            apersonastatecategoryinlist[3] = ONLINE;
            apersonastatecategoryinlist[4] = OFFLINE;
            apersonastatecategoryinlist[5] = REQUEST_SENT;
            apersonastatecategoryinlist[6] = SEARCH_ALL;
            $VALUES = apersonastatecategoryinlist;
        }

        private PersonaStateCategoryInList(String s, int i)
        {
            super(s, i);
        }
    }


    public PersonaStateCategoryInList m_categoryInList;
    public ISteamUmqCommunicationDatabase.UserConversationInfo m_chatInfo;
    public int m_currentGameID;
    public String m_currentGameString;
    public String m_lastOnlineString;
    public int m_lastOnlineTime;
    public String m_personaName;
    public PersonaState m_personaState;
    public String m_realName;
    public FriendRelationship m_relationship;

    public FriendInfo()
    {
        m_personaState = PersonaState.OFFLINE;
        m_categoryInList = PersonaStateCategoryInList.OFFLINE;
        m_relationship = FriendRelationship.none;
        m_currentGameString = "";
        m_lastOnlineTime = 0;
        m_lastOnlineString = null;
    }

    public String GetPersonaNameSafe()
    {
        if (HasPresentationData())
        {
            return m_personaName;
        } else
        {
            return "";
        }
    }

    public boolean HasPresentationData()
    {
        return m_personaName != null;
    }

    protected GenericListDB.GenericListItem.RequestForAvatarImage RequestAvatarImage(GenericListDB genericlistdb)
    {
        return GetRequestForAvatarImage("JobQueueAvatarsFriends", m_avatarSmallURL, m_steamID.toString(), genericlistdb);
    }

    public void UpdateLastOnlineTime(int i)
    {
label0:
        {
            int j;
label1:
            {
                if (m_personaState == PersonaState.OFFLINE)
                {
                    if (i == 0 || m_lastOnlineTime == 0)
                    {
                        break label0;
                    }
                    j = i - m_lastOnlineTime;
                    if (j < 10)
                    {
                        j = 10;
                    }
                    if (j >= 60)
                    {
                        break label1;
                    }
                    m_lastOnlineString = SteamCommunityApplication.GetInstance().getResources().getString(0x7f070075).replace("#", String.valueOf(j));
                }
                return;
            }
            int k = 1 + j / 60;
            if (k < 60)
            {
                m_lastOnlineString = SteamCommunityApplication.GetInstance().getResources().getString(0x7f070074).replace("#", String.valueOf(k));
                return;
            }
            int l = 1 + k / 60;
            if (l < 48)
            {
                m_lastOnlineString = SteamCommunityApplication.GetInstance().getResources().getString(0x7f070073).replace("#", String.valueOf(l));
                return;
            }
            int i1 = l / 24;
            if (i1 < 365)
            {
                m_lastOnlineString = SteamCommunityApplication.GetInstance().getResources().getString(0x7f070072).replace("#", String.valueOf(i1));
                return;
            } else
            {
                m_lastOnlineString = SteamCommunityApplication.GetInstance().getResources().getString(0x7f070071);
                return;
            }
        }
        m_lastOnlineString = null;
    }
}
