// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.fragment;

import android.view.View;
import android.view.animation.Animation;

// Referenced classes of package com.valvesoftware.android.steam.community.fragment:
//            NavigationFragment

class this._cls0
    implements android.view.animation.stener
{

    final NavigationFragment this$0;

    public void onAnimationEnd(Animation animation)
    {
        NavigationFragment.access$102(NavigationFragment.this, false);
        if (!NavigationFragment.access$200(NavigationFragment.this))
        {
            NavigationFragment.access$500(NavigationFragment.this).setVisibility(8);
        } else
        if (NavigationFragment.access$600(NavigationFragment.this))
        {
            NavigationFragment.access$602(NavigationFragment.this, false);
            onNavActivationButtonClicked();
            return;
        }
    }

    public void onAnimationRepeat(Animation animation)
    {
    }

    public void onAnimationStart(Animation animation)
    {
    }

    ()
    {
        this$0 = NavigationFragment.this;
        super();
    }
}
