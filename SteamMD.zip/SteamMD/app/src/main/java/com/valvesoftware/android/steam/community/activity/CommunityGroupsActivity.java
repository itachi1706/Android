// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.activity;

import android.os.Bundle;
import com.valvesoftware.android.steam.community.SteamWebApi;

// Referenced classes of package com.valvesoftware.android.steam.community.activity:
//            FragmentActivityWithNavigationSupport

public class CommunityGroupsActivity extends FragmentActivityWithNavigationSupport
{

    public CommunityGroupsActivity()
    {
    }

    public void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        setContentView(0x7f030008);
    }

    protected void onDestroy()
    {
        super.onDestroy();
    }

    protected void onResume()
    {
        SteamWebApi.SubmitSimpleActionRequest("UmqActivity", new com.valvesoftware.android.steam.community.SteamDBService.REQ_ACT_UMQACTIVITY_DATA());
        super.onResume();
    }
}
