// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;


// Referenced classes of package com.valvesoftware.android.steam.community:
//            SteamUmqCommunicationService

public static class e
{

    public e m_eCommand;
    public int m_nMessage;
    public int m_nTimeout;
    public e m_request;
    public String m_sMySteamID;
    public String m_sOAuthToken;

    public e()
    {
    }
}
