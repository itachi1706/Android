// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;

import android.app.PendingIntent;
import com.valvesoftware.android.steam.community.activity.CommunityActivity;
import com.valvesoftware.android.steam.community.activity.CommunityGroupsActivity;
import com.valvesoftware.android.steam.community.activity.SettingsActivity;

// Referenced classes of package com.valvesoftware.android.steam.community:
//            SteamCommunityApplication, Config

public static class Y
{

    public static final String NOTIFICATION_TAG = "URINOTIFICATION";
    public int actionDrawable;
    public PendingIntent actionPendingIntent;
    public String actionString;
    public int id;
    public String text;
    public String title;

    public boolean setActionInfo(String s)
    {
        if (s == null || s.equals(""))
        {
            return false;
        }
        actionString = s;
        String as[] = s.split(":");
        if (as.length < 1)
        {
            return false;
        }
        if (as[0].equals("CF"))
        {
            actionDrawable = 0x7f020018;
            actionPendingIntent = SteamCommunityApplication.GetInstance().GetIntentForActivityClass(com/valvesoftware/android/steam/community/activity/CommunityActivity);
            return true;
        }
        if (as[0].equals("CG"))
        {
            actionDrawable = 0x7f020019;
            actionPendingIntent = SteamCommunityApplication.GetInstance().GetIntentForActivityClass(com/valvesoftware/android/steam/community/activity/CommunityGroupsActivity);
            return true;
        }
        if (as[0].equals("SS"))
        {
            actionDrawable = 0x7f02001b;
            actionPendingIntent = SteamCommunityApplication.GetInstance().GetIntentForActivityClass(com/valvesoftware/android/steam/community/activity/SettingsActivity);
            return true;
        }
        if (as[0].equals("M") && as.length >= 2 && as[1].length() > 0)
        {
            actionDrawable = 0x7f020023;
            actionPendingIntent = SteamCommunityApplication.GetInstance().GetIntentToChatWithSteamID(as[1]);
            return true;
        }
        if (as[0].length() > 0 && as[0].startsWith("U") && as.length >= 3 && as[1].length() > 0 && as[2].length() > 0)
        {
            actionDrawable = 0x7f02001c;
            boolean flag;
            boolean flag1;
            SteamCommunityApplication steamcommunityapplication;
            StringBuilder stringbuilder;
            String s1;
            StringBuilder stringbuilder1;
            String s2;
            if (as[1].equals("CF"))
            {
                actionDrawable = 0x7f020018;
            } else
            if (as[1].equals("CG"))
            {
                actionDrawable = 0x7f020019;
            } else
            if (as[1].equals("SS"))
            {
                actionDrawable = 0x7f02001b;
            } else
            if (as[1].equals("SC"))
            {
                actionDrawable = 0x7f02001c;
            } else
            if (as[1].equals("SW"))
            {
                actionDrawable = 0x7f02001d;
            } else
            if (as[1].equals("ST"))
            {
                actionDrawable = 0x7f020015;
            } else
            if (as[1].equals("SF"))
            {
                actionDrawable = 0x7f02001a;
            } else
            if (as[1].equals("FF"))
            {
                actionDrawable = 0x7f020017;
            } else
            if (as[1].equals("MM"))
            {
                actionDrawable = 0x7f020023;
            }
            if (as[0].indexOf("C", 1) > 0)
            {
                flag = true;
            } else
            {
                flag = false;
            }
            if (as[0].indexOf("S", 1) > 0)
            {
                flag1 = true;
            } else
            {
                flag1 = false;
            }
            steamcommunityapplication = SteamCommunityApplication.GetInstance();
            stringbuilder = (new StringBuilder()).append("steammobile://");
            if (flag)
            {
                s1 = actionDrawable.actionDrawable();
            } else
            {
                s1 = actionDrawable.actionDrawable();
            }
            stringbuilder1 = stringbuilder.append(s1).append("?").append(actionDrawable.actionDrawable()).append("=");
            if (flag1)
            {
                if (flag)
                {
                    s2 = Config.URL_STORE_BASE_INSECURE;
                } else
                {
                    s2 = Config.URL_STORE_BASE;
                }
            } else
            if (flag)
            {
                s2 = Config.URL_COMMUNITY_BASE_INSECURE;
            } else
            {
                s2 = Config.URL_COMMUNITY_BASE;
            }
            actionPendingIntent = steamcommunityapplication.GetIntentForUriString(stringbuilder1.append(s2).append("/").append(as[2]).toString());
            return true;
        } else
        {
            return false;
        }
    }

    public void setDefaultActionInfo()
    {
        actionString = "";
        actionDrawable = 0x7f020028;
        actionPendingIntent = SteamCommunityApplication.GetInstance().GetIntentForActivityClass(com/valvesoftware/android/steam/community/activity/CommunityActivity);
    }

    public Y()
    {
    }
}
