// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;


// Referenced classes of package com.valvesoftware.android.steam.community:
//            SettingInfo

public static final class  extends Enum
{

    private static final .VALUES $VALUES[];
    public static final .VALUES CODE;
    public static final .VALUES NONE;
    public static final .VALUES USER;
    public static final .VALUES VALID_ACCOUNT;

    public static  valueOf(String s)
    {
        return ()Enum.valueOf(com/valvesoftware/android/steam/community/SettingInfo$AccessRight, s);
    }

    public static [] values()
    {
        return ([])$VALUES.clone();
    }

    static 
    {
        NONE = new <init>("NONE", 0);
        VALID_ACCOUNT = new <init>("VALID_ACCOUNT", 1);
        USER = new <init>("USER", 2);
        CODE = new <init>("CODE", 3);
        t_3B_.clone aclone[] = new <init>[4];
        aclone[0] = NONE;
        aclone[1] = VALID_ACCOUNT;
        aclone[2] = USER;
        aclone[3] = CODE;
        $VALUES = aclone;
    }

    private (String s, int i)
    {
        super(s, i);
    }
}
