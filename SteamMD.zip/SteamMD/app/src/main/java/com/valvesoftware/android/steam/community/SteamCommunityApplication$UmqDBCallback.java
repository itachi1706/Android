// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

// Referenced classes of package com.valvesoftware.android.steam.community:
//            SteamCommunityApplication, FriendInfoDB, GroupInfoDB

private class <init> extends BroadcastReceiver
{

    final SteamCommunityApplication this$0;

    public void onReceive(Context context, Intent intent)
    {
        String s = intent.getStringExtra("type");
        if (!s.equalsIgnoreCase("chatmsg")) goto _L2; else goto _L1
_L1:
        String s1 = intent.getStringExtra("action");
        if (!"incoming".equals(s1)) goto _L4; else goto _L3
_L3:
        int j = intent.getIntExtra("msgidLast", -1);
        if (j > 0)
        {
            GetFriendInfoDB().ChatsWithUserUpdate(intent.getStringExtra("steamid"), j, g, intent.getIntExtra("incoming", 0) + intent.getIntExtra("my_incoming", 0));
        }
_L6:
        return;
_L4:
        if ("read".equals(s1))
        {
            GetFriendInfoDB().ChatsWithUserUpdate(intent.getStringExtra("steamid"), -1, B, 0);
            return;
        }
        if ("clear".equals(s1))
        {
            GetFriendInfoDB().ChatsWithUserUpdate(intent.getStringExtra("steamid"), -1, B, 0);
            return;
        }
        if ("send".equals(s1))
        {
            int i = intent.getIntExtra("msgid", -1);
            if (i > 0)
            {
                GetFriendInfoDB().ChatsWithUserUpdate(intent.getStringExtra("steamid"), i, B, 1);
                return;
            }
        }
        continue; /* Loop/switch isn't completed */
_L2:
        if (s.equalsIgnoreCase("personastate"))
        {
            GetFriendInfoDB().onReceive(context, intent);
            return;
        }
        if (s.equalsIgnoreCase("personarelationship"))
        {
            GetFriendInfoDB().onReceive(context, intent);
            GetGroupInfoDB().onReceive(context, intent);
            return;
        }
        if (s.equalsIgnoreCase("umqstate"))
        {
            GetFriendInfoDB().onReceive(context, intent);
            GetGroupInfoDB().onReceive(context, intent);
            return;
        }
        if (true) goto _L6; else goto _L5
_L5:
    }

    private ()
    {
        this$0 = SteamCommunityApplication.this;
        super();
    }

    this._cls0(this._cls0 _pcls0)
    {
        this();
    }
}
