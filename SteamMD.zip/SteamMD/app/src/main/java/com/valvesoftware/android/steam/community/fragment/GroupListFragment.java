// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.fragment;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import com.valvesoftware.android.steam.community.AndroidUtils;
import com.valvesoftware.android.steam.community.Config;
import com.valvesoftware.android.steam.community.GenericListDB;
import com.valvesoftware.android.steam.community.GroupInfo;
import com.valvesoftware.android.steam.community.GroupInfoDB;
import com.valvesoftware.android.steam.community.SteamCommunityApplication;
import com.valvesoftware.android.steam.community.SteamWebApi;
import com.valvesoftware.android.steam.community.activity.ActivityHelper;
import com.valvesoftware.android.steam.community.activity.SearchGroupsActivity;
import com.valvesoftware.android.steam.community.activity.SteamMobileUriActivity;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;

// Referenced classes of package com.valvesoftware.android.steam.community.fragment:
//            BasePresentationListFragmentWithSearch, BaseFragmentWithLogin, TitlebarFragment

public class GroupListFragment extends BasePresentationListFragmentWithSearch
{
    private class GroupsListAdapter extends BasePresentationListFragment.HelperDbListAdapter
    {

        final GroupListFragment this$0;

        public View getView(int i, View view, ViewGroup viewgroup)
        {
            View view1;
            TextView textview2;
            TextView textview3;
            ImageView imageview;
            ImageView imageview1;
label0:
            {
                view1 = view;
                SteamCommunityApplication steamcommunityapplication = SteamCommunityApplication.GetInstance();
                if (view1 == null)
                {
                    view1 = ((LayoutInflater)steamcommunityapplication.getSystemService("layout_inflater")).inflate(0x7f03000b, null);
                    view1.setClickable(true);
                    view1.setOnClickListener(groupListClickListener);
                }
                GroupInfo groupinfo = (GroupInfo)m_presentationArray.get(i);
                if (groupinfo != null)
                {
                    if (!groupinfo.IsAvatarSmallLoaded())
                    {
                        RequestVisibleAvatars();
                    }
                    TextView textview = (TextView)view1.findViewById(0x7f09000d);
                    TextView textview1 = (TextView)view1.findViewById(0x7f090013);
                    textview2 = (TextView)view1.findViewById(0x7f090020);
                    textview3 = (TextView)view1.findViewById(0x7f090021);
                    imageview = (ImageView)view1.findViewById(0x7f09000e);
                    imageview1 = (ImageView)view1.findViewById(0x7f090012);
                    TextView textview4 = (TextView)view1.findViewById(0x7f090018);
                    if (i == 0 || groupinfo.m_categoryInList != ((GroupInfo)m_presentationArray.get(i - 1)).m_categoryInList)
                    {
                        textview.setText(groupinfo.m_categoryInList.GetDisplayString());
                        textview.setVisibility(0);
                    } else
                    {
                        textview.setVisibility(8);
                    }
                    textview.setOnClickListener(dummyClickListener);
                    textview4.setText(Long.toString(groupinfo.m_steamID.longValue()));
                    AndroidUtils.setTextViewText(textview1, groupinfo.m_groupName);
                    if (groupinfo == GetSearchItem())
                    {
                        break label0;
                    }
                    imageview.setImageBitmap(groupinfo.GetAvatarSmall());
                    imageview1.setVisibility(0);
                    textview2.setText((new StringBuilder()).append(Integer.toString(groupinfo.m_numMembersTotal)).append(" ").append(steamcommunityapplication.getResources().getString(0x7f07006f)).toString());
                    textview3.setText((new StringBuilder()).append(Integer.toString(groupinfo.m_numMembersOnline)).append(" ").append(steamcommunityapplication.getResources().getString(0x7f070070)).toString());
                }
                return view1;
            }
            imageview.setImageResource(0x7f020010);
            imageview1.setVisibility(8);
            AndroidUtils.setTextViewText(textview2, getSearchModeText());
            textview3.setText("");
            return view1;
        }

        public GroupsListAdapter()
        {
            this$0 = GroupListFragment.this;
            super(GroupListFragment.this, 0x7f03000b);
        }
    }


    private android.view.View.OnClickListener dummyClickListener;
    private android.view.View.OnClickListener groupListClickListener;
    private BaseFragmentWithLogin m_login;
    private TitlebarFragment.TitlebarButtonHander m_refreshHandler;
    private Comparator m_sorter;

    public GroupListFragment()
    {
        m_login = new BaseFragmentWithLogin(this);
        m_refreshHandler = new TitlebarFragment.TitlebarButtonHander() {

            final GroupListFragment this$0;

            public void onTitlebarButtonClicked(int i)
            {
                if (!SteamWebApi.IsLoggedIn())
                {
                    return;
                } else
                {
                    myListDb().RefreshFromHttpOnly();
                    return;
                }
            }

            
            {
                this$0 = GroupListFragment.this;
                super();
            }
        };
        groupListClickListener = new android.view.View.OnClickListener() {

            final GroupListFragment this$0;

            public void onClick(View view)
            {
                TextView textview = (TextView)view.findViewById(0x7f090018);
                String s = "0";
                if (textview != null)
                {
                    s = textview.getText().toString();
                }
                if (s.equals("0"))
                {
                    Intent intent1 = (new Intent()).setClass(getActivity(), com/valvesoftware/android/steam/community/activity/SearchGroupsActivity).addFlags(0x20000000).addFlags(0x10000000).setData(Uri.parse((new StringBuilder()).append("searchgroup://").append(System.currentTimeMillis()).append(getSearchModeText()).toString())).putExtra("query", getSearchModeText());
                    getActivity().startActivity(intent1);
                } else
                {
                    GroupInfo groupinfo = ((GroupInfoDB)myListDb()).GetGroupInfo(Long.valueOf(s));
                    if (groupinfo != null)
                    {
                        Intent intent = (new Intent()).addFlags(0x18000000).setClass(getActivity(), com/valvesoftware/android/steam/community/activity/SteamMobileUriActivity).setData(Uri.parse((new StringBuilder()).append("steammobile://").append(com.valvesoftware.android.steam.community.SteamUriHandler.Command.openurl).append("?url=").append(Config.URL_COMMUNITY_BASE).append(groupinfo.m_profileURL).toString())).setAction("android.intent.action.VIEW");
                        getActivity().startActivity(intent);
                        return;
                    }
                }
            }

            
            {
                this$0 = GroupListFragment.this;
                super();
            }
        };
        dummyClickListener = new android.view.View.OnClickListener() {

            final GroupListFragment this$0;

            public void onClick(View view)
            {
            }

            
            {
                this$0 = GroupListFragment.this;
                super();
            }
        };
        m_sorter = new Comparator() {

            final GroupListFragment this$0;

            public int compare(GroupInfo groupinfo, GroupInfo groupinfo1)
            {
                if (groupinfo.m_categoryInList != groupinfo1.m_categoryInList)
                {
                    return groupinfo.m_categoryInList.ordinal() >= groupinfo1.m_categoryInList.ordinal() ? 1 : -1;
                } else
                {
                    return groupinfo.m_groupName.compareToIgnoreCase(groupinfo1.m_groupName);
                }
            }

            public volatile int compare(Object obj, Object obj1)
            {
                return compare((GroupInfo)obj, (GroupInfo)obj1);
            }

            
            {
                this$0 = GroupListFragment.this;
                super();
            }
        };
    }

    protected void UpdateGlobalInformationPreSort()
    {
        super.UpdateGlobalInformationPreSort();
        m_login.UpdateGlobalInformationPreSort();
    }

    protected void activateSearch(boolean flag)
    {
        super.activateSearch(flag);
        TitlebarFragment titlebarfragment = ActivityHelper.GetTitlebarFragmentForActivity(getActivity());
        if (titlebarfragment != null)
        {
            TitlebarFragment.TitlebarButtonHander titlebarbuttonhander;
            if (flag)
            {
                titlebarbuttonhander = null;
            } else
            {
                titlebarbuttonhander = m_refreshHandler;
            }
            titlebarfragment.setRefreshHandler(titlebarbuttonhander);
        }
    }

    protected void myCbckProcessPresentationArray()
    {
        for (Iterator iterator = m_presentationArray.iterator(); iterator.hasNext();)
        {
            GroupInfo groupinfo = (GroupInfo)iterator.next();
            if (groupinfo.m_relationship == com.valvesoftware.android.steam.community.GroupInfo.GroupRelationship.Invited)
            {
                groupinfo.m_categoryInList = com.valvesoftware.android.steam.community.GroupInfo.GroupCategoryInList.REQUEST_INVITE;
            } else
            if (groupinfo.m_groupType == com.valvesoftware.android.steam.community.GroupInfo.GroupType.OFFICIAL)
            {
                groupinfo.m_categoryInList = com.valvesoftware.android.steam.community.GroupInfo.GroupCategoryInList.OFFICIAL;
            } else
            if (groupinfo.m_groupType == com.valvesoftware.android.steam.community.GroupInfo.GroupType.PRIVATE)
            {
                groupinfo.m_categoryInList = com.valvesoftware.android.steam.community.GroupInfo.GroupCategoryInList.PRIVATE;
            } else
            {
                groupinfo.m_categoryInList = com.valvesoftware.android.steam.community.GroupInfo.GroupCategoryInList.PUBLIC;
            }
        }

        super.myCbckProcessPresentationArray();
        Collections.sort(m_presentationArray, m_sorter);
    }

    protected volatile boolean myCbckShouldDisplayItemInList(com.valvesoftware.android.steam.community.GenericListDB.GenericListItem genericlistitem)
    {
        return myCbckShouldDisplayItemInList((GroupInfo)genericlistitem);
    }

    protected boolean myCbckShouldDisplayItemInList(GroupInfo groupinfo)
    {
        return groupinfo.HasPresentationData() && ApplySearchFilterBeforeDisplay(groupinfo.m_groupName);
    }

    protected BasePresentationListFragment.HelperDbListAdapter myCreateListAdapter()
    {
        return new GroupsListAdapter();
    }

    protected volatile com.valvesoftware.android.steam.community.GenericListDB.GenericListItem myDbItemCreateSearchItem()
    {
        return myDbItemCreateSearchItem();
    }

    protected GroupInfo myDbItemCreateSearchItem()
    {
        GroupInfo groupinfo = new GroupInfo();
        groupinfo.m_steamID = new Long(0L);
        groupinfo.m_groupType = com.valvesoftware.android.steam.community.GroupInfo.GroupType.DISABLED;
        groupinfo.m_categoryInList = com.valvesoftware.android.steam.community.GroupInfo.GroupCategoryInList.SEARCH_ALL;
        groupinfo.m_relationship = com.valvesoftware.android.steam.community.GroupInfo.GroupRelationship.Member;
        groupinfo.m_groupName = SteamCommunityApplication.GetInstance().getResources().getString(0x7f070077);
        return groupinfo;
    }

    protected GenericListDB myListDb()
    {
        return SteamCommunityApplication.GetInstance().GetGroupInfoDB();
    }

    public void onActivityCreated(Bundle bundle)
    {
        super.onActivityCreated(bundle);
        m_login.onActivityCreated(bundle);
        TitlebarFragment titlebarfragment = ActivityHelper.GetTitlebarFragmentForActivity(getActivity());
        if (titlebarfragment != null)
        {
            titlebarfragment.setTitleLabel(0x7f070029);
            titlebarfragment.setRefreshHandler(m_refreshHandler);
        }
    }

    public void onResume()
    {
        super.onResume();
        m_login.onResume();
    }


}
