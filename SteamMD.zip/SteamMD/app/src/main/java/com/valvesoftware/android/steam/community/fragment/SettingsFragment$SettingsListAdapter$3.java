// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.fragment;

import android.app.Activity;
import android.widget.CompoundButton;
import com.valvesoftware.android.steam.community.SettingInfo;

// Referenced classes of package com.valvesoftware.android.steam.community.fragment:
//            SettingsFragment

class val.settingInfo
    implements android.widget.tingsFragment.SettingsListAdapter._cls3
{

    final is._cls0 this$1;
    final SettingInfo val$settingInfo;

    public void onCheckedChanged(CompoundButton compoundbutton, boolean flag)
    {
        SettingInfo settinginfo = val$settingInfo;
        android.content.Context context = SettingsFragment.access$400(_fld0).getApplicationContext();
        String s;
        if (flag)
        {
            s = "1";
        } else
        {
            s = "";
        }
        settinginfo.setValueAndCommit(context, s);
    }

    ()
    {
        this$1 = final_;
        val$settingInfo = SettingInfo.this;
        super();
    }
}
