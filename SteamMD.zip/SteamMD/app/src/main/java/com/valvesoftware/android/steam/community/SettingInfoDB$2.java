// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;


// Referenced classes of package com.valvesoftware.android.steam.community:
//            SettingInfoDB, SteamWebApi, SettingInfo

class this._cls0
    implements teListener
{

    final SettingInfoDB this$0;

    public void OnSettingInfoValueUpdate(SettingInfo settinginfo, String s, saction saction)
    {
        EQ_ACT_SETTINGCHANGE_DATA eq_act_settingchange_data = new EQ_ACT_SETTINGCHANGE_DATA();
        eq_act_settingchange_data.sSteamID = SteamWebApi.GetLoginSteamID();
        eq_act_settingchange_data.sSettingKey = "notifications_ongoing";
        eq_act_settingchange_data.sNewValue = s;
        SteamWebApi.SubmitSimpleActionRequest("SettingChange", eq_act_settingchange_data);
    }

    saction()
    {
        this$0 = SettingInfoDB.this;
        super();
    }
}
