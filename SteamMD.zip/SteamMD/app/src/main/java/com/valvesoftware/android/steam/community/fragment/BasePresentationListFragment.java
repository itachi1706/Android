// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.fragment;

import android.os.Bundle;
import android.support.v4.app.ListFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import com.valvesoftware.android.steam.community.GenericListDB;
import com.valvesoftware.android.steam.community.SettingInfo;
import com.valvesoftware.android.steam.community.SettingInfoDB;
import com.valvesoftware.android.steam.community.SteamCommunityApplication;
import com.valvesoftware.android.steam.community.SteamDBService;
import com.valvesoftware.android.steam.community.activity.ActivityHelper;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Iterator;
import java.util.concurrent.ConcurrentHashMap;

// Referenced classes of package com.valvesoftware.android.steam.community.fragment:
//            TitlebarFragment

public abstract class BasePresentationListFragment extends ListFragment
{
    protected class HelperDbListAdapter extends ArrayAdapter
    {

        final BasePresentationListFragment this$0;

        public void RequestVisibleAvatars()
        {
            RequestVisibleAvatars(false);
        }

        public void RequestVisibleAvatars(boolean flag)
        {
            if (getListAdapter() != this)
            {
                return;
            }
            int i = getListView().getFirstVisiblePosition();
            int j = getListView().getLastVisiblePosition();
            com.valvesoftware.android.steam.community.GenericListDB.GenericListItem agenericlistitem[] = null;
            if (j >= i)
            {
                agenericlistitem = null;
                if (i >= 0)
                {
                    int k = 1 + (j - i);
                    agenericlistitem = new com.valvesoftware.android.steam.community.GenericListDB.GenericListItem[k];
                    for (int l = 0; l < k; l++)
                    {
                        if (m_presentationArray.size() > i + l)
                        {
                            agenericlistitem[l] = (com.valvesoftware.android.steam.community.GenericListDB.GenericListItem)m_presentationArray.get(i + l);
                        }
                        if (agenericlistitem[l] == null || agenericlistitem[l].IsAvatarSmallLoaded())
                        {
                            agenericlistitem[l] = null;
                        }
                    }

                }
            }
            myListDb().RequestAvatarImage(agenericlistitem);
        }

        public void notifyDataSetChanged()
        {
            super.notifyDataSetChanged();
            RequestVisibleAvatars(true);
        }

        public HelperDbListAdapter(int i)
        {
            this$0 = BasePresentationListFragment.this;
            super(getActivity(), i, m_presentationArray);
        }
    }

    protected class ListDbListener
        implements com.valvesoftware.android.steam.community.GenericListDB.ListItemUpdatedListener
    {

        protected HelperDbListAdapter m_adapter;
        final BasePresentationListFragment this$0;

        public void OnListItemInfoUpdateError(com.valvesoftware.android.steam.community.SteamWebApi.RequestBase requestbase)
        {
        }

        public void OnListItemInfoUpdated(ArrayList arraylist, boolean flag)
        {
            if (flag)
            {
                UpdateGlobalInformationPreSort();
                m_presentationArray.clear();
                Iterator iterator = myListDb().GetItemsMap().values().iterator();
                do
                {
                    if (!iterator.hasNext())
                    {
                        break;
                    }
                    com.valvesoftware.android.steam.community.GenericListDB.GenericListItem genericlistitem = (com.valvesoftware.android.steam.community.GenericListDB.GenericListItem)iterator.next();
                    if (myCbckShouldDisplayItemInList(genericlistitem))
                    {
                        m_presentationArray.add(genericlistitem);
                    }
                } while (true);
                myCbckProcessPresentationArray();
            }
            m_adapter.notifyDataSetChanged();
        }

        public void OnListRefreshError(com.valvesoftware.android.steam.community.SteamWebApi.RequestBase requestbase, boolean flag)
        {
            myCbckOnListRefreshError(requestbase);
        }

        public void OnListRequestsInProgress(boolean flag)
        {
            TitlebarFragment titlebarfragment = ActivityHelper.GetTitlebarFragmentForActivity(getActivity());
            if (titlebarfragment != null)
            {
                titlebarfragment.setRefreshInProgress(flag);
            }
        }

        protected ListDbListener()
        {
            this$0 = BasePresentationListFragment.this;
            super();
            m_adapter = null;
        }
    }


    protected Calendar m_calRecentChatsThreshold;
    protected ListDbListener m_listDbListener;
    protected ListView m_listView;
    protected ArrayList m_presentationArray;
    protected int m_umqCurrentServerTime;

    public BasePresentationListFragment()
    {
        m_presentationArray = new ArrayList();
        m_listView = null;
        m_calRecentChatsThreshold = Calendar.getInstance();
        m_umqCurrentServerTime = 0;
        m_listDbListener = new ListDbListener();
    }

    protected void UpdateGlobalInformationPreSort()
    {
        m_calRecentChatsThreshold = Calendar.getInstance();
        int i = SteamCommunityApplication.GetInstance().GetSettingInfoDB().m_settingChatsRecent.getRadioSelectorItemValue(SteamCommunityApplication.GetInstance().getApplicationContext()).value;
        m_calRecentChatsThreshold.setTimeInMillis(m_calRecentChatsThreshold.getTimeInMillis() - 1000L * (long)i);
        SteamDBService steamdbservice = SteamCommunityApplication.GetInstance().GetSteamDB();
        m_umqCurrentServerTime = 0;
        if (steamdbservice != null)
        {
            m_umqCurrentServerTime = steamdbservice.getSteamUmqCurrentServerTime();
        }
    }

    protected void myCbckOnListRefreshError(com.valvesoftware.android.steam.community.SteamWebApi.RequestBase requestbase)
    {
    }

    protected abstract void myCbckProcessPresentationArray();

    protected abstract boolean myCbckShouldDisplayItemInList(com.valvesoftware.android.steam.community.GenericListDB.GenericListItem genericlistitem);

    protected abstract HelperDbListAdapter myCreateListAdapter();

    protected abstract GenericListDB myListDb();

    public void onActivityCreated(Bundle bundle)
    {
        super.onActivityCreated(bundle);
        m_listDbListener.m_adapter = myCreateListAdapter();
        refreshListView();
        if (m_listView == null)
        {
            m_listView = getListView();
            m_listView.setTextFilterEnabled(false);
        }
        setListAdapter(m_listDbListener.m_adapter);
        m_listDbListener.m_adapter.RequestVisibleAvatars();
        myListDb().RegisterCallback(m_listDbListener);
    }

    public View onCreateView(LayoutInflater layoutinflater, ViewGroup viewgroup, Bundle bundle)
    {
        return layoutinflater.inflate(0x7f03000a, viewgroup, false);
    }

    public void onDestroy()
    {
        super.onDestroy();
        myListDb().DeregisterCallback(m_listDbListener);
    }

    public void onPause()
    {
        super.onPause();
        myListDb().SetAutoRefreshIfDataMightBeStale(false);
    }

    public void onResume()
    {
        super.onResume();
        myListDb().SetAutoRefreshIfDataMightBeStale(true);
    }

    protected void refreshListView()
    {
        m_listDbListener.OnListItemInfoUpdated(null, true);
    }
}
