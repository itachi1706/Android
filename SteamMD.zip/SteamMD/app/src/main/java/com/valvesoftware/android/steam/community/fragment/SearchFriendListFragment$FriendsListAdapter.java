// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.fragment;

import android.content.Context;
import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import com.valvesoftware.android.steam.community.AndroidUtils;
import com.valvesoftware.android.steam.community.FriendInfo;
import com.valvesoftware.android.steam.community.SteamCommunityApplication;
import java.util.ArrayList;

// Referenced classes of package com.valvesoftware.android.steam.community.fragment:
//            SearchFriendListFragment

private class pter extends pter
{

    final SearchFriendListFragment this$0;

    public View getView(int i, View view, ViewGroup viewgroup)
    {
        View view1;
        SteamCommunityApplication steamcommunityapplication;
        FriendInfo friendinfo;
        TextView textview;
        TextView textview1;
        ImageView imageview1;
label0:
        {
            view1 = view;
            steamcommunityapplication = SteamCommunityApplication.GetInstance();
            if (view1 == null)
            {
                view1 = ((LayoutInflater)steamcommunityapplication.getSystemService("layout_inflater")).inflate(0x7f030009, null);
                view1.setClickable(true);
                view1.setOnClickListener(SearchFriendListFragment.access$100(SearchFriendListFragment.this));
            }
            friendinfo = (FriendInfo)m_presentationArray.get(i);
            if (friendinfo != null)
            {
                if (!friendinfo.IsAvatarSmallLoaded())
                {
                    RequestVisibleAvatars();
                }
                ((TextView)view1.findViewById(0x7f09000d)).setVisibility(8);
                textview = (TextView)view1.findViewById(0x7f090013);
                textview1 = (TextView)view1.findViewById(0x7f090014);
                ImageView imageview = (ImageView)view1.findViewById(0x7f09000e);
                imageview1 = (ImageView)view1.findViewById(0x7f090012);
                TextView textview2 = (TextView)view1.findViewById(0x7f090018);
                ((ImageView)view1.findViewById(0x7f090017)).setVisibility(0);
                ((Button)view1.findViewById(0x7f090016)).setVisibility(8);
                textview2.setText(Long.toString(friendinfo.m_steamID.longValue()));
                AndroidUtils.setTextViewText(textview, friendinfo.m_personaName);
                imageview.setImageBitmap(friendinfo.GetAvatarSmall());
                imageview1.setVisibility(0);
                String s;
                if (friendinfo.m_personaState == com.valvesoftware.android.steam.community.tAdapter.RequestVisibleAvatars && friendinfo.m_lastOnlineString != null)
                {
                    textview1.setText(friendinfo.m_lastOnlineString);
                } else
                {
                    textview1.setText(friendinfo.m_personaState.RequestVisibleAvatars());
                }
                if (friendinfo.m_currentGameString.length() <= 0)
                {
                    break label0;
                }
                imageview1.setImageResource(0x7f020000);
                textview.setTextColor(steamcommunityapplication.getResources().getColor(0x7f060013));
                textview1.setTextColor(steamcommunityapplication.getResources().getColor(0x7f060013));
                s = steamcommunityapplication.getResources().getString(0x7f070028);
                textview1.setText((new StringBuilder()).append(s).append(" ").append(friendinfo.m_currentGameString).toString());
            }
            return view1;
        }
        if (friendinfo.m_personaState == com.valvesoftware.android.steam.community.tAdapter.RequestVisibleAvatars)
        {
            imageview1.setImageResource(0x7f020001);
            textview.setTextColor(steamcommunityapplication.getResources().getColor(0x7f060012));
            textview1.setTextColor(steamcommunityapplication.getResources().getColor(0x7f060012));
            return view1;
        } else
        {
            imageview1.setImageResource(0x7f020002);
            textview.setTextColor(steamcommunityapplication.getResources().getColor(0x7f060014));
            textview1.setTextColor(steamcommunityapplication.getResources().getColor(0x7f060014));
            return view1;
        }
    }

    public pter()
    {
        this$0 = SearchFriendListFragment.this;
        super(SearchFriendListFragment.this, 0x7f030009);
    }
}
