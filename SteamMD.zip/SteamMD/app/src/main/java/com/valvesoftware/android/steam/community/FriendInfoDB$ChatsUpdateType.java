// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;


// Referenced classes of package com.valvesoftware.android.steam.community:
//            FriendInfoDB

public static final class  extends Enum
{

    private static final .VALUES $VALUES[];
    public static final .VALUES clear;
    public static final .VALUES mark_read;
    public static final .VALUES msg_incoming;
    public static final .VALUES msg_sent;

    public static  valueOf(String s)
    {
        return ()Enum.valueOf(com/valvesoftware/android/steam/community/FriendInfoDB$ChatsUpdateType, s);
    }

    public static [] values()
    {
        return ([])$VALUES.clone();
    }

    static 
    {
        clear = new <init>("clear", 0);
        mark_read = new <init>("mark_read", 1);
        msg_sent = new <init>("msg_sent", 2);
        msg_incoming = new <init>("msg_incoming", 3);
        e_3B_.clone aclone[] = new <init>[4];
        aclone[0] = clear;
        aclone[1] = mark_read;
        aclone[2] = msg_sent;
        aclone[3] = msg_incoming;
        $VALUES = aclone;
    }

    private (String s, int i)
    {
        super(s, i);
    }
}
