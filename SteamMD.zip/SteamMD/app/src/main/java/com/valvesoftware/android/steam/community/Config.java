// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;


public class Config
{
    public static class Debug
    {

        public static final boolean AggressiveActivityKilling;
        public static final boolean DisableOverTheAir;
        public static final boolean DiskCacheForceMiss;
        public static final boolean HockeyUpdaterForceTest;
        public static final int HttpFakeLatencyMilliseconds;
        public static final boolean JobQueuesDebug;
        public static final int UmqFakePollFailurePercentage;

        public Debug()
        {
        }
    }

    public static class Feature
    {

        public static final boolean LoginRequiredToUseApp = true;
        public static final boolean SteamGuardShipping;

        public Feature()
        {
        }
    }

    public static class Logging
    {

        public Logging()
        {
        }
    }

    public static class Logging.Activities
    {

        public static final boolean chat;
        public static final boolean listdbrefresh;
        public static final boolean login;
        public static final boolean tabgroup;
        public static final boolean tabs;
        public static final boolean uri;

        public Logging.Activities()
        {
        }
    }

    public static class Logging.C2DM
    {

        public static final boolean app2google;
        public static final boolean pushnotifications;
        public static final boolean service;
        public static final boolean unsupported;

        public Logging.C2DM()
        {
        }
    }

    public static class Logging.DebugUtil
    {

        public static final boolean log_collected_info;
        public static final boolean log_sql;
        public static final boolean log_uploaded_dumps;
        public static final boolean retain_collected_after_upload;
        public static final boolean verbose_collection;

        public Logging.DebugUtil()
        {
        }
    }

    public static class Logging.SteamDB
    {

        public static final boolean cache_files;
        public static final boolean cache_read_hit;
        public static final boolean cache_read_miss;
        public static final boolean cache_write;
        public static final boolean disk_errors;
        public static final boolean http_request;
        public static final boolean http_response_fail;
        public static final boolean http_response_ok;
        public static final boolean parse_errors;
        public static final boolean text_full_docs;

        public Logging.SteamDB()
        {
        }
    }

    public static class Logging.ThreadPool
    {

        public static final boolean start_stop;

        public Logging.ThreadPool()
        {
        }
    }

    public static class Logging.UMQ
    {

        public static final boolean log_exceptions;
        public static final boolean log_sql;
        public static final boolean messages;
        public static final boolean parse_errors;
        public static final boolean relationship;
        public static final boolean state;

        public Logging.UMQ()
        {
        }
    }

    public static final class SteamUniverse extends Enum
    {

        private static final SteamUniverse $VALUES[];
        public static final SteamUniverse Beta;
        public static final SteamUniverse Dev;
        public static final SteamUniverse Public;

        public static SteamUniverse valueOf(String s)
        {
            return (SteamUniverse)Enum.valueOf(com/valvesoftware/android/steam/community/Config$SteamUniverse, s);
        }

        public static SteamUniverse[] values()
        {
            return (SteamUniverse[])$VALUES.clone();
        }

        static 
        {
            Public = new SteamUniverse("Public", 0);
            Beta = new SteamUniverse("Beta", 1);
            Dev = new SteamUniverse("Dev", 2);
            SteamUniverse asteamuniverse[] = new SteamUniverse[3];
            asteamuniverse[0] = Public;
            asteamuniverse[1] = Beta;
            asteamuniverse[2] = Dev;
            $VALUES = asteamuniverse;
        }

        private SteamUniverse(String s, int i)
        {
            super(s, i);
        }
    }

    public static class WebAPI
    {

        public static final int MAX_IDS_PER_CALL = 100;
        public static final String OAUTH_CLIENT_ID;

        static 
        {
            String s;
            if (Config.STEAM_UNIVERSE_WEBAPI == SteamUniverse.Public)
            {
                s = "DE45CD61";
            } else
            if (Config.STEAM_UNIVERSE_WEBAPI == SteamUniverse.Beta)
            {
                s = "7DC60112";
            } else
            {
                s = "E77327FA";
            }
            OAUTH_CLIENT_ID = s;
        }

        public WebAPI()
        {
        }
    }


    public static String APP_VERSION = "1.0";
    public static int APP_VERSION_ID = 0;
    public static final String STEAM_UNIVERSE_DEV_HOST = "vitaliy";
    public static final SteamUniverse STEAM_UNIVERSE_WEBAPI;
    public static final SteamUniverse STEAM_UNIVERSE_WEBPHP;
    public static final String URL_COMMUNITY_BASE;
    public static final String URL_COMMUNITY_BASE_INSECURE;
    public static final String URL_MOBILE_CRASH_UPLOAD;
    public static final String URL_MOBILE_UPDATE = "http://m.valvesoftware.com/";
    public static final String URL_STORE_BASE;
    public static final String URL_STORE_BASE_INSECURE;
    public static final String URL_WEBAPI_BASE;
    public static final String URL_WEBAPI_BASE_INSECURE;

    public Config()
    {
    }

    static 
    {
        APP_VERSION_ID = 0;
        STEAM_UNIVERSE_WEBAPI = SteamUniverse.Public;
        STEAM_UNIVERSE_WEBPHP = SteamUniverse.Public;
        String s;
        String s1;
        StringBuilder stringbuilder;
        String s2;
        StringBuilder stringbuilder1;
        String s3;
        StringBuilder stringbuilder2;
        String s4;
        StringBuilder stringbuilder3;
        String s5;
        String s6;
        if (STEAM_UNIVERSE_WEBAPI == SteamUniverse.Public)
        {
            s = "https://api.steampowered.com:443";
        } else
        if (STEAM_UNIVERSE_WEBAPI == SteamUniverse.Beta)
        {
            s = "https://api-beta.steampowered.com:443";
        } else
        {
            s = "https://vitaliy.valvesoftware.com:8283";
        }
        URL_WEBAPI_BASE = s;
        if (STEAM_UNIVERSE_WEBAPI == SteamUniverse.Public)
        {
            s1 = "http://api.steampowered.com:80";
        } else
        if (STEAM_UNIVERSE_WEBAPI == SteamUniverse.Beta)
        {
            s1 = "http://api-beta.steampowered.com:80";
        } else
        {
            s1 = "http://vitaliy.valvesoftware.com:8282";
        }
        URL_WEBAPI_BASE_INSECURE = s1;
        stringbuilder = (new StringBuilder()).append("https://");
        if (STEAM_UNIVERSE_WEBPHP == SteamUniverse.Public)
        {
            s2 = "steamcommunity.com";
        } else
        if (STEAM_UNIVERSE_WEBPHP == SteamUniverse.Beta)
        {
            s2 = "beta.steamcommunity.com";
        } else
        {
            s2 = "vitaliy.valvesoftware.com/community";
        }
        URL_COMMUNITY_BASE = stringbuilder.append(s2).toString();
        stringbuilder1 = (new StringBuilder()).append("http://");
        if (STEAM_UNIVERSE_WEBPHP == SteamUniverse.Public)
        {
            s3 = "steamcommunity.com";
        } else
        if (STEAM_UNIVERSE_WEBPHP == SteamUniverse.Beta)
        {
            s3 = "beta.steamcommunity.com";
        } else
        {
            s3 = "vitaliy.valvesoftware.com/community";
        }
        URL_COMMUNITY_BASE_INSECURE = stringbuilder1.append(s3).toString();
        stringbuilder2 = (new StringBuilder()).append("https://");
        if (STEAM_UNIVERSE_WEBPHP == SteamUniverse.Public)
        {
            s4 = "store.steampowered.com";
        } else
        if (STEAM_UNIVERSE_WEBPHP == SteamUniverse.Beta)
        {
            s4 = "store-beta.steampowered.com";
        } else
        {
            s4 = "vitaliy.valvesoftware.com/store";
        }
        URL_STORE_BASE = stringbuilder2.append(s4).toString();
        stringbuilder3 = (new StringBuilder()).append("http://");
        if (STEAM_UNIVERSE_WEBPHP == SteamUniverse.Public)
        {
            s5 = "store.steampowered.com";
        } else
        if (STEAM_UNIVERSE_WEBPHP == SteamUniverse.Beta)
        {
            s5 = "store-beta.steampowered.com";
        } else
        {
            s5 = "vitaliy.valvesoftware.com/store";
        }
        URL_STORE_BASE_INSECURE = stringbuilder3.append(s5).toString();
        if (STEAM_UNIVERSE_WEBPHP != SteamUniverse.Dev)
        {
            s6 = "http://m.valvesoftware.com/androidsubmit1";
        } else
        {
            s6 = "http://vitaliy.valvesoftware.com/crashupload/androidsubmit1";
        }
        URL_MOBILE_CRASH_UPLOAD = s6;
    }
}
