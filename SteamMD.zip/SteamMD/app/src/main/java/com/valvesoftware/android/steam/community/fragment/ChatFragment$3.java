// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.fragment;

import android.view.KeyEvent;
import android.widget.TextView;

// Referenced classes of package com.valvesoftware.android.steam.community.fragment:
//            ChatFragment

class this._cls0
    implements android.widget.orActionListener
{

    final ChatFragment this$0;

    public boolean onEditorAction(TextView textview, int i, KeyEvent keyevent)
    {
        if (i == 4 || i == 6 || i == 0)
        {
            onClick(ChatFragment.access$1700(ChatFragment.this));
        }
        return true;
    }

    ()
    {
        this$0 = ChatFragment.this;
        super();
    }
}
