// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.fragment;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JsResult;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.DatePicker;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.ToggleButton;
import com.valvesoftware.android.steam.community.SettingInfo;
import com.valvesoftware.android.steam.community.SettingInfoDB;
import com.valvesoftware.android.steam.community.SteamCommunityApplication;
import com.valvesoftware.android.steam.community.SteamUriHandler;
import com.valvesoftware.android.steam.community.activity.ActivityHelper;
import com.valvesoftware.android.steam.community.activity.ChatActivity;
import com.valvesoftware.android.steam.community.activity.LoginActivity;
import com.valvesoftware.android.steam.community.activity.SteamMobileUriActivity;
import java.lang.ref.WeakReference;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Calendar;

// Referenced classes of package com.valvesoftware.android.steam.community.fragment:
//            TitlebarFragment

public class WebViewFragment extends Fragment
{
    private class SteamWebChromeClient extends WebChromeClient
    {

        final WebViewFragment this$0;

        public boolean onJsAlert(WebView webview, String s, String s1, JsResult jsresult)
        {
            return super.onJsAlert(webview, s, s1, jsresult);
        }

        public void onProgressChanged(WebView webview, int i)
        {
            super.onProgressChanged(webview, i);
            if (i > 25)
            {
                m_progress.hide();
                requestWebViewFocusAndEnableTyping();
            }
        }

        private SteamWebChromeClient()
        {
            this$0 = WebViewFragment.this;
            super();
        }

    }

    private class SteamWebViewClient extends WebViewClient
        implements com.valvesoftware.android.steam.community.activity.LoginActivity.LoginChangedListener
    {

        static final boolean $assertionsDisabled;
        private com.valvesoftware.android.steam.community.SteamUriHandler.Result m_loginContext;
        private WeakReference m_urlWebView;
        final WebViewFragment this$0;

        private void doNavigationInWebView(WebView webview, com.valvesoftware.android.steam.community.SteamUriHandler.Result result)
        {
            if (webview != null)
            {
                String s = result.getProperty(com.valvesoftware.android.steam.community.SteamUriHandler.CommandProperty.call);
                if (s != null && s.length() > 0)
                {
                    webview.loadUrl((new StringBuilder()).append("javascript:(function(){").append(s).append(";})()").toString());
                    return;
                }
                String s1 = result.getProperty(com.valvesoftware.android.steam.community.SteamUriHandler.CommandProperty.url);
                if (s1 != null && s1.length() > 0)
                {
                    requestWebViewFocusAndEnableTyping();
                    webview.loadUrl(s1);
                    m_progress.show();
                    return;
                }
            }
        }

        public void onLoginChangedSuccessfully()
        {
            doNavigationInWebView((WebView)m_urlWebView.get(), m_loginContext);
        }

        public void onPageFinished(WebView webview, String s)
        {
            super.onPageFinished(webview, s);
        }

        public void onPageStarted(WebView webview, String s, Bitmap bitmap)
        {
            super.onPageStarted(webview, s, bitmap);
        }

        public void onReceivedError(WebView webview, int i, String s, String s1)
        {
            while (getActivity() == null || m_progress == null || !m_progress.isShowing()) 
            {
                return;
            }
            getActivity().setTitle(getResources().getString(0x7f070038));
            setViewContentsShowFailure((new StringBuilder()).append("steammobile://").append(com.valvesoftware.android.steam.community.SteamUriHandler.Command.errorrecovery.toString()).toString(), s);
        }

        public void onReceivedSslError(WebView webview, SslErrorHandler sslerrorhandler, SslError sslerror)
        {
            SettingInfo settinginfo = SteamCommunityApplication.GetInstance().GetSettingInfoDB().m_settingSslUntrustedPrompt;
            if (settinginfo.m_access != com.valvesoftware.android.steam.community.SettingInfo.AccessRight.NONE)
            {
                if (settinginfo.getRadioSelectorItemValue(SteamCommunityApplication.GetInstance().getApplicationContext()).value == -1)
                {
                    sslerrorhandler.proceed();
                    return;
                } else
                {
                    (getActivity(). new SettingsFragment.RadioSelectorItemOnClickListener(settinginfo, null, sslerrorhandler) {

                        private SslErrorHandler m_hdlrDelayed;
                        final SteamWebViewClient this$1;
                        final SslErrorHandler val$hdlrDelayed;

                        public void onSettingChanged(com.valvesoftware.android.steam.community.SettingInfo.RadioSelectorItem radioselectoritem)
                        {
                            if (radioselectoritem.value != 1)
                            {
                                m_hdlrDelayed.proceed();
                                return;
                            } else
                            {
                                setCategoriesFailed();
                                m_hdlrDelayed.cancel();
                                return;
                            }
                        }

            
            {
                this$1 = final_steamwebviewclient;
                hdlrDelayed = sslerrorhandler;
                super(Activity.this, settinginfo, textview);
                m_hdlrDelayed = hdlrDelayed;
            }
                    }).onClick(null);
                    return;
                }
            } else
            {
                sslerrorhandler.cancel();
                return;
            }
        }

        public boolean shouldOverrideUrlLoading(WebView webview, String s)
        {
            if (getActivity() == null)
            {
                return true;
            }
            if (!s.startsWith("steammobile://")) goto _L2; else goto _L1
_L1:
            com.valvesoftware.android.steam.community.SteamUriHandler.Result result = SteamUriHandler.HandleSteamURI(Uri.parse(s));
            if (!result.handled) goto _L4; else goto _L3
_L3:
            static class _cls5
            {

                static final int $SwitchMap$com$valvesoftware$android$steam$community$SteamUriHandler$Command[];

                static 
                {
                    $SwitchMap$com$valvesoftware$android$steam$community$SteamUriHandler$Command = new int[com.valvesoftware.android.steam.community.SteamUriHandler.Command.values().length];
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$SteamUriHandler$Command[com.valvesoftware.android.steam.community.SteamUriHandler.Command.opencategoryurl.ordinal()] = 1;
                    }
                    catch (NoSuchFieldError nosuchfielderror) { }
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$SteamUriHandler$Command[com.valvesoftware.android.steam.community.SteamUriHandler.Command.openurl.ordinal()] = 2;
                    }
                    catch (NoSuchFieldError nosuchfielderror1) { }
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$SteamUriHandler$Command[com.valvesoftware.android.steam.community.SteamUriHandler.Command.openexternalurl.ordinal()] = 3;
                    }
                    catch (NoSuchFieldError nosuchfielderror2) { }
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$SteamUriHandler$Command[com.valvesoftware.android.steam.community.SteamUriHandler.Command.mobileloginsucceeded.ordinal()] = 4;
                    }
                    catch (NoSuchFieldError nosuchfielderror3) { }
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$SteamUriHandler$Command[com.valvesoftware.android.steam.community.SteamUriHandler.Command.reloadpage.ordinal()] = 5;
                    }
                    catch (NoSuchFieldError nosuchfielderror4) { }
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$SteamUriHandler$Command[com.valvesoftware.android.steam.community.SteamUriHandler.Command.errorrecovery.ordinal()] = 6;
                    }
                    catch (NoSuchFieldError nosuchfielderror5) { }
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$SteamUriHandler$Command[com.valvesoftware.android.steam.community.SteamUriHandler.Command.login.ordinal()] = 7;
                    }
                    catch (NoSuchFieldError nosuchfielderror6) { }
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$SteamUriHandler$Command[com.valvesoftware.android.steam.community.SteamUriHandler.Command.closethis.ordinal()] = 8;
                    }
                    catch (NoSuchFieldError nosuchfielderror7) { }
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$SteamUriHandler$Command[com.valvesoftware.android.steam.community.SteamUriHandler.Command.notfound.ordinal()] = 9;
                    }
                    catch (NoSuchFieldError nosuchfielderror8) { }
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$SteamUriHandler$Command[com.valvesoftware.android.steam.community.SteamUriHandler.Command.agecheckfailed.ordinal()] = 10;
                    }
                    catch (NoSuchFieldError nosuchfielderror9) { }
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$SteamUriHandler$Command[com.valvesoftware.android.steam.community.SteamUriHandler.Command.agecheck.ordinal()] = 11;
                    }
                    catch (NoSuchFieldError nosuchfielderror10) { }
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$SteamUriHandler$Command[com.valvesoftware.android.steam.community.SteamUriHandler.Command.settitle.ordinal()] = 12;
                    }
                    catch (NoSuchFieldError nosuchfielderror11) { }
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$SteamUriHandler$Command[com.valvesoftware.android.steam.community.SteamUriHandler.Command.chat.ordinal()] = 13;
                    }
                    catch (NoSuchFieldError nosuchfielderror12)
                    {
                        return;
                    }
                }
            }

            _cls5..SwitchMap.com.valvesoftware.android.steam.community.SteamUriHandler.Command[result.command.ordinal()];
            JVM INSTR tableswitch 1 13: default 112
        //                       1 114
        //                       2 114
        //                       3 165
        //                       4 209
        //                       5 239
        //                       6 268
        //                       7 289
        //                       8 327
        //                       9 417
        //                       10 566
        //                       11 635
        //                       12 757
        //                       13 810;
               goto _L4 _L5 _L5 _L6 _L7 _L8 _L9 _L10 _L11 _L12 _L13 _L14 _L15 _L16
_L4:
            return true;
_L5:
            Intent intent4 = (new Intent()).setData(Uri.parse(s)).setAction("android.intent.action.VIEW").setClass(getActivity(), com/valvesoftware/android/steam/community/activity/SteamMobileUriActivity);
            getActivity().startActivityForResult(intent4, 0);
            continue; /* Loop/switch isn't completed */
_L6:
            try
            {
                getActivity().startActivity((new Intent()).setData(Uri.parse(result.getProperty(com.valvesoftware.android.steam.community.SteamUriHandler.CommandProperty.url))).setAction("android.intent.action.VIEW"));
            }
            catch (Exception exception1) { }
            continue; /* Loop/switch isn't completed */
_L7:
            if (getActivity() instanceof LoginActivity)
            {
                ((LoginActivity)getActivity()).OnMobileLoginSucceeded(result);
            }
            continue; /* Loop/switch isn't completed */
_L8:
            if (getActivity() instanceof SteamMobileUriActivity)
            {
                ((SteamMobileUriActivity)getActivity()).ReloadPage();
            }
            continue; /* Loop/switch isn't completed */
_L9:
            requestWebViewFocusAndEnableTyping();
            webview.loadUrl(m_url);
            continue; /* Loop/switch isn't completed */
_L10:
            WeakReference weakreference = new WeakReference(webview);
            m_urlWebView = weakreference;
            m_loginContext = result;
            ActivityHelper.PresentLoginActivity(getActivity(), com.valvesoftware.android.steam.community.activity.LoginActivity.LoginAction.LOGIN_EVEN_IF_LOGGED_IN, this);
            continue; /* Loop/switch isn't completed */
_L11:
            if (!$assertionsDisabled && result.getProperty(com.valvesoftware.android.steam.community.SteamUriHandler.CommandProperty.call) == null)
            {
                throw new AssertionError();
            }
            Intent intent3 = getActivity().getIntent();
            intent3.putExtra(com.valvesoftware.android.steam.community.SteamUriHandler.CommandProperty.call.toString(), result.getProperty(com.valvesoftware.android.steam.community.SteamUriHandler.CommandProperty.call));
            intent3.setAction("com.valvesoftware.android.steam.community.intent.action.WEBVIEW_RESULT");
            getActivity().setResult(-1, intent3);
            getActivity().finish();
            continue; /* Loop/switch isn't completed */
_L12:
            boolean flag = true;
            if ((getActivity() instanceof SteamMobileUriActivity) && ((SteamMobileUriActivity)getActivity()).isCategoriesUrl())
            {
                flag = false;
                setViewContentsShowFailure((new StringBuilder()).append("steammobile://").append(com.valvesoftware.android.steam.community.SteamUriHandler.Command.reloadpage.toString()).toString(), SteamCommunityApplication.GetInstance().getString(0x7f07006d));
            }
            if (flag)
            {
                Intent intent2 = getActivity().getIntent();
                intent2.putExtra("dialogtext", getResources().getString(0x7f070037));
                intent2.setAction("com.valvesoftware.android.steam.community.intent.action.WEBVIEW_RESULT");
                getActivity().setResult(-1, intent2);
                getActivity().finish();
            }
            continue; /* Loop/switch isn't completed */
_L13:
            Intent intent1 = getActivity().getIntent();
            intent1.putExtra("dialogtext", getResources().getString(0x7f070058));
            intent1.setAction("com.valvesoftware.android.steam.community.intent.action.WEBVIEW_RESULT");
            getActivity().setResult(-1, intent1);
            getActivity().finish();
            continue; /* Loop/switch isn't completed */
_L14:
            final SettingInfo settingInfo = SteamCommunityApplication.GetInstance().GetSettingInfoDB().m_settingDOB;
            Calendar calendar;
            android.content.DialogInterface.OnClickListener onclicklistener;
            FragmentActivity fragmentactivity;
            android.app.DatePickerDialog.OnDateSetListener ondatesetlistener;
            com.valvesoftware.android.steam.community.SettingInfo.CustomDatePickerDialog customdatepickerdialog;
            if (settingInfo == null)
            {
                calendar = Calendar.getInstance();
            } else
            {
                calendar = com.valvesoftware.android.steam.community.SettingInfo.DateConverter.makeCalendar(settingInfo.getValue(getActivity().getApplicationContext()));
            }
            onclicklistener = new android.content.DialogInterface.OnClickListener() {

                final SteamWebViewClient this$1;

                public void onClick(DialogInterface dialoginterface, int i)
                {
                    if (i == -2)
                    {
                        getActivity().setResult(-1);
                        getActivity().finish();
                    } else
                    if (dialoginterface == null && i == -3)
                    {
                        requestWebViewFocusAndEnableTyping();
                        m_webView.loadUrl(m_url);
                        m_progress.show();
                        return;
                    }
                }

            
            {
                this$1 = SteamWebViewClient.this;
                super();
            }
            };
            fragmentactivity = getActivity();
            ondatesetlistener = onclicklistener. new android.app.DatePickerDialog.OnDateSetListener() {

                final SteamWebViewClient this$1;
                final android.content.DialogInterface.OnClickListener val$onPickerButtons;
                final SettingInfo val$settingInfo;

                public void onDateSet(DatePicker datepicker, int i, int j, int k)
                {
                    String s = com.valvesoftware.android.steam.community.SettingInfo.DateConverter.makeValue(i, j, k);
                    settingInfo.setValueAndCommit(getActivity().getApplicationContext(), s);
                    onPickerButtons.onClick(null, -3);
                }

            
            {
                this$1 = final_steamwebviewclient;
                settingInfo = settinginfo;
                onPickerButtons = android.content.DialogInterface.OnClickListener.this;
                super();
            }
            };
            customdatepickerdialog = new com.valvesoftware.android.steam.community.SettingInfo.CustomDatePickerDialog(fragmentactivity, ondatesetlistener, calendar, 0x7f07004f);
            customdatepickerdialog.setButton(-2, getText(0x7f07001f), onclicklistener);
            customdatepickerdialog.show();
            continue; /* Loop/switch isn't completed */
_L15:
            String s2;
            s2 = result.getProperty(com.valvesoftware.android.steam.community.SteamUriHandler.CommandProperty.title);
            if (s2 == null)
            {
                continue; /* Loop/switch isn't completed */
            }
            String s3;
            TitlebarFragment titlebarfragment;
            s3 = URLDecoder.decode(s2);
            titlebarfragment = ActivityHelper.GetTitlebarFragmentForActivity(getActivity());
            if (titlebarfragment != null)
            {
                try
                {
                    titlebarfragment.setTitleLabel(s3);
                }
                catch (Exception exception) { }
            }
            continue; /* Loop/switch isn't completed */
_L16:
            String s1 = result.getProperty(com.valvesoftware.android.steam.community.SteamUriHandler.CommandProperty.steamid);
            Intent intent = (new Intent()).addFlags(0x18000000).setClass(getActivity(), com/valvesoftware/android/steam/community/activity/ChatActivity).putExtra(com.valvesoftware.android.steam.community.SteamUriHandler.CommandProperty.steamid.toString(), s1).setAction("android.intent.action.VIEW");
            startActivity(intent);
            continue; /* Loop/switch isn't completed */
_L2:
            requestWebViewFocusAndEnableTyping();
            webview.loadUrl(s);
            m_progress.show();
            if (true) goto _L4; else goto _L17
_L17:
        }

        static 
        {
            boolean flag;
            if (!com/valvesoftware/android/steam/community/fragment/WebViewFragment.desiredAssertionStatus())
            {
                flag = true;
            } else
            {
                flag = false;
            }
            $assertionsDisabled = flag;
        }

        private SteamWebViewClient()
        {
            this$0 = WebViewFragment.this;
            super();
        }

    }

    private class SteamWebViewProgressDialog extends ProgressDialog
    {

        final WebViewFragment this$0;

        public void onBackPressed()
        {
            m_webView.setWebViewClient(null);
            m_webView.stopLoading();
            super.onBackPressed();
            getActivity().finish();
        }

        public SteamWebViewProgressDialog(Context context)
        {
            this$0 = WebViewFragment.this;
            super(context);
        }
    }

    private class ToggleOnClickListener
        implements android.view.View.OnClickListener
    {

        String m_clickUrl;
        final WebViewFragment this$0;

        public void onClick(View view)
        {
            ToggleButton togglebutton = (ToggleButton)view;
            RadioGroup radiogroup = (RadioGroup)view.getParent();
            boolean flag;
            if (radiogroup.getCheckedRadioButtonId() == view.getId())
            {
                flag = true;
            } else
            {
                flag = false;
            }
            radiogroup.check(view.getId());
            m_url = m_clickUrl;
            if (flag)
            {
                togglebutton.setChecked(true);
            } else
            {
                requestWebViewFocusAndEnableTyping();
                m_webView.loadUrl(m_url);
                m_progress.show();
            }
            UpdateToggleButtonStyles();
        }

        ToggleOnClickListener(String s)
        {
            this$0 = WebViewFragment.this;
            super();
            m_clickUrl = s;
        }
    }

    public static interface WebViewFragmentOwner
    {

        public abstract String GetRootURL();
    }

    public static class WebViewFragmentOwner.URLCategory
    {

        public String title;
        public String url;

        public WebViewFragmentOwner.URLCategory()
        {
        }
    }


    private static final int m_categoryButtons[] = {
        0x7f09003d, 0x7f09003e, 0x7f09003f, 0x7f090040, 0x7f090041, 0x7f090042, 0x7f090043, 0x7f090044
    };
    private SteamWebChromeClient m_chromeViewClient;
    private SteamWebViewProgressDialog m_progress;
    private int m_selectedTab;
    private final android.widget.RadioGroup.OnCheckedChangeListener m_toggleListener = new android.widget.RadioGroup.OnCheckedChangeListener() {

        final WebViewFragment this$0;

        public void onCheckedChanged(RadioGroup radiogroup, int i)
        {
            int j = 0;
            while (j < radiogroup.getChildCount()) 
            {
                ToggleButton togglebutton = (ToggleButton)radiogroup.getChildAt(j);
                boolean flag;
                if (togglebutton.getId() == i)
                {
                    flag = true;
                } else
                {
                    flag = false;
                }
                togglebutton.setChecked(flag);
                if (togglebutton.getId() == i)
                {
                    m_selectedTab = j;
                }
                j++;
            }
        }

            
            {
                this$0 = WebViewFragment.this;
                super();
            }
    };
    private String m_url;
    private WebView m_webView;
    private SteamWebViewClient m_webViewClient;
    private android.view.View.OnTouchListener m_webViewTouchListener;

    public WebViewFragment()
    {
        m_webView = null;
        m_url = null;
        m_webViewClient = new SteamWebViewClient();
        m_chromeViewClient = new SteamWebChromeClient();
        m_selectedTab = 0;
        m_webViewTouchListener = new android.view.View.OnTouchListener() {

            final WebViewFragment this$0;

            public boolean onTouch(View view, MotionEvent motionevent)
            {
                motionevent.getAction();
                JVM INSTR tableswitch 0 1: default 28
            //                           0 30
            //                           1 30;
                   goto _L1 _L2 _L2
_L1:
                return false;
_L2:
                if (!view.hasFocus())
                {
                    view.requestFocus();
                }
                if (true) goto _L1; else goto _L3
_L3:
            }

            
            {
                this$0 = WebViewFragment.this;
                super();
            }
        };
    }

    private String GetDebugName()
    {
        StringBuilder stringbuilder = (new StringBuilder()).append(getClass().getSimpleName()).append("[");
        String s;
        StringBuilder stringbuilder1;
        String s1;
        if (m_url != null)
        {
            s = m_url;
        } else
        {
            s = "";
        }
        stringbuilder1 = stringbuilder.append(s).append("]@");
        if (m_webView != null)
        {
            s1 = m_webView.getUrl();
        } else
        {
            s1 = "";
        }
        return stringbuilder1.append(s1).toString();
    }

    private void UpdateToggleButtonStyles()
    {
        int i = 0;
        while (i < m_categoryButtons.length) 
        {
            ToggleButton togglebutton = (ToggleButton)getActivity().findViewById(m_categoryButtons[i]);
            if (togglebutton != null)
            {
                ActivityHelper.UpdateToggleButtonStyles(togglebutton);
            }
            i++;
        }
    }

    private void requestWebViewFocusAndEnableTyping()
    {
        if (!m_webView.hasFocus())
        {
            m_webView.requestFocus();
        }
        m_webView.setOnTouchListener(m_webViewTouchListener);
    }

    public void loadUrl(String s)
    {
        requestWebViewFocusAndEnableTyping();
        m_webView.loadUrl(s);
        if (!s.startsWith("javascript:"))
        {
            m_progress.show();
        }
    }

    public void onActivityCreated(Bundle bundle)
    {
        super.onActivityCreated(bundle);
        if (m_webView == null)
        {
            m_webView = (WebView)getActivity().findViewById(0x7f090045);
            m_webView.setBackgroundColor(0);
            m_webView.setWebViewClient(m_webViewClient);
            m_webView.setWebChromeClient(m_chromeViewClient);
            m_webView.getSettings().setJavaScriptEnabled(true);
            m_webView.getSettings().setDomStorageEnabled(true);
            m_webView.setScrollBarStyle(0);
            m_webView.setHorizontalScrollBarEnabled(false);
            if (m_webView != null && m_url != null)
            {
                requestWebViewFocusAndEnableTyping();
                m_webView.loadUrl(m_url);
                m_progress.show();
            }
            ((RadioGroup)getActivity().findViewById(0x7f09003c)).setOnCheckedChangeListener(m_toggleListener);
        }
        TitlebarFragment titlebarfragment = ActivityHelper.GetTitlebarFragmentForActivity(getActivity());
        if (titlebarfragment != null)
        {
            titlebarfragment.setRefreshHandler(new TitlebarFragment.TitlebarButtonHander() {

                final WebViewFragment this$0;

                public void onTitlebarButtonClicked(int i)
                {
                    if (getActivity() instanceof SteamMobileUriActivity)
                    {
                        ((SteamMobileUriActivity)getActivity()).ReloadPage();
                    }
                }

            
            {
                this$0 = WebViewFragment.this;
                super();
            }
            });
        }
    }

    public void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        setHasOptionsMenu(true);
        m_progress = new SteamWebViewProgressDialog(getActivity());
        m_progress.setMessage(getResources().getString(0x7f070036));
        m_progress.setIndeterminate(true);
        m_progress.setCancelable(true);
        if (getActivity() != null && (getActivity() instanceof WebViewFragmentOwner))
        {
            WebViewFragmentOwner webviewfragmentowner = (WebViewFragmentOwner)getActivity();
            if (webviewfragmentowner != null)
            {
                m_url = webviewfragmentowner.GetRootURL();
            }
        }
    }

    public View onCreateView(LayoutInflater layoutinflater, ViewGroup viewgroup, Bundle bundle)
    {
        return layoutinflater.inflate(0x7f030019, viewgroup, false);
    }

    public void onDestroy()
    {
        super.onDestroy();
        m_progress.dismiss();
        m_webView.stopLoading();
    }

    public void onResume()
    {
        super.onResume();
    }

    public void setCategories(ArrayList arraylist, String s)
    {
        TitlebarFragment titlebarfragment;
label0:
        {
            if (arraylist != null && arraylist.size() > 0)
            {
                if (m_selectedTab > -1 + arraylist.size())
                {
                    m_selectedTab = -1 + arraylist.size();
                }
                LinearLayout linearlayout = (LinearLayout)getActivity().findViewById(0x7f09003b);
                linearlayout.setWeightSum(arraylist.size());
                int i;
                int j;
                if (arraylist.size() > 1)
                {
                    i = 0;
                } else
                {
                    i = 8;
                }
                linearlayout.setVisibility(i);
                j = 0;
                while (j < arraylist.size()) 
                {
                    ToggleButton togglebutton = (ToggleButton)getActivity().findViewById(m_categoryButtons[j]);
                    togglebutton.setVisibility(0);
                    togglebutton.setText(((WebViewFragmentOwner.URLCategory)arraylist.get(j)).title);
                    togglebutton.setTextOn(((WebViewFragmentOwner.URLCategory)arraylist.get(j)).title);
                    togglebutton.setTextOff(((WebViewFragmentOwner.URLCategory)arraylist.get(j)).title);
                    togglebutton.setOnClickListener(new ToggleOnClickListener(((WebViewFragmentOwner.URLCategory)arraylist.get(j)).url));
                    boolean flag;
                    if (j == m_selectedTab)
                    {
                        flag = true;
                    } else
                    {
                        flag = false;
                    }
                    togglebutton.setChecked(flag);
                    j++;
                }
                for (; j < m_categoryButtons.length; j++)
                {
                    ((ToggleButton)getActivity().findViewById(m_categoryButtons[j])).setVisibility(8);
                }

                UpdateToggleButtonStyles();
                m_url = ((WebViewFragmentOwner.URLCategory)arraylist.get(m_selectedTab)).url;
                loadUrl(m_url);
            }
            titlebarfragment = ActivityHelper.GetTitlebarFragmentForActivity(getActivity());
            if (titlebarfragment != null)
            {
                if (s == null || s.equals(""))
                {
                    break label0;
                }
                titlebarfragment.setSearchHandler(new TitlebarFragment.TitlebarButtonHander() {

                    final WebViewFragment this$0;
                    final Uri val$uriSearch;

                    public void onTitlebarButtonClicked(int k)
                    {
                        getActivity().startActivity((new Intent()).addFlags(0x18000000).setClass(getActivity(), com/valvesoftware/android/steam/community/activity/SteamMobileUriActivity).setAction("android.intent.action.VIEW").putExtra("title_resid", 0x7f070004).setData(uriSearch));
                    }

            
            {
                this$0 = WebViewFragment.this;
                uriSearch = uri;
                super();
            }
                });
            }
            return;
        }
        titlebarfragment.setSearchHandler(null);
    }

    public void setCategoriesFailed()
    {
        setViewContentsShowFailure((new StringBuilder()).append("steammobile://").append(com.valvesoftware.android.steam.community.SteamUriHandler.Command.reloadpage.toString()).toString(), SteamCommunityApplication.GetInstance().getString(0x7f07006d));
    }

    public void setViewContentsShowFailure(String s, String s1)
    {
        m_webView.loadData((new StringBuilder()).append("<html><head><META http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"></head><body bgcolor=\"#181818\" text=\"#D6D6D6\" link=\"#FFFFFF\" alink=\"#FFFFFF\" vlink=\"#FFFFFF\"><br/><h2 align=\"center\">").append(SteamCommunityApplication.GetInstance().getString(0x7f07006c)).append("</h2>").append("<p align=\"left\">").append(s1).append("</p>").append("<p align=\"center\">").append("<a href=\"").append(s).append("\">").append(SteamCommunityApplication.GetInstance().getString(0x7f07006e)).append("</a></p>").append("</body></html>").toString(), "text/html", "utf-8");
    }




/*
    static int access$302(WebViewFragment webviewfragment, int i)
    {
        webviewfragment.m_selectedTab = i;
        return i;
    }

*/



/*
    static String access$402(WebViewFragment webviewfragment, String s)
    {
        webviewfragment.m_url = s;
        return s;
    }

*/



}
