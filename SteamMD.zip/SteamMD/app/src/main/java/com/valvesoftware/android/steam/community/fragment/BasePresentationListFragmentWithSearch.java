// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.fragment;

import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import com.valvesoftware.android.steam.community.SteamWebApi;
import com.valvesoftware.android.steam.community.activity.ActivityHelper;
import java.util.ArrayList;

// Referenced classes of package com.valvesoftware.android.steam.community.fragment:
//            BasePresentationListFragment, TitlebarFragment

public abstract class BasePresentationListFragmentWithSearch extends BasePresentationListFragment
{

    private boolean m_bSearchModeActive;
    private com.valvesoftware.android.steam.community.GenericListDB.GenericListItem m_mySearchItem;
    private android.view.View.OnClickListener m_searchDeactivateButtonHdlr;
    private EditText m_searchEditText;
    private TitlebarFragment.TitlebarButtonHander m_searchHandler;
    private String m_searchModeFilter;
    private android.widget.TextView.OnEditorActionListener m_searchTxtActionListener;
    private TextWatcher m_searchTxtWatcher;

    public BasePresentationListFragmentWithSearch()
    {
        m_mySearchItem = null;
        m_searchHandler = new TitlebarFragment.TitlebarButtonHander() {

            final BasePresentationListFragmentWithSearch this$0;

            public void onTitlebarButtonClicked(int i)
            {
                if (!SteamWebApi.IsLoggedIn())
                {
                    return;
                } else
                {
                    activateSearch(true);
                    return;
                }
            }

            
            {
                this$0 = BasePresentationListFragmentWithSearch.this;
                super();
            }
        };
        m_searchDeactivateButtonHdlr = new android.view.View.OnClickListener() {

            final BasePresentationListFragmentWithSearch this$0;

            public void onClick(View view)
            {
                activateSearch(false);
            }

            
            {
                this$0 = BasePresentationListFragmentWithSearch.this;
                super();
            }
        };
        m_searchTxtActionListener = new android.widget.TextView.OnEditorActionListener() {

            final BasePresentationListFragmentWithSearch this$0;

            public boolean onEditorAction(TextView textview, int i, KeyEvent keyevent)
            {
                if (i == 3)
                {
                    searchFilterUpdateList();
                    hideOnscreenKeyboard();
                }
                return true;
            }

            
            {
                this$0 = BasePresentationListFragmentWithSearch.this;
                super();
            }
        };
        m_searchTxtWatcher = new TextWatcher() {

            final BasePresentationListFragmentWithSearch this$0;

            public void afterTextChanged(Editable editable)
            {
                searchFilterUpdateList();
            }

            public void beforeTextChanged(CharSequence charsequence, int i, int j, int k)
            {
            }

            public void onTextChanged(CharSequence charsequence, int i, int j, int k)
            {
            }

            
            {
                this$0 = BasePresentationListFragmentWithSearch.this;
                super();
            }
        };
        m_searchEditText = null;
        m_searchModeFilter = null;
        m_bSearchModeActive = false;
    }

    private void hideOnscreenKeyboard()
    {
        InputMethodManager inputmethodmanager = (InputMethodManager)getActivity().getSystemService("input_method");
        if (inputmethodmanager != null && m_searchEditText != null)
        {
            inputmethodmanager.hideSoftInputFromWindow(m_searchEditText.getWindowToken(), 0);
        }
    }

    private void searchFilterUpdateList()
    {
        if (m_searchEditText == null)
        {
            return;
        } else
        {
            m_searchModeFilter = m_searchEditText.getText().toString().toLowerCase();
            refreshListView();
            return;
        }
    }

    protected boolean ApplySearchFilterBeforeDisplay(String s)
    {
        return m_searchModeFilter == null || m_searchModeFilter.equals("") || s != null && s.toLowerCase().indexOf(m_searchModeFilter) >= 0;
    }

    protected com.valvesoftware.android.steam.community.GenericListDB.GenericListItem GetSearchItem()
    {
        if (m_mySearchItem == null)
        {
            m_mySearchItem = myDbItemCreateSearchItem();
        }
        return m_mySearchItem;
    }

    protected void activateSearch(boolean flag)
    {
        if (flag != m_bSearchModeActive)
        {
            m_bSearchModeActive = flag;
            TitlebarFragment titlebarfragment = ActivityHelper.GetTitlebarFragmentForActivity(getActivity());
            if (titlebarfragment != null)
            {
                View view;
                View view1;
                TitlebarFragment.TitlebarButtonHander titlebarbuttonhander;
                if (flag)
                {
                    titlebarbuttonhander = null;
                } else
                {
                    titlebarbuttonhander = m_searchHandler;
                }
                titlebarfragment.setSearchHandler(titlebarbuttonhander, 0x7f020011);
            }
            view = getActivity().findViewById(0x7f09001d);
            if (view != null)
            {
                int i;
                if (flag)
                {
                    i = 0;
                } else
                {
                    i = 8;
                }
                view.setVisibility(i);
                if (flag)
                {
                    if (m_searchEditText == null)
                    {
                        view1 = view.findViewById(0x7f09001f);
                        if (view1 != null)
                        {
                            view1.setOnClickListener(m_searchDeactivateButtonHdlr);
                        }
                        m_searchEditText = (EditText)view.findViewById(0x7f09001e);
                        if (m_searchEditText != null)
                        {
                            m_searchEditText.addTextChangedListener(m_searchTxtWatcher);
                            m_searchEditText.setOnEditorActionListener(m_searchTxtActionListener);
                        }
                    }
                    if (m_searchEditText != null)
                    {
                        m_searchEditText.post(new Runnable() {

                            final BasePresentationListFragmentWithSearch this$0;

                            public void run()
                            {
                                m_searchEditText.requestFocusFromTouch();
                            }

            
            {
                this$0 = BasePresentationListFragmentWithSearch.this;
                super();
            }
                        });
                        return;
                    }
                } else
                {
                    if (m_searchEditText != null)
                    {
                        m_searchEditText.setText("");
                    }
                    m_searchModeFilter = null;
                    refreshListView();
                    m_listView.requestFocusFromTouch();
                    hideOnscreenKeyboard();
                    return;
                }
            }
        }
    }

    protected String getSearchModeText()
    {
        return m_searchEditText.getText().toString();
    }

    protected void myCbckProcessPresentationArray()
    {
        if (m_searchModeFilter != null && m_searchModeFilter.length() >= 3)
        {
            com.valvesoftware.android.steam.community.GenericListDB.GenericListItem genericlistitem = GetSearchItem();
            if (genericlistitem != null)
            {
                m_presentationArray.add(genericlistitem);
            }
        }
    }

    protected abstract com.valvesoftware.android.steam.community.GenericListDB.GenericListItem myDbItemCreateSearchItem();

    public void onActivityCreated(Bundle bundle)
    {
        super.onActivityCreated(bundle);
        TitlebarFragment titlebarfragment = ActivityHelper.GetTitlebarFragmentForActivity(getActivity());
        if (titlebarfragment != null)
        {
            titlebarfragment.setSearchHandler(m_searchHandler, 0x7f020011);
        }
    }

    public void onResume()
    {
        super.onResume();
        if (SteamWebApi.IsLoggedIn())
        {
            refreshListView();
        }
    }

    public boolean overrideActivityOnBackPressed()
    {
        boolean flag = m_bSearchModeActive;
        boolean flag1 = false;
        if (flag)
        {
            activateSearch(false);
            flag1 = true;
        }
        return flag1;
    }



}
