// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.fragment;

import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebView;

// Referenced classes of package com.valvesoftware.android.steam.community.fragment:
//            WebViewFragment

private class <init> extends WebChromeClient
{

    final WebViewFragment this$0;

    public boolean onJsAlert(WebView webview, String s, String s1, JsResult jsresult)
    {
        return super.onJsAlert(webview, s, s1, jsresult);
    }

    public void onProgressChanged(WebView webview, int i)
    {
        super.onProgressChanged(webview, i);
        if (i > 25)
        {
            WebViewFragment.access$600(WebViewFragment.this).hide();
            WebViewFragment.access$500(WebViewFragment.this);
        }
    }

    private ialog()
    {
        this$0 = WebViewFragment.this;
        super();
    }

    this._cls0(this._cls0 _pcls0)
    {
        this();
    }
}
