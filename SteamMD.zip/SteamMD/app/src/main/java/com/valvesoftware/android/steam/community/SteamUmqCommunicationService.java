// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;

import android.app.Notification;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Process;
import com.valvesoftware.android.steam.community.activity.CommunityActivity;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

// Referenced classes of package com.valvesoftware.android.steam.community:
//            Config, SteamUmqCommunicationDatabase, SteamDBService, C2DMessaging, 
//            SteamCommunityApplication, SettingInfoDB, SettingInfo, ISteamUmqCommunicationDatabase, 
//            C2DMProcessor, FriendInfoDB, FriendInfo

public class SteamUmqCommunicationService
{
    private class BaseUMQRequest extends SteamWebApi.RequestBase
    {

        final SteamUmqCommunicationService this$0;

        protected HttpParams GetDefaultHttpParams()
        {
            HttpParams httpparams = super.GetDefaultHttpParams();
            HttpConnectionParams.setSoTimeout(httpparams, 25000);
            return httpparams;
        }

        public BaseUMQRequest()
        {
            this$0 = SteamUmqCommunicationService.this;
            super(m_ThreadPoolCounter.GetThreadPoolQueueId());
        }

        public BaseUMQRequest(String s)
        {
            this$0 = SteamUmqCommunicationService.this;
            super(s);
        }
    }

    private static class C2DM extends BroadcastReceiver
    {

        public boolean m_c2dmClientPushIsActive;
        public String m_c2dmRegistrationId;
        public String m_c2dmRegistrationLanguage;
        public boolean m_c2dmShouldBeSentToServer;

        public boolean isClientPushActive()
        {
            String s = m_c2dmRegistrationId;
            boolean flag = false;
            if (s != null)
            {
                boolean flag1 = m_c2dmRegistrationId.equals("");
                flag = false;
                if (!flag1)
                {
                    int i = SteamCommunityApplication.GetInstance().GetSettingInfoDB().m_settingNotificationsIMs2.getRadioSelectorItemValue(SteamCommunityApplication.GetInstance().getApplicationContext()).value;
                    flag = false;
                    if (i > 0)
                    {
                        flag = true;
                    }
                }
            }
            return flag;
        }

        public void onReceive(Context context, Intent intent)
        {
            String s = intent.getStringExtra("registration.id");
            if (s != null && !s.equals(""))
            {
                m_c2dmRegistrationId = s;
                m_c2dmShouldBeSentToServer = true;
            }
        }

        private C2DM()
        {
            m_c2dmRegistrationId = null;
            m_c2dmRegistrationLanguage = null;
            m_c2dmShouldBeSentToServer = true;
            m_c2dmClientPushIsActive = false;
        }

    }

    private class CancelOngoingNotificationThread extends Thread
    {

        public long m_timeToClearOngoingNotification;
        final SteamUmqCommunicationService this$0;

        public void run()
        {
_L2:
            m_cmdCurrentLock.lock();
            if (m_timeToClearOngoingNotification != 0L)
            {
                break MISSING_BLOCK_LABEL_43;
            }
            m_cancelOngoingNotificationThread = null;
            m_cmdCurrentLock.unlock();
            return;
            long l = m_timeToClearOngoingNotification - System.currentTimeMillis();
            if (l > 0L)
            {
                break MISSING_BLOCK_LABEL_87;
            }
            cancelOngoingNotification();
            m_cancelOngoingNotificationThread = null;
            m_cmdCurrentLock.unlock();
            return;
            m_cmdCurrentLock.unlock();
            long l1 = 100L + l;
            try
            {
                Thread.sleep(l1);
            }
            catch (InterruptedException interruptedexception) { }
            if (true) goto _L2; else goto _L1
_L1:
            Exception exception;
            exception;
            m_cmdCurrentLock.unlock();
            throw exception;
        }

        private CancelOngoingNotificationThread()
        {
            this$0 = SteamUmqCommunicationService.this;
            super();
            m_timeToClearOngoingNotification = 0L;
        }

    }

    private static class MessageNotifyInfo
    {

        public String msg;
        public int num;

        private MessageNotifyInfo()
        {
        }

    }

    private class RequestUMQDeviceInfo extends BaseUMQRequest
    {

        private boolean m_bClientPushIsActive;
        final SteamUmqCommunicationService this$0;

        public void RequestFailedOnResponseWorkerThread()
        {
            synchronized (m_c2dmIntentReceiver)
            {
                m_c2dmIntentReceiver.m_c2dmShouldBeSentToServer = true;
            }
            return;
            exception;
            c2dm;
            JVM INSTR monitorexit ;
            throw exception;
        }

        public void RequestSucceededOnResponseWorkerThread()
        {
            if (!"OK".equals(m_jsonDocument.optString("error", "fail")))
            {
                RequestFailedOnResponseWorkerThread();
                return;
            }
            synchronized (m_c2dmIntentReceiver)
            {
                m_c2dmIntentReceiver.m_c2dmClientPushIsActive = m_bClientPushIsActive;
            }
            return;
            exception;
            c2dm;
            JVM INSTR monitorexit ;
            throw exception;
        }

        public RequestUMQDeviceInfo(String s)
        {
            this$0 = SteamUmqCommunicationService.this;
            super("JobQueueUMQdeviceinfo");
            m_bClientPushIsActive = false;
            SetUriAndDocumentType(SteamUmqCommunicationService.URI_RequestUMQDeviceInfo, SteamWebApi.RequestDocumentType.JSON);
            SetRequestAction(SteamWebApi.RequestActionType.DoHttpRequestNoCache);
            String s1 = Uri.encode(m_c2dmIntentReceiver.m_c2dmRegistrationId);
            StringBuilder stringbuilder = new StringBuilder(12 + (16 + (8 + (16 + s.length()) + s1.length())));
            stringbuilder.append(s);
            stringbuilder.append("&deviceid=");
            stringbuilder.append("GOOG%3A");
            stringbuilder.append(s1);
            stringbuilder.append("&lang=");
            stringbuilder.append(m_c2dmIntentReceiver.m_c2dmRegistrationLanguage);
            stringbuilder.append("&im_enable=");
            m_bClientPushIsActive = m_c2dmIntentReceiver.isClientPushActive();
            String s2;
            if (m_bClientPushIsActive)
            {
                s2 = "1";
            } else
            {
                s2 = "0";
            }
            stringbuilder.append(s2);
            stringbuilder.append("&im_id=");
            stringbuilder.append(C2DMProcessor.getIMID(m_svc));
            SetPostData(stringbuilder.toString());
        }
    }

    private class RequestUMQLogoff extends BaseUMQRequest
    {

        private UmqCommand m_cmd;
        private int m_numRetriesLeft;
        final SteamUmqCommunicationService this$0;

        private void onThisRequestFinished(String s)
        {
            if (SteamCommunityApplication.GetInstance().m_bApplicationExiting)
            {
                Process.killProcess(Process.myPid());
                return;
            } else
            {
                CurrentJobDone(m_cmd);
                Intent intent = new Intent("com.valvesoftware.android.steam.community.SteamUmqCommunicationIntent");
                intent.putExtra("type", "umqlogoff");
                intent.putExtra("umqlogoff", s);
                m_svc.getApplicationContext().sendBroadcast(intent);
                return;
            }
        }

        public void RequestFailedOnResponseWorkerThread()
        {
            if (m_numRetriesLeft > 0)
            {
                m_numRetriesLeft = -1 + m_numRetriesLeft;
                m_svc.SubmitRequest(this);
                return;
            } else
            {
                onThisRequestFinished("error");
                return;
            }
        }

        public void RequestSucceededOnResponseWorkerThread()
        {
            onThisRequestFinished("OK");
        }

        public RequestUMQLogoff(UmqCommand umqcommand)
        {
            this$0 = SteamUmqCommunicationService.this;
            super();
            m_numRetriesLeft = 2;
            m_cmd = umqcommand;
            m_cmd.m_request = this;
            SetUriAndDocumentType(SteamUmqCommunicationService.URI_RequestUMQLogoff, SteamWebApi.RequestDocumentType.JSON);
        }
    }

    private class RequestUMQLogon extends BaseUMQRequest
    {

        private UmqCommand m_cmd;
        final SteamUmqCommunicationService this$0;

        private void onThisRequestFailed(String s)
        {
            UmqCommand umqcommand = new UmqCommand();
            umqcommand.m_eCommand = UmqCommState.UMQ_LOGON_RETRY;
            umqcommand.m_sOAuthToken = m_cmd.m_sOAuthToken;
            umqcommand.m_sMySteamID = m_cmd.m_sMySteamID;
            umqcommand.m_nMessage = m_cmd.m_nMessage;
            AddCommandToQueue(umqcommand);
            onThisRequestFinished(s);
        }

        private void onThisRequestFinished(String s)
        {
            CurrentJobDone(m_cmd);
            Intent intent = new Intent("com.valvesoftware.android.steam.community.SteamUmqCommunicationIntent");
            intent.putExtra("type", "umqlogon");
            intent.putExtra("umqlogon", s);
            m_svc.getApplicationContext().sendBroadcast(intent);
        }

        public void RequestFailedOnResponseWorkerThread()
        {
            if (GetHttpResponseUriData().m_httpResult != 401)
            {
                onThisRequestFailed("error");
                return;
            } else
            {
                onThisRequestFinished("invalidcredentials");
                SetUmqConnectionState(UmqConnectionState.invalidcredentials);
                SteamDBService.REQ_ACT_LOGININFO_DATA req_act_logininfo_data = new SteamDBService.REQ_ACT_LOGININFO_DATA();
                req_act_logininfo_data.sOAuthToken = null;
                req_act_logininfo_data.sSteamID = null;
                SvcReq_SetUmqCommunicationSettings(req_act_logininfo_data);
                return;
            }
        }

        public void RequestSucceededOnResponseWorkerThread()
        {
            if (m_jsonDocument == null) goto _L2; else goto _L1
_L1:
            String s = "";
            String s1 = m_jsonDocument.getString("error");
            s = s1;
_L6:
            int i;
            boolean flag;
            UmqCommand umqcommand;
            int j;
            if (m_jsonDocument.has("umqid"))
            {
                try
                {
                    SteamUmqCommunicationService.m_sUMQID = m_jsonDocument.getString("umqid");
                    android.content.SharedPreferences.Editor editor = SteamCommunityApplication.GetInstance().getApplicationContext().getSharedPreferences("steamumqcommunication", 0).edit();
                    editor.putString("umqid", SteamUmqCommunicationService.m_sUMQID);
                    editor.commit();
                }
                catch (JSONException jsonexception2)
                {
                    s = "";
                }
            }
            if (m_jsonDocument.has("push"))
            {
                boolean flag1 = m_jsonDocument.optBoolean("push", false);
                if (m_c2dmIntentReceiver.isClientPushActive() != flag1)
                {
                    m_c2dmIntentReceiver.m_c2dmShouldBeSentToServer = true;
                }
            }
            flag = m_jsonDocument.has("message");
            i = 0;
            if (!flag)
            {
                break MISSING_BLOCK_LABEL_171;
            }
            j = m_jsonDocument.getInt("message");
            i = j;
_L4:
            if ("OK".equals(s))
            {
                m_screenStateReceiver.m_timeLastApplicationActivity = System.currentTimeMillis();
                umqcommand = new UmqCommand();
                umqcommand.m_eCommand = UmqCommState.UMQ_POLL_STATUS;
                umqcommand.m_sOAuthToken = m_cmd.m_sOAuthToken;
                umqcommand.m_sMySteamID = m_cmd.m_sMySteamID;
                umqcommand.m_nMessage = i;
                AddCommandToQueue(umqcommand);
                onThisRequestFinished("OK");
                return;
            }
_L2:
            onThisRequestFailed("error");
            return;
            JSONException jsonexception1;
            jsonexception1;
            i = 0;
            if (true) goto _L4; else goto _L3
_L3:
            JSONException jsonexception;
            jsonexception;
            if (true) goto _L6; else goto _L5
_L5:
        }

        public RequestUMQLogon(UmqCommand umqcommand)
        {
            this$0 = SteamUmqCommunicationService.this;
            super();
            m_cmd = umqcommand;
            m_cmd.m_request = this;
            SetUriAndDocumentType(SteamUmqCommunicationService.URI_RequestUMQLogon, SteamWebApi.RequestDocumentType.JSON);
        }
    }

    private class RequestUMQMessage extends BaseUMQRequest
    {

        final SteamUmqCommunicationService this$0;

        private void onThisRequestFinished(String s)
        {
            SteamDBService.REQ_ACT_SENDMESSAGE_DATA req_act_sendmessage_data = (SteamDBService.REQ_ACT_SENDMESSAGE_DATA)GetObjData();
            Intent intent = new Intent("com.valvesoftware.android.steam.community.SteamUmqCommunicationIntent");
            intent.putExtra("type", "chatmsg");
            intent.putExtra("action", "send");
            intent.putExtra("send", s);
            intent.putExtra("steamid", req_act_sendmessage_data.msg.sWithSteamID);
            intent.putExtra("msgid", req_act_sendmessage_data.msg.id);
            if (req_act_sendmessage_data.intentcontext != null)
            {
                intent.putExtra("intentcontext", req_act_sendmessage_data.intentcontext);
            }
            m_svc.getApplicationContext().sendBroadcast(intent);
        }

        public void RequestFailedOnResponseWorkerThread()
        {
            onThisRequestFinished("error");
        }

        public void RequestSucceededOnResponseWorkerThread()
        {
            if (m_jsonDocument == null) goto _L2; else goto _L1
_L1:
            String s = "";
            String s1 = m_jsonDocument.getString("error");
            s = s1;
_L4:
            if ("OK".equals(s))
            {
                SteamDBService.REQ_ACT_SENDMESSAGE_DATA req_act_sendmessage_data = (SteamDBService.REQ_ACT_SENDMESSAGE_DATA)GetObjData();
                req_act_sendmessage_data.msg.sMySteamID = req_act_sendmessage_data.mylogin.sSteamID;
                req_act_sendmessage_data.msg.bIncoming = false;
                req_act_sendmessage_data.msg.bUnread = false;
                req_act_sendmessage_data.msg.msgtime = Calendar.getInstance();
                if (!req_act_sendmessage_data.msg.msgtype.equals("typing"))
                {
                    m_db.insertMessage(req_act_sendmessage_data.msg);
                }
                onThisRequestFinished("OK");
                return;
            }
_L2:
            onThisRequestFinished("error");
            return;
            JSONException jsonexception;
            jsonexception;
            if (true) goto _L4; else goto _L3
_L3:
        }

        public RequestUMQMessage()
        {
            this$0 = SteamUmqCommunicationService.this;
            super("JobQueueUMQsendmsg");
            SetUriAndDocumentType(SteamUmqCommunicationService.URI_RequestUMQMessage, SteamWebApi.RequestDocumentType.JSON);
            SetRequestAction(SteamWebApi.RequestActionType.DoHttpRequestNoCache);
        }
    }

    private class RequestUMQPoll extends BaseUMQRequest
    {

        private ArrayList m_arrSteamIdsPersonaState;
        private ArrayList m_arrSteamIdsRelationshipChanges;
        private UmqCommand m_cmd;
        private HashMap m_mapMessagesFromSteamIds;
        final SteamUmqCommunicationService this$0;

        private void DispatchIncomingMessagesNotifications()
        {
            if (m_mapMessagesFromSteamIds == null || m_mapMessagesFromSteamIds.isEmpty())
            {
                return;
            }
            Intent intent;
            for (Iterator iterator = m_mapMessagesFromSteamIds.values().iterator(); iterator.hasNext(); m_svc.getApplicationContext().sendBroadcast(intent))
            {
                intent = (Intent)iterator.next();
                if (intent.hasExtra("notifymsgtext"))
                {
                    UpdateAndroidNotificationMessage(intent.getStringExtra("steamid"), intent.getStringExtra("notifymsgtext"), intent.getIntExtra("incoming", 1));
                    intent.removeExtra("notifymsgtext");
                }
            }

            m_screenStateReceiver.m_timeLastApplicationActivity = System.currentTimeMillis();
        }

        private void DispatchPersonaStateNotifications()
        {
            if (m_arrSteamIdsPersonaState == null || m_arrSteamIdsPersonaState.isEmpty())
            {
                return;
            } else
            {
                Intent intent = new Intent("com.valvesoftware.android.steam.community.SteamUmqCommunicationIntent");
                intent.putExtra("type", "personastate");
                String as[] = new String[m_arrSteamIdsPersonaState.size()];
                intent.putExtra("steamids", (String[])m_arrSteamIdsPersonaState.toArray(as));
                m_svc.getApplicationContext().sendBroadcast(intent);
                m_arrSteamIdsPersonaState.clear();
                return;
            }
        }

        private void DispatchRelationshipChangesNotifications()
        {
            if (m_arrSteamIdsRelationshipChanges == null || m_arrSteamIdsRelationshipChanges.isEmpty())
            {
                return;
            } else
            {
                Intent intent = new Intent("com.valvesoftware.android.steam.community.SteamUmqCommunicationIntent");
                intent.putExtra("type", "personarelationship");
                String as[] = new String[m_arrSteamIdsRelationshipChanges.size()];
                intent.putExtra("steamids", (String[])m_arrSteamIdsRelationshipChanges.toArray(as));
                m_svc.getApplicationContext().sendBroadcast(intent);
                m_arrSteamIdsRelationshipChanges.clear();
                return;
            }
        }

        private boolean isSecure()
        {
            return m_cmd.m_eCommand == UmqCommState.UMQ_POLL;
        }

        private void notifyMessage(JSONObject jsonobject, long l, int i)
        {
            String s1;
            int k;
            String s;
            ISteamUmqCommunicationDatabase.Message message;
            int j;
            Long long1;
            FriendInfo friendinfo;
            Intent intent;
            String s2;
            String s3;
            try
            {
                s = jsonobject.getString("type");
            }
            catch (JSONException jsonexception)
            {
                return;
            }
            if (s == null)
            {
                return;
            }
            if (!s.equals("saytext") && !s.equals("my_saytext") && !s.equals("emote") && !s.equals("my_emote") && !s.equals("typing"))
            {
                break MISSING_BLOCK_LABEL_535;
            }
            boolean flag;
            if (!s.startsWith("my_"))
            {
                flag = true;
            } else
            {
                flag = false;
            }
            if (flag)
            {
                break MISSING_BLOCK_LABEL_90;
            }
            s = s.substring(3);
            message = new ISteamUmqCommunicationDatabase.Message();
            message.sMySteamID = m_cmd.m_sMySteamID;
            message.sWithSteamID = jsonobject.getString("steamid_from");
            message.bIncoming = flag;
            message.bUnread = flag;
            if (i == 0)
            {
                break MISSING_BLOCK_LABEL_184;
            }
            j = jsonobject.optInt("timestamp", 0);
            if (j == 0 || j >= i)
            {
                break MISSING_BLOCK_LABEL_184;
            }
            l = (l + (long)j) - (long)i;
            if (l < SteamUmqCommunicationService.s_lastTimestampOnMessage)
            {
                l = SteamUmqCommunicationService.s_lastTimestampOnMessage;
            }
            message.msgtime = Calendar.getInstance();
            message.msgtime.setTimeInMillis(l);
            SteamUmqCommunicationService.s_lastTimestampOnMessage = l;
            long1 = Long.valueOf(message.sWithSteamID);
            friendinfo = (FriendInfo)SteamCommunityApplication.GetInstance().GetFriendInfoDB().GetItemsMap().get(long1);
            if (friendinfo == null)
            {
                break MISSING_BLOCK_LABEL_685;
            }
            if (friendinfo.m_relationship != FriendInfo.FriendRelationship.friend)
            {
                break MISSING_BLOCK_LABEL_685;
            }
            message.msgtype = s;
            message.bindata = "";
            if (!s.equals("typing"))
            {
                message.bindata = jsonobject.getString("text");
                m_db.insertMessage(message);
            }
            if (m_mapMessagesFromSteamIds == null)
            {
                m_mapMessagesFromSteamIds = new HashMap();
            }
            intent = (Intent)m_mapMessagesFromSteamIds.get(long1);
            if (intent != null)
            {
                break MISSING_BLOCK_LABEL_396;
            }
            intent = new Intent("com.valvesoftware.android.steam.community.SteamUmqCommunicationIntent");
            intent.putExtra("type", "chatmsg");
            intent.putExtra("action", "incoming");
            intent.putExtra("steamid", message.sWithSteamID);
            m_mapMessagesFromSteamIds.put(long1, intent);
            if (s.equals("typing"))
            {
                break MISSING_BLOCK_LABEL_451;
            }
            if (flag)
            {
                s1 = "incoming";
            } else
            {
                s1 = "my_incoming";
            }
            intent.putExtra(s1, 1 + intent.getIntExtra(s1, 0));
            if (!flag)
            {
                break MISSING_BLOCK_LABEL_451;
            }
            intent.putExtra("notifymsgtext", message.bindata);
            if (!flag)
            {
                break MISSING_BLOCK_LABEL_479;
            }
            if (s.equals("typing"))
            {
                k = 1;
            } else
            {
                k = 0;
            }
            intent.putExtra("typing", k);
            if (message.id > 0 && !intent.hasExtra("msgidFirst"))
            {
                intent.putExtra("msgidFirst", message.id);
            }
            if (message.id > 0)
            {
                intent.putExtra("msgidLast", message.id);
                return;
            }
            break MISSING_BLOCK_LABEL_685;
            if (s.equals("personastate"))
            {
                s3 = jsonobject.getString("steamid_from");
                if (m_arrSteamIdsPersonaState == null)
                {
                    m_arrSteamIdsPersonaState = new ArrayList();
                }
                m_arrSteamIdsPersonaState.add(s3);
                UpdateAndroidNotificationNameMap(s3, jsonobject.optString("persona_name"));
                return;
            }
            if (s.equals("personarelationship"))
            {
                s2 = jsonobject.getString("steamid_from");
                if (m_arrSteamIdsRelationshipChanges == null)
                {
                    m_arrSteamIdsRelationshipChanges = new ArrayList();
                }
                m_arrSteamIdsRelationshipChanges.add(s2);
                return;
            }
            if (s.equals("push2poll"))
            {
                if (m_arrSteamIdsRelationshipChanges == null)
                {
                    m_arrSteamIdsRelationshipChanges = new ArrayList();
                }
                m_arrSteamIdsRelationshipChanges.add("");
            }
        }

        private void onThisRequestFailed(String s)
        {
            UmqCommand umqcommand = new UmqCommand();
            umqcommand.m_eCommand = UmqCommState.UMQ_LOGON;
            umqcommand.m_sOAuthToken = m_cmd.m_sOAuthToken;
            umqcommand.m_sMySteamID = m_cmd.m_sMySteamID;
            umqcommand.m_nMessage = m_cmd.m_nMessage;
            AddCommandToQueue(umqcommand);
            onThisRequestFinished(s);
        }

        private void onThisRequestFinished(String s)
        {
            CurrentJobDone(m_cmd);
        }

        protected HttpParams GetDefaultHttpParams()
        {
            HttpParams httpparams = super.GetDefaultHttpParams();
            if (m_cmd.m_nTimeout > 0)
            {
                HttpConnectionParams.setSoTimeout(httpparams, Math.max(1000 * (7 + m_cmd.m_nTimeout), 25000));
            }
            return httpparams;
        }

        public void RequestFailedOnResponseWorkerThread()
        {
            onThisRequestFailed("error");
        }

        public void RequestSucceededOnResponseWorkerThread()
        {
            if (m_jsonDocument == null) goto _L2; else goto _L1
_L1:
            String s = "";
            String s1 = m_jsonDocument.getString("error");
            s = s1;
_L16:
            if (!"OK".equals(s) && !"Timeout".equals(s)) goto _L2; else goto _L3
_L3:
            int i;
            boolean flag;
            boolean flag1;
            i = m_cmd.m_nMessage;
            flag = m_jsonDocument.has("messages");
            flag1 = false;
            if (!flag) goto _L5; else goto _L4
_L4:
            JSONArray jsonarray1 = m_jsonDocument.getJSONArray("messages");
            JSONArray jsonarray = jsonarray1;
_L14:
            long l;
            int j;
            int k;
            int i1;
            l = System.currentTimeMillis();
            j = m_jsonDocument.optInt("timestamp", 0);
            k = 0;
            if (jsonarray != null)
            {
                k = jsonarray.length();
            }
            i1 = 0;
_L11:
            flag1 = false;
            if (i1 >= k) goto _L5; else goto _L6
_L6:
            JSONObject jsonobject1 = jsonarray.getJSONObject(i1);
            JSONObject jsonobject = jsonobject1;
_L12:
            if (jsonobject == null) goto _L8; else goto _L7
_L7:
            if (isSecure() || !jsonobject.has("secure_message_id")) goto _L10; else goto _L9
_L9:
            i = jsonobject.optInt("secure_message_id", m_cmd.m_nMessage);
            flag1 = true;
_L5:
            DispatchIncomingMessagesNotifications();
            DispatchPersonaStateNotifications();
            DispatchRelationshipChangesNotifications();
            UmqCommand umqcommand = new UmqCommand();
            umqcommand.m_eCommand = UmqCommState.UMQ_POLL_STATUS;
            umqcommand.m_sOAuthToken = m_cmd.m_sOAuthToken;
            umqcommand.m_sMySteamID = m_cmd.m_sMySteamID;
            umqcommand.m_nMessage = m_cmd.m_nMessage;
            if (flag1)
            {
                umqcommand.m_nMessage = i;
                umqcommand.m_eCommand = UmqCommState.UMQ_POLL;
            } else
            if (m_jsonDocument.has("messagelast"))
            {
                try
                {
                    umqcommand.m_nMessage = m_jsonDocument.getInt("messagelast");
                }
                catch (JSONException jsonexception1) { }
            }
            JSONException jsonexception4;
            if (m_jsonDocument.has("nextsectimeout"))
            {
                try
                {
                    umqcommand.m_nTimeout = m_jsonDocument.getInt("nextsectimeout");
                }
                catch (JSONException jsonexception2) { }
            }
            AddCommandToQueue(umqcommand);
            CurrentJobDone(m_cmd);
            return;
_L10:
            notifyMessage(jsonobject, l, j);
_L8:
            i1++;
              goto _L11
_L2:
            onThisRequestFailed("error");
            return;
            jsonexception4;
            jsonobject = null;
              goto _L12
            JSONException jsonexception3;
            jsonexception3;
            jsonarray = null;
            if (true) goto _L14; else goto _L13
_L13:
            JSONException jsonexception;
            jsonexception;
            if (true) goto _L16; else goto _L15
_L15:
        }

        public RequestUMQPoll(UmqCommand umqcommand)
        {
            this$0 = SteamUmqCommunicationService.this;
            super();
            m_arrSteamIdsPersonaState = null;
            m_arrSteamIdsRelationshipChanges = null;
            m_mapMessagesFromSteamIds = null;
            m_cmd = umqcommand;
            m_cmd.m_request = this;
            String s;
            if (isSecure())
            {
                s = SteamUmqCommunicationService.URI_RequestUMQPoll;
            } else
            {
                s = SteamUmqCommunicationService.URI_RequestUMQPollStatus;
            }
            SetUriAndDocumentType(s, SteamWebApi.RequestDocumentType.JSON);
        }
    }

    private class RequestUMQServerInfo extends BaseUMQRequest
    {

        private int localTime;
        final SteamUmqCommunicationService this$0;

        public void RequestFailedOnResponseWorkerThread()
        {
            synchronized (m_steamServerInfo)
            {
                m_steamServerInfo.m_steamServerInfoRequired = true;
            }
            return;
            exception;
            steamserverinfo;
            JVM INSTR monitorexit ;
            throw exception;
        }

        public void RequestSucceededOnResponseWorkerThread()
        {
            int i = m_jsonDocument.optInt("servertime");
            if (i == 0)
            {
                RequestFailedOnResponseWorkerThread();
                return;
            } else
            {
                m_steamServerInfo.UpdateServerInfo(localTime, i);
                return;
            }
        }

        public RequestUMQServerInfo()
        {
            this$0 = SteamUmqCommunicationService.this;
            super("JobQueueUMQdeviceinfo");
            localTime = (int)(System.currentTimeMillis() / 1000L);
            SetUriAndDocumentType(SteamUmqCommunicationService.URI_RequestUMQServerInfo, SteamWebApi.RequestDocumentType.JSON);
            SetRequestAction(SteamWebApi.RequestActionType.DoHttpRequestNoCache);
        }
    }

    private class ScreenStateReceiver extends BroadcastReceiver
    {

        public boolean m_bIsScreenActive;
        public long m_timeLastApplicationActivity;
        public long m_timeScreenStateChanged;
        final SteamUmqCommunicationService this$0;

        public void onReceive(Context context, Intent intent)
        {
            if (intent.getAction().equals("android.intent.action.SCREEN_OFF"))
            {
                m_bIsScreenActive = false;
                m_timeScreenStateChanged = System.currentTimeMillis();
            } else
            if (intent.getAction().equals("android.intent.action.SCREEN_ON"))
            {
                m_bIsScreenActive = true;
                m_timeScreenStateChanged = System.currentTimeMillis();
                SvcReq_UmqActivity(null);
                return;
            }
        }

        private ScreenStateReceiver()
        {
            this$0 = SteamUmqCommunicationService.this;
            super();
            m_bIsScreenActive = true;
            m_timeScreenStateChanged = System.currentTimeMillis();
            m_timeLastApplicationActivity = System.currentTimeMillis();
        }

    }

    private static class SteamServerInfo
    {

        private int m_reqLocalTimestamp;
        private int m_reqRemoteTimestamp;
        public boolean m_steamServerInfoRequired;

        public int GetCurrentServerTime()
        {
            this;
            JVM INSTR monitorenter ;
            if (m_reqLocalTimestamp == 0) goto _L2; else goto _L1
_L1:
            int j = m_reqRemoteTimestamp;
            if (j != 0) goto _L3; else goto _L2
_L2:
            int i = 0;
_L5:
            this;
            JVM INSTR monitorexit ;
            return i;
_L3:
            int k;
            int l;
            int i1;
            k = m_reqRemoteTimestamp;
            l = (int)(System.currentTimeMillis() / 1000L);
            i1 = m_reqLocalTimestamp;
            i = k + (l - i1);
            if (true) goto _L5; else goto _L4
_L4:
            Exception exception;
            exception;
            throw exception;
        }

        public void UpdateServerInfo(int i, int j)
        {
            this;
            JVM INSTR monitorenter ;
            Exception exception1;
            try
            {
                android.content.SharedPreferences.Editor editor = SteamCommunityApplication.GetInstance().getApplicationContext().getSharedPreferences("steamumqcommunication", 0).edit();
                editor.putInt("serverInfo_LocalTime", m_reqLocalTimestamp);
                editor.putInt("serverInfo_RemoteTime", m_reqRemoteTimestamp);
                editor.commit();
                m_reqLocalTimestamp = i;
                m_reqRemoteTimestamp = j;
            }
            catch (Exception exception) { }
            finally
            {
                this;
            }
            return;
            throw exception1;
        }

        public SteamServerInfo()
        {
            m_steamServerInfoRequired = true;
            m_reqLocalTimestamp = 0;
            m_reqRemoteTimestamp = 0;
            try
            {
                SharedPreferences sharedpreferences = SteamCommunityApplication.GetInstance().getApplicationContext().getSharedPreferences("steamumqcommunication", 0);
                m_reqLocalTimestamp = sharedpreferences.getInt("serverInfo_LocalTime", 0);
                m_reqRemoteTimestamp = sharedpreferences.getInt("serverInfo_RemoteTime", 0);
                return;
            }
            catch (Exception exception)
            {
                m_reqLocalTimestamp = 0;
            }
            m_reqRemoteTimestamp = 0;
        }
    }

    private class ThreadPoolQueueCounter
    {

        private int m_nThreadPoolQueueId;
        private String m_sThreadPoolQueueId;
        final SteamUmqCommunicationService this$0;

        public String GetThreadPoolQueueId()
        {
            return m_sThreadPoolQueueId;
        }

        public void SwitchToNextThreadPoolQueueId()
        {
            SteamWebApi.RequestBase requestbase = new SteamWebApi.RequestBase(GetThreadPoolQueueId());
            requestbase.SetCallerIntent("JOB_INTENT_SHUTDOWN_JOB_QUEUE");
            m_svc.SubmitRequest(requestbase);
            m_nThreadPoolQueueId = 1 + m_nThreadPoolQueueId;
            m_sThreadPoolQueueId = (new StringBuilder()).append("JobQueueUMQpoll").append(m_nThreadPoolQueueId).toString();
        }

        private ThreadPoolQueueCounter()
        {
            this$0 = SteamUmqCommunicationService.this;
            super();
            m_nThreadPoolQueueId = 0;
            m_sThreadPoolQueueId = "JobQueueUMQpoll";
        }

    }

    public static final class UmqCommState extends Enum
    {

        private static final UmqCommState $VALUES[];
        public static final UmqCommState UMQ_LOGOFF;
        public static final UmqCommState UMQ_LOGON;
        public static final UmqCommState UMQ_LOGON_RETRY;
        public static final UmqCommState UMQ_NONE;
        public static final UmqCommState UMQ_POLL;
        public static final UmqCommState UMQ_POLL_STATUS;

        public static UmqCommState valueOf(String s)
        {
            return (UmqCommState)Enum.valueOf(com/valvesoftware/android/steam/community/SteamUmqCommunicationService$UmqCommState, s);
        }

        public static UmqCommState[] values()
        {
            return (UmqCommState[])$VALUES.clone();
        }

        static 
        {
            UMQ_NONE = new UmqCommState("UMQ_NONE", 0);
            UMQ_LOGON = new UmqCommState("UMQ_LOGON", 1);
            UMQ_LOGON_RETRY = new UmqCommState("UMQ_LOGON_RETRY", 2);
            UMQ_POLL_STATUS = new UmqCommState("UMQ_POLL_STATUS", 3);
            UMQ_POLL = new UmqCommState("UMQ_POLL", 4);
            UMQ_LOGOFF = new UmqCommState("UMQ_LOGOFF", 5);
            UmqCommState aumqcommstate[] = new UmqCommState[6];
            aumqcommstate[0] = UMQ_NONE;
            aumqcommstate[1] = UMQ_LOGON;
            aumqcommstate[2] = UMQ_LOGON_RETRY;
            aumqcommstate[3] = UMQ_POLL_STATUS;
            aumqcommstate[4] = UMQ_POLL;
            aumqcommstate[5] = UMQ_LOGOFF;
            $VALUES = aumqcommstate;
        }

        private UmqCommState(String s, int i)
        {
            super(s, i);
        }
    }

    public static class UmqCommand
    {

        public UmqCommState m_eCommand;
        public int m_nMessage;
        public int m_nTimeout;
        public SteamWebApi.RequestBase m_request;
        public String m_sMySteamID;
        public String m_sOAuthToken;

        public UmqCommand()
        {
        }
    }

    public static final class UmqConnectionState extends Enum
    {

        private static final UmqConnectionState $VALUES[];
        public static final UmqConnectionState active;
        public static final UmqConnectionState connecting;
        public static final UmqConnectionState idle;
        public static final UmqConnectionState invalidcredentials;
        public static final UmqConnectionState offline;
        public static final UmqConnectionState reconnecting;

        public static UmqConnectionState valueOf(String s)
        {
            return (UmqConnectionState)Enum.valueOf(com/valvesoftware/android/steam/community/SteamUmqCommunicationService$UmqConnectionState, s);
        }

        public static UmqConnectionState[] values()
        {
            return (UmqConnectionState[])$VALUES.clone();
        }

        public int getStringResid()
        {
            static class _cls2
            {

                static final int $SwitchMap$com$valvesoftware$android$steam$community$SteamUmqCommunicationService$UmqCommState[];
                static final int $SwitchMap$com$valvesoftware$android$steam$community$SteamUmqCommunicationService$UmqConnectionState[];

                static 
                {
                    $SwitchMap$com$valvesoftware$android$steam$community$SteamUmqCommunicationService$UmqCommState = new int[UmqCommState.values().length];
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$SteamUmqCommunicationService$UmqCommState[UmqCommState.UMQ_LOGON_RETRY.ordinal()] = 1;
                    }
                    catch (NoSuchFieldError nosuchfielderror) { }
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$SteamUmqCommunicationService$UmqCommState[UmqCommState.UMQ_LOGON.ordinal()] = 2;
                    }
                    catch (NoSuchFieldError nosuchfielderror1) { }
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$SteamUmqCommunicationService$UmqCommState[UmqCommState.UMQ_POLL_STATUS.ordinal()] = 3;
                    }
                    catch (NoSuchFieldError nosuchfielderror2) { }
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$SteamUmqCommunicationService$UmqCommState[UmqCommState.UMQ_POLL.ordinal()] = 4;
                    }
                    catch (NoSuchFieldError nosuchfielderror3) { }
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$SteamUmqCommunicationService$UmqCommState[UmqCommState.UMQ_LOGOFF.ordinal()] = 5;
                    }
                    catch (NoSuchFieldError nosuchfielderror4) { }
                    $SwitchMap$com$valvesoftware$android$steam$community$SteamUmqCommunicationService$UmqConnectionState = new int[UmqConnectionState.values().length];
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$SteamUmqCommunicationService$UmqConnectionState[UmqConnectionState.offline.ordinal()] = 1;
                    }
                    catch (NoSuchFieldError nosuchfielderror5) { }
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$SteamUmqCommunicationService$UmqConnectionState[UmqConnectionState.invalidcredentials.ordinal()] = 2;
                    }
                    catch (NoSuchFieldError nosuchfielderror6) { }
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$SteamUmqCommunicationService$UmqConnectionState[UmqConnectionState.connecting.ordinal()] = 3;
                    }
                    catch (NoSuchFieldError nosuchfielderror7) { }
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$SteamUmqCommunicationService$UmqConnectionState[UmqConnectionState.reconnecting.ordinal()] = 4;
                    }
                    catch (NoSuchFieldError nosuchfielderror8) { }
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$SteamUmqCommunicationService$UmqConnectionState[UmqConnectionState.idle.ordinal()] = 5;
                    }
                    catch (NoSuchFieldError nosuchfielderror9) { }
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$SteamUmqCommunicationService$UmqConnectionState[UmqConnectionState.active.ordinal()] = 6;
                    }
                    catch (NoSuchFieldError nosuchfielderror10)
                    {
                        return;
                    }
                }
            }

            switch (_cls2..SwitchMap.com.valvesoftware.android.steam.community.SteamUmqCommunicationService.UmqConnectionState[ordinal()])
            {
            default:
                return 0x7f070021;

            case 2: // '\002'
                return 0x7f07005d;

            case 3: // '\003'
                return 0x7f07005b;

            case 4: // '\004'
                return 0x7f07005c;

            case 5: // '\005'
                return 0x7f070026;

            case 6: // '\006'
                return 0x7f070020;
            }
        }

        public boolean isConnected()
        {
            return this == active;
        }

        static 
        {
            offline = new UmqConnectionState("offline", 0);
            invalidcredentials = new UmqConnectionState("invalidcredentials", 1);
            connecting = new UmqConnectionState("connecting", 2);
            reconnecting = new UmqConnectionState("reconnecting", 3);
            idle = new UmqConnectionState("idle", 4);
            active = new UmqConnectionState("active", 5);
            UmqConnectionState aumqconnectionstate[] = new UmqConnectionState[6];
            aumqconnectionstate[0] = offline;
            aumqconnectionstate[1] = invalidcredentials;
            aumqconnectionstate[2] = connecting;
            aumqconnectionstate[3] = reconnecting;
            aumqconnectionstate[4] = idle;
            aumqconnectionstate[5] = active;
            $VALUES = aumqconnectionstate;
        }

        private UmqConnectionState(String s, int i)
        {
            super(s, i);
        }
    }


    public static final String E_NotLoggedOn = "Not Logged On";
    public static final String E_OK = "OK";
    public static final String E_Timeout = "Timeout";
    public static final String INTENT_ACTION = "com.valvesoftware.android.steam.community.SteamUmqCommunicationIntent";
    private static final String TAG = "SteamUmqCommunication";
    private static final int UMQ_TIMEOUT_DEFAULT_SO = 25000;
    private static final String URI_RequestUMQDeviceInfo;
    private static final String URI_RequestUMQLogoff;
    private static final String URI_RequestUMQLogon;
    private static final String URI_RequestUMQMessage;
    private static final String URI_RequestUMQPoll;
    private static final String URI_RequestUMQPollStatus;
    private static final String URI_RequestUMQServerInfo;
    private static final int m_nIdleTimeBeforePollingStopsSeconds = 60;
    private static final int m_nIdleTimeDisconnectedForSeconds = 0x93a80;
    private static final int m_nIdleTimePausePollingForSeconds = 1800;
    private static final int m_nRetryLogonSleepSecondsMax = 3600;
    private static final int m_nRetryLogonSleepSecondsMed = 600;
    private static final int m_nRetryLogonSleepSecondsMin = 2;
    private static String m_sUMQID = null;
    private static long s_lastTimestampOnMessage = System.currentTimeMillis();
    ThreadPoolQueueCounter m_ThreadPoolCounter;
    private ArrayList m_arrCommands;
    private boolean m_bRunningInForeground;
    private C2DM m_c2dmIntentReceiver;
    private CancelOngoingNotificationThread m_cancelOngoingNotificationThread;
    private UmqCommand m_cmdCurrent;
    private final Condition m_cmdCurrentCond;
    private final Lock m_cmdCurrentLock = new ReentrantLock();
    private final Condition m_cmdRetryLogonCond;
    private SteamUmqCommunicationDatabase m_db;
    private UmqConnectionState m_eMyConnectionState;
    private int m_lastAndroidNotificationResID;
    private Object m_lockNotificationMessages;
    private int m_nRetryLogonSleepSeconds;
    private HashMap m_notificationsMessages;
    private ScreenStateReceiver m_screenStateReceiver;
    private boolean m_settingOngoingEnabled;
    private SteamServerInfo m_steamServerInfo;
    private SteamDBService m_svc;
    private Thread m_thread;

    SteamUmqCommunicationService(SteamDBService steamdbservice)
    {
        m_c2dmIntentReceiver = new C2DM();
        m_screenStateReceiver = new ScreenStateReceiver();
        m_steamServerInfo = new SteamServerInfo();
        m_eMyConnectionState = UmqConnectionState.offline;
        m_lockNotificationMessages = new Object();
        m_notificationsMessages = new HashMap();
        m_settingOngoingEnabled = true;
        m_bRunningInForeground = false;
        m_lastAndroidNotificationResID = 0;
        m_cancelOngoingNotificationThread = null;
        m_ThreadPoolCounter = new ThreadPoolQueueCounter();
        m_arrCommands = new ArrayList();
        m_cmdCurrent = null;
        m_cmdCurrentCond = m_cmdCurrentLock.newCondition();
        m_cmdRetryLogonCond = m_cmdCurrentLock.newCondition();
        m_nRetryLogonSleepSeconds = 2;
        m_thread = null;
        m_svc = steamdbservice;
        m_db = new SteamUmqCommunicationDatabase(steamdbservice.getApplicationContext());
        m_c2dmIntentReceiver.m_c2dmRegistrationId = C2DMessaging.getRegistrationId(m_svc);
        m_c2dmIntentReceiver.m_c2dmRegistrationLanguage = SteamCommunityApplication.GetInstance().getString(0x7f070000);
        m_svc.registerReceiver(m_c2dmIntentReceiver, new IntentFilter("com.valvesoftware.android.steam.community.INTENT_C2DM_REGISTRATION_READY"));
        IntentFilter intentfilter = new IntentFilter("android.intent.action.SCREEN_OFF");
        intentfilter.addAction("android.intent.action.SCREEN_ON");
        m_svc.registerReceiver(m_screenStateReceiver, intentfilter);
    }

    private void AddCommandToQueue(UmqCommand umqcommand)
    {
        AddCommandToQueue(umqcommand, false);
    }

    private void AddCommandToQueue(UmqCommand umqcommand, boolean flag)
    {
        m_cmdCurrentLock.lock();
        UmqCommand umqcommand1;
        if (!m_arrCommands.isEmpty())
        {
            break MISSING_BLOCK_LABEL_78;
        }
        umqcommand1 = m_cmdCurrent;
_L1:
        if (umqcommand1 == null)
        {
            break MISSING_BLOCK_LABEL_64;
        }
        boolean flag1;
        if (umqcommand1.m_sOAuthToken == null || umqcommand.m_sOAuthToken == null)
        {
            break MISSING_BLOCK_LABEL_64;
        }
        flag1 = umqcommand.m_sOAuthToken.equals(umqcommand1.m_sOAuthToken);
        if (flag1)
        {
            break MISSING_BLOCK_LABEL_226;
        }
        if (!flag)
        {
            m_cmdCurrentLock.unlock();
            return;
        }
        break MISSING_BLOCK_LABEL_102;
        umqcommand1 = (UmqCommand)m_arrCommands.get(-1 + m_arrCommands.size());
          goto _L1
        UmqCommState umqcommstate;
        UmqCommState umqcommstate1;
        umqcommstate = umqcommand.m_eCommand;
        umqcommstate1 = UmqCommState.UMQ_LOGON;
        if (umqcommstate != umqcommstate1)
        {
            m_cmdCurrentLock.unlock();
            return;
        }
        if (umqcommand1 == null)
        {
            break MISSING_BLOCK_LABEL_226;
        }
        if (umqcommand1.m_sOAuthToken != null)
        {
            if (m_cmdCurrent != null)
            {
                CurrentJobDoneNonLocking(m_cmdCurrent);
            }
            m_arrCommands.clear();
            SetUmqConnectionState(UmqConnectionState.offline);
            m_ThreadPoolCounter.SwitchToNextThreadPoolQueueId();
            UmqCommand umqcommand2 = new UmqCommand();
            umqcommand2.m_eCommand = UmqCommState.UMQ_LOGOFF;
            umqcommand2.m_sOAuthToken = umqcommand1.m_sOAuthToken;
            umqcommand2.m_sMySteamID = umqcommand1.m_sMySteamID;
            m_arrCommands.add(umqcommand2);
        }
        if (!umqcommand.m_eCommand.equals(UmqCommState.UMQ_LOGON_RETRY)) goto _L3; else goto _L2
_L2:
        m_arrCommands.add(0, umqcommand);
        if (4 * m_nRetryLogonSleepSeconds >= 600) goto _L5; else goto _L4
_L4:
        m_nRetryLogonSleepSeconds = 4 * m_nRetryLogonSleepSeconds;
_L6:
        if (m_nRetryLogonSleepSeconds > 3600)
        {
            m_nRetryLogonSleepSeconds = 3600;
        }
_L7:
        if (m_thread != null)
        {
            break MISSING_BLOCK_LABEL_377;
        }
        m_thread = new Thread() {

            final SteamUmqCommunicationService this$0;

            public void run()
            {
                while (ProcessCommandsThreadedBlocking()) ;
            }

            
            {
                this$0 = SteamUmqCommunicationService.this;
                super();
            }
        };
        m_thread.setName("UmqCommunicationThread");
        m_thread.start();
_L8:
        m_cmdCurrentLock.unlock();
        return;
_L5:
        m_nRetryLogonSleepSeconds = 600 + m_nRetryLogonSleepSeconds;
          goto _L6
        Exception exception;
        exception;
        m_cmdCurrentLock.unlock();
        throw exception;
_L3:
        m_arrCommands.add(umqcommand);
        m_nRetryLogonSleepSeconds = 2;
          goto _L7
        m_cmdRetryLogonCond.signalAll();
          goto _L8
    }

    private void CurrentJobDone(UmqCommand umqcommand)
    {
        Exception exception;
        m_cmdCurrentLock.lock();
        try
        {
            CurrentJobDoneNonLocking(umqcommand);
        }
        catch (Exception exception1)
        {
            m_cmdCurrentLock.unlock();
            return;
        }
        finally
        {
            m_cmdCurrentLock.unlock();
        }
        m_cmdCurrentLock.unlock();
        return;
        throw exception;
    }

    private void CurrentJobDoneNonLocking(UmqCommand umqcommand)
    {
        umqcommand.m_request = null;
        m_cmdCurrentCond.signalAll();
    }

    private boolean ProcessCommandsThreadedBlocking()
    {
        m_cmdCurrentLock.lock();
        if (m_cmdCurrent == null || m_cmdCurrent.m_request == null)
        {
            break MISSING_BLOCK_LABEL_46;
        }
        m_cmdCurrentCond.await();
        m_cmdCurrentLock.unlock();
        return true;
        if (!m_arrCommands.isEmpty())
        {
            break MISSING_BLOCK_LABEL_72;
        }
        m_thread = null;
        m_cmdCurrentLock.unlock();
        return false;
        Exception exception;
        try
        {
            m_cmdCurrent = (UmqCommand)m_arrCommands.get(0);
            m_arrCommands.remove(0);
            ProcessNextCommand();
        }
        catch (Exception exception1)
        {
            m_cmdCurrentLock.unlock();
            return true;
        }
        finally
        {
            m_cmdCurrentLock.unlock();
        }
        m_cmdCurrentLock.unlock();
        return true;
        throw exception;
    }

    private void ProcessNextCommand()
    {
        _cls2..SwitchMap.com.valvesoftware.android.steam.community.SteamUmqCommunicationService.UmqCommState[m_cmdCurrent.m_eCommand.ordinal()];
        JVM INSTR tableswitch 1 5: default 48
    //                   1 57
    //                   2 68
    //                   3 234
    //                   4 234
    //                   5 972;
           goto _L1 _L2 _L3 _L4 _L4 _L5
_L1:
        CurrentJobDoneNonLocking(m_cmdCurrent);
_L14:
        return;
_L2:
        SetUmqConnectionState(UmqConnectionState.reconnecting);
        RetryLogonWaitForMoreJobs();
_L3:
        if (m_cmdCurrent.m_sOAuthToken == null)
        {
            SetUmqConnectionState(UmqConnectionState.offline);
            CurrentJobDoneNonLocking(m_cmdCurrent);
            return;
        }
        SetUmqConnectionState(UmqConnectionState.connecting);
        RequestUMQLogon requestumqlogon = new RequestUMQLogon(m_cmdCurrent);
        String s4 = (new StringBuilder()).append("?access_token=").append(m_cmdCurrent.m_sOAuthToken).toString();
        if (m_sUMQID == null)
        {
            m_sUMQID = SteamCommunityApplication.GetInstance().getApplicationContext().getSharedPreferences("steamumqcommunication", 0).getString("umqid", null);
        }
        if (m_sUMQID != null)
        {
            s4 = (new StringBuilder()).append(s4).append("&umqid=").append(m_sUMQID).toString();
        }
        requestumqlogon.SetPostData(s4);
        requestumqlogon.SetRequestAction(SteamWebApi.RequestActionType.DoHttpRequestNoCache);
        m_svc.SubmitRequest(requestumqlogon);
        return;
_L4:
        if (m_cmdCurrent.m_eCommand != UmqCommState.UMQ_POLL_STATUS || m_screenStateReceiver.m_bIsScreenActive || (int)((System.currentTimeMillis() - m_screenStateReceiver.m_timeScreenStateChanged) / 1000L) <= 60 || (int)((System.currentTimeMillis() - m_screenStateReceiver.m_timeLastApplicationActivity) / 1000L) <= 60) goto _L7; else goto _L6
_L6:
        int i;
        boolean flag2;
        i = SteamCommunityApplication.GetInstance().GetSettingInfoDB().m_settingNotificationsIMs2.getRadioSelectorItemValue(SteamCommunityApplication.GetInstance().getApplicationContext()).value;
        flag2 = true;
        i;
        JVM INSTR tableswitch 1 2: default 348
    //                   1 893
    //                   2 913;
           goto _L8 _L9 _L10
_L8:
        m_nRetryLogonSleepSeconds = 0x93a80;
_L18:
        if (flag2 && (int)((System.currentTimeMillis() - m_screenStateReceiver.m_timeScreenStateChanged) / 1000L) < 900)
        {
            m_screenStateReceiver.m_timeScreenStateChanged = System.currentTimeMillis() - 0xea600L;
        }
        RetryLogonWaitForMoreJobs();
        m_screenStateReceiver.m_timeLastApplicationActivity = System.currentTimeMillis();
        m_nRetryLogonSleepSeconds = 2;
_L7:
        SteamServerInfo steamserverinfo;
        C2DM c2dm;
        SetUmqConnectionState(UmqConnectionState.active);
        RequestUMQPoll requestumqpoll = new RequestUMQPoll(m_cmdCurrent);
        String s1;
        String s2;
        boolean flag;
        RequestUMQServerInfo requestumqserverinfo;
        boolean flag1;
        RequestUMQDeviceInfo requestumqdeviceinfo;
        String s3;
        if (m_cmdCurrent.m_eCommand == UmqCommState.UMQ_POLL_STATUS)
        {
            s1 = (new StringBuilder()).append("?steamid=").append(m_cmdCurrent.m_sMySteamID).toString();
        } else
        {
            s1 = (new StringBuilder()).append("?access_token=").append(m_cmdCurrent.m_sOAuthToken).toString();
        }
        if (m_sUMQID != null)
        {
            s1 = (new StringBuilder()).append(s1).append("&umqid=").append(m_sUMQID).toString();
        }
        s2 = (new StringBuilder()).append(s1).append("&message=").append(m_cmdCurrent.m_nMessage).toString();
        if (m_cmdCurrent.m_nTimeout > 0)
        {
            s2 = (new StringBuilder()).append(s2).append("&sectimeout=").append(m_cmdCurrent.m_nTimeout).toString();
        }
        if (!m_screenStateReceiver.m_bIsScreenActive)
        {
            s2 = (new StringBuilder()).append(s2).append("&secidletime=").append((int)((System.currentTimeMillis() - m_screenStateReceiver.m_timeScreenStateChanged) / 1000L)).toString();
        }
        requestumqpoll.SetPostData(s2);
        requestumqpoll.SetRequestAction(SteamWebApi.RequestActionType.DoHttpRequestNoCache);
        m_svc.SubmitRequest(requestumqpoll);
        if (!m_c2dmIntentReceiver.m_c2dmShouldBeSentToServer || m_c2dmIntentReceiver.m_c2dmRegistrationId == null || m_c2dmIntentReceiver.m_c2dmRegistrationId.equals(""))
        {
            continue; /* Loop/switch isn't completed */
        }
        c2dm = m_c2dmIntentReceiver;
        c2dm;
        JVM INSTR monitorenter ;
        flag1 = m_c2dmIntentReceiver.m_c2dmShouldBeSentToServer;
        requestumqdeviceinfo = null;
        if (!flag1) goto _L12; else goto _L11
_L11:
        m_c2dmIntentReceiver.m_c2dmShouldBeSentToServer = false;
        s3 = (new StringBuilder()).append("?access_token=").append(m_cmdCurrent.m_sOAuthToken).toString();
        if (m_sUMQID != null)
        {
            s3 = (new StringBuilder()).append(s3).append("&umqid=").append(m_sUMQID).toString();
        }
        requestumqdeviceinfo = new RequestUMQDeviceInfo(s3);
_L12:
        c2dm;
        JVM INSTR monitorexit ;
        if (requestumqdeviceinfo != null)
        {
            m_svc.SubmitRequest(requestumqdeviceinfo);
        }
        if (!m_steamServerInfo.m_steamServerInfoRequired) goto _L14; else goto _L13
_L13:
        steamserverinfo = m_steamServerInfo;
        steamserverinfo;
        JVM INSTR monitorenter ;
        flag = m_steamServerInfo.m_steamServerInfoRequired;
        requestumqserverinfo = null;
        if (!flag) goto _L16; else goto _L15
_L15:
        m_steamServerInfo.m_steamServerInfoRequired = false;
        requestumqserverinfo = new RequestUMQServerInfo();
_L16:
        steamserverinfo;
        JVM INSTR monitorexit ;
        if (requestumqserverinfo != null)
        {
            m_svc.SubmitRequest(requestumqserverinfo);
            return;
        }
        continue; /* Loop/switch isn't completed */
_L9:
        if (!m_c2dmIntentReceiver.m_c2dmClientPushIsActive) goto _L10; else goto _L17
_L17:
        m_nRetryLogonSleepSeconds = 1800;
          goto _L18
_L10:
        m_nRetryLogonSleepSeconds = 15;
        flag2 = false;
          goto _L18
        Exception exception1;
        exception1;
        c2dm;
        JVM INSTR monitorexit ;
        throw exception1;
        Exception exception;
        exception;
        steamserverinfo;
        JVM INSTR monitorexit ;
        throw exception;
_L5:
        SetUmqConnectionState(UmqConnectionState.offline);
        RequestUMQLogoff requestumqlogoff = new RequestUMQLogoff(m_cmdCurrent);
        String s = (new StringBuilder()).append("?access_token=").append(m_cmdCurrent.m_sOAuthToken).toString();
        if (m_sUMQID != null)
        {
            s = (new StringBuilder()).append(s).append("&umqid=").append(m_sUMQID).toString();
        }
        requestumqlogoff.SetPostData(s);
        requestumqlogoff.SetRequestAction(SteamWebApi.RequestActionType.DoHttpRequestNoCache);
        m_svc.SubmitRequest(requestumqlogoff);
        return;
        if (true) goto _L14; else goto _L19
_L19:
    }

    private void RetryLogonSignalMoreJobsAvailable(int i)
    {
        m_cmdCurrentLock.lock();
        m_nRetryLogonSleepSeconds = i;
        m_cmdRetryLogonCond.signalAll();
        m_cmdCurrentLock.unlock();
    }

    private void RetryLogonWaitForMoreJobs()
    {
        long l = System.currentTimeMillis();
_L1:
        long l1;
        if (!m_arrCommands.isEmpty())
        {
            break MISSING_BLOCK_LABEL_59;
        }
        l1 = (l + (long)(1000 * m_nRetryLogonSleepSeconds)) - System.currentTimeMillis();
        if (l1 <= 0L)
        {
            return;
        }
        m_cmdRetryLogonCond.awaitNanos(0xf4240L * l1);
          goto _L1
        Exception exception;
        exception;
    }

    private void SetUmqConnectionState(UmqConnectionState umqconnectionstate)
    {
        while (m_eMyConnectionState == UmqConnectionState.invalidcredentials && umqconnectionstate == UmqConnectionState.offline || m_eMyConnectionState == umqconnectionstate) 
        {
            return;
        }
        UpdateAndroidNotificationPanelFromUmqState(umqconnectionstate, false);
        Intent intent = new Intent("com.valvesoftware.android.steam.community.SteamUmqCommunicationIntent");
        intent.putExtra("type", "umqstate");
        intent.putExtra("state", umqconnectionstate.toString());
        intent.putExtra("old_state", m_eMyConnectionState.toString());
        m_eMyConnectionState = umqconnectionstate;
        m_svc.getApplicationContext().sendBroadcast(intent);
    }

    private void UpdateAndroidNotificationMessage(String s, String s1, int i)
    {
        Object obj = m_lockNotificationMessages;
        obj;
        JVM INSTR monitorenter ;
        NotificationManager notificationmanager;
        MessageNotifyInfo messagenotifyinfo;
        notificationmanager = (NotificationManager)m_svc.getSystemService("notification");
        messagenotifyinfo = (MessageNotifyInfo)m_notificationsMessages.get(s);
        if (messagenotifyinfo != null) goto _L2; else goto _L1
_L1:
        messagenotifyinfo = new MessageNotifyInfo();
        boolean flag = true;
        messagenotifyinfo.num = i;
        messagenotifyinfo.msg = s1;
        if (s1.length() > 40)
        {
            StringBuilder stringbuilder = new StringBuilder(43);
            stringbuilder.append(s1.substring(0, 40));
            stringbuilder.append("...");
            messagenotifyinfo.msg = stringbuilder.toString();
        }
        m_notificationsMessages.put(s, messagenotifyinfo);
_L5:
        if (notificationmanager == null) goto _L4; else goto _L3
_L3:
        Notification notification;
        ISteamUmqCommunicationDatabase.UmqInfo umqinfo;
        notification = new Notification(0x7f020023, messagenotifyinfo.msg, System.currentTimeMillis());
        notification.flags = 0x10 | notification.flags;
        SteamCommunityApplication.GetInstance().GetSettingInfoDB().configureNotificationObject(notification, flag);
        umqinfo = m_db.selectInfo(s);
        if (umqinfo == null)
        {
            break MISSING_BLOCK_LABEL_453;
        }
        String s2 = umqinfo.name;
_L6:
        if (s2 != null)
        {
            break MISSING_BLOCK_LABEL_223;
        }
        s2 = m_svc.getText(0x7f07000c).toString();
        notification.setLatestEventInfo(m_svc, s2, messagenotifyinfo.msg, SteamCommunityApplication.GetInstance().GetIntentToChatWithSteamID(s));
        notificationmanager.notify(s, 0x7f07000c, notification);
_L4:
        obj;
        JVM INSTR monitorexit ;
        return;
_L2:
        String s3;
        messagenotifyinfo.num = i + messagenotifyinfo.num;
        s3 = m_svc.getText(0x7f070065).toString().replace("#", String.valueOf(messagenotifyinfo.num));
        messagenotifyinfo.msg = s1;
        int j = 40 - s3.length();
        if (s1.length() <= j)
        {
            break MISSING_BLOCK_LABEL_403;
        }
        StringBuilder stringbuilder1 = new StringBuilder(3 + (j + s3.length()));
        stringbuilder1.append(s3);
        stringbuilder1.append(s1.substring(0, j));
        stringbuilder1.append("...");
        messagenotifyinfo.msg = stringbuilder1.toString();
        flag = false;
          goto _L5
        Exception exception1;
        exception1;
        obj;
        JVM INSTR monitorexit ;
        try
        {
            throw exception1;
        }
        catch (Exception exception)
        {
            return;
        }
        StringBuilder stringbuilder2 = new StringBuilder(s3.length() + s1.length());
        stringbuilder2.append(s3);
        stringbuilder2.append(s1);
        messagenotifyinfo.msg = stringbuilder2.toString();
        flag = false;
          goto _L5
        s2 = null;
          goto _L6
    }

    private void UpdateAndroidNotificationMessageRemove(String s)
    {
label0:
        {
            synchronized (m_lockNotificationMessages)
            {
                if ((MessageNotifyInfo)m_notificationsMessages.remove(s) != null)
                {
                    break label0;
                }
            }
            return;
        }
        NotificationManager notificationmanager = (NotificationManager)m_svc.getSystemService("notification");
        if (notificationmanager == null)
        {
            break MISSING_BLOCK_LABEL_53;
        }
        notificationmanager.cancel(s, 0x7f07000c);
        obj;
        JVM INSTR monitorexit ;
        return;
        exception1;
        obj;
        JVM INSTR monitorexit ;
        try
        {
            throw exception1;
        }
        catch (Exception exception)
        {
            return;
        }
    }

    private void UpdateAndroidNotificationMessageRemoveAll()
    {
        Object obj = m_lockNotificationMessages;
        obj;
        JVM INSTR monitorenter ;
        NotificationManager notificationmanager = (NotificationManager)m_svc.getSystemService("notification");
        if (notificationmanager == null)
        {
            break MISSING_BLOCK_LABEL_79;
        }
        for (Iterator iterator = m_notificationsMessages.keySet().iterator(); iterator.hasNext(); notificationmanager.cancel((String)iterator.next(), 0x7f07000c)) { }
        break MISSING_BLOCK_LABEL_79;
        Exception exception1;
        exception1;
        obj;
        JVM INSTR monitorexit ;
        try
        {
            throw exception1;
        }
        catch (Exception exception)
        {
            return;
        }
        m_notificationsMessages.clear();
        obj;
        JVM INSTR monitorexit ;
    }

    private void UpdateAndroidNotificationNameMap(String s, String s1)
    {
        if (s1 != null && !s1.equals(""))
        {
            ISteamUmqCommunicationDatabase.UmqInfo umqinfo = new ISteamUmqCommunicationDatabase.UmqInfo();
            umqinfo.steamid = s;
            umqinfo.name = s1;
            m_db.insertInfo(umqinfo);
        }
    }

    private void UpdateAndroidNotificationPanel(int i)
    {
_L2:
        return;
        if (i == m_lastAndroidNotificationResID || i != 0 && SteamCommunityApplication.GetInstance().m_bApplicationExiting) goto _L2; else goto _L1
_L1:
        int j;
        if (i == 0x7f07005a || i == 0x7f070020)
        {
            j = 0x7f020024;
        } else
        {
            j = 0x7f020025;
        }
        if (m_lastAndroidNotificationResID != 0) goto _L4; else goto _L3
_L3:
        CharSequence charsequence1 = m_svc.getText(i);
        Notification notification1 = new Notification(j, charsequence1, System.currentTimeMillis());
        notification1.setLatestEventInfo(m_svc, m_svc.getText(0x7f070038), charsequence1, SteamCommunityApplication.GetInstance().GetIntentForActivityClassFromService(com/valvesoftware/android/steam/community/activity/CommunityActivity));
        m_svc.startForeground(0x7f07005a, notification1);
        m_lastAndroidNotificationResID = i;
        m_bRunningInForeground = true;
_L5:
        if (m_cancelOngoingNotificationThread == null && !m_settingOngoingEnabled && m_bRunningInForeground)
        {
            m_cancelOngoingNotificationThread = new CancelOngoingNotificationThread();
            m_cancelOngoingNotificationThread.setName("CancelOngoingNotificationThread");
            m_cancelOngoingNotificationThread.start();
        }
        NotificationManager notificationmanager;
        CharSequence charsequence;
        Notification notification;
        if (m_cancelOngoingNotificationThread != null)
        {
            if (!m_settingOngoingEnabled)
            {
                m_cancelOngoingNotificationThread.m_timeToClearOngoingNotification = 3000L + System.currentTimeMillis();
                return;
            } else
            {
                m_cancelOngoingNotificationThread.m_timeToClearOngoingNotification = 0L;
                return;
            }
        }
        if (true) goto _L2; else goto _L4
_L4:
label0:
        {
            if (i != 0)
            {
                break label0;
            }
            try
            {
                if (m_bRunningInForeground)
                {
                    m_svc.stopForeground(true);
                    m_bRunningInForeground = false;
                }
                m_lastAndroidNotificationResID = 0;
                UpdateAndroidNotificationMessageRemoveAll();
                return;
            }
            catch (Exception exception) { }
        }
          goto _L5
        notificationmanager = (NotificationManager)m_svc.getSystemService("notification");
        if (notificationmanager == null) goto _L5; else goto _L6
_L6:
        charsequence = m_svc.getText(i);
        notification = new Notification(j, charsequence, System.currentTimeMillis());
        notification.setLatestEventInfo(m_svc, m_svc.getText(0x7f070038), charsequence, SteamCommunityApplication.GetInstance().GetIntentForActivityClassFromService(com/valvesoftware/android/steam/community/activity/CommunityActivity));
        if (!m_bRunningInForeground)
        {
            break MISSING_BLOCK_LABEL_350;
        }
        notificationmanager.notify(0x7f07005a, notification);
_L7:
        m_bRunningInForeground = true;
        m_lastAndroidNotificationResID = i;
          goto _L5
        m_svc.startForeground(0x7f07005a, notification);
          goto _L7
    }

    private void UpdateAndroidNotificationPanelFromUmqState(UmqConnectionState umqconnectionstate, boolean flag)
    {
        if (flag)
        {
            m_lastAndroidNotificationResID = 0;
        }
        if (!m_bRunningInForeground && !flag && umqconnectionstate != UmqConnectionState.offline)
        {
            m_settingOngoingEnabled = SteamCommunityApplication.GetInstance().GetSettingInfoDB().m_settingForegroundService.getBooleanValue(SteamCommunityApplication.GetInstance().getApplicationContext());
        }
        _cls2..SwitchMap.com.valvesoftware.android.steam.community.SteamUmqCommunicationService.UmqConnectionState[umqconnectionstate.ordinal()];
        JVM INSTR tableswitch 1 3: default 84
    //                   1 129
    //                   2 84
    //                   3 93;
           goto _L1 _L2 _L1 _L3
_L1:
        UpdateAndroidNotificationPanel(umqconnectionstate.getStringResid());
_L5:
        return;
_L3:
        if (!flag && m_eMyConnectionState == UmqConnectionState.active || !flag && m_eMyConnectionState == UmqConnectionState.reconnecting) goto _L5; else goto _L4
_L4:
        UpdateAndroidNotificationPanel(0x7f07005b);
        return;
_L2:
        UpdateAndroidNotificationPanel(0);
        return;
    }

    private void cancelOngoingNotification()
    {
        if (!m_bRunningInForeground)
        {
            return;
        }
        try
        {
            m_svc.stopForeground(true);
            m_bRunningInForeground = false;
            return;
        }
        catch (Exception exception)
        {
            return;
        }
    }

    public UmqConnectionState SvcReq_GetUmqConnectionState()
    {
        return m_eMyConnectionState;
    }

    public int SvcReq_GetUmqCurrentServerTime()
    {
        return m_steamServerInfo.GetCurrentServerTime();
    }

    public void SvcReq_MarkReadMessages(SteamDBService.REQ_ACT_MARKREADMESSAGES_DATA req_act_markreadmessages_data)
    {
        m_db.updateMarkReadMessagesWithUser(req_act_markreadmessages_data.mysteamid, req_act_markreadmessages_data.withsteamid, req_act_markreadmessages_data.deleteAllMessages);
        if (req_act_markreadmessages_data.withsteamid != null)
        {
            UpdateAndroidNotificationMessageRemove(req_act_markreadmessages_data.withsteamid);
            return;
        } else
        {
            UpdateAndroidNotificationMessageRemoveAll();
            return;
        }
    }

    public void SvcReq_SendMessage(SteamDBService.REQ_ACT_SENDMESSAGE_DATA req_act_sendmessage_data)
    {
        RequestUMQMessage requestumqmessage = new RequestUMQMessage();
        String s = (new StringBuilder()).append("?access_token=").append(req_act_sendmessage_data.mylogin.sOAuthToken).toString();
        if (m_sUMQID != null)
        {
            s = (new StringBuilder()).append(s).append("&umqid=").append(m_sUMQID).toString();
        }
        String s1 = (new StringBuilder()).append(s).append("&type=").append(req_act_sendmessage_data.msg.msgtype).toString();
        String s2 = (new StringBuilder()).append(s1).append("&steamid_dst=").append(req_act_sendmessage_data.msg.sWithSteamID).toString();
        if (req_act_sendmessage_data.msg.bindata != null && !req_act_sendmessage_data.msg.bindata.equals("") && (req_act_sendmessage_data.msg.msgtype.equals("saytext") || req_act_sendmessage_data.msg.msgtype.equals("emote")))
        {
            String s3 = Uri.encode(req_act_sendmessage_data.msg.bindata);
            s2 = (new StringBuilder()).append(s2).append("&text=").append(s3).toString();
        }
        requestumqmessage.SetObjData(req_act_sendmessage_data);
        requestumqmessage.SetPostData(s2);
        Intent intent = new Intent("com.valvesoftware.android.steam.community.SteamUmqCommunicationIntent");
        intent.putExtra("type", "chatmsg");
        intent.putExtra("action", "send");
        intent.putExtra("send", "starting");
        intent.putExtra("steamid", req_act_sendmessage_data.msg.sWithSteamID);
        if (req_act_sendmessage_data.intentcontext != null)
        {
            intent.putExtra("intentcontext", req_act_sendmessage_data.intentcontext);
        }
        m_svc.getApplicationContext().sendBroadcast(intent);
        m_svc.SubmitRequest(requestumqmessage);
    }

    public void SvcReq_SetUmqCommunicationSettings(SteamDBService.REQ_ACT_LOGININFO_DATA req_act_logininfo_data)
    {
        UmqCommand umqcommand = new UmqCommand();
        umqcommand.m_eCommand = UmqCommState.UMQ_LOGON;
        umqcommand.m_sOAuthToken = req_act_logininfo_data.sOAuthToken;
        umqcommand.m_sMySteamID = req_act_logininfo_data.sSteamID;
        AddCommandToQueue(umqcommand, true);
    }

    public void SvcReq_SettingChange(SteamDBService.REQ_ACT_SETTINGCHANGE_DATA req_act_settingchange_data)
    {
        boolean flag = true;
        if (!req_act_settingchange_data.sSettingKey.equals("notifications_im2")) goto _L2; else goto _L1
_L1:
        m_cmdCurrentLock.lock();
        m_c2dmIntentReceiver.m_c2dmShouldBeSentToServer = true;
        m_cmdCurrentLock.unlock();
_L4:
        return;
        Exception exception1;
        exception1;
        m_cmdCurrentLock.unlock();
        throw exception1;
_L2:
        if (!req_act_settingchange_data.sSettingKey.equals("notifications_ongoing")) goto _L4; else goto _L3
_L3:
        if (req_act_settingchange_data.sNewValue == null || req_act_settingchange_data.sNewValue.equals(""))
        {
            flag = false;
        }
        if (m_settingOngoingEnabled == flag) goto _L4; else goto _L5
_L5:
        m_cmdCurrentLock.lock();
        m_settingOngoingEnabled = flag;
        if (m_settingOngoingEnabled) goto _L7; else goto _L6
_L6:
        cancelOngoingNotification();
_L9:
        m_cmdCurrentLock.unlock();
        return;
_L7:
        UpdateAndroidNotificationPanelFromUmqState(m_eMyConnectionState, true);
        if (true) goto _L9; else goto _L8
_L8:
        Exception exception;
        exception;
        m_cmdCurrentLock.unlock();
        throw exception;
    }

    public void SvcReq_UmqActivity(SteamDBService.REQ_ACT_UMQACTIVITY_DATA req_act_umqactivity_data)
    {
        m_screenStateReceiver.m_timeLastApplicationActivity = System.currentTimeMillis();
        RetryLogonSignalMoreJobsAvailable(2);
    }

    public ISteamUmqCommunicationDatabase getDB()
    {
        return m_db;
    }

    static 
    {
        URI_RequestUMQLogon = (new StringBuilder()).append(Config.URL_WEBAPI_BASE).append("/ISteamWebUserPresenceOAuth/Logon/v0001").toString();
        URI_RequestUMQPollStatus = (new StringBuilder()).append(Config.URL_WEBAPI_BASE_INSECURE).append("/ISteamWebUserPresenceOAuth/PollStatus/v0001").toString();
        URI_RequestUMQPoll = (new StringBuilder()).append(Config.URL_WEBAPI_BASE).append("/ISteamWebUserPresenceOAuth/Poll/v0001").toString();
        URI_RequestUMQMessage = (new StringBuilder()).append(Config.URL_WEBAPI_BASE).append("/ISteamWebUserPresenceOAuth/Message/v0001").toString();
        URI_RequestUMQLogoff = (new StringBuilder()).append(Config.URL_WEBAPI_BASE).append("/ISteamWebUserPresenceOAuth/Logoff/v0001").toString();
        URI_RequestUMQDeviceInfo = (new StringBuilder()).append(Config.URL_WEBAPI_BASE).append("/ISteamWebUserPresenceOAuth/DeviceInfo/v0001").toString();
        URI_RequestUMQServerInfo = (new StringBuilder()).append(Config.URL_WEBAPI_BASE).append("/ISteamWebAPIUtil/GetServerInfo/v0001").toString();
    }




/*
    static String access$1102(String s)
    {
        m_sUMQID = s;
        return s;
    }

*/











/*
    static long access$2002(long l)
    {
        s_lastTimestampOnMessage = l;
        return l;
    }

*/










/*
    static CancelOngoingNotificationThread access$502(SteamUmqCommunicationService steamumqcommunicationservice, CancelOngoingNotificationThread cancelongoingnotificationthread)
    {
        steamumqcommunicationservice.m_cancelOngoingNotificationThread = cancelongoingnotificationthread;
        return cancelongoingnotificationthread;
    }

*/



}
