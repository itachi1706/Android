// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

// Referenced classes of package com.valvesoftware.android.steam.community:
//            SteamDebugUtilDatabase, SteamDBService, Config, SteamCommunityApplication

public class SteamDebugUtil extends ISteamDebugUtil.Helper
{
    final class UploaderRequest extends SteamWebApi.RequestBase
    {

        public SteamDebugUtilDatabase.CrashTrace m_CrashTrace;
        public boolean m_bFinished;
        public boolean m_bSucceeded;
        final _cls1 this$1;

        private void onUploaderFinished(boolean flag)
        {
            this;
            JVM INSTR monitorenter ;
            m_bFinished = true;
            m_bSucceeded = flag;
            notifyAll();
            this;
            JVM INSTR monitorexit ;
            return;
            Exception exception;
            exception;
            throw exception;
        }

        public void RequestFailedOnResponseWorkerThread()
        {
            onUploaderFinished(false);
        }

        public void RequestSucceededOnResponseWorkerThread()
        {
            onUploaderFinished(true);
        }

        public String buildPostData()
        {
            return m_CrashTrace.info;
        }

        public UploaderRequest(SteamDebugUtilDatabase.CrashTrace crashtrace)
        {
            this$1 = _cls1.this;
            super("SteamDebugUtilUploader");
            m_CrashTrace = crashtrace;
        }
    }

    public static class DebugUtilRecord
        implements ISteamDebugUtil.IDebugUtilRecord
    {

        long id;
        String key;
        ISteamDebugUtil.IDebugUtilRecord parent;
        long sessionstate;
        long threadid;
        Calendar timestamp;
        String value;

        public long getId()
        {
            return id;
        }

        public DebugUtilRecord()
        {
            timestamp = Calendar.getInstance();
            threadid = Thread.currentThread().getId();
        }
    }

    public static class Dummy_ISteamDebugUtil extends ISteamDebugUtil.Helper
    {

        public String getSessionId()
        {
            return "";
        }

        public ISteamDebugUtil.IDebugUtilRecord newDebugUtilRecord(ISteamDebugUtil.IDebugUtilRecord idebugutilrecord, String s, String s1)
        {
            return new DebugUtilRecord();
        }

        public Dummy_ISteamDebugUtil()
        {
        }
    }

    private static class Dummy_ISteamDebugUtil.DebugUtilRecord
        implements ISteamDebugUtil.IDebugUtilRecord
    {

        public long getId()
        {
            return -1L;
        }

        private Dummy_ISteamDebugUtil.DebugUtilRecord()
        {
        }

    }


    private ArrayList m_arrCommands;
    private DebugUtilRecord m_cmdCurrent;
    private final Condition m_cmdCurrentCond;
    private final Lock m_cmdCurrentLock = new ReentrantLock();
    private SteamDebugUtilDatabase m_db;
    private SteamDBService m_svc;
    private Thread m_thread;

    public SteamDebugUtil(SteamDBService steamdbservice)
    {
        m_svc = null;
        m_db = null;
        m_arrCommands = new ArrayList();
        m_cmdCurrent = null;
        m_cmdCurrentCond = m_cmdCurrentLock.newCondition();
        m_thread = null;
        if (steamdbservice != null)
        {
            SetServiceContext(steamdbservice);
            return;
        } else
        {
            DebugUtilRecord debugutilrecord = new DebugUtilRecord();
            debugutilrecord.key = "SteamDebugUtil";
            debugutilrecord.value = "Application Started";
            debugutilrecord.sessionstate = Calendar.getInstance().getTimeInMillis();
            AddCommandToQueue(debugutilrecord);
            return;
        }
    }

    private void AddCommandToQueue(DebugUtilRecord debugutilrecord)
    {
        AddCommandToQueue(debugutilrecord, false);
    }

    private void AddCommandToQueue(DebugUtilRecord debugutilrecord, final boolean bDbReadyNow)
    {
        m_cmdCurrentLock.lock();
        m_arrCommands.add(debugutilrecord);
        if (m_thread != null)
        {
            break MISSING_BLOCK_LABEL_106;
        }
        this;
        JVM INSTR monitorenter ;
        if (m_svc != null)
        {
            break MISSING_BLOCK_LABEL_46;
        }
        this;
        JVM INSTR monitorexit ;
        m_cmdCurrentLock.unlock();
        return;
        this;
        JVM INSTR monitorexit ;
        m_thread = new Thread() {

            final SteamDebugUtil this$0;
            final boolean val$bDbReadyNow;

            public void run()
            {
                if (bDbReadyNow)
                {
                    ProcessCrashesThreaded();
                }
                while (ProcessCommandsThreadedBlocking()) ;
            }

            
            {
                this$0 = SteamDebugUtil.this;
                bDbReadyNow = flag;
                super();
            }
        };
        m_thread.setName("SteamDebugUtilThread");
        m_thread.start();
_L1:
        m_cmdCurrentLock.unlock();
        return;
        Exception exception1;
        exception1;
        this;
        JVM INSTR monitorexit ;
        throw exception1;
        Exception exception;
        exception;
        m_cmdCurrentLock.unlock();
        throw exception;
        m_cmdCurrentCond.signalAll();
          goto _L1
    }

    private boolean ProcessCommandsThreadedBlocking()
    {
        m_cmdCurrentLock.lock();
        if (!m_arrCommands.isEmpty())
        {
            break MISSING_BLOCK_LABEL_35;
        }
        m_thread = null;
        m_cmdCurrentLock.unlock();
        return false;
        m_cmdCurrent = (DebugUtilRecord)m_arrCommands.get(0);
        m_arrCommands.remove(0);
        boolean flag;
        flag = true;
        m_cmdCurrentLock.unlock();
_L2:
        if (flag)
        {
            ProcessNextCommand();
        }
        return true;
        Exception exception1;
        exception1;
        m_cmdCurrentLock.unlock();
        flag = false;
        if (true) goto _L2; else goto _L1
_L1:
        Exception exception;
        exception;
        m_cmdCurrentLock.unlock();
        throw exception;
    }

    private void ProcessCrashesThreaded()
    {
        final ArrayList arrTraces = m_db.selectCrashTraces();
        if (arrTraces == null || arrTraces.isEmpty())
        {
            return;
        } else
        {
            Thread thread = new Thread() {

                final SteamDebugUtil this$0;
                final ArrayList val$arrTraces;

                public void run()
                {
                    int j;
                    int k;
                    int i = arrTraces.size();
                    j = 30;
                    k = i;
_L4:
                    int l;
                    UploaderRequest uploaderrequest;
                    l = k - 1;
                    if (k <= 0)
                    {
                        break MISSING_BLOCK_LABEL_191;
                    }
                    uploaderrequest = new UploaderRequest((SteamDebugUtilDatabase.CrashTrace)arrTraces.get(l));
                    uploaderrequest.SetUriAndDocumentType(Config.URL_MOBILE_CRASH_UPLOAD, SteamWebApi.RequestDocumentType.JSON);
                    uploaderrequest.SetPostData(uploaderrequest.buildPostData());
                    uploaderrequest.SetRequestAction(SteamWebApi.RequestActionType.DoHttpRequestNoCache);
                    uploaderrequest;
                    JVM INSTR monitorenter ;
                    SteamCommunityApplication.GetInstance().SubmitSteamDBRequest(uploaderrequest);
_L1:
                    boolean flag = uploaderrequest.m_bFinished;
label0:
                    {
                        if (flag)
                        {
                            break label0;
                        }
                        long l1;
                        try
                        {
                            uploaderrequest.wait();
                        }
                        catch (InterruptedException interruptedexception1) { }
                        finally { }
                    }
                      goto _L1
                    if (!uploaderrequest.m_bSucceeded)
                    {
                        break MISSING_BLOCK_LABEL_157;
                    }
                    j = 30;
                    m_db.updateMarkCrashTraceUploaded(uploaderrequest.m_CrashTrace);
_L2:
                    uploaderrequest;
                    JVM INSTR monitorexit ;
                    l1 = j * 1000;
                    Exception exception;
                    try
                    {
                        Thread.sleep(l1);
                    }
                    catch (InterruptedException interruptedexception) { }
                    k = l;
                    continue; /* Loop/switch isn't completed */
                    j *= 2;
                    if (j > 10800)
                    {
                        j = 10800;
                    }
                    l++;
                      goto _L2
                    uploaderrequest;
                    JVM INSTR monitorexit ;
                    throw exception;
                    return;
                    if (true) goto _L4; else goto _L3
_L3:
                }

            
            {
                this$0 = SteamDebugUtil.this;
                arrTraces = arraylist;
                super();
            }
            };
            thread.setName("SteamDebugUtilUploader");
            thread.start();
            return;
        }
    }

    private void ProcessNextCommand()
    {
        m_db.insertMessage(m_cmdCurrent);
    }

    public void SetServiceContext(SteamDBService steamdbservice)
    {
        m_db = new SteamDebugUtilDatabase(steamdbservice.getApplicationContext());
        this;
        JVM INSTR monitorenter ;
        m_svc = steamdbservice;
        this;
        JVM INSTR monitorexit ;
        DebugUtilRecord debugutilrecord = new DebugUtilRecord();
        debugutilrecord.key = "SteamDebugUtil";
        debugutilrecord.value = "DB Started";
        AddCommandToQueue(debugutilrecord, true);
        return;
        Exception exception;
        exception;
        this;
        JVM INSTR monitorexit ;
        throw exception;
    }

    public String getSessionId()
    {
        return m_db.getDbName();
    }

    public ISteamDebugUtil.IDebugUtilRecord newDebugUtilRecord(ISteamDebugUtil.IDebugUtilRecord idebugutilrecord, String s, String s1)
    {
        DebugUtilRecord debugutilrecord = new DebugUtilRecord();
        debugutilrecord.parent = idebugutilrecord;
        debugutilrecord.key = s;
        debugutilrecord.value = s1;
        AddCommandToQueue(debugutilrecord);
        return debugutilrecord;
    }



}
