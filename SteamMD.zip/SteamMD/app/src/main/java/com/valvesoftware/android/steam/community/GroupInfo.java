// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;


// Referenced classes of package com.valvesoftware.android.steam.community:
//            GenericListDB

public class GroupInfo extends GenericListDB.GenericListItem
{
    public static final class GroupCategoryInList extends Enum
    {

        private static final GroupCategoryInList $VALUES[];
        public static final GroupCategoryInList OFFICIAL;
        public static final GroupCategoryInList PRIVATE;
        public static final GroupCategoryInList PUBLIC;
        public static final GroupCategoryInList REQUEST_INVITE;
        public static final GroupCategoryInList SEARCH_ALL;

        public static GroupCategoryInList valueOf(String s)
        {
            return (GroupCategoryInList)Enum.valueOf(com/valvesoftware/android/steam/community/GroupInfo$GroupCategoryInList, s);
        }

        public static GroupCategoryInList[] values()
        {
            return (GroupCategoryInList[])$VALUES.clone();
        }

        public int GetDisplayString()
        {
            static class _cls1
            {

                static final int $SwitchMap$com$valvesoftware$android$steam$community$GroupInfo$GroupCategoryInList[];

                static 
                {
                    $SwitchMap$com$valvesoftware$android$steam$community$GroupInfo$GroupCategoryInList = new int[GroupCategoryInList.values().length];
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$GroupInfo$GroupCategoryInList[GroupCategoryInList.REQUEST_INVITE.ordinal()] = 1;
                    }
                    catch (NoSuchFieldError nosuchfielderror) { }
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$GroupInfo$GroupCategoryInList[GroupCategoryInList.OFFICIAL.ordinal()] = 2;
                    }
                    catch (NoSuchFieldError nosuchfielderror1) { }
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$GroupInfo$GroupCategoryInList[GroupCategoryInList.PRIVATE.ordinal()] = 3;
                    }
                    catch (NoSuchFieldError nosuchfielderror2) { }
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$GroupInfo$GroupCategoryInList[GroupCategoryInList.PUBLIC.ordinal()] = 4;
                    }
                    catch (NoSuchFieldError nosuchfielderror3) { }
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$GroupInfo$GroupCategoryInList[GroupCategoryInList.SEARCH_ALL.ordinal()] = 5;
                    }
                    catch (NoSuchFieldError nosuchfielderror4)
                    {
                        return;
                    }
                }
            }

            switch (_cls1..SwitchMap.com.valvesoftware.android.steam.community.GroupInfo.GroupCategoryInList[ordinal()])
            {
            default:
                return 0x7f070027;

            case 1: // '\001'
                return 0x7f070060;

            case 2: // '\002'
                return 0x7f070061;

            case 3: // '\003'
                return 0x7f070063;

            case 4: // '\004'
                return 0x7f070062;

            case 5: // '\005'
                return 0x7f070004;
            }
        }

        static 
        {
            REQUEST_INVITE = new GroupCategoryInList("REQUEST_INVITE", 0);
            PRIVATE = new GroupCategoryInList("PRIVATE", 1);
            PUBLIC = new GroupCategoryInList("PUBLIC", 2);
            OFFICIAL = new GroupCategoryInList("OFFICIAL", 3);
            SEARCH_ALL = new GroupCategoryInList("SEARCH_ALL", 4);
            GroupCategoryInList agroupcategoryinlist[] = new GroupCategoryInList[5];
            agroupcategoryinlist[0] = REQUEST_INVITE;
            agroupcategoryinlist[1] = PRIVATE;
            agroupcategoryinlist[2] = PUBLIC;
            agroupcategoryinlist[3] = OFFICIAL;
            agroupcategoryinlist[4] = SEARCH_ALL;
            $VALUES = agroupcategoryinlist;
        }

        private GroupCategoryInList(String s, int i)
        {
            super(s, i);
        }
    }

    public static final class GroupRelationship extends Enum
    {

        private static final GroupRelationship $VALUES[];
        public static final GroupRelationship Blocked;
        public static final GroupRelationship Invited;
        public static final GroupRelationship Kicked;
        public static final GroupRelationship Member;
        public static final GroupRelationship None;

        public static GroupRelationship valueOf(String s)
        {
            return (GroupRelationship)Enum.valueOf(com/valvesoftware/android/steam/community/GroupInfo$GroupRelationship, s);
        }

        public static GroupRelationship[] values()
        {
            return (GroupRelationship[])$VALUES.clone();
        }

        static 
        {
            None = new GroupRelationship("None", 0);
            Blocked = new GroupRelationship("Blocked", 1);
            Invited = new GroupRelationship("Invited", 2);
            Member = new GroupRelationship("Member", 3);
            Kicked = new GroupRelationship("Kicked", 4);
            GroupRelationship agrouprelationship[] = new GroupRelationship[5];
            agrouprelationship[0] = None;
            agrouprelationship[1] = Blocked;
            agrouprelationship[2] = Invited;
            agrouprelationship[3] = Member;
            agrouprelationship[4] = Kicked;
            $VALUES = agrouprelationship;
        }

        private GroupRelationship(String s, int i)
        {
            super(s, i);
        }
    }

    public static final class GroupType extends Enum
    {

        private static final GroupType $VALUES[];
        public static final GroupType DISABLED;
        public static final GroupType LOCKED;
        public static final GroupType OFFICIAL;
        public static final GroupType PRIVATE;
        public static final GroupType PUBLIC;

        public static GroupType FromInteger(int i)
        {
            switch (i)
            {
            default:
                return PRIVATE;

            case 0: // '\0'
                return PRIVATE;

            case 1: // '\001'
                return PUBLIC;

            case 2: // '\002'
                return LOCKED;

            case 3: // '\003'
                return DISABLED;

            case 4: // '\004'
                return OFFICIAL;
            }
        }

        public static GroupType valueOf(String s)
        {
            return (GroupType)Enum.valueOf(com/valvesoftware/android/steam/community/GroupInfo$GroupType, s);
        }

        public static GroupType[] values()
        {
            return (GroupType[])$VALUES.clone();
        }

        static 
        {
            PRIVATE = new GroupType("PRIVATE", 0);
            PUBLIC = new GroupType("PUBLIC", 1);
            LOCKED = new GroupType("LOCKED", 2);
            DISABLED = new GroupType("DISABLED", 3);
            OFFICIAL = new GroupType("OFFICIAL", 4);
            GroupType agrouptype[] = new GroupType[5];
            agrouptype[0] = PRIVATE;
            agrouptype[1] = PUBLIC;
            agrouptype[2] = LOCKED;
            agrouptype[3] = DISABLED;
            agrouptype[4] = OFFICIAL;
            $VALUES = agrouptype;
        }

        private GroupType(String s, int i)
        {
            super(s, i);
        }
    }


    public int m_appidFavorite;
    public String m_avatarMediumURL;
    public GroupCategoryInList m_categoryInList;
    public String m_groupName;
    public GroupType m_groupType;
    public int m_numMembersOnline;
    public int m_numMembersTotal;
    public String m_profileURL;
    public GroupRelationship m_relationship;

    public GroupInfo()
    {
        m_groupType = GroupType.PRIVATE;
        m_categoryInList = GroupCategoryInList.PUBLIC;
        m_relationship = GroupRelationship.None;
        m_appidFavorite = 0;
    }

    public boolean HasPresentationData()
    {
        return m_profileURL != null;
    }

    protected GenericListDB.GenericListItem.RequestForAvatarImage RequestAvatarImage(GenericListDB genericlistdb)
    {
        return GetRequestForAvatarImage("JobQueueAvatarsGroups", m_avatarSmallURL, m_steamID.toString(), genericlistdb);
    }
}
