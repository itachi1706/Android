// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

// Referenced classes of package com.valvesoftware.android.steam.community:
//            SteamCommunityApplication, SettingInfoDB, SettingInfo, SteamUmqCommunicationService

private static class <init> extends BroadcastReceiver
{

    public boolean m_c2dmClientPushIsActive;
    public String m_c2dmRegistrationId;
    public String m_c2dmRegistrationLanguage;
    public boolean m_c2dmShouldBeSentToServer;

    public boolean isClientPushActive()
    {
        String s = m_c2dmRegistrationId;
        boolean flag = false;
        if (s != null)
        {
            boolean flag1 = m_c2dmRegistrationId.equals("");
            flag = false;
            if (!flag1)
            {
                int i = SteamCommunityApplication.GetInstance().GetSettingInfoDB().m_settingNotificationsIMs2.getRadioSelectorItemValue(SteamCommunityApplication.GetInstance().getApplicationContext()).e;
                flag = false;
                if (i > 0)
                {
                    flag = true;
                }
            }
        }
        return flag;
    }

    public void onReceive(Context context, Intent intent)
    {
        String s = intent.getStringExtra("registration.id");
        if (s != null && !s.equals(""))
        {
            m_c2dmRegistrationId = s;
            m_c2dmShouldBeSentToServer = true;
        }
    }

    private Q()
    {
        m_c2dmRegistrationId = null;
        m_c2dmRegistrationLanguage = null;
        m_c2dmShouldBeSentToServer = true;
        m_c2dmClientPushIsActive = false;
    }

    m_c2dmClientPushIsActive(m_c2dmClientPushIsActive m_c2dmclientpushisactive)
    {
        this();
    }
}
