// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;


// Referenced classes of package com.valvesoftware.android.steam.community:
//            SteamDBService, WorkerThreadPool

public class this._cls0 extends this._cls0
{

    final SteamDBService this$0;

    protected void WriteToCacheInBackground(this._cls0 _pcls0)
    {
        SteamDBService.access$000(SteamDBService.this).AddTask(new t>(m_request.fo(), _pcls0.fo()));
    }

    public ( )
    {
        this$0 = SteamDBService.this;
        super();
    }
}
