// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;

import android.content.Context;
import android.content.Intent;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Iterator;
import java.util.concurrent.ConcurrentHashMap;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

// Referenced classes of package com.valvesoftware.android.steam.community:
//            GenericListDB, FriendInfo, SteamCommunityApplication, SteamDBService, 
//            SteamWebApi, ISteamUmqCommunicationDatabase

public class FriendInfoDB extends GenericListDB
{
    public static final class ChatsUpdateType extends Enum
    {

        private static final ChatsUpdateType $VALUES[];
        public static final ChatsUpdateType clear;
        public static final ChatsUpdateType mark_read;
        public static final ChatsUpdateType msg_incoming;
        public static final ChatsUpdateType msg_sent;

        public static ChatsUpdateType valueOf(String s)
        {
            return (ChatsUpdateType)Enum.valueOf(com/valvesoftware/android/steam/community/FriendInfoDB$ChatsUpdateType, s);
        }

        public static ChatsUpdateType[] values()
        {
            return (ChatsUpdateType[])$VALUES.clone();
        }

        static 
        {
            clear = new ChatsUpdateType("clear", 0);
            mark_read = new ChatsUpdateType("mark_read", 1);
            msg_sent = new ChatsUpdateType("msg_sent", 2);
            msg_incoming = new ChatsUpdateType("msg_incoming", 3);
            ChatsUpdateType achatsupdatetype[] = new ChatsUpdateType[4];
            achatsupdatetype[0] = clear;
            achatsupdatetype[1] = mark_read;
            achatsupdatetype[2] = msg_sent;
            achatsupdatetype[3] = msg_incoming;
            $VALUES = achatsupdatetype;
        }

        private ChatsUpdateType(String s, int i)
        {
            super(s, i);
        }
    }


    private String m_sActiveChatPartnerSteamId;

    public FriendInfoDB()
    {
        m_sActiveChatPartnerSteamId = null;
    }

    public void ChatsWithUserUpdate(String s, int i, ChatsUpdateType chatsupdatetype, int j)
    {
        if (s != null && !s.equals("") && !s.equals("0")) goto _L2; else goto _L1
_L1:
        static class _cls1
        {

            static final int $SwitchMap$com$valvesoftware$android$steam$community$FriendInfoDB$ChatsUpdateType[];

            static 
            {
                $SwitchMap$com$valvesoftware$android$steam$community$FriendInfoDB$ChatsUpdateType = new int[ChatsUpdateType.values().length];
                try
                {
                    $SwitchMap$com$valvesoftware$android$steam$community$FriendInfoDB$ChatsUpdateType[ChatsUpdateType.mark_read.ordinal()] = 1;
                }
                catch (NoSuchFieldError nosuchfielderror) { }
                try
                {
                    $SwitchMap$com$valvesoftware$android$steam$community$FriendInfoDB$ChatsUpdateType[ChatsUpdateType.clear.ordinal()] = 2;
                }
                catch (NoSuchFieldError nosuchfielderror1) { }
                try
                {
                    $SwitchMap$com$valvesoftware$android$steam$community$FriendInfoDB$ChatsUpdateType[ChatsUpdateType.msg_sent.ordinal()] = 3;
                }
                catch (NoSuchFieldError nosuchfielderror2) { }
                try
                {
                    $SwitchMap$com$valvesoftware$android$steam$community$FriendInfoDB$ChatsUpdateType[ChatsUpdateType.msg_incoming.ordinal()] = 4;
                }
                catch (NoSuchFieldError nosuchfielderror3)
                {
                    return;
                }
            }
        }

        _cls1..SwitchMap.com.valvesoftware.android.steam.community.FriendInfoDB.ChatsUpdateType[chatsupdatetype.ordinal()];
        JVM INSTR tableswitch 1 1: default 48
    //                   1 49;
           goto _L3 _L4
_L3:
        return;
_L4:
        Iterator iterator = GetItemsMap().values().iterator();
        while (iterator.hasNext()) 
        {
            ((FriendInfo)(GenericListDB.GenericListItem)iterator.next()).m_chatInfo.numUnreadMsgs = 0;
        }
        if (true) goto _L3; else goto _L2
_L2:
        Long long1;
        FriendInfo friendinfo;
        long1 = Long.valueOf(s);
        friendinfo = GetFriendInfo(long1);
        if (friendinfo == null) goto _L3; else goto _L5
_L5:
        _cls1..SwitchMap.com.valvesoftware.android.steam.community.FriendInfoDB.ChatsUpdateType[chatsupdatetype.ordinal()];
        JVM INSTR tableswitch 1 4: default 152
    //                   1 230
    //                   2 180
    //                   3 253
    //                   4 300;
           goto _L6 _L7 _L8 _L9 _L10
_L6:
        ArrayList arraylist = new ArrayList();
        arraylist.add(long1);
        m_eventBroadcaster.OnListItemInfoUpdated(arraylist, true);
        return;
_L8:
        if (friendinfo.m_chatInfo.numMsgsTotal == 0) goto _L3; else goto _L11
_L11:
        friendinfo.m_chatInfo.numMsgsTotal = 0;
        friendinfo.m_chatInfo.numUnreadMsgs = 0;
        friendinfo.m_chatInfo.latestTimestamp = null;
        friendinfo.m_chatInfo.latestMsgId = 0;
          goto _L6
_L7:
        if (friendinfo.m_chatInfo.numUnreadMsgs == 0) goto _L3; else goto _L12
_L12:
        friendinfo.m_chatInfo.numUnreadMsgs = 0;
          goto _L6
_L9:
        ISteamUmqCommunicationDatabase.UserConversationInfo userconversationinfo2 = friendinfo.m_chatInfo;
        userconversationinfo2.numMsgsTotal = j + userconversationinfo2.numMsgsTotal;
        friendinfo.m_chatInfo.latestTimestamp = Calendar.getInstance();
        if (i > 0)
        {
            friendinfo.m_chatInfo.latestMsgId = i;
        }
          goto _L6
_L10:
        ISteamUmqCommunicationDatabase.UserConversationInfo userconversationinfo = friendinfo.m_chatInfo;
        userconversationinfo.numUnreadMsgs = j + userconversationinfo.numUnreadMsgs;
        ISteamUmqCommunicationDatabase.UserConversationInfo userconversationinfo1 = friendinfo.m_chatInfo;
        userconversationinfo1.numMsgsTotal = j + userconversationinfo1.numMsgsTotal;
        friendinfo.m_chatInfo.latestTimestamp = Calendar.getInstance();
        if (i > 0)
        {
            friendinfo.m_chatInfo.latestMsgId = i;
        }
          goto _L6
    }

    public FriendInfo GetFriendInfo(Long long1)
    {
        return (FriendInfo)m_itemsMap.get(long1);
    }

    protected FriendInfo GetOrAllocateNewFriendInfo(String s)
    {
        Long long1 = Long.valueOf(s);
        FriendInfo friendinfo = (FriendInfo)m_itemsMap.get(long1);
        if (friendinfo == null)
        {
            friendinfo = new FriendInfo();
            friendinfo.m_steamID = long1;
            friendinfo.m_chatInfo = SteamCommunityApplication.GetInstance().GetSteamDB().getSteamUmqCommunicationServiceDB().selectUserConversationInfo(SteamWebApi.GetLoginSteamID(), s);
            m_itemsMap.put(long1, friendinfo);
        }
        return friendinfo;
    }

    protected void HandleItemSummaryDocument(SteamWebApi.RequestBase requestbase)
    {
        JSONObject jsonobject = requestbase.GetJSONDocument();
        if (jsonobject != null)
        {
            JSONArray jsonarray;
            ArrayList arraylist;
            int i;
            try
            {
                jsonarray = jsonobject.getJSONArray("players");
            }
            catch (Exception exception)
            {
                return;
            }
            arraylist = new ArrayList();
            i = 0;
            while (i < jsonarray.length()) 
            {
                try
                {
                    JSONObject jsonobject1 = jsonarray.getJSONObject(i);
                    String s = jsonobject1.getString("steamid");
                    StoreItemSummaryDocumentInCache(s, jsonobject1.toString());
                    HandleItemSummaryDocument(jsonobject1, s);
                    arraylist.add(Long.valueOf(s));
                }
                catch (Exception exception1) { }
                i++;
            }
            if (!arraylist.isEmpty())
            {
                m_eventBroadcaster.OnListItemInfoUpdated(arraylist, true);
                return;
            }
        }
    }

    protected void HandleItemSummaryDocument(JSONObject jsonobject, String s)
    {
        FriendInfo friendinfo = GetOrAllocateNewFriendInfo(s);
        friendinfo.m_personaName = jsonobject.optString("personaname");
        friendinfo.m_realName = jsonobject.optString("realname");
        friendinfo.m_avatarSmallURL = jsonobject.optString("avatar");
        friendinfo.m_personaState = FriendInfo.PersonaState.FromInteger(jsonobject.optInt("personastate"));
        friendinfo.m_currentGameID = jsonobject.optInt("gameid");
        friendinfo.m_currentGameString = jsonobject.optString("gameextrainfo");
        friendinfo.m_lastOnlineTime = jsonobject.optInt("lastlogoff");
        if (friendinfo.m_relationship == FriendInfo.FriendRelationship.myself && !friendinfo.IsAvatarSmallLoaded())
        {
            RequestAvatarImageImmediately(friendinfo);
        }
    }

    protected void HandleListRefreshDocument(SteamWebApi.RequestBase requestbase, boolean flag)
    {
        JSONObject jsonobject = requestbase.GetJSONDocument();
        if (jsonobject == null)
        {
            return;
        }
        JSONArray jsonarray;
        int i;
        ArrayList arraylist;
        ArrayList arraylist1;
        String s;
        int j;
        try
        {
            jsonarray = jsonobject.getJSONArray("friends");
        }
        catch (JSONException jsonexception)
        {
            return;
        }
        i = jsonarray.length();
        arraylist = new ArrayList();
        arraylist1 = new ArrayList(m_itemsMap.keySet());
        s = SteamWebApi.GetLoginSteamID();
        if (s != null)
        {
            arraylist.add(s);
            arraylist1.remove(Long.valueOf(s));
            GetOrAllocateNewFriendInfo(s).m_relationship = FriendInfo.FriendRelationship.myself;
        }
        j = 0;
label0:
        do
        {
label1:
            {
                if (j >= i)
                {
                    break label0;
                }
                String s1;
                FriendInfo.FriendRelationship friendrelationship;
                try
                {
                    s1 = jsonarray.getJSONObject(j).getString("steamid");
                    friendrelationship = FriendInfo.FriendRelationship.valueOf(jsonarray.getJSONObject(j).getString("relationship"));
                }
                catch (Exception exception)
                {
                    break label1;
                }
                if (friendrelationship == FriendInfo.FriendRelationship.friend || friendrelationship == FriendInfo.FriendRelationship.requestrecipient)
                {
                    arraylist.add(s1);
                    arraylist1.remove(Long.valueOf(s1));
                    GetOrAllocateNewFriendInfo(s1).m_relationship = friendrelationship;
                }
            }
            j++;
        } while (true);
        RemoveOldItemList(arraylist1);
        String as[] = new String[arraylist.size()];
        arraylist.toArray(as);
        IssueItemSummaryRequest(as, flag);
    }

    public void IncrementUnreadChatsWithUser(String s)
    {
        Long long1 = Long.valueOf(s);
        FriendInfo friendinfo = GetFriendInfo(long1);
        if (friendinfo != null)
        {
            ISteamUmqCommunicationDatabase.UserConversationInfo userconversationinfo = friendinfo.m_chatInfo;
            userconversationinfo.numUnreadMsgs = 1 + userconversationinfo.numUnreadMsgs;
            ISteamUmqCommunicationDatabase.UserConversationInfo userconversationinfo1 = friendinfo.m_chatInfo;
            userconversationinfo1.numMsgsTotal = 1 + userconversationinfo1.numMsgsTotal;
            friendinfo.m_chatInfo.latestTimestamp = Calendar.getInstance();
            ArrayList arraylist = new ArrayList();
            arraylist.add(long1);
            m_eventBroadcaster.OnListItemInfoUpdated(arraylist, true);
        }
    }

    protected SteamWebApi.RequestBase IssueFullListRefreshRequest(boolean flag)
    {
        return SteamWebApi.GetRequestForFriendListByOwnerSteamID(SteamWebApi.GetLoginSteamID(), flag);
    }

    protected SteamWebApi.RequestBase IssueSingleItemSummaryRequest(String as[])
    {
        return SteamWebApi.GetRequestForUserSummariesBySteamIDs(as);
    }

    public void onReceive(Context context, Intent intent)
    {
        if (!"com.valvesoftware.android.steam.community.SteamUmqCommunicationIntent".equals(intent.getAction())) goto _L2; else goto _L1
_L1:
        String s = intent.getStringExtra("type");
        if (!s.equalsIgnoreCase("personastate") || !HasLiveItemData()) goto _L4; else goto _L3
_L3:
        boolean flag;
        String as[];
        flag = m_bAutoRefreshIfDataMightBeStale;
        as = null;
        if (flag) goto _L6; else goto _L5
_L5:
        String s1;
        s1 = m_sActiveChatPartnerSteamId;
        as = null;
        if (s1 == null) goto _L6; else goto _L7
_L7:
        String as1[];
        int i;
        int j;
        as = null;
        if (true)
        {
            as = intent.getStringArrayExtra("steamids");
        }
        as1 = as;
        i = as1.length;
        j = 0;
_L19:
        if (j >= i) goto _L6; else goto _L8
_L8:
        if (!as1[j].equals(m_sActiveChatPartnerSteamId)) goto _L10; else goto _L9
_L9:
        flag = true;
_L6:
        if (!flag) goto _L12; else goto _L11
_L11:
        if (as == null)
        {
            as = intent.getStringArrayExtra("steamids");
        }
        IssueItemSummaryRequest(as, false);
_L14:
        return;
_L10:
        j++;
        continue; /* Loop/switch isn't completed */
_L12:
        m_bDataMightBeStale = true;
        return;
_L4:
        if (!s.equalsIgnoreCase("personarelationship") || !HasLiveItemData())
        {
            continue; /* Loop/switch isn't completed */
        }
        m_bDataMightBeStale = true;
        if (!m_bAutoRefreshIfDataMightBeStale) goto _L14; else goto _L13
_L13:
        RefreshFromHttpIfDataMightBeStale();
        return;
        if (!s.equalsIgnoreCase("umqstate")) goto _L14; else goto _L15
_L15:
        if ("active".equals(intent.getStringExtra("old_state")))
        {
            m_bDataMightBeStale = true;
            return;
        }
        if (!m_bDataMightBeStale || !"active".equals(intent.getStringExtra("state"))) goto _L14; else goto _L16
_L16:
        if (m_bAutoRefreshIfDataMightBeStale)
        {
            m_bDataMightBeStale = false;
            RefreshFromHttpOnly();
            return;
        }
        if (m_sActiveChatPartnerSteamId == null) goto _L14; else goto _L17
_L17:
        setActiveChatPartnerSteamId(m_sActiveChatPartnerSteamId);
        return;
_L2:
        super.onReceive(context, intent);
        return;
        if (true) goto _L19; else goto _L18
_L18:
    }

    public void setActiveChatPartnerSteamId(String s)
    {
        m_sActiveChatPartnerSteamId = s;
        if (m_sActiveChatPartnerSteamId != null && m_bDataMightBeStale)
        {
            String as[] = new String[1];
            as[0] = m_sActiveChatPartnerSteamId;
            IssueItemSummaryRequest(as, false);
        }
    }
}
