// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.fragment;


// Referenced classes of package com.valvesoftware.android.steam.community.fragment:
//            NavigationFragment

public static abstract class 
{

    public boolean m_bShowIfNotSignedIn;
    public int resid_category;
    public int resid_icon;

    public abstract String getDetails();

    public abstract int getName();

    public abstract void onClick();

    public ()
    {
    }
}
