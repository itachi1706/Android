// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Calendar;

// Referenced classes of package com.valvesoftware.android.steam.community:
//            ISteamUmqCommunicationDatabase

public class SteamUmqCommunicationDatabase
    implements ISteamUmqCommunicationDatabase
{
    private class DbOpenHelper extends SQLiteOpenHelper
    {

        final SteamUmqCommunicationDatabase this$0;

        public void onCreate(SQLiteDatabase sqlitedatabase)
        {
            sqlitedatabase.execSQL("CREATE TABLE UmqMsg (   _id integer primary key autoincrement , myuser1 integer not null , myuser2 integer not null , wuser1 integer not null , wuser2 integer not null , msgincoming integer not null , msgunread integer not null , msgtime integer not null , msgtype text not null , bindata text not null  )");
            sqlitedatabase.execSQL("CREATE INDEX idxMyUser ON UmqMsg ( myuser1,myuser2 )");
            sqlitedatabase.execSQL("CREATE INDEX idxWUser ON UmqMsg ( wuser1,wuser2 )");
            sqlitedatabase.execSQL("CREATE INDEX idxUnread ON UmqMsg ( msgunread )");
            sqlitedatabase.execSQL("CREATE INDEX idxTime ON UmqMsg ( msgtime )");
            sqlitedatabase.execSQL("CREATE TABLE UmqInfo (   id1 integer not null , id2 integer not null , name text not null  )");
            sqlitedatabase.execSQL("CREATE UNIQUE INDEX idxUserInfoId ON UmqInfo ( id1,id2 )");
        }

        public void onUpgrade(SQLiteDatabase sqlitedatabase, int i, int j)
        {
            sqlitedatabase.execSQL("DROP TABLE if exists UmqMsg");
            onCreate(sqlitedatabase);
        }

        public DbOpenHelper(Context context)
        {
            this$0 = SteamUmqCommunicationDatabase.this;
            super(context, "umqcomm.db", null, 2);
        }
    }


    private static final BigInteger BIGINT_STEAMID32BIT = BigInteger.valueOf(0x100000000L);
    private static final BigInteger BIGINT_STEAMID_HIGHBIT = BigInteger.valueOf(0x80000000L);
    private static final String DB_C_MSG_BINDATA = "bindata";
    private static final String DB_C_MSG_ID = "_id";
    private static final String DB_C_MSG_INCOMING = "msgincoming";
    private static final String DB_C_MSG_MYUSER1 = "myuser1";
    private static final String DB_C_MSG_MYUSER2 = "myuser2";
    private static final String DB_C_MSG_TIME = "msgtime";
    private static final String DB_C_MSG_TYPE = "msgtype";
    private static final String DB_C_MSG_UNREAD = "msgunread";
    private static final String DB_C_MSG_WUSER1 = "wuser1";
    private static final String DB_C_MSG_WUSER2 = "wuser2";
    private static final String DB_C_USERINFO_ID1 = "id1";
    private static final String DB_C_USERINFO_ID2 = "id2";
    private static final String DB_C_USERINFO_NAME = "name";
    private static final String DB_IDX_MSG_MYUSER = "idxMyUser";
    private static final String DB_IDX_MSG_TIME = "idxTime";
    private static final String DB_IDX_MSG_UNREAD = "idxUnread";
    private static final String DB_IDX_MSG_WUSER = "idxWUser";
    private static final String DB_IDX_USERINFO_ID = "idxUserInfoId";
    private static final String DB_NAME = "umqcomm.db";
    private static final String DB_T_MSG = "UmqMsg";
    private static final String DB_T_USERINFO = "UmqInfo";
    private static final int DB_VERSION = 2;
    private static final String SQL_SELECT_INFO_TEMPLATE = "SELECT id1, id2, name FROM UmqInfo WHERE ";
    private static final String SQL_SELECT_MSG_TEMPLATE = "SELECT _id, myuser1,myuser2,wuser1,wuser2,msgincoming,msgunread,msgtime,msgtype,bindata FROM UmqMsg WHERE ";
    private SQLiteStatement dbStmt_SQL_DELETE_MSG_WITH_ALL;
    private SQLiteStatement dbStmt_SQL_DELETE_MSG_WITH_USER;
    private SQLiteStatement dbStmt_SQL_INSERT_INFO;
    private SQLiteStatement dbStmt_SQL_INSERT_MSG;
    private SQLiteStatement dbStmt_SQL_SELECT_MSG_UNREAD_COUNT;
    private SQLiteStatement dbStmt_SQL_SELECT_MSG_UNREAD_COUNT_WITH_USER;
    private SQLiteStatement dbStmt_SQL_UPDATE_MSG_UNREAD_WITH_ALL;
    private SQLiteStatement dbStmt_SQL_UPDATE_MSG_UNREAD_WITH_USER;
    private Context m_context;
    private SQLiteDatabase m_db;
    private DbOpenHelper m_helper;

    public SteamUmqCommunicationDatabase(Context context)
    {
        dbStmt_SQL_INSERT_MSG = null;
        dbStmt_SQL_SELECT_MSG_UNREAD_COUNT = null;
        dbStmt_SQL_SELECT_MSG_UNREAD_COUNT_WITH_USER = null;
        dbStmt_SQL_UPDATE_MSG_UNREAD_WITH_USER = null;
        dbStmt_SQL_DELETE_MSG_WITH_USER = null;
        dbStmt_SQL_UPDATE_MSG_UNREAD_WITH_ALL = null;
        dbStmt_SQL_DELETE_MSG_WITH_ALL = null;
        dbStmt_SQL_INSERT_INFO = null;
        m_context = context;
        m_helper = new DbOpenHelper(m_context);
        m_db = m_helper.getWritableDatabase();
    }

    private static Calendar dateFromDbTimestamp(int i)
    {
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(1000L * (long)i);
        return calendar;
    }

    private ArrayList selectInfoWhere(String s)
    {
        String s1 = (new StringBuilder()).append("SELECT id1, id2, name FROM UmqInfo WHERE ").append(s).toString();
        return selectProcessInfo(m_db.rawQuery(s1, null));
    }

    private ArrayList selectMessagesWhere(String s)
    {
        String s1 = (new StringBuilder()).append("SELECT _id, myuser1,myuser2,wuser1,wuser2,msgincoming,msgunread,msgtime,msgtype,bindata FROM UmqMsg WHERE ").append(s).toString();
        return selectProcessCursor(m_db.rawQuery(s1, null));
    }

    private ArrayList selectProcessCursor(Cursor cursor)
    {
        ArrayList arraylist = new ArrayList();
        cursor.moveToFirst();
        for (; !cursor.isAfterLast(); cursor.moveToNext())
        {
            arraylist.add(selectProcessSingleMessage(cursor));
        }

        cursor.close();
        return arraylist;
    }

    private ArrayList selectProcessInfo(Cursor cursor)
    {
        ArrayList arraylist = new ArrayList();
        cursor.moveToFirst();
        for (; !cursor.isAfterLast(); cursor.moveToNext())
        {
            arraylist.add(selectProcessSingleInfo(cursor));
        }

        cursor.close();
        return arraylist;
    }

    private ISteamUmqCommunicationDatabase.UmqInfo selectProcessSingleInfo(Cursor cursor)
    {
        ISteamUmqCommunicationDatabase.UmqInfo umqinfo = new ISteamUmqCommunicationDatabase.UmqInfo();
        umqinfo.steamid = steamidJoin(cursor.getInt(0), cursor.getInt(1));
        umqinfo.name = cursor.getString(2);
        return umqinfo;
    }

    private ISteamUmqCommunicationDatabase.Message selectProcessSingleMessage(Cursor cursor)
    {
        boolean flag = true;
        ISteamUmqCommunicationDatabase.Message message = new ISteamUmqCommunicationDatabase.Message();
        message.id = cursor.getInt(0);
        message.sMySteamID = steamidJoin(cursor.getInt(flag), cursor.getInt(2));
        message.sWithSteamID = steamidJoin(cursor.getInt(3), cursor.getInt(4));
        boolean flag1;
        if (cursor.getInt(5) != 0)
        {
            flag1 = flag;
        } else
        {
            flag1 = false;
        }
        message.bIncoming = flag1;
        if (cursor.getInt(6) == 0)
        {
            flag = false;
        }
        message.bUnread = flag;
        message.msgtime = dateFromDbTimestamp(cursor.getInt(7));
        message.msgtype = cursor.getString(8);
        message.bindata = cursor.getString(9);
        return message;
    }

    private static String steamidJoin(int i, int j)
    {
        BigInteger biginteger;
        BigInteger biginteger1;
        if (i == 0x80000000)
        {
            biginteger = BIGINT_STEAMID_HIGHBIT;
        } else
        if (i >= 0)
        {
            biginteger = BigInteger.valueOf(i);
        } else
        {
            biginteger = BigInteger.valueOf(-i).or(BIGINT_STEAMID_HIGHBIT);
        }
        if (j == 0x80000000)
        {
            biginteger1 = BIGINT_STEAMID_HIGHBIT;
        } else
        if (j >= 0)
        {
            biginteger1 = BigInteger.valueOf(j);
        } else
        {
            biginteger1 = BigInteger.valueOf(-j).or(BIGINT_STEAMID_HIGHBIT);
        }
        return biginteger.multiply(BIGINT_STEAMID32BIT).add(biginteger1).toString();
    }

    private static int[] steamidSplit(String s)
    {
        BigInteger abiginteger[] = (new BigInteger(s)).divideAndRemainder(BIGINT_STEAMID32BIT);
        BigInteger abiginteger1[] = abiginteger[0].divideAndRemainder(BIGINT_STEAMID_HIGHBIT);
        BigInteger abiginteger2[] = abiginteger[1].divideAndRemainder(BIGINT_STEAMID_HIGHBIT);
        int i;
        int j;
        if (abiginteger1[0].equals(BigInteger.ZERO))
        {
            i = abiginteger1[1].intValue();
        } else
        if (abiginteger1[1].intValue() != 0)
        {
            i = -abiginteger1[1].intValue();
        } else
        {
            i = 0x80000000;
        }
        if (abiginteger2[0].equals(BigInteger.ZERO))
        {
            j = abiginteger2[1].intValue();
        } else
        if (abiginteger2[1].intValue() != 0)
        {
            j = -abiginteger2[1].intValue();
        } else
        {
            j = 0x80000000;
        }
        return (new int[] {
            i, j
        });
    }

    public boolean insertInfo(ISteamUmqCommunicationDatabase.UmqInfo umqinfo)
    {
        this;
        JVM INSTR monitorenter ;
        if (dbStmt_SQL_INSERT_INFO == null)
        {
            dbStmt_SQL_INSERT_INFO = m_db.compileStatement("INSERT OR REPLACE INTO UmqInfo ( id1,id2,name ) VALUES ( ?,?, ? )");
        }
        int ai[] = steamidSplit(umqinfo.steamid);
        dbStmt_SQL_INSERT_INFO.bindLong(1, ai[0]);
        dbStmt_SQL_INSERT_INFO.bindLong(2, ai[1]);
        dbStmt_SQL_INSERT_INFO.bindString(3, umqinfo.name);
        dbStmt_SQL_INSERT_INFO.executeInsert();
        this;
        JVM INSTR monitorexit ;
        return true;
        Exception exception;
        exception;
        throw exception;
    }

    public boolean insertMessage(ISteamUmqCommunicationDatabase.Message message)
    {
        long l = 1L;
        boolean flag = true;
        this;
        JVM INSTR monitorenter ;
        SQLiteStatement sqlitestatement;
        if (dbStmt_SQL_INSERT_MSG == null)
        {
            dbStmt_SQL_INSERT_MSG = m_db.compileStatement("INSERT INTO UmqMsg ( myuser1,myuser2,wuser1,wuser2,msgincoming,msgunread,msgtime,msgtype,bindata ) VALUES ( ?,?, ?,?, ?,?,?, ?,? )");
        }
        int ai[] = steamidSplit(message.sMySteamID);
        dbStmt_SQL_INSERT_MSG.bindLong(1, ai[0]);
        dbStmt_SQL_INSERT_MSG.bindLong(2, ai[1]);
        int ai1[] = steamidSplit(message.sWithSteamID);
        dbStmt_SQL_INSERT_MSG.bindLong(3, ai1[0]);
        dbStmt_SQL_INSERT_MSG.bindLong(4, ai1[1]);
        sqlitestatement = dbStmt_SQL_INSERT_MSG;
        long l1;
        SQLiteStatement sqlitestatement1;
        int i;
        int j;
        if (message.bIncoming)
        {
            l1 = l;
        } else
        {
            l1 = 0L;
        }
        sqlitestatement.bindLong(5, l1);
        sqlitestatement1 = dbStmt_SQL_INSERT_MSG;
        if (!message.bUnread)
        {
            l = 0L;
        }
        sqlitestatement1.bindLong(6, l);
        i = (int)(message.msgtime.getTimeInMillis() / 1000L);
        dbStmt_SQL_INSERT_MSG.bindLong(7, i);
        dbStmt_SQL_INSERT_MSG.bindString(8, message.msgtype);
        dbStmt_SQL_INSERT_MSG.bindString(9, message.bindata);
        message.id = (int)dbStmt_SQL_INSERT_MSG.executeInsert();
        j = message.id;
        if (j == -1)
        {
            flag = false;
        }
        this;
        JVM INSTR monitorexit ;
        return flag;
        Exception exception;
        exception;
        throw exception;
    }

    public ArrayList selectAllMessages()
    {
        this;
        JVM INSTR monitorenter ;
        ArrayList arraylist = selectMessagesWhere("1");
        this;
        JVM INSTR monitorexit ;
        return arraylist;
        Exception exception;
        exception;
        throw exception;
    }

    public int selectCountOfUnreadMessages(String s)
    {
        this;
        JVM INSTR monitorenter ;
        long l;
        if (dbStmt_SQL_SELECT_MSG_UNREAD_COUNT == null)
        {
            dbStmt_SQL_SELECT_MSG_UNREAD_COUNT = m_db.compileStatement("SELECT COUNT(*) FROM UmqMsg WHERE msgunread=1  AND myuser1=?  AND myuser2=? ");
        }
        int ai[] = steamidSplit(s);
        dbStmt_SQL_SELECT_MSG_UNREAD_COUNT.bindLong(1, ai[0]);
        dbStmt_SQL_SELECT_MSG_UNREAD_COUNT.bindLong(2, ai[1]);
        l = dbStmt_SQL_SELECT_MSG_UNREAD_COUNT.simpleQueryForLong();
        int i = (int)l;
        this;
        JVM INSTR monitorexit ;
        return i;
        Exception exception;
        exception;
        throw exception;
    }

    public int selectCountOfUnreadMessagesWithUser(String s, String s1)
    {
        this;
        JVM INSTR monitorenter ;
        long l;
        if (dbStmt_SQL_SELECT_MSG_UNREAD_COUNT_WITH_USER == null)
        {
            dbStmt_SQL_SELECT_MSG_UNREAD_COUNT_WITH_USER = m_db.compileStatement("SELECT COUNT(*) FROM UmqMsg WHERE msgunread=1  AND myuser1=?  AND myuser2=?  AND wuser1=?  AND wuser2=? ");
        }
        int ai[] = steamidSplit(s);
        dbStmt_SQL_SELECT_MSG_UNREAD_COUNT_WITH_USER.bindLong(1, ai[0]);
        dbStmt_SQL_SELECT_MSG_UNREAD_COUNT_WITH_USER.bindLong(2, ai[1]);
        int ai1[] = steamidSplit(s1);
        dbStmt_SQL_SELECT_MSG_UNREAD_COUNT_WITH_USER.bindLong(3, ai1[0]);
        dbStmt_SQL_SELECT_MSG_UNREAD_COUNT_WITH_USER.bindLong(4, ai1[1]);
        l = dbStmt_SQL_SELECT_MSG_UNREAD_COUNT_WITH_USER.simpleQueryForLong();
        int i = (int)l;
        this;
        JVM INSTR monitorexit ;
        return i;
        Exception exception;
        exception;
        throw exception;
    }

    public ISteamUmqCommunicationDatabase.UmqInfo selectInfo(String s)
    {
        this;
        JVM INSTR monitorenter ;
        ArrayList arraylist;
        int ai[] = steamidSplit(s);
        arraylist = selectInfoWhere((new StringBuilder()).append("id1=").append(ai[0]).append(" AND ").append("id2").append("=").append(ai[1]).append(" LIMIT 1").toString());
        if (arraylist == null) goto _L2; else goto _L1
_L1:
        boolean flag = arraylist.isEmpty();
        if (!flag) goto _L3; else goto _L2
_L2:
        ISteamUmqCommunicationDatabase.UmqInfo umqinfo = null;
_L5:
        this;
        JVM INSTR monitorexit ;
        return umqinfo;
_L3:
        umqinfo = (ISteamUmqCommunicationDatabase.UmqInfo)arraylist.get(0);
        if (true) goto _L5; else goto _L4
_L4:
        Exception exception;
        exception;
        throw exception;
    }

    public ArrayList selectMessagesByID(int i)
    {
        this;
        JVM INSTR monitorenter ;
        ArrayList arraylist = selectMessagesWhere((new StringBuilder()).append("_id=").append(i).toString());
        this;
        JVM INSTR monitorexit ;
        return arraylist;
        Exception exception;
        exception;
        throw exception;
    }

    public ArrayList selectMessagesWithUser(String s, String s1, int i, ISteamUmqCommunicationDatabase.Message message)
    {
        this;
        JVM INSTR monitorenter ;
        StringBuilder stringbuilder;
        int ai[] = steamidSplit(s);
        int ai1[] = steamidSplit(s1);
        stringbuilder = (new StringBuilder()).append("myuser1=").append(ai[0]).append(" AND ").append("myuser2").append("=").append(ai[1]).append(" AND ").append("wuser1").append("=").append(ai1[0]).append(" AND ").append("wuser2").append("=").append(ai1[1]);
        if (message == null)
        {
            break MISSING_BLOCK_LABEL_187;
        }
        String s2 = (new StringBuilder()).append(" AND _id<").append(message.id).toString();
_L1:
        ArrayList arraylist = selectMessagesWhere(stringbuilder.append(s2).append(" ORDER BY ").append("_id").append(" DESC ").append(" LIMIT ").append(i).toString());
        this;
        JVM INSTR monitorexit ;
        return arraylist;
        s2 = "";
          goto _L1
        Exception exception;
        exception;
        throw exception;
    }

    public ArrayList selectMessagesWithUserLatest(String s, String s1, int i)
    {
        int ai[] = steamidSplit(s);
        int ai1[] = steamidSplit(s1);
        return selectMessagesWhere((new StringBuilder()).append("myuser1=").append(ai[0]).append(" AND ").append("myuser2").append("=").append(ai[1]).append(" AND ").append("wuser1").append("=").append(ai1[0]).append(" AND ").append("wuser2").append("=").append(ai1[1]).append(" AND ").append("_id").append(">=").append(i).append(" ORDER BY ").append("_id").append(" DESC ").toString());
    }

    public ISteamUmqCommunicationDatabase.UserConversationInfo selectUserConversationInfo(String s, String s1)
    {
        this;
        JVM INSTR monitorenter ;
        Cursor cursor;
        ISteamUmqCommunicationDatabase.UserConversationInfo userconversationinfo;
        int i;
        int ai[] = steamidSplit(s);
        int ai1[] = steamidSplit(s1);
        String s2 = (new StringBuilder()).append(" SELECT SUM( msgunread),  COUNT( * ), msgtime, _id FROM UmqMsg WHERE myuser1=").append(ai[0]).append(" AND ").append("myuser2").append("=").append(ai[1]).append(" AND ").append("wuser1").append("=").append(ai1[0]).append(" AND ").append("wuser2").append("=").append(ai1[1]).append(" ORDER BY ").append("_id").append(" DESC ").append(" LIMIT 1 ").toString();
        cursor = m_db.rawQuery(s2, null);
        userconversationinfo = new ISteamUmqCommunicationDatabase.UserConversationInfo();
        if (!cursor.moveToFirst() || cursor.isAfterLast())
        {
            break MISSING_BLOCK_LABEL_246;
        }
        i = cursor.getInt(1);
        if (i <= 0)
        {
            break MISSING_BLOCK_LABEL_239;
        }
        userconversationinfo.numMsgsTotal = i;
        userconversationinfo.numUnreadMsgs = cursor.getInt(0);
        userconversationinfo.latestTimestamp = dateFromDbTimestamp(cursor.getInt(2));
        userconversationinfo.latestMsgId = cursor.getInt(3);
        cursor.close();
        this;
        JVM INSTR monitorexit ;
        return userconversationinfo;
        Exception exception;
        exception;
        throw exception;
    }

    public void updateMarkReadMessagesWithUser(String s, String s1, boolean flag)
    {
        this;
        JVM INSTR monitorenter ;
        if (!flag) goto _L2; else goto _L1
_L1:
        if (s1 == null) goto _L4; else goto _L3
_L3:
        SQLiteStatement sqlitestatement = dbStmt_SQL_DELETE_MSG_WITH_USER;
_L9:
        if (sqlitestatement != null) goto _L6; else goto _L5
_L5:
        SQLiteDatabase sqlitedatabase1;
        StringBuilder stringbuilder1;
        sqlitedatabase1 = m_db;
        stringbuilder1 = (new StringBuilder()).append("DELETE FROM UmqMsg WHERE myuser1=?  AND myuser2=? ");
        SQLiteDatabase sqlitedatabase;
        StringBuilder stringbuilder;
        String s2;
        Exception exception;
        String s3;
        if (s1 != null)
        {
            s3 = " AND wuser1=?  AND wuser2=? ";
        } else
        {
            s3 = "";
        }
        sqlitestatement = sqlitedatabase1.compileStatement(stringbuilder1.append(s3).toString());
        if (s1 == null) goto _L8; else goto _L7
_L7:
        dbStmt_SQL_DELETE_MSG_WITH_USER = sqlitestatement;
_L6:
        int ai[] = steamidSplit(s);
        sqlitestatement.bindLong(1, ai[0]);
        sqlitestatement.bindLong(2, ai[1]);
        if (s1 == null)
        {
            break MISSING_BLOCK_LABEL_138;
        }
        int ai1[] = steamidSplit(s1);
        sqlitestatement.bindLong(3, ai1[0]);
        sqlitestatement.bindLong(4, ai1[1]);
        sqlitestatement.execute();
        this;
        JVM INSTR monitorexit ;
        return;
_L4:
        sqlitestatement = dbStmt_SQL_DELETE_MSG_WITH_ALL;
          goto _L9
_L8:
        dbStmt_SQL_DELETE_MSG_WITH_ALL = sqlitestatement;
          goto _L6
        exception;
        throw exception;
_L2:
        if (s1 == null)
        {
            break MISSING_BLOCK_LABEL_246;
        }
        sqlitestatement = dbStmt_SQL_UPDATE_MSG_UNREAD_WITH_USER;
_L11:
        if (sqlitestatement != null) goto _L6; else goto _L10
_L10:
        sqlitedatabase = m_db;
        stringbuilder = (new StringBuilder()).append("UPDATE UmqMsg SET msgunread=0  WHERE msgunread=1  AND myuser1=?  AND myuser2=? ");
        if (s1 != null)
        {
            s2 = " AND wuser1=?  AND wuser2=? ";
        } else
        {
            s2 = "";
        }
        sqlitestatement = sqlitedatabase.compileStatement(stringbuilder.append(s2).toString());
        if (s1 == null)
        {
            break MISSING_BLOCK_LABEL_255;
        }
        dbStmt_SQL_UPDATE_MSG_UNREAD_WITH_USER = sqlitestatement;
          goto _L6
        sqlitestatement = dbStmt_SQL_UPDATE_MSG_UNREAD_WITH_ALL;
          goto _L11
        dbStmt_SQL_UPDATE_MSG_UNREAD_WITH_ALL = sqlitestatement;
          goto _L6
    }

}
