// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import java.security.KeyStore;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.conn.scheme.PlainSocketFactory;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

// Referenced classes of package com.valvesoftware.android.steam.community:
//            SteamWebApi, Config, SteamCommunityApplication, SteamDBDiskCache

public static class m_callerRequestQueue
{
    public static class DiskCacheInfo
    {

        SteamDBDiskCache disk;
        String uri;

        public DiskCacheInfo()
        {
        }
    }


    static final boolean $assertionsDisabled = false;
    private static final String HTTP_PARAM_DEFAULT_PROXY = "proxy.valvesoftware.com";
    private static final int HTTP_PARAM_DEFAULT_PROXY_PORT = 3128;
    private static final boolean HTTP_PARAM_DEFAULT_USING_PROXY = false;
    private static final int HTTP_TIMEOUT_DEFAULT_CONN = 25000;
    private static final int HTTP_TIMEOUT_DEFAULT_SO = 25000;
    private DiskCacheInfo m_DiskCacheInfo;
    protected Bitmap m_bitmap;
    private String m_callerIntent;
    private String m_callerRequestQueue;
    protected JSONObject m_jsonDocument;
    private Object m_objData;
    private String m_postData;
    private entType m_requestDocumentType;
    private ode m_requestMode;
    private ode m_result;
    private nType m_skipMode;
    private String m_uri;

    public HttpResponse FetchHttpResponseOnWorkerThread()
        throws Exception
    {
        return GetDefaultHttpClient().execute(GetDefaultHttpRequestBase());
    }

    public Bitmap GetBitmap()
    {
        return m_bitmap;
    }

    public String GetCallerIntent()
    {
        return m_callerIntent;
    }

    protected DefaultHttpClient GetDefaultHttpClient()
    {
        if (Config.STEAM_UNIVERSE_WEBAPI != )
        {
            break MISSING_BLOCK_LABEL_122;
        }
        DefaultHttpClient defaulthttpclient;
        KeyStore keystore = KeyStore.getInstance(KeyStore.getDefaultType());
        keystore.load(null, null);
        SLSocketFactory slsocketfactory = new SLSocketFactory(keystore);
        slsocketfactory.setHostnameVerifier(SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
        SchemeRegistry schemeregistry = new SchemeRegistry();
        schemeregistry.register(new Scheme("http", PlainSocketFactory.getSocketFactory(), 80));
        schemeregistry.register(new Scheme("https", slsocketfactory, 443));
        HttpParams httpparams = GetDefaultHttpParams();
        defaulthttpclient = new DefaultHttpClient(new ThreadSafeClientConnManager(httpparams, schemeregistry), httpparams);
        return defaulthttpclient;
        Exception exception;
        exception;
        exception.printStackTrace();
        return new DefaultHttpClient(GetDefaultHttpParams());
    }

    protected HttpParams GetDefaultHttpParams()
    {
        BasicHttpParams basichttpparams = new BasicHttpParams();
        HttpConnectionParams.setConnectionTimeout(basichttpparams, 25000);
        HttpConnectionParams.setSoTimeout(basichttpparams, 25000);
        return basichttpparams;
    }

    protected HttpRequestBase GetDefaultHttpRequestBase()
        throws Exception
    {
        Object obj;
        if (GetMode() == ode.Get)
        {
            obj = new HttpGet(GetUri(0));
        } else
        {
            HttpPost httppost = new HttpPost(GetUri(0));
            obj = httppost;
            httppost.addHeader("Content-Type", "application/x-www-form-urlencoded");
            httppost.setEntity(new StringEntity(GetPostData()));
        }
        ((HttpRequestBase) (obj)).addHeader("User-Agent", (new StringBuilder()).append("Steam App / Android / ").append(Config.APP_VERSION).append(" / ").append(Config.APP_VERSION_ID).toString());
        return ((HttpRequestBase) (obj));
    }

    public DiskCacheInfo GetDiskCacheInfo()
    {
        if (m_DiskCacheInfo == null)
        {
            m_DiskCacheInfo = new DiskCacheInfo();
            m_DiskCacheInfo.disk = SteamCommunityApplication.GetInstance().GetDiskCacheWeb();
            m_DiskCacheInfo.uri = GetUri(0);
        }
        return m_DiskCacheInfo;
    }

    public String GetDocument()
    {
        m_DiskCacheInfo m_diskcacheinfo = m_result;
        String s = null;
        if (m_diskcacheinfo != null)
        {
            s = m_result.etDocument();
        }
        if (s == null)
        {
            s = "";
        }
        return s;
    }

    public etDocument GetHttpResponseUriData()
    {
        return m_result;
    }

    public int GetIntentId()
    {
        return System.identityHashCode(this);
    }

    public JSONObject GetJSONDocument()
    {
        return m_jsonDocument;
    }

    public ode GetMode()
    {
        return m_requestMode;
    }

    public Object GetObjData()
    {
        return m_objData;
    }

    public String GetPostData()
    {
        return m_postData;
    }

    public nType GetRequestAction()
    {
        return m_skipMode;
    }

    public entType GetRequestDocumentType()
    {
        return m_requestDocumentType;
    }

    public String GetRequestQueue()
    {
        return m_callerRequestQueue;
    }

    public String GetUri()
    {
        if (!$assertionsDisabled && m_uri == null)
        {
            throw new AssertionError();
        } else
        {
            return m_uri;
        }
    }

    public String GetUri(int i)
    {
        if (!$assertionsDisabled && m_uri == null)
        {
            throw new AssertionError();
        } else
        {
            return m_uri;
        }
    }

    public boolean IsRequestForByteData()
    {
        return GetRequestDocumentType() == com.valvesoftware.android.steam.community.entType.Bitmap;
    }

    public boolean IsRequestLive()
    {
        if (m_result == null)
        {
            return false;
        } else
        {
            return m_result.sRequestLive();
        }
    }

    public void OnFailureWorkerThread(sRequestLive srequestlive)
    {
        m_result = srequestlive;
        RequestFailedOnResponseWorkerThread();
        if (srequestlive._httpResult == 401)
        {
            SteamWebApi.LogOut();
        }
    }

    public void OnResponseWorkerThread(_httpResult _phttpresult)
        throws Exception
    {
        m_result = _phttpresult;
        .com.valvesoftware.android.steam.community.SteamWebApi.RequestDocumentType[m_requestDocumentType.ordinal()];
        JVM INSTR tableswitch 1 3: default 44
    //                   1 50
    //                   2 55
    //                   3 129;
           goto _L1 _L2 _L3 _L4
_L1:
        OnFailureWorkerThread(_phttpresult);
        return;
_L2:
        RequestSucceededOnResponseWorkerThread();
        return;
_L3:
        try
        {
            Object obj = (new JSONTokener(m_result.etDocument())).nextValue();
            if (org/json/JSONObject.isInstance(obj))
            {
                m_jsonDocument = (JSONObject)obj;
                RequestSucceededOnResponseWorkerThread();
                return;
            }
        }
        catch (JSONException jsonexception)
        {
            m_result.etRequestError(1);
            OnFailureWorkerThread(_phttpresult);
            return;
        }
        m_result.etRequestError(1);
        OnFailureWorkerThread(_phttpresult);
        return;
_L4:
        byte abyte0[] = m_result.etByteData();
        Bitmap bitmap;
        if (abyte0 != null)
        {
            bitmap = BitmapFactory.decodeByteArray(abyte0, 0, abyte0.length);
        } else
        {
            bitmap = null;
        }
        m_bitmap = bitmap;
        if (m_bitmap != null)
        {
            RequestSucceededOnResponseWorkerThread();
            return;
        } else
        {
            m_result.etRequestError(1);
            OnFailureWorkerThread(_phttpresult);
            return;
        }
    }

    public boolean OnTaskReadyToRunOnJobQueue()
    {
        return true;
    }

    public void RequestFailedOnResponseWorkerThread()
    {
    }

    public void RequestSucceededOnResponseWorkerThread()
    {
    }

    public void SetCallerIntent(String s)
    {
        if (!$assertionsDisabled && m_callerIntent != null)
        {
            throw new AssertionError();
        } else
        {
            m_callerIntent = s;
            return;
        }
    }

    public void SetIndefiniteCacheFilename(String s)
    {
        if (!$assertionsDisabled && m_DiskCacheInfo != null)
        {
            throw new AssertionError();
        } else
        {
            m_DiskCacheInfo = new DiskCacheInfo();
            m_DiskCacheInfo.disk = SteamCommunityApplication.GetInstance().GetDiskCacheIndefinite();
            m_DiskCacheInfo.uri = s;
            return;
        }
    }

    public void SetObjData(Object obj)
    {
        if (!$assertionsDisabled && m_objData != null)
        {
            throw new AssertionError();
        } else
        {
            m_objData = obj;
            return;
        }
    }

    public void SetPostData(String s)
    {
        if (!$assertionsDisabled && m_postData != null)
        {
            throw new AssertionError();
        } else
        {
            m_requestMode = ode.Post;
            m_postData = s;
            return;
        }
    }

    public void SetRequestAction(nType ntype)
    {
        m_skipMode = ntype;
    }

    public void SetUriAndDocumentType(String s, entType enttype)
    {
        if (!$assertionsDisabled && m_uri != null)
        {
            throw new AssertionError();
        } else
        {
            m_uri = s;
            m_requestDocumentType = enttype;
            return;
        }
    }

    static 
    {
        boolean flag;
        if (!com/valvesoftware/android/steam/community/SteamWebApi.desiredAssertionStatus())
        {
            flag = true;
        } else
        {
            flag = false;
        }
        $assertionsDisabled = flag;
    }


/*
    static String access$002(entType enttype, String s)
    {
        enttype.m_uri = s;
        return s;
    }

*/


/*
    static Object access$102(m_uri m_uri1, Object obj)
    {
        m_uri1.m_objData = obj;
        return obj;
    }

*/

    public DiskCacheInfo(String s)
    {
        m_callerIntent = null;
        m_callerRequestQueue = null;
        m_uri = null;
        m_requestMode = ode.Get;
        m_postData = null;
        m_objData = null;
        m_requestDocumentType = entType.String;
        m_skipMode = nType.DoHttpRequestAndCacheResults;
        m_result = null;
        m_jsonDocument = null;
        m_bitmap = null;
        m_callerRequestQueue = s;
    }
}
