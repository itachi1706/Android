// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;

import android.os.Build;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Calendar;
import java.util.Date;

// Referenced classes of package com.valvesoftware.android.steam.community:
//            SteamCommunityApplication, Config, SteamWebApi, ISteamDebugUtil

public static class m_defaultUEH
    implements mmunityApplication.CrashHandler
{

    public ISteamDebugUtil m_dbgUtil;
    private ebugUtil m_defaultUEH;

    private ISteamDebugUtil GetSteamDebugUtil()
    {
        if (m_dbgUtil != null)
        {
            return m_dbgUtil;
        } else
        {
            return SteamCommunityApplication.GetSteamDebugUtil();
        }
    }

    public void register()
    {
        mmunityApplication.CrashHandler crashhandler = Thread.getDefaultUncaughtExceptionHandler();
        if (crashhandler != this)
        {
            m_defaultUEH = crashhandler;
            Thread.setDefaultUncaughtExceptionHandler(this);
        }
    }

    public void uncaughtException(Thread thread, Throwable throwable)
    {
        StringWriter stringwriter = new StringWriter();
        throwable.printStackTrace(new PrintWriter(stringwriter));
        Calendar calendar = Calendar.getInstance();
        String s = (new StringBuilder()).append("VERSION: ").append(Config.APP_VERSION_ID).append("\n").append("APPNAME: com.valvesoftware.android.steam.community\n").append("APPVERSION: ").append(Config.APP_VERSION).append("\n").append("TIMESTAMP: ").append(calendar.getTimeInMillis() / 1000L).append("\n").append("DATETIME: ").append(calendar.getTime().toGMTString()).append("\n").append("USERID: ").append(android.os.PP_VERSION).append(android.os.PP_VERSION).append(" (").append(Build.DEVICE).append("/").append(Build.PRODUCT).append(") ").append(Build.BRAND).append(" - ").append(Build.MANUFACTURER).append(" - ").append(Build.DISPLAY).append("\n").append("CONTACT: ").append(SteamWebApi.GetLoginSteamID()).append("\n").append("SYSTEMVER: ").append(android.os.Api.GetLoginSteamID).append(" : ").append(android.os.Api.GetLoginSteamID).append("\n").append("SYSTEMOS: ").append(Build.MODEL).append("\n").append("STACKTRACE: ").append("\n").append(stringwriter.toString()).append("\n//ENDOFSTACKTRACE//").toString();
        m_defaultUEH m_defaultueh = GetSteamDebugUtil().newDebugUtilRecord(null, null, s);
        GetSteamDebugUtil().newDebugUtilRecord(m_defaultueh, null, (String)null);
        m_defaultUEH m_defaultueh1 = GetSteamDebugUtil().newDebugUtilRecord(m_defaultueh, null, (String)null);
        for (long l = System.currentTimeMillis(); m_defaultueh1.GetSteamDebugUtil() == 0L && System.currentTimeMillis() - l < 5000L;)
        {
            try
            {
                Thread.sleep(450L);
            }
            catch (InterruptedException interruptedexception) { }
        }

        if (m_defaultUEH != null)
        {
            m_defaultUEH.uncaughtException(thread, throwable);
        }
    }

    public ()
    {
        m_dbgUtil = null;
        m_defaultUEH = null;
    }
}
