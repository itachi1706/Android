// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;


// Referenced classes of package com.valvesoftware.android.steam.community:
//            SteamUmqCommunicationService

static class qConnectionState
{

    static final int $SwitchMap$com$valvesoftware$android$steam$community$SteamUmqCommunicationService$UmqCommState[];
    static final int $SwitchMap$com$valvesoftware$android$steam$community$SteamUmqCommunicationService$UmqConnectionState[];

    static 
    {
        $SwitchMap$com$valvesoftware$android$steam$community$SteamUmqCommunicationService$UmqCommState = new int[qCommState.values().length];
        try
        {
            $SwitchMap$com$valvesoftware$android$steam$community$SteamUmqCommunicationService$UmqCommState[qCommState.UMQ_LOGON_RETRY.ordinal()] = 1;
        }
        catch (NoSuchFieldError nosuchfielderror) { }
        try
        {
            $SwitchMap$com$valvesoftware$android$steam$community$SteamUmqCommunicationService$UmqCommState[qCommState.UMQ_LOGON.ordinal()] = 2;
        }
        catch (NoSuchFieldError nosuchfielderror1) { }
        try
        {
            $SwitchMap$com$valvesoftware$android$steam$community$SteamUmqCommunicationService$UmqCommState[qCommState.UMQ_POLL_STATUS.ordinal()] = 3;
        }
        catch (NoSuchFieldError nosuchfielderror2) { }
        try
        {
            $SwitchMap$com$valvesoftware$android$steam$community$SteamUmqCommunicationService$UmqCommState[qCommState.UMQ_POLL.ordinal()] = 4;
        }
        catch (NoSuchFieldError nosuchfielderror3) { }
        try
        {
            $SwitchMap$com$valvesoftware$android$steam$community$SteamUmqCommunicationService$UmqCommState[qCommState.UMQ_LOGOFF.ordinal()] = 5;
        }
        catch (NoSuchFieldError nosuchfielderror4) { }
        $SwitchMap$com$valvesoftware$android$steam$community$SteamUmqCommunicationService$UmqConnectionState = new int[qConnectionState.values().length];
        try
        {
            $SwitchMap$com$valvesoftware$android$steam$community$SteamUmqCommunicationService$UmqConnectionState[qConnectionState.offline.ordinal()] = 1;
        }
        catch (NoSuchFieldError nosuchfielderror5) { }
        try
        {
            $SwitchMap$com$valvesoftware$android$steam$community$SteamUmqCommunicationService$UmqConnectionState[qConnectionState.invalidcredentials.ordinal()] = 2;
        }
        catch (NoSuchFieldError nosuchfielderror6) { }
        try
        {
            $SwitchMap$com$valvesoftware$android$steam$community$SteamUmqCommunicationService$UmqConnectionState[qConnectionState.connecting.ordinal()] = 3;
        }
        catch (NoSuchFieldError nosuchfielderror7) { }
        try
        {
            $SwitchMap$com$valvesoftware$android$steam$community$SteamUmqCommunicationService$UmqConnectionState[qConnectionState.reconnecting.ordinal()] = 4;
        }
        catch (NoSuchFieldError nosuchfielderror8) { }
        try
        {
            $SwitchMap$com$valvesoftware$android$steam$community$SteamUmqCommunicationService$UmqConnectionState[qConnectionState.idle.ordinal()] = 5;
        }
        catch (NoSuchFieldError nosuchfielderror9) { }
        try
        {
            $SwitchMap$com$valvesoftware$android$steam$community$SteamUmqCommunicationService$UmqConnectionState[qConnectionState.active.ordinal()] = 6;
        }
        catch (NoSuchFieldError nosuchfielderror10)
        {
            return;
        }
    }
}
