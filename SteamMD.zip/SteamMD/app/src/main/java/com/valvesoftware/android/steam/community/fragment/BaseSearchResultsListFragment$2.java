// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.fragment;

import java.util.Comparator;
import java.util.HashMap;

// Referenced classes of package com.valvesoftware.android.steam.community.fragment:
//            BaseSearchResultsListFragment

class this._cls0
    implements Comparator
{

    final BaseSearchResultsListFragment this$0;

    public int compare(com.valvesoftware.android.steam.community.agment._cls2 _pcls2, com.valvesoftware.android.steam.community.agment._cls2 _pcls2_1)
    {
        Integer integer = (Integer)m_searchResultsOrderMap.get(_pcls2.steamID);
        Integer integer1 = (Integer)m_searchResultsOrderMap.get(_pcls2_1.steamID);
        if (integer != null && integer1 != null)
        {
            return integer.compareTo(integer1);
        }
        if (integer == null && integer1 == null)
        {
            return 0;
        }
        return integer == null ? 1 : -1;
    }

    public volatile int compare(Object obj, Object obj1)
    {
        return compare((com.valvesoftware.android.steam.community.agment._cls2.compare)obj, (com.valvesoftware.android.steam.community.agment._cls2.compare)obj1);
    }

    ()
    {
        this$0 = BaseSearchResultsListFragment.this;
        super();
    }
}
