// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

// Referenced classes of package com.valvesoftware.android.steam.community:
//            WorkerThreadPool

private class m_sName
    implements Runnable
{

    private String m_sName;
    private final List m_tasks = new ArrayList();
    private Thread m_thread;
    final WorkerThreadPool this$0;

    private boolean RunNextTask()
    {
label0:
        {
            synchronized (m_tasks)
            {
                if (!m_tasks.isEmpty())
                {
                    break label0;
                }
                WaitForNextTaskOrTimeout();
                if (!m_tasks.isEmpty())
                {
                    break label0;
                }
                m_thread = null;
            }
            return false;
        }
        m_sName m_sname;
        m_tasks.size();
        m_sname = (m_tasks)m_tasks.remove(0);
        list;
        JVM INSTR monitorexit ;
        TreeMap treemap;
        t t = WorkerThreadPool.RunTask(m_sname);
        switch (Map.com.valvesoftware.android.steam.community.WorkerThreadPool.TaskResult[t.ordinal()])
        {
        default:
            return true;

        case 1: // '\001'
            AddTask(m_sname);
            return true;

        case 2: // '\002'
            treemap = WorkerThreadPool.access$000(WorkerThreadPool.this);
            break;
        }
        break MISSING_BLOCK_LABEL_135;
        exception;
        list;
        JVM INSTR monitorexit ;
        throw exception;
        treemap;
        JVM INSTR monitorenter ;
        if (this == (this._cls0)WorkerThreadPool.access$000(WorkerThreadPool.this).remove(Integer.valueOf(System.identityHashCode(GetName()))));
        treemap;
        JVM INSTR monitorexit ;
        synchronized (m_tasks)
        {
            if (m_tasks.isEmpty());
        }
        return false;
        Exception exception1;
        exception1;
        treemap;
        JVM INSTR monitorexit ;
        throw exception1;
        exception2;
        list1;
        JVM INSTR monitorexit ;
        throw exception2;
    }

    private void WaitForNextTaskOrTimeout()
    {
        long l = System.currentTimeMillis();
_L2:
        long l1 = 2000L + l;
        long l2 = l1 - System.currentTimeMillis();
        if (l2 <= 0L)
        {
            break; /* Loop/switch isn't completed */
        }
        try
        {
            m_tasks.wait(l2);
            continue; /* Loop/switch isn't completed */
        }
        catch (InterruptedException interruptedexception) { }
        break; /* Loop/switch isn't completed */
        if (true) goto _L2; else goto _L1
_L1:
    }

    public void EnqueueTask(m_tasks m_tasks1)
    {
        List list = m_tasks;
        list;
        JVM INSTR monitorenter ;
        m_tasks.add(m_tasks1);
        if (m_thread == null)
        {
            break MISSING_BLOCK_LABEL_35;
        }
        m_tasks.notify();
_L2:
        return;
        m_thread = new Thread(this, GetName());
        m_thread.start();
        if (true) goto _L2; else goto _L1
_L1:
        Exception exception;
        exception;
        list;
        JVM INSTR monitorexit ;
        throw exception;
    }

    public String GetName()
    {
        return m_sName;
    }

    public void run()
    {
        while (RunNextTask()) ;
    }

    public t(String s)
    {
        this$0 = WorkerThreadPool.this;
        super();
        m_sName = null;
        m_thread = null;
        m_sName = s;
    }
}
