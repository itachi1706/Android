// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.fragment;

import android.text.Editable;
import android.text.TextWatcher;

// Referenced classes of package com.valvesoftware.android.steam.community.fragment:
//            BasePresentationListFragmentWithSearch

class this._cls0
    implements TextWatcher
{

    final BasePresentationListFragmentWithSearch this$0;

    public void afterTextChanged(Editable editable)
    {
        BasePresentationListFragmentWithSearch.access$000(BasePresentationListFragmentWithSearch.this);
    }

    public void beforeTextChanged(CharSequence charsequence, int i, int j, int k)
    {
    }

    public void onTextChanged(CharSequence charsequence, int i, int j, int k)
    {
    }

    a()
    {
        this$0 = BasePresentationListFragmentWithSearch.this;
        super();
    }
}
