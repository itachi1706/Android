// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.fragment;

import android.support.v4.app.FragmentActivity;
import com.valvesoftware.android.steam.community.SteamCommunityApplication;
import com.valvesoftware.android.steam.community.SteamWebApi;
import com.valvesoftware.android.steam.community.activity.FragmentActivityWithNavigationSupport;

// Referenced classes of package com.valvesoftware.android.steam.community.fragment:
//            NavigationFragment

public class this._cls0 extends this._cls0
{

    final NavigationFragment this$0;

    public String getDetails()
    {
        return "";
    }

    public int getName()
    {
        return 0x7f070016;
    }

    public void onClick()
    {
        FragmentActivityWithNavigationSupport.finishAllExceptOne((FragmentActivityWithNavigationSupport)getActivity());
        if (SteamCommunityApplication.GetInstance().GetSteamDB() == null)
        {
            break MISSING_BLOCK_LABEL_98;
        }
        SteamCommunityApplication.GetInstance().m_bApplicationExiting = true;
        com.valvesoftware.android.steam.community.lication lication = new com.valvesoftware.android.steam.community.ishAllExceptOne();
        lication.ishAllExceptOne = null;
        lication.ishAllExceptOne = null;
        SteamWebApi.SubmitSimpleActionRequest("SetLoginInformation", lication);
        this._cls0 _lcls0 = new eptOne(getActivity());
        _lcls0.e(getActivity().getString(0x7f07001a));
        _lcls0.rminate(true);
        _lcls0.able(false);
        _lcls0.able();
        return;
        Exception exception;
        exception;
    }

    public ()
    {
        this$0 = NavigationFragment.this;
        super();
    }
}
