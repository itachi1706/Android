// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;

import java.util.Calendar;
import java.util.Date;

// Referenced classes of package com.valvesoftware.android.steam.community:
//            ISteamUmqCommunicationDatabase

public static class 
{

    public boolean bIncoming;
    public boolean bUnread;
    public String bindata;
    public int id;
    public Calendar msgtime;
    public String msgtype;
    public String sMySteamID;
    public String sWithSteamID;

    public String toString()
    {
        return (new StringBuilder()).append("Message:[ ID=").append(id).append(" MYSTEAMID=").append(sMySteamID).append(" WSTEAMID=").append(sWithSteamID).append(" incoming=").append(bIncoming).append(" unread=").append(bUnread).append(" time=").append(msgtime.getTime().toLocaleString()).append(" type=").append(msgtype).append(" data=//").append(bindata).append("// ]").toString();
    }

    public ()
    {
    }
}
