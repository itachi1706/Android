// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;

import android.content.Intent;
import android.os.Bundle;
import java.util.Iterator;
import java.util.Set;

// Referenced classes of package com.valvesoftware.android.steam.community:
//            ISteamDebugUtil

public static abstract class tilRecord
    implements ISteamDebugUtil
{

    public tilRecord newDebugUtilRecord(tilRecord tilrecord, String s, Intent intent)
    {
        if (intent != null) goto _L2; else goto _L1
_L1:
        tilRecord tilrecord1 = newDebugUtilRecord(tilrecord, s, "intent==null");
_L4:
        return tilrecord1;
_L2:
        tilrecord1 = newDebugUtilRecord(tilrecord, s, intent.toString());
        if (intent.getExtras() != null)
        {
            Iterator iterator = intent.getExtras().keySet().iterator();
            while (iterator.hasNext()) 
            {
                String s1 = (String)iterator.next();
                newDebugUtilRecord(tilrecord1, s1, intent.getExtras().get(s1).toString());
            }
        }
        if (true) goto _L4; else goto _L3
_L3:
    }

    public tilRecord newDebugUtilRecord(tilRecord tilrecord, String s, Throwable throwable)
    {
        if (throwable == null)
        {
            return newDebugUtilRecord(tilrecord, s, "ex==null");
        } else
        {
            tilRecord tilrecord1 = newDebugUtilRecord(tilrecord, s, throwable.toString());
            newDebugUtilRecord(tilrecord1, "class", throwable.getClass().getName());
            newDebugUtilRecord(tilrecord1, "msg", throwable.getMessage());
            newDebugUtilRecord(tilrecord1, "locmsg", throwable.getLocalizedMessage());
            newDebugUtilRecord(tilrecord1, "stacktrace", throwable.getStackTrace());
            return tilrecord1;
        }
    }

    public tilRecord newDebugUtilRecord(tilRecord tilrecord, String s, StackTraceElement astacktraceelement[])
    {
        if (astacktraceelement == null)
        {
            return newDebugUtilRecord(tilrecord, s, "trace==null");
        }
        if (astacktraceelement.length <= 0)
        {
            return newDebugUtilRecord(tilrecord, s, "Empty Stack Trace");
        }
        tilRecord tilrecord1 = newDebugUtilRecord(tilrecord, s, (new StringBuilder()).append(astacktraceelement[0].toString()).append(" // ").append(astacktraceelement.length).append(" stack trace element(s)").toString());
        int i = astacktraceelement.length;
        int j = 0;
        while (j < i) 
        {
            StackTraceElement stacktraceelement = astacktraceelement[j];
            String s1 = (new StringBuilder()).append(stacktraceelement.getClassName()).append(".").append(stacktraceelement.getMethodName()).toString();
            String s4;
            if (stacktraceelement.isNativeMethod())
            {
                s4 = "NativeMethod";
            } else
            {
                StringBuilder stringbuilder = new StringBuilder();
                String s2;
                StringBuilder stringbuilder1;
                String s3;
                if (stacktraceelement.getFileName() != null)
                {
                    s2 = stacktraceelement.getFileName();
                } else
                {
                    s2 = "unknown";
                }
                stringbuilder1 = stringbuilder.append(s2);
                if (stacktraceelement.getLineNumber() >= 0)
                {
                    s3 = (new StringBuilder()).append(":").append(stacktraceelement.getLineNumber()).toString();
                } else
                {
                    s3 = "";
                }
                s4 = stringbuilder1.append(s3).toString();
            }
            tilrecord1 = newDebugUtilRecord(tilrecord1, s1, s4);
            j++;
        }
        return tilrecord1;
    }

    public tilRecord newDebugUtilRecord(String s, String s1)
    {
        return newDebugUtilRecord(null, s, s1);
    }

    public tilRecord()
    {
    }
}
