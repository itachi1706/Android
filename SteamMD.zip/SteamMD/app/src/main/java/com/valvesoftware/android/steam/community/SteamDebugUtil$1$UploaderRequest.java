// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;

import java.util.ArrayList;

// Referenced classes of package com.valvesoftware.android.steam.community:
//            SteamDebugUtil, Config, SteamCommunityApplication, SteamDebugUtilDatabase

final class m_CrashTrace extends m_CrashTrace
{

    public  m_CrashTrace;
    public boolean m_bFinished;
    public boolean m_bSucceeded;
    final  this$1;

    private void onUploaderFinished(boolean flag)
    {
        this;
        JVM INSTR monitorenter ;
        m_bFinished = true;
        m_bSucceeded = flag;
        notifyAll();
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public void RequestFailedOnResponseWorkerThread()
    {
        onUploaderFinished(false);
    }

    public void RequestSucceededOnResponseWorkerThread()
    {
        onUploaderFinished(true);
    }

    public String buildPostData()
    {
        return m_CrashTrace.info;
    }

    public ( 1)
    {
        this$1 = this._cls1.this;
        super("SteamDebugUtilUploader");
        m_CrashTrace = 1;
    }

    // Unreferenced inner class com/valvesoftware/android/steam/community/SteamDebugUtil$1

/* anonymous class */
    class SteamDebugUtil._cls1 extends Thread
    {

        final SteamDebugUtil this$0;
        final ArrayList val$arrTraces;

        public void run()
        {
            int j;
            int k;
            int i = arrTraces.size();
            j = 30;
            k = i;
_L4:
            int l;
            SteamDebugUtil._cls1.UploaderRequest uploaderrequest;
            l = k - 1;
            if (k <= 0)
            {
                break MISSING_BLOCK_LABEL_191;
            }
            uploaderrequest = new SteamDebugUtil._cls1.UploaderRequest((SteamDebugUtilDatabase.CrashTrace)arrTraces.get(l));
            uploaderrequest.SetUriAndDocumentType(Config.URL_MOBILE_CRASH_UPLOAD, SteamWebApi.RequestDocumentType.JSON);
            uploaderrequest.SetPostData(uploaderrequest.buildPostData());
            uploaderrequest.SetRequestAction(SteamWebApi.RequestActionType.DoHttpRequestNoCache);
            uploaderrequest;
            JVM INSTR monitorenter ;
            SteamCommunityApplication.GetInstance().SubmitSteamDBRequest(uploaderrequest);
_L1:
            boolean flag = uploaderrequest.m_bFinished;
label0:
            {
                if (flag)
                {
                    break label0;
                }
                long l1;
                try
                {
                    uploaderrequest.wait();
                }
                catch (InterruptedException interruptedexception1) { }
                finally { }
            }
              goto _L1
            if (!uploaderrequest.m_bSucceeded)
            {
                break MISSING_BLOCK_LABEL_157;
            }
            j = 30;
            SteamDebugUtil.access$100(SteamDebugUtil.this).updateMarkCrashTraceUploaded(uploaderrequest.m_CrashTrace);
_L2:
            uploaderrequest;
            JVM INSTR monitorexit ;
            l1 = j * 1000;
            Exception exception;
            try
            {
                Thread.sleep(l1);
            }
            catch (InterruptedException interruptedexception) { }
            k = l;
            continue; /* Loop/switch isn't completed */
            j *= 2;
            if (j > 10800)
            {
                j = 10800;
            }
            l++;
              goto _L2
            uploaderrequest;
            JVM INSTR monitorexit ;
            throw exception;
            return;
            if (true) goto _L4; else goto _L3
_L3:
        }

            
            {
                this$0 = final_steamdebugutil;
                arrTraces = ArrayList.this;
                super();
            }
    }

}
