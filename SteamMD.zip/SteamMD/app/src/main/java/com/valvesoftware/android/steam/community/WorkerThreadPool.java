// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

public class WorkerThreadPool
{
    public static class AddBackToPoolException extends RuntimeException
    {

        private static final long serialVersionUID = 0x166a974b6d72b6L;

        public AddBackToPoolException()
        {
        }
    }

    private class JobQueue
        implements Runnable
    {

        private String m_sName;
        private final List m_tasks = new ArrayList();
        private Thread m_thread;
        final WorkerThreadPool this$0;

        private boolean RunNextTask()
        {
label0:
            {
                synchronized (m_tasks)
                {
                    if (!m_tasks.isEmpty())
                    {
                        break label0;
                    }
                    WaitForNextTaskOrTimeout();
                    if (!m_tasks.isEmpty())
                    {
                        break label0;
                    }
                    m_thread = null;
                }
                return false;
            }
            Task task;
            m_tasks.size();
            task = (Task)m_tasks.remove(0);
            list;
            JVM INSTR monitorexit ;
            TreeMap treemap;
            TaskResult taskresult = WorkerThreadPool.RunTask(task);
            static class _cls1
            {

                static final int $SwitchMap$com$valvesoftware$android$steam$community$WorkerThreadPool$TaskResult[];

                static 
                {
                    $SwitchMap$com$valvesoftware$android$steam$community$WorkerThreadPool$TaskResult = new int[TaskResult.values().length];
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$WorkerThreadPool$TaskResult[TaskResult.AddBackToPool.ordinal()] = 1;
                    }
                    catch (NoSuchFieldError nosuchfielderror) { }
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$WorkerThreadPool$TaskResult[TaskResult.ShutdownQueue.ordinal()] = 2;
                    }
                    catch (NoSuchFieldError nosuchfielderror1)
                    {
                        return;
                    }
                }
            }

            switch (_cls1..SwitchMap.com.valvesoftware.android.steam.community.WorkerThreadPool.TaskResult[taskresult.ordinal()])
            {
            default:
                return true;

            case 1: // '\001'
                AddTask(task);
                return true;

            case 2: // '\002'
                treemap = m_jobQueues;
                break;
            }
            break MISSING_BLOCK_LABEL_135;
            exception;
            list;
            JVM INSTR monitorexit ;
            throw exception;
            treemap;
            JVM INSTR monitorenter ;
            if (this == (JobQueue)m_jobQueues.remove(Integer.valueOf(System.identityHashCode(GetName()))));
            treemap;
            JVM INSTR monitorexit ;
            synchronized (m_tasks)
            {
                if (m_tasks.isEmpty());
            }
            return false;
            Exception exception1;
            exception1;
            treemap;
            JVM INSTR monitorexit ;
            throw exception1;
            exception2;
            list1;
            JVM INSTR monitorexit ;
            throw exception2;
        }

        private void WaitForNextTaskOrTimeout()
        {
            long l = System.currentTimeMillis();
_L2:
            long l1 = 2000L + l;
            long l2 = l1 - System.currentTimeMillis();
            if (l2 <= 0L)
            {
                break; /* Loop/switch isn't completed */
            }
            try
            {
                m_tasks.wait(l2);
                continue; /* Loop/switch isn't completed */
            }
            catch (InterruptedException interruptedexception) { }
            break; /* Loop/switch isn't completed */
            if (true) goto _L2; else goto _L1
_L1:
        }

        public void EnqueueTask(Task task)
        {
            List list = m_tasks;
            list;
            JVM INSTR monitorenter ;
            m_tasks.add(task);
            if (m_thread == null)
            {
                break MISSING_BLOCK_LABEL_35;
            }
            m_tasks.notify();
_L2:
            return;
            m_thread = new Thread(this, GetName());
            m_thread.start();
            if (true) goto _L2; else goto _L1
_L1:
            Exception exception;
            exception;
            list;
            JVM INSTR monitorexit ;
            throw exception;
        }

        public String GetName()
        {
            return m_sName;
        }

        public void run()
        {
            while (RunNextTask()) ;
        }

        public JobQueue(String s)
        {
            this$0 = WorkerThreadPool.this;
            super();
            m_sName = null;
            m_thread = null;
            m_sName = s;
        }
    }

    public static class ShutdownJobQueueException extends RuntimeException
    {

        private static final long serialVersionUID = 0xcd90656cde2413eaL;

        public ShutdownJobQueueException()
        {
        }
    }

    public static interface Task
    {

        public abstract String GetRequestQueue();

        public abstract void Run()
            throws Exception;
    }

    private static final class TaskResult extends Enum
    {

        private static final TaskResult $VALUES[];
        public static final TaskResult AddBackToPool;
        public static final TaskResult Continue;
        public static final TaskResult ShutdownQueue;

        public static TaskResult valueOf(String s)
        {
            return (TaskResult)Enum.valueOf(com/valvesoftware/android/steam/community/WorkerThreadPool$TaskResult, s);
        }

        public static TaskResult[] values()
        {
            return (TaskResult[])$VALUES.clone();
        }

        static 
        {
            Continue = new TaskResult("Continue", 0);
            AddBackToPool = new TaskResult("AddBackToPool", 1);
            ShutdownQueue = new TaskResult("ShutdownQueue", 2);
            TaskResult ataskresult[] = new TaskResult[3];
            ataskresult[0] = Continue;
            ataskresult[1] = AddBackToPool;
            ataskresult[2] = ShutdownQueue;
            $VALUES = ataskresult;
        }

        private TaskResult(String s, int i)
        {
            super(s, i);
        }
    }


    static String TAG = "WorkerThreadPool";
    private final TreeMap m_jobQueues = new TreeMap();

    public WorkerThreadPool()
    {
    }

    public static TaskResult RunTask(Task task)
    {
        try
        {
            task.Run();
        }
        catch (ShutdownJobQueueException shutdownjobqueueexception)
        {
            return TaskResult.ShutdownQueue;
        }
        catch (AddBackToPoolException addbacktopoolexception)
        {
            return TaskResult.AddBackToPool;
        }
        catch (Exception exception) { }
        return TaskResult.Continue;
    }

    public void AddTask(Task task)
    {
        String s;
        Integer integer;
        s = task.GetRequestQueue();
        integer = Integer.valueOf(System.identityHashCode(s));
        TreeMap treemap = m_jobQueues;
        treemap;
        JVM INSTR monitorenter ;
        JobQueue jobqueue = (JobQueue)m_jobQueues.get(integer);
        if (jobqueue != null)
        {
            break MISSING_BLOCK_LABEL_68;
        }
        JobQueue jobqueue1 = new JobQueue(s);
        m_jobQueues.put(integer, jobqueue1);
        jobqueue = jobqueue1;
        treemap;
        JVM INSTR monitorexit ;
        jobqueue.EnqueueTask(task);
        return;
        Exception exception;
        exception;
_L2:
        treemap;
        JVM INSTR monitorexit ;
        throw exception;
        exception;
        if (true) goto _L2; else goto _L1
_L1:
    }


}
