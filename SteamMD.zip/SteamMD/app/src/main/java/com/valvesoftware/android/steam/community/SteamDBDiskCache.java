// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.TreeMap;

public class SteamDBDiskCache
{
    private static class DataDiskAccessByteArray
        implements IDataDiskAccess
    {

        byte m_data[];

        public void onRead(FileInputStream fileinputstream, long l)
            throws IOException
        {
            byte abyte0[] = new byte[(int)l];
            int i = fileinputstream.read(abyte0);
            if ((long)i != l)
            {
                throw new IOException((new StringBuilder()).append("File read produced ").append(i).append(" when ").append(l).append(" was expected").toString());
            } else
            {
                m_data = abyte0;
                return;
            }
        }

        public void onWrite(OutputStream outputstream)
            throws IOException
        {
            if (m_data != null)
            {
                outputstream.write(m_data);
            }
        }

        private DataDiskAccessByteArray()
        {
        }

    }

    public static interface IDataDiskAccess
    {

        public abstract void onRead(FileInputStream fileinputstream, long l)
            throws IOException;

        public abstract void onWrite(OutputStream outputstream)
            throws IOException;
    }

    public static class IndefiniteCache extends SteamDBDiskCache
    {

        public void Delete(String s)
        {
            this;
            JVM INSTR monitorenter ;
            (new File(m_dir, getFileNameFromUri(s))).delete();
            this;
            JVM INSTR monitorexit ;
            return;
            Exception exception;
            exception;
            throw exception;
        }

        public IndefiniteCache(File file)
        {
            super(file);
        }
    }

    public static class WebCache extends SteamDBDiskCache
    {

        private TreeMap m_ageMap;
        private final int m_numFilesLimit = 1024;

        protected String getFileNameFromUri(String s)
        {
            int i = s.hashCode();
            int j = s.length();
            int ai[] = new int[2];
            ai[0] = 1 + s.lastIndexOf('=');
            ai[1] = 1 + s.lastIndexOf('/');
            int k = Math.max(ai[0], ai[1]);
            if (k <= 0)
            {
                k = j;
            }
            StringBuilder stringbuilder = new StringBuilder((j + 13) - k);
            stringbuilder.append(i);
            stringbuilder.append("_");
            stringbuilder.append(s.substring(k));
            return stringbuilder.toString();
        }

        protected void onAfterWriteToFile(File file)
        {
            if (m_ageMap != null)
            {
                m_ageMap.put(Long.valueOf(System.currentTimeMillis()), file);
            }
            if (m_ageMap == null)
            {
                m_ageMap = new TreeMap();
                File afile[] = m_dir.listFiles();
                int i = afile.length;
                for (int j = 0; j < i; j++)
                {
                    File file1 = afile[j];
                    long l = file1.lastModified();
                    m_ageMap.put(Long.valueOf(l), file1);
                }

            }
            while (m_ageMap.size() > 1024) 
            {
                if (((File)m_ageMap.remove(m_ageMap.firstKey())).delete());
            }
        }

        public WebCache(File file)
        {
            super(file);
            m_ageMap = null;
        }
    }


    private static final String s_tmpFileName = "tmpfile";
    protected File m_dir;
    private int m_idxTmpFileName;

    protected SteamDBDiskCache(File file)
    {
        m_idxTmpFileName = 0;
        m_dir = file;
    }

    private boolean ReadFromFile(File file, IDataDiskAccess idatadiskaccess)
        throws IOException
    {
        this;
        JVM INSTR monitorenter ;
        boolean flag = file.exists();
        if (flag) goto _L2; else goto _L1
_L1:
        boolean flag1 = false;
_L4:
        this;
        JVM INSTR monitorexit ;
        return flag1;
_L2:
        FileInputStream fileinputstream = new FileInputStream(file);
        long l = file.length();
        if (l <= 0x7fffffffL)
        {
            break MISSING_BLOCK_LABEL_101;
        }
        throw new IOException((new StringBuilder()).append("File ").append(file.getAbsolutePath()).append(" is too large: ").append(l).toString());
        Exception exception1;
        exception1;
        fileinputstream.close();
        throw exception1;
        Exception exception;
        exception;
        this;
        JVM INSTR monitorexit ;
        throw exception;
        if (idatadiskaccess == null)
        {
            break MISSING_BLOCK_LABEL_115;
        }
        idatadiskaccess.onRead(fileinputstream, l);
        fileinputstream.close();
        flag1 = true;
        if (true) goto _L4; else goto _L3
_L3:
    }

    private void WriteToFile(File file, IDataDiskAccess idatadiskaccess)
        throws IOException
    {
        this;
        JVM INSTR monitorenter ;
        File file1;
        m_idxTmpFileName = 1 + m_idxTmpFileName;
        file1 = new File(m_dir, (new StringBuilder()).append("tmpfile").append(m_idxTmpFileName).toString());
        FileOutputStream fileoutputstream = null;
        FileOutputStream fileoutputstream1 = new FileOutputStream(file1);
        if (idatadiskaccess == null)
        {
            break MISSING_BLOCK_LABEL_73;
        }
        idatadiskaccess.onWrite(fileoutputstream1);
        fileoutputstream1.flush();
        fileoutputstream1.close();
        if (true)
        {
            break MISSING_BLOCK_LABEL_91;
        }
        null.close();
        if (file1.renameTo(file));
        onAfterWriteToFile(file);
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception1;
        exception1;
_L2:
        if (fileoutputstream == null)
        {
            break MISSING_BLOCK_LABEL_120;
        }
        fileoutputstream.close();
        throw exception1;
        Exception exception;
        exception;
        this;
        JVM INSTR monitorexit ;
        throw exception;
        exception1;
        fileoutputstream = fileoutputstream1;
        if (true) goto _L2; else goto _L1
_L1:
    }

    public boolean Read(String s, IDataDiskAccess idatadiskaccess)
    {
        boolean flag;
        try
        {
            flag = ReadFromFile(new File(m_dir, getFileNameFromUri(s)), idatadiskaccess);
        }
        catch (Exception exception)
        {
            return false;
        }
        return flag;
    }

    public byte[] Read(String s)
    {
        DataDiskAccessByteArray datadiskaccessbytearray = new DataDiskAccessByteArray();
        boolean flag = Read(s, ((IDataDiskAccess) (datadiskaccessbytearray)));
        byte abyte0[] = null;
        if (flag)
        {
            abyte0 = datadiskaccessbytearray.m_data;
        }
        return abyte0;
    }

    public void Write(String s, IDataDiskAccess idatadiskaccess)
    {
        try
        {
            WriteToFile(new File(m_dir, getFileNameFromUri(s)), idatadiskaccess);
            return;
        }
        catch (Exception exception)
        {
            return;
        }
    }

    public void Write(String s, byte abyte0[])
    {
        DataDiskAccessByteArray datadiskaccessbytearray = new DataDiskAccessByteArray();
        datadiskaccessbytearray.m_data = abyte0;
        Write(s, ((IDataDiskAccess) (datadiskaccessbytearray)));
    }

    protected String getFileNameFromUri(String s)
    {
        return s;
    }

    protected void onAfterWriteToFile(File file)
    {
    }
}
