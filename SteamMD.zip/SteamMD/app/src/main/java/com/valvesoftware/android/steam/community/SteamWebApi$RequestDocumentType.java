// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;


// Referenced classes of package com.valvesoftware.android.steam.community:
//            SteamWebApi

public static final class  extends Enum
{

    private static final .VALUES $VALUES[];
    public static final .VALUES Bitmap;
    public static final .VALUES JSON;
    public static final .VALUES String;

    public static  valueOf(String s)
    {
        return ()Enum.valueOf(com/valvesoftware/android/steam/community/SteamWebApi$RequestDocumentType, s);
    }

    public static [] values()
    {
        return ([])$VALUES.clone();
    }

    static 
    {
        String = new <init>("String", 0);
        JSON = new <init>("JSON", 1);
        Bitmap = new <init>("Bitmap", 2);
        e_3B_.clone aclone[] = new <init>[3];
        aclone[0] = String;
        aclone[1] = JSON;
        aclone[2] = Bitmap;
        $VALUES = aclone;
    }

    private (String s, int i)
    {
        super(s, i);
    }
}
