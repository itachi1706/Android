// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;


// Referenced classes of package com.valvesoftware.android.steam.community:
//            GroupInfo

public static final class  extends Enum
{

    private static final .VALUES $VALUES[];
    public static final .VALUES Blocked;
    public static final .VALUES Invited;
    public static final .VALUES Kicked;
    public static final .VALUES Member;
    public static final .VALUES None;

    public static  valueOf(String s)
    {
        return ()Enum.valueOf(com/valvesoftware/android/steam/community/GroupInfo$GroupRelationship, s);
    }

    public static [] values()
    {
        return ([])$VALUES.clone();
    }

    static 
    {
        None = new <init>("None", 0);
        Blocked = new <init>("Blocked", 1);
        Invited = new <init>("Invited", 2);
        Member = new <init>("Member", 3);
        Kicked = new <init>("Kicked", 4);
        p_3B_.clone aclone[] = new <init>[5];
        aclone[0] = None;
        aclone[1] = Blocked;
        aclone[2] = Invited;
        aclone[3] = Member;
        aclone[4] = Kicked;
        $VALUES = aclone;
    }

    private (String s, int i)
    {
        super(s, i);
    }
}
