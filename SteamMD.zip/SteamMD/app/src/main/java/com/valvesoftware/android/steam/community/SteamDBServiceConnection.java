// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;

import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.IBinder;
import java.util.ArrayList;
import java.util.Iterator;

// Referenced classes of package com.valvesoftware.android.steam.community:
//            SteamDBService

class SteamDBServiceConnection
    implements ServiceConnection
{

    private ArrayList m_pendingReqs;
    private SteamDBService m_steamDBBinder;

    SteamDBServiceConnection()
    {
        m_steamDBBinder = null;
        m_pendingReqs = new ArrayList();
    }

    SteamDBService GetService()
    {
        return m_steamDBBinder;
    }

    public void SubmitRequest(SteamWebApi.RequestBase requestbase)
    {
        if (m_steamDBBinder != null)
        {
            m_steamDBBinder.SubmitRequest(requestbase);
            return;
        } else
        {
            m_pendingReqs.add(requestbase);
            return;
        }
    }

    protected final String TAG()
    {
        return getClass().getSimpleName();
    }

    public void onServiceConnected(ComponentName componentname, IBinder ibinder)
    {
        m_steamDBBinder = ((SteamDBService.SteamDBTempBinder)ibinder).getService();
        SteamWebApi.RequestBase requestbase;
        for (Iterator iterator = m_pendingReqs.iterator(); iterator.hasNext(); m_steamDBBinder.SubmitRequest(requestbase))
        {
            requestbase = (SteamWebApi.RequestBase)iterator.next();
        }

        m_pendingReqs.clear();
    }

    public void onServiceDisconnected(ComponentName componentname)
    {
        m_steamDBBinder = null;
    }
}
