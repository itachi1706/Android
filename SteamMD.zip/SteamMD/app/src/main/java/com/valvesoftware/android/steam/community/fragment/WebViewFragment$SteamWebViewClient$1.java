// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.fragment;

import android.content.DialogInterface;
import android.support.v4.app.FragmentActivity;
import android.webkit.WebView;

// Referenced classes of package com.valvesoftware.android.steam.community.fragment:
//            WebViewFragment

class this._cls1
    implements android.content.bViewFragment.SteamWebViewClient._cls1
{

    final ialog.show this$1;

    public void onClick(DialogInterface dialoginterface, int i)
    {
        if (i == -2)
        {
            getActivity().setResult(-1);
            getActivity().finish();
        } else
        if (dialoginterface == null && i == -3)
        {
            WebViewFragment.access$500(_fld0);
            WebViewFragment.access$200(_fld0).loadUrl(WebViewFragment.access$400(_fld0));
            WebViewFragment.access$600(_fld0).show();
            return;
        }
    }

    ialog()
    {
        this$1 = this._cls1.this;
        super();
    }
}
