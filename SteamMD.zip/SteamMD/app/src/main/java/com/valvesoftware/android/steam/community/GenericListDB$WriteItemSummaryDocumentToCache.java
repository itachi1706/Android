// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;


// Referenced classes of package com.valvesoftware.android.steam.community:
//            SteamDBDiskCache, GenericListDB

protected static class m_data extends m_data
{

    byte m_data[];

    public boolean OnTaskReadyToRunOnJobQueue()
    {
        m_data m_data1 = GetDiskCacheInfo();
        m_data1.GetDiskCacheInfo.Write(m_data1.GetDiskCacheInfo, m_data);
        return false;
    }

    public (String s, byte abyte0[])
    {
        super("JobQueueDiskCache");
        SetIndefiniteCacheFilename(s);
        m_data = abyte0;
    }
}
