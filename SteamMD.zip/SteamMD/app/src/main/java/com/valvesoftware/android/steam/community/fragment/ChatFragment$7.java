// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.fragment;

import java.util.ArrayList;

// Referenced classes of package com.valvesoftware.android.steam.community.fragment:
//            ChatFragment

class this._cls0
    implements com.valvesoftware.android.steam.community.istItemUpdatedListener
{

    final ChatFragment this$0;

    public void OnListItemInfoUpdateError(com.valvesoftware.android.steam.community.uestBase uestbase)
    {
    }

    public void OnListItemInfoUpdated(ArrayList arraylist, boolean flag)
    {
        ChatFragment.access$2100(ChatFragment.this);
    }

    public void OnListRefreshError(com.valvesoftware.android.steam.community.uestBase uestbase, boolean flag)
    {
    }

    public void OnListRequestsInProgress(boolean flag)
    {
    }

    datedListener()
    {
        this$0 = ChatFragment.this;
        super();
    }
}
