// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.fragment;

import android.view.KeyEvent;
import android.widget.TextView;

// Referenced classes of package com.valvesoftware.android.steam.community.fragment:
//            BasePresentationListFragmentWithSearch

class this._cls0
    implements android.widget.resentationListFragmentWithSearch._cls3
{

    final BasePresentationListFragmentWithSearch this$0;

    public boolean onEditorAction(TextView textview, int i, KeyEvent keyevent)
    {
        if (i == 3)
        {
            BasePresentationListFragmentWithSearch.access$000(BasePresentationListFragmentWithSearch.this);
            BasePresentationListFragmentWithSearch.access$100(BasePresentationListFragmentWithSearch.this);
        }
        return true;
    }

    a()
    {
        this$0 = BasePresentationListFragmentWithSearch.this;
        super();
    }
}
