// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.fragment;

import android.widget.EditText;

// Referenced classes of package com.valvesoftware.android.steam.community.fragment:
//            ChatFragment

class this._cls0
    implements Runnable
{

    final ChatFragment this$0;

    public void run()
    {
        ChatFragment.access$1800(ChatFragment.this).requestFocusFromTouch();
    }

    ()
    {
        this$0 = ChatFragment.this;
        super();
    }
}
