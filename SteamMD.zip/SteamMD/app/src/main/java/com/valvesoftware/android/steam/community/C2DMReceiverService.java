// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;

import android.app.AlarmManager;
import android.app.IntentService;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.PowerManager;
import java.io.IOException;

// Referenced classes of package com.valvesoftware.android.steam.community:
//            C2DMessaging

public abstract class C2DMReceiverService extends IntentService
{

    private static final String C2DM_INTENT = "com.google.android.c2dm.intent.RECEIVE";
    private static final String C2DM_RETRY = "com.google.android.c2dm.intent.RETRY";
    public static final String ERR_ACCOUNT_MISSING = "ACCOUNT_MISSING";
    public static final String ERR_AUTHENTICATION_FAILED = "AUTHENTICATION_FAILED";
    public static final String ERR_INVALID_PARAMETERS = "INVALID_PARAMETERS";
    public static final String ERR_INVALID_SENDER = "INVALID_SENDER";
    public static final String ERR_PHONE_REGISTRATION_ERROR = "PHONE_REGISTRATION_ERROR";
    public static final String ERR_SERVICE_NOT_AVAILABLE = "SERVICE_NOT_AVAILABLE";
    public static final String ERR_TOO_MANY_REGISTRATIONS = "TOO_MANY_REGISTRATIONS";
    public static final String EXTRA_ERROR = "error";
    public static final String EXTRA_REGISTRATION_ID = "registration_id";
    public static final String EXTRA_UNREGISTERED = "unregistered";
    public static final String REGISTRATION_CALLBACK_INTENT = "com.google.android.c2dm.intent.REGISTRATION";
    private static final String WAKELOCK_KEY = "C2DM_LIB";
    private final String senderId;

    public C2DMReceiverService(String s)
    {
        super(s);
        senderId = s;
    }

    private void handleRegistration(Context context, Intent intent)
    {
        String s = intent.getStringExtra("registration_id");
        String s1 = intent.getStringExtra("error");
        if (intent.getStringExtra("unregistered") != null)
        {
            C2DMessaging.clearRegistrationId(context);
            C2DMessaging.resetBackoff(context);
            onUnregistered(context);
        } else
        if (s1 != null)
        {
            C2DMessaging.clearRegistrationId(context);
            onError(context, s1);
            if ("SERVICE_NOT_AVAILABLE".equals(s1))
            {
                long l = C2DMessaging.getBackoff(context);
                PendingIntent pendingintent = PendingIntent.getBroadcast(context, 0, new Intent("com.google.android.c2dm.intent.RETRY"), 0);
                ((AlarmManager)context.getSystemService("alarm")).set(3, l, pendingintent);
                C2DMessaging.setBackoff(context, l * 2L);
                return;
            }
        } else
        {
            try
            {
                C2DMessaging.setRegistrationId(context, s);
                C2DMessaging.resetBackoff(context);
                onRegistered(context, s);
                return;
            }
            catch (IOException ioexception)
            {
                return;
            }
        }
    }

    static void runIntentInService(Context context, Intent intent)
    {
        intent.setClassName(context, (new StringBuilder()).append(context.getPackageName()).append(".C2DMProcessor").toString());
        context.startService(intent);
    }

    public abstract void onError(Context context, String s);

    public final void onHandleIntent(Intent intent)
    {
        android.os.PowerManager.WakeLock wakelock = null;
        Context context;
        PowerManager powermanager;
        context = getApplicationContext();
        powermanager = (PowerManager)context.getSystemService("power");
        wakelock = null;
        if (powermanager == null)
        {
            break MISSING_BLOCK_LABEL_44;
        }
        wakelock = powermanager.newWakeLock(1, "C2DM_LIB");
        if (wakelock == null)
        {
            break MISSING_BLOCK_LABEL_44;
        }
        wakelock.acquire();
        if (!intent.getAction().equals("com.google.android.c2dm.intent.REGISTRATION")) goto _L2; else goto _L1
_L1:
        handleRegistration(context, intent);
_L5:
        if (wakelock != null)
        {
            wakelock.release();
        }
        return;
_L2:
        if (!intent.getAction().equals("com.google.android.c2dm.intent.RECEIVE")) goto _L4; else goto _L3
_L3:
        onMessage(context, intent);
          goto _L5
        Exception exception;
        exception;
        if (wakelock != null)
        {
            wakelock.release();
        }
        throw exception;
_L4:
        if (!intent.getAction().equals("com.google.android.c2dm.intent.RETRY")) goto _L5; else goto _L6
_L6:
        C2DMessaging.register(context, senderId);
          goto _L5
    }

    protected abstract void onMessage(Context context, Intent intent);

    public void onRegistered(Context context, String s)
        throws IOException
    {
    }

    public void onUnregistered(Context context)
    {
    }
}
