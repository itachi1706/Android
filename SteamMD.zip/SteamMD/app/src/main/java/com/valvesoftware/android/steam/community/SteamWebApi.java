// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.webkit.CookieManager;
import android.webkit.CookieSyncManager;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.Socket;
import java.net.URLEncoder;
import java.net.UnknownHostException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.conn.scheme.PlainSocketFactory;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

// Referenced classes of package com.valvesoftware.android.steam.community:
//            Config, SteamCommunityApplication, FriendInfoDB, GroupInfoDB, 
//            SettingInfoDB, SettingInfo, SteamDBDiskCache

public class SteamWebApi
{
    public static class DevUniverseSSLSocketFactory extends SSLSocketFactory
    {

        SSLContext sslContext;

        public Socket createSocket()
            throws IOException
        {
            return sslContext.getSocketFactory().createSocket();
        }

        public Socket createSocket(Socket socket, String s, int i, boolean flag)
            throws IOException, UnknownHostException
        {
            return sslContext.getSocketFactory().createSocket(socket, s, i, flag);
        }

        public DevUniverseSSLSocketFactory(KeyStore keystore)
            throws NoSuchAlgorithmException, KeyManagementException, KeyStoreException, UnrecoverableKeyException
        {
            super(keystore);
            sslContext = SSLContext.getInstance("TLS");
            X509TrustManager x509trustmanager = new _cls1();
            sslContext.init(null, new TrustManager[] {
                x509trustmanager
            }, null);
        }
    }

    public static class LoginInformation
    {

        public String m_accessToken;
        public LoginState m_loginState;
        public String m_steamID;

        void LogOut()
        {
            m_loginState = LoginState.RequireUsernameAndPassword;
            m_steamID = null;
            m_accessToken = null;
        }

        public LoginInformation()
        {
            LogOut();
        }
    }

    public static final class LoginState extends Enum
    {

        private static final LoginState $VALUES[];
        public static final LoginState LoggedIn;
        public static final LoginState RequireSteamGuardEmailToken;
        public static final LoginState RequireUsernameAndPassword;

        public static LoginState valueOf(String s)
        {
            return (LoginState)Enum.valueOf(com/valvesoftware/android/steam/community/SteamWebApi$LoginState, s);
        }

        public static LoginState[] values()
        {
            return (LoginState[])$VALUES.clone();
        }

        static 
        {
            RequireUsernameAndPassword = new LoginState("RequireUsernameAndPassword", 0);
            RequireSteamGuardEmailToken = new LoginState("RequireSteamGuardEmailToken", 1);
            LoggedIn = new LoginState("LoggedIn", 2);
            LoginState aloginstate[] = new LoginState[3];
            aloginstate[0] = RequireUsernameAndPassword;
            aloginstate[1] = RequireSteamGuardEmailToken;
            aloginstate[2] = LoggedIn;
            $VALUES = aloginstate;
        }

        private LoginState(String s, int i)
        {
            super(s, i);
        }
    }

    public static final class RequestActionType extends Enum
    {

        private static final RequestActionType $VALUES[];
        public static final RequestActionType DoHttpRequestAndCacheResults;
        public static final RequestActionType DoHttpRequestNoCache;
        public static final RequestActionType GetFromCacheOnly;
        public static final RequestActionType GetFromCacheOrDoHttpRequestAndCacheResults;

        public static RequestActionType valueOf(String s)
        {
            return (RequestActionType)Enum.valueOf(com/valvesoftware/android/steam/community/SteamWebApi$RequestActionType, s);
        }

        public static RequestActionType[] values()
        {
            return (RequestActionType[])$VALUES.clone();
        }

        static 
        {
            DoHttpRequestAndCacheResults = new RequestActionType("DoHttpRequestAndCacheResults", 0);
            GetFromCacheOnly = new RequestActionType("GetFromCacheOnly", 1);
            GetFromCacheOrDoHttpRequestAndCacheResults = new RequestActionType("GetFromCacheOrDoHttpRequestAndCacheResults", 2);
            DoHttpRequestNoCache = new RequestActionType("DoHttpRequestNoCache", 3);
            RequestActionType arequestactiontype[] = new RequestActionType[4];
            arequestactiontype[0] = DoHttpRequestAndCacheResults;
            arequestactiontype[1] = GetFromCacheOnly;
            arequestactiontype[2] = GetFromCacheOrDoHttpRequestAndCacheResults;
            arequestactiontype[3] = DoHttpRequestNoCache;
            $VALUES = arequestactiontype;
        }

        private RequestActionType(String s, int i)
        {
            super(s, i);
        }
    }

    public static class RequestBase
    {

        static final boolean $assertionsDisabled = false;
        private static final String HTTP_PARAM_DEFAULT_PROXY = "proxy.valvesoftware.com";
        private static final int HTTP_PARAM_DEFAULT_PROXY_PORT = 3128;
        private static final boolean HTTP_PARAM_DEFAULT_USING_PROXY = false;
        private static final int HTTP_TIMEOUT_DEFAULT_CONN = 25000;
        private static final int HTTP_TIMEOUT_DEFAULT_SO = 25000;
        private DiskCacheInfo m_DiskCacheInfo;
        protected Bitmap m_bitmap;
        private String m_callerIntent;
        private String m_callerRequestQueue;
        protected JSONObject m_jsonDocument;
        private Object m_objData;
        private String m_postData;
        private RequestDocumentType m_requestDocumentType;
        private RequestHttpMode m_requestMode;
        private SteamDBService.UriData m_result;
        private RequestActionType m_skipMode;
        private String m_uri;

        public HttpResponse FetchHttpResponseOnWorkerThread()
            throws Exception
        {
            return GetDefaultHttpClient().execute(GetDefaultHttpRequestBase());
        }

        public Bitmap GetBitmap()
        {
            return m_bitmap;
        }

        public String GetCallerIntent()
        {
            return m_callerIntent;
        }

        protected DefaultHttpClient GetDefaultHttpClient()
        {
            if (Config.STEAM_UNIVERSE_WEBAPI != Config.SteamUniverse.Dev)
            {
                break MISSING_BLOCK_LABEL_122;
            }
            DefaultHttpClient defaulthttpclient;
            KeyStore keystore = KeyStore.getInstance(KeyStore.getDefaultType());
            keystore.load(null, null);
            DevUniverseSSLSocketFactory devuniversesslsocketfactory = new DevUniverseSSLSocketFactory(keystore);
            devuniversesslsocketfactory.setHostnameVerifier(SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
            SchemeRegistry schemeregistry = new SchemeRegistry();
            schemeregistry.register(new Scheme("http", PlainSocketFactory.getSocketFactory(), 80));
            schemeregistry.register(new Scheme("https", devuniversesslsocketfactory, 443));
            HttpParams httpparams = GetDefaultHttpParams();
            defaulthttpclient = new DefaultHttpClient(new ThreadSafeClientConnManager(httpparams, schemeregistry), httpparams);
            return defaulthttpclient;
            Exception exception;
            exception;
            exception.printStackTrace();
            return new DefaultHttpClient(GetDefaultHttpParams());
        }

        protected HttpParams GetDefaultHttpParams()
        {
            BasicHttpParams basichttpparams = new BasicHttpParams();
            HttpConnectionParams.setConnectionTimeout(basichttpparams, 25000);
            HttpConnectionParams.setSoTimeout(basichttpparams, 25000);
            return basichttpparams;
        }

        protected HttpRequestBase GetDefaultHttpRequestBase()
            throws Exception
        {
            Object obj;
            if (GetMode() == RequestHttpMode.Get)
            {
                obj = new HttpGet(GetUri(0));
            } else
            {
                HttpPost httppost = new HttpPost(GetUri(0));
                obj = httppost;
                httppost.addHeader("Content-Type", "application/x-www-form-urlencoded");
                httppost.setEntity(new StringEntity(GetPostData()));
            }
            ((HttpRequestBase) (obj)).addHeader("User-Agent", (new StringBuilder()).append("Steam App / Android / ").append(Config.APP_VERSION).append(" / ").append(Config.APP_VERSION_ID).toString());
            return ((HttpRequestBase) (obj));
        }

        public DiskCacheInfo GetDiskCacheInfo()
        {
            if (m_DiskCacheInfo == null)
            {
                m_DiskCacheInfo = new DiskCacheInfo();
                m_DiskCacheInfo.disk = SteamCommunityApplication.GetInstance().GetDiskCacheWeb();
                m_DiskCacheInfo.uri = GetUri(0);
            }
            return m_DiskCacheInfo;
        }

        public String GetDocument()
        {
            SteamDBService.UriData uridata = m_result;
            String s = null;
            if (uridata != null)
            {
                s = m_result.GetDocument();
            }
            if (s == null)
            {
                s = "";
            }
            return s;
        }

        public SteamDBService.UriData GetHttpResponseUriData()
        {
            return m_result;
        }

        public int GetIntentId()
        {
            return System.identityHashCode(this);
        }

        public JSONObject GetJSONDocument()
        {
            return m_jsonDocument;
        }

        public RequestHttpMode GetMode()
        {
            return m_requestMode;
        }

        public Object GetObjData()
        {
            return m_objData;
        }

        public String GetPostData()
        {
            return m_postData;
        }

        public RequestActionType GetRequestAction()
        {
            return m_skipMode;
        }

        public RequestDocumentType GetRequestDocumentType()
        {
            return m_requestDocumentType;
        }

        public String GetRequestQueue()
        {
            return m_callerRequestQueue;
        }

        public String GetUri()
        {
            if (!$assertionsDisabled && m_uri == null)
            {
                throw new AssertionError();
            } else
            {
                return m_uri;
            }
        }

        public String GetUri(int i)
        {
            if (!$assertionsDisabled && m_uri == null)
            {
                throw new AssertionError();
            } else
            {
                return m_uri;
            }
        }

        public boolean IsRequestForByteData()
        {
            return GetRequestDocumentType() == com.valvesoftware.android.steam.community.RequestDocumentType.Bitmap;
        }

        public boolean IsRequestLive()
        {
            if (m_result == null)
            {
                return false;
            } else
            {
                return m_result.IsRequestLive();
            }
        }

        public void OnFailureWorkerThread(SteamDBService.UriData uridata)
        {
            m_result = uridata;
            RequestFailedOnResponseWorkerThread();
            if (uridata.m_httpResult == 401)
            {
                SteamWebApi.LogOut();
            }
        }

        public void OnResponseWorkerThread(SteamDBService.UriData uridata)
            throws Exception
        {
            m_result = uridata;
            static class _cls1
            {

                static final int $SwitchMap$com$valvesoftware$android$steam$community$SteamWebApi$RequestDocumentType[];

                static 
                {
                    $SwitchMap$com$valvesoftware$android$steam$community$SteamWebApi$RequestDocumentType = new int[RequestDocumentType.values().length];
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$SteamWebApi$RequestDocumentType[RequestDocumentType.String.ordinal()] = 1;
                    }
                    catch (NoSuchFieldError nosuchfielderror) { }
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$SteamWebApi$RequestDocumentType[RequestDocumentType.JSON.ordinal()] = 2;
                    }
                    catch (NoSuchFieldError nosuchfielderror1) { }
                    try
                    {
                        $SwitchMap$com$valvesoftware$android$steam$community$SteamWebApi$RequestDocumentType[com.valvesoftware.android.steam.community.RequestDocumentType.Bitmap.ordinal()] = 3;
                    }
                    catch (NoSuchFieldError nosuchfielderror2)
                    {
                        return;
                    }
                }
            }

            _cls1..SwitchMap.com.valvesoftware.android.steam.community.SteamWebApi.RequestDocumentType[m_requestDocumentType.ordinal()];
            JVM INSTR tableswitch 1 3: default 44
        //                       1 50
        //                       2 55
        //                       3 129;
               goto _L1 _L2 _L3 _L4
_L1:
            OnFailureWorkerThread(uridata);
            return;
_L2:
            RequestSucceededOnResponseWorkerThread();
            return;
_L3:
            try
            {
                Object obj = (new JSONTokener(m_result.GetDocument())).nextValue();
                if (org/json/JSONObject.isInstance(obj))
                {
                    m_jsonDocument = (JSONObject)obj;
                    RequestSucceededOnResponseWorkerThread();
                    return;
                }
            }
            catch (JSONException jsonexception)
            {
                m_result.SetRequestError(1);
                OnFailureWorkerThread(uridata);
                return;
            }
            m_result.SetRequestError(1);
            OnFailureWorkerThread(uridata);
            return;
_L4:
            byte abyte0[] = m_result.GetByteData();
            Bitmap bitmap;
            if (abyte0 != null)
            {
                bitmap = BitmapFactory.decodeByteArray(abyte0, 0, abyte0.length);
            } else
            {
                bitmap = null;
            }
            m_bitmap = bitmap;
            if (m_bitmap != null)
            {
                RequestSucceededOnResponseWorkerThread();
                return;
            } else
            {
                m_result.SetRequestError(1);
                OnFailureWorkerThread(uridata);
                return;
            }
        }

        public boolean OnTaskReadyToRunOnJobQueue()
        {
            return true;
        }

        public void RequestFailedOnResponseWorkerThread()
        {
        }

        public void RequestSucceededOnResponseWorkerThread()
        {
        }

        public void SetCallerIntent(String s)
        {
            if (!$assertionsDisabled && m_callerIntent != null)
            {
                throw new AssertionError();
            } else
            {
                m_callerIntent = s;
                return;
            }
        }

        public void SetIndefiniteCacheFilename(String s)
        {
            if (!$assertionsDisabled && m_DiskCacheInfo != null)
            {
                throw new AssertionError();
            } else
            {
                m_DiskCacheInfo = new DiskCacheInfo();
                m_DiskCacheInfo.disk = SteamCommunityApplication.GetInstance().GetDiskCacheIndefinite();
                m_DiskCacheInfo.uri = s;
                return;
            }
        }

        public void SetObjData(Object obj)
        {
            if (!$assertionsDisabled && m_objData != null)
            {
                throw new AssertionError();
            } else
            {
                m_objData = obj;
                return;
            }
        }

        public void SetPostData(String s)
        {
            if (!$assertionsDisabled && m_postData != null)
            {
                throw new AssertionError();
            } else
            {
                m_requestMode = RequestHttpMode.Post;
                m_postData = s;
                return;
            }
        }

        public void SetRequestAction(RequestActionType requestactiontype)
        {
            m_skipMode = requestactiontype;
        }

        public void SetUriAndDocumentType(String s, RequestDocumentType requestdocumenttype)
        {
            if (!$assertionsDisabled && m_uri != null)
            {
                throw new AssertionError();
            } else
            {
                m_uri = s;
                m_requestDocumentType = requestdocumenttype;
                return;
            }
        }

        static 
        {
            boolean flag;
            if (!com/valvesoftware/android/steam/community/SteamWebApi.desiredAssertionStatus())
            {
                flag = true;
            } else
            {
                flag = false;
            }
            $assertionsDisabled = flag;
        }


/*
        static String access$002(RequestBase requestbase, String s)
        {
            requestbase.m_uri = s;
            return s;
        }

*/


/*
        static Object access$102(RequestBase requestbase, Object obj)
        {
            requestbase.m_objData = obj;
            return obj;
        }

*/

        public RequestBase(String s)
        {
            m_callerIntent = null;
            m_callerRequestQueue = null;
            m_uri = null;
            m_requestMode = RequestHttpMode.Get;
            m_postData = null;
            m_objData = null;
            m_requestDocumentType = RequestDocumentType.String;
            m_skipMode = RequestActionType.DoHttpRequestAndCacheResults;
            m_result = null;
            m_jsonDocument = null;
            m_bitmap = null;
            m_callerRequestQueue = s;
        }
    }

    public static class RequestBase.DiskCacheInfo
    {

        SteamDBDiskCache disk;
        String uri;

        public RequestBase.DiskCacheInfo()
        {
        }
    }

    public static final class RequestDocumentType extends Enum
    {

        private static final RequestDocumentType $VALUES[];
        public static final RequestDocumentType Bitmap;
        public static final RequestDocumentType JSON;
        public static final RequestDocumentType String;

        public static RequestDocumentType valueOf(String s)
        {
            return (RequestDocumentType)Enum.valueOf(com/valvesoftware/android/steam/community/SteamWebApi$RequestDocumentType, s);
        }

        public static RequestDocumentType[] values()
        {
            return (RequestDocumentType[])$VALUES.clone();
        }

        static 
        {
            String = new RequestDocumentType("String", 0);
            JSON = new RequestDocumentType("JSON", 1);
            Bitmap = new RequestDocumentType("Bitmap", 2);
            RequestDocumentType arequestdocumenttype[] = new RequestDocumentType[3];
            arequestdocumenttype[0] = String;
            arequestdocumenttype[1] = JSON;
            arequestdocumenttype[2] = Bitmap;
            $VALUES = arequestdocumenttype;
        }

        private RequestDocumentType(String s, int i)
        {
            super(s, i);
        }
    }

    public static class RequestForAppSummariesByAppIDs extends RequestBase
    {

        public String m_appIDs[];

        public RequestForAppSummariesByAppIDs()
        {
            super("JobQueueAppsDB");
            m_appIDs = null;
            SetRequestAction(RequestActionType.DoHttpRequestNoCache);
        }
    }

    public static class RequestForFriendListByOwnerSteamID extends RequestBase
    {

        public String m_steamID;

        public RequestForFriendListByOwnerSteamID()
        {
            super("JobQueueFriendsDB");
            m_steamID = null;
        }
    }

    public static class RequestForGroupListByOwnerSteamID extends RequestBase
    {

        public String m_steamID;

        public RequestForGroupListByOwnerSteamID()
        {
            super("JobQueueGroupsDB");
            m_steamID = null;
        }
    }

    public static class RequestForGroupsBySteamIDs extends RequestBase
    {

        public String m_steamIDs[];

        public RequestForGroupsBySteamIDs()
        {
            super("JobQueueGroupsDB");
            m_steamIDs = null;
            SetRequestAction(RequestActionType.DoHttpRequestNoCache);
        }
    }

    public static class RequestForLogin
    {

        public static final String CACHE_FILENAME = "login.json";

        public static LoginInformation GetLoginInformation()
        {
            return SteamWebApi.s_loginInformation;
        }

        public RequestForLogin()
        {
        }
    }

    public static class RequestForUserSummariesBySteamIDs extends RequestBase
    {

        public String m_steamIDs[];

        public RequestForUserSummariesBySteamIDs()
        {
            super("JobQueueFriendsDB");
            m_steamIDs = null;
            SetRequestAction(RequestActionType.DoHttpRequestNoCache);
        }
    }

    public static final class RequestHttpMode extends Enum
    {

        private static final RequestHttpMode $VALUES[];
        public static final RequestHttpMode Get;
        public static final RequestHttpMode Post;

        public static RequestHttpMode valueOf(String s)
        {
            return (RequestHttpMode)Enum.valueOf(com/valvesoftware/android/steam/community/SteamWebApi$RequestHttpMode, s);
        }

        public static RequestHttpMode[] values()
        {
            return (RequestHttpMode[])$VALUES.clone();
        }

        static 
        {
            Get = new RequestHttpMode("Get", 0);
            Post = new RequestHttpMode("Post", 1);
            RequestHttpMode arequesthttpmode[] = new RequestHttpMode[2];
            arequesthttpmode[0] = Get;
            arequesthttpmode[1] = Post;
            $VALUES = arequesthttpmode;
        }

        private RequestHttpMode(String s, int i)
        {
            super(s, i);
        }
    }


    static final boolean $assertionsDisabled = false;
    private static final String RequestForAppSummariesByAppIDs_URI;
    private static final String RequestForFriendListByOwnerSteamID_URI;
    private static final String RequestForGroupListByOwnerSteamID_URI;
    private static final String RequestForGroupsBySteamIDs_URI;
    private static final String RequestForUserSummariesBySteamIDs_URI;
    private static final String TAG = "SteamWebApi";
    private static boolean s_bCookiesAreOutOfDate = false;
    private static Map s_cookiesConfiguration = new HashMap();
    private static LoginInformation s_loginInformation = new LoginInformation();

    public SteamWebApi()
    {
    }

    private static void AddAppIds(StringBuilder stringbuilder, String as[])
    {
        stringbuilder.append("&appids=");
        AddIds(stringbuilder, as);
    }

    private static void AddIds(StringBuilder stringbuilder, String as[])
    {
        if (as.length > 0)
        {
            stringbuilder.append(as[0]);
        }
        int i = Math.min(as.length, 100);
        if (!$assertionsDisabled && i != as.length)
        {
            throw new AssertionError();
        }
        int j = 1;
        do
        {
            if (j >= i || as[j] == null)
            {
                return;
            }
            stringbuilder.append(",");
            stringbuilder.append(as[j]);
            j++;
        } while (true);
    }

    private static void AddSteamId(StringBuilder stringbuilder, String s)
    {
        stringbuilder.append("&steamid=");
        stringbuilder.append(s);
    }

    private static void AddSteamIds(StringBuilder stringbuilder, String as[])
    {
        stringbuilder.append("&steamids=");
        AddIds(stringbuilder, as);
    }

    public static String GetCookieHeaderString(boolean flag)
    {
        Iterator iterator = s_cookiesConfiguration.entrySet().iterator();
        if (!iterator.hasNext()) goto _L2; else goto _L1
_L1:
        String s;
        Iterator iterator1;
        java.util.Map.Entry entry = (java.util.Map.Entry)iterator.next();
        s = "";
        iterator1 = ((Map)entry.getValue()).entrySet().iterator();
_L8:
        java.util.Map.Entry entry1;
        if (!iterator1.hasNext())
        {
            break; /* Loop/switch isn't completed */
        }
        entry1 = (java.util.Map.Entry)iterator1.next();
        if (!flag && ((String)entry1.getKey()).equals("steamLogin"))
        {
            continue; /* Loop/switch isn't completed */
        }
        if (entry1.getValue() == null) goto _L4; else goto _L3
_L3:
        String s4 = URLEncoder.encode((String)entry1.getValue(), "ISO-8859-1");
        String s1 = s4;
_L6:
        if (!s.equals(""))
        {
            s = (new StringBuilder()).append(s).append("; ").toString();
        }
        String s2 = (new StringBuilder()).append(s).append((String)entry1.getKey()).toString();
        String s3 = (new StringBuilder()).append(s2).append("=").toString();
        s = (new StringBuilder()).append(s3).append(s1).toString();
        continue; /* Loop/switch isn't completed */
_L4:
        s1 = "";
        if (true) goto _L6; else goto _L5
_L5:
        UnsupportedEncodingException unsupportedencodingexception;
        unsupportedencodingexception;
        if (true) goto _L8; else goto _L7
_L2:
        s = null;
_L7:
        return s;
    }

    public static String GetLoginAccessToken()
    {
        return s_loginInformation.m_accessToken;
    }

    public static LoginState GetLoginState()
    {
        return s_loginInformation.m_loginState;
    }

    public static String GetLoginSteamID()
    {
        return s_loginInformation.m_steamID;
    }

    public static RequestForAppSummariesByAppIDs GetRequestForAppSummariesByAppIDs(String as[])
    {
        if (!$assertionsDisabled && !IsLoggedIn())
        {
            throw new AssertionError();
        } else
        {
            StringBuilder stringbuilder = new StringBuilder(RequestForAppSummariesByAppIDs_URI.length() + PrecomputeAccessTokenLength() + PrecomputeKeyLength() + PrecomputeIdsLength(as));
            stringbuilder.append(RequestForAppSummariesByAppIDs_URI);
            StartWithAccessToken(stringbuilder);
            AddAppIds(stringbuilder, as);
            RequestForAppSummariesByAppIDs requestforappsummariesbyappids = new RequestForAppSummariesByAppIDs();
            requestforappsummariesbyappids.SetUriAndDocumentType(stringbuilder.toString(), RequestDocumentType.JSON);
            requestforappsummariesbyappids.m_appIDs = (String[])as.clone();
            return requestforappsummariesbyappids;
        }
    }

    public static RequestForFriendListByOwnerSteamID GetRequestForFriendListByOwnerSteamID(String s, boolean flag)
    {
        if (!$assertionsDisabled && !IsLoggedIn())
        {
            throw new AssertionError();
        }
        StringBuilder stringbuilder = new StringBuilder(RequestForFriendListByOwnerSteamID_URI.length() + PrecomputeAccessTokenLength() + PrecomputeKeyLength() + s.length());
        stringbuilder.append(RequestForFriendListByOwnerSteamID_URI);
        StartWithAccessToken(stringbuilder);
        AddSteamId(stringbuilder, s);
        RequestForFriendListByOwnerSteamID requestforfriendlistbyownersteamid = new RequestForFriendListByOwnerSteamID();
        requestforfriendlistbyownersteamid.SetUriAndDocumentType(stringbuilder.toString(), RequestDocumentType.JSON);
        requestforfriendlistbyownersteamid.m_steamID = s;
        requestforfriendlistbyownersteamid.SetIndefiniteCacheFilename((new StringBuilder()).append(s).append("_friends").toString());
        if (flag)
        {
            requestforfriendlistbyownersteamid.SetRequestAction(RequestActionType.GetFromCacheOnly);
        }
        return requestforfriendlistbyownersteamid;
    }

    public static RequestForGroupListByOwnerSteamID GetRequestForGroupListByOwnerSteamID(String s, boolean flag)
    {
        if (!$assertionsDisabled && !IsLoggedIn())
        {
            throw new AssertionError();
        }
        StringBuilder stringbuilder = new StringBuilder(RequestForGroupListByOwnerSteamID_URI.length() + PrecomputeAccessTokenLength() + PrecomputeKeyLength() + s.length());
        stringbuilder.append(RequestForGroupListByOwnerSteamID_URI);
        StartWithAccessToken(stringbuilder);
        AddSteamId(stringbuilder, s);
        RequestForGroupListByOwnerSteamID requestforgrouplistbyownersteamid = new RequestForGroupListByOwnerSteamID();
        requestforgrouplistbyownersteamid.SetUriAndDocumentType(stringbuilder.toString(), RequestDocumentType.JSON);
        requestforgrouplistbyownersteamid.m_steamID = s;
        requestforgrouplistbyownersteamid.SetIndefiniteCacheFilename((new StringBuilder()).append(s).append("_groups").toString());
        if (flag)
        {
            requestforgrouplistbyownersteamid.SetRequestAction(RequestActionType.GetFromCacheOnly);
        }
        return requestforgrouplistbyownersteamid;
    }

    public static RequestForGroupsBySteamIDs GetRequestForGroupsBySteamIDs(String as[])
    {
        if (!$assertionsDisabled && !IsLoggedIn())
        {
            throw new AssertionError();
        } else
        {
            StringBuilder stringbuilder = new StringBuilder(RequestForGroupsBySteamIDs_URI.length() + PrecomputeAccessTokenLength() + PrecomputeKeyLength() + PrecomputeIdsLength(as));
            stringbuilder.append(RequestForGroupsBySteamIDs_URI);
            StartWithAccessToken(stringbuilder);
            AddSteamIds(stringbuilder, as);
            RequestForGroupsBySteamIDs requestforgroupsbysteamids = new RequestForGroupsBySteamIDs();
            requestforgroupsbysteamids.SetUriAndDocumentType(stringbuilder.toString(), RequestDocumentType.JSON);
            requestforgroupsbysteamids.m_steamIDs = (String[])as.clone();
            return requestforgroupsbysteamids;
        }
    }

    public static RequestForUserSummariesBySteamIDs GetRequestForUserSummariesBySteamIDs(String as[])
    {
        if (!$assertionsDisabled && !IsLoggedIn())
        {
            throw new AssertionError();
        } else
        {
            StringBuilder stringbuilder = new StringBuilder(RequestForUserSummariesBySteamIDs_URI.length() + PrecomputeAccessTokenLength() + PrecomputeKeyLength() + PrecomputeIdsLength(as));
            stringbuilder.append(RequestForUserSummariesBySteamIDs_URI);
            StartWithAccessToken(stringbuilder);
            AddSteamIds(stringbuilder, as);
            RequestForUserSummariesBySteamIDs requestforusersummariesbysteamids = new RequestForUserSummariesBySteamIDs();
            requestforusersummariesbysteamids.SetUriAndDocumentType(stringbuilder.toString(), RequestDocumentType.JSON);
            requestforusersummariesbysteamids.m_steamIDs = (String[])as.clone();
            return requestforusersummariesbysteamids;
        }
    }

    public static boolean IsLoggedIn()
    {
        return s_loginInformation.m_loginState == LoginState.LoggedIn;
    }

    public static void LogOut()
    {
        SteamCommunityApplication.GetInstance().GetDiskCacheIndefinite().Delete("login.json");
        s_loginInformation.LogOut();
        SetLoginInformation(s_loginInformation);
        SteamCommunityApplication.GetInstance().GetFriendInfoDB().ClearItems();
        SteamCommunityApplication.GetInstance().GetGroupInfoDB().ClearItems();
    }

    private static int PrecomputeAccessTokenLength()
    {
        int i;
        if (s_loginInformation.m_accessToken != null)
        {
            i = s_loginInformation.m_accessToken.length();
        } else
        {
            i = 16;
        }
        return i + 32;
    }

    private static int PrecomputeIdsLength(String as[])
    {
        return 22 * as.length;
    }

    private static int PrecomputeKeyLength()
    {
        return 32;
    }

    public static void ResetAllCookies()
    {
        s_cookiesConfiguration.clear();
        SetCookie2("mobileClient", "android");
        SetCookie2("forceMobile", "1");
        SetCookie2("mobileClientVersion", (new StringBuilder()).append("").append(Config.APP_VERSION_ID).append(" (").append(Config.APP_VERSION).append(")").toString());
        SetCookie2("Steam_Language", SteamCommunityApplication.GetInstance().getString(0x7f070000));
        SetCookie2("steamLogin", null);
        SetCookie2("steamid", null);
        SetCookie2("dob", null);
    }

    public static void SetCookie2(String s, String s1)
    {
        Map map;
        String s2 = Config.URL_COMMUNITY_BASE;
        int i = s2.indexOf("://", 0);
        int j = s2.indexOf("/", i + 3);
        String s3;
        if (j < 0)
        {
            s3 = s2;
        } else
        {
            s3 = s2.substring(0, j);
        }
        s3.substring(i + 3);
        if (!s_cookiesConfiguration.containsKey(""))
        {
            s_cookiesConfiguration.put("", new HashMap());
        }
        map = (Map)s_cookiesConfiguration.get("");
        if (!map.containsKey(s))
        {
            if (s1 != null)
            {
                s_bCookiesAreOutOfDate = true;
            }
            map.put(s, s1);
            return;
        }
        if (s1 != null) goto _L2; else goto _L1
_L1:
        if (map.get(s) != null)
        {
            s_bCookiesAreOutOfDate = true;
        }
_L4:
        map.remove(s);
        map.put(s, s1);
        return;
_L2:
        String s4 = (String)map.get(s);
        if (s4 == null || !s1.equals(s4))
        {
            s_bCookiesAreOutOfDate = true;
        }
        if (true) goto _L4; else goto _L3
_L3:
    }

    public static void SetLoginInformation(LoginInformation logininformation)
    {
        s_loginInformation = logininformation;
        ResetAllCookies();
        String s;
        SettingInfo settinginfo;
        String s1;
        String s2;
        SteamDBService.REQ_ACT_LOGININFO_DATA req_act_logininfo_data;
        if (s_loginInformation.m_accessToken != null)
        {
            s = (new StringBuilder()).append(s_loginInformation.m_steamID).append("||oauth:").append(s_loginInformation.m_accessToken).toString();
        } else
        {
            s = null;
        }
        SetCookie2("steamLogin", s);
        SetCookie2("steamid", s_loginInformation.m_steamID);
        settinginfo = SteamCommunityApplication.GetInstance().GetSettingInfoDB().m_settingDOB;
        if (settinginfo == null)
        {
            s1 = null;
        } else
        {
            s1 = settinginfo.getValue(SteamCommunityApplication.GetInstance().getApplicationContext());
        }
        if (s1 == null || s1.equals(""))
        {
            s2 = null;
        } else
        {
            s2 = SettingInfo.DateConverter.makeUnixTime(s1);
        }
        SetCookie2("dob", s2);
        SyncAllCookies();
        req_act_logininfo_data = new SteamDBService.REQ_ACT_LOGININFO_DATA();
        req_act_logininfo_data.sOAuthToken = s_loginInformation.m_accessToken;
        req_act_logininfo_data.sSteamID = s_loginInformation.m_steamID;
        SubmitSimpleActionRequest("SetLoginInformation", req_act_logininfo_data);
        if (IsLoggedIn())
        {
            SteamCommunityApplication.GetInstance().GetFriendInfoDB().RefreshFromCacheAndHttp();
            SteamCommunityApplication.GetInstance().GetGroupInfoDB().RefreshFromCacheAndHttp();
        }
    }

    private static void StartWithAccessToken(StringBuilder stringbuilder)
    {
        stringbuilder.append("?access_token=");
        if (s_loginInformation.m_accessToken != null)
        {
            stringbuilder.append(s_loginInformation.m_accessToken);
            return;
        } else
        {
            stringbuilder.append("error");
            return;
        }
    }

    public static void SubmitSimpleActionRequest(String s, Object obj)
    {
        RequestBase requestbase = new RequestBase("JobQueueSimpleAction");
        requestbase.m_uri = s;
        requestbase.m_objData = obj;
        SteamCommunityApplication.GetInstance().SubmitSteamDBRequest(requestbase);
    }

    public static void SyncAllCookies()
    {
        CookieManager cookiemanager;
        Iterator iterator;
        if (!s_bCookiesAreOutOfDate)
        {
            return;
        }
        s_bCookiesAreOutOfDate = false;
        cookiemanager = CookieManager.getInstance();
        iterator = s_cookiesConfiguration.entrySet().iterator();
_L8:
        String s;
        Iterator iterator1;
        if (!iterator.hasNext())
        {
            break MISSING_BLOCK_LABEL_286;
        }
        java.util.Map.Entry entry = (java.util.Map.Entry)iterator.next();
        s = "";
        iterator1 = ((Map)entry.getValue()).entrySet().iterator();
_L6:
        java.util.Map.Entry entry1;
        if (!iterator1.hasNext())
        {
            break; /* Loop/switch isn't completed */
        }
        entry1 = (java.util.Map.Entry)iterator1.next();
        if (entry1.getValue() == null) goto _L2; else goto _L1
_L1:
        String s6 = URLEncoder.encode((String)entry1.getValue(), "ISO-8859-1");
        String s1 = s6;
_L4:
        if (!s.equals(""))
        {
            s = (new StringBuilder()).append(s).append("; ").toString();
        }
        String s2 = (new StringBuilder()).append(s).append((String)entry1.getKey()).toString();
        String s3 = (new StringBuilder()).append(s2).append("=").toString();
        String s4 = (new StringBuilder()).append(s3).append(s1).toString();
        String s5 = (new StringBuilder()).append(s4).append("; secure;").toString();
        cookiemanager.setCookie(Config.URL_COMMUNITY_BASE, s5);
        cookiemanager.setCookie(Config.URL_STORE_BASE, s5);
        s = "";
        continue; /* Loop/switch isn't completed */
_L2:
        s1 = "";
        if (true) goto _L4; else goto _L3
_L3:
        UnsupportedEncodingException unsupportedencodingexception;
        unsupportedencodingexception;
        if (true) goto _L6; else goto _L5
_L5:
        if (true) goto _L8; else goto _L7
_L7:
        CookieSyncManager.getInstance().sync();
        return;
    }

    static 
    {
        boolean flag;
        if (!com/valvesoftware/android/steam/community/SteamWebApi.desiredAssertionStatus())
        {
            flag = true;
        } else
        {
            flag = false;
        }
        $assertionsDisabled = flag;
        RequestForFriendListByOwnerSteamID_URI = (new StringBuilder()).append(Config.URL_WEBAPI_BASE).append("/ISteamUserOAuth/GetFriendList/v0001").toString();
        RequestForUserSummariesBySteamIDs_URI = (new StringBuilder()).append(Config.URL_WEBAPI_BASE).append("/ISteamUserOAuth/GetUserSummaries/v0001").toString();
        RequestForGroupListByOwnerSteamID_URI = (new StringBuilder()).append(Config.URL_WEBAPI_BASE).append("/ISteamUserOAuth/GetGroupList/v0001").toString();
        RequestForGroupsBySteamIDs_URI = (new StringBuilder()).append(Config.URL_WEBAPI_BASE).append("/ISteamUserOAuth/GetGroupSummaries/v0001").toString();
        RequestForAppSummariesByAppIDs_URI = (new StringBuilder()).append(Config.URL_WEBAPI_BASE).append("/ISteamGameOAuth/GetAppInfo/v0001").toString();
    }


    // Unreferenced inner class com/valvesoftware/android/steam/community/SteamWebApi$DevUniverseSSLSocketFactory$1

/* anonymous class */
    class DevUniverseSSLSocketFactory._cls1
        implements X509TrustManager
    {

        final DevUniverseSSLSocketFactory this$0;

        public void checkClientTrusted(X509Certificate ax509certificate[], String s)
            throws CertificateException
        {
        }

        public void checkServerTrusted(X509Certificate ax509certificate[], String s)
            throws CertificateException
        {
        }

        public X509Certificate[] getAcceptedIssuers()
        {
            return null;
        }

            
            {
                this$0 = DevUniverseSSLSocketFactory.this;
                super();
            }
    }

}
