// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.fragment;

import android.content.Intent;
import android.net.Uri;
import com.valvesoftware.android.steam.community.Config;
import com.valvesoftware.android.steam.community.SteamWebApi;
import com.valvesoftware.android.steam.community.activity.ActivityHelper;

// Referenced classes of package com.valvesoftware.android.steam.community.fragment:
//            NavigationFragment

public class it> extends it>
{

    final NavigationFragment this$0;

    public Intent getNewActivityIntent()
    {
        return super.NewActivityIntent().setData(Uri.parse((new StringBuilder()).append("steammobile://openurl?url=").append(Config.URL_COMMUNITY_BASE).append("/profiles/").append(SteamWebApi.GetLoginSteamID()).toString()));
    }

    public void onClick()
    {
        if (!SteamWebApi.IsLoggedIn())
        {
            ActivityHelper.PresentLoginActivity(getActivity(), com.valvesoftware.android.steam.community.activity.NewActivityIntent);
            return;
        } else
        {
            super.lick();
            return;
        }
    }

    public ()
    {
        this$0 = NavigationFragment.this;
        super(NavigationFragment.this);
    }
}
