// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;


// Referenced classes of package com.valvesoftware.android.steam.community:
//            FriendInfoDB

static class atsUpdateType
{

    static final int $SwitchMap$com$valvesoftware$android$steam$community$FriendInfoDB$ChatsUpdateType[];

    static 
    {
        $SwitchMap$com$valvesoftware$android$steam$community$FriendInfoDB$ChatsUpdateType = new int[atsUpdateType.values().length];
        try
        {
            $SwitchMap$com$valvesoftware$android$steam$community$FriendInfoDB$ChatsUpdateType[atsUpdateType.mark_read.ordinal()] = 1;
        }
        catch (NoSuchFieldError nosuchfielderror) { }
        try
        {
            $SwitchMap$com$valvesoftware$android$steam$community$FriendInfoDB$ChatsUpdateType[atsUpdateType.clear.ordinal()] = 2;
        }
        catch (NoSuchFieldError nosuchfielderror1) { }
        try
        {
            $SwitchMap$com$valvesoftware$android$steam$community$FriendInfoDB$ChatsUpdateType[atsUpdateType.msg_sent.ordinal()] = 3;
        }
        catch (NoSuchFieldError nosuchfielderror2) { }
        try
        {
            $SwitchMap$com$valvesoftware$android$steam$community$FriendInfoDB$ChatsUpdateType[atsUpdateType.msg_incoming.ordinal()] = 4;
        }
        catch (NoSuchFieldError nosuchfielderror3)
        {
            return;
        }
    }
}
