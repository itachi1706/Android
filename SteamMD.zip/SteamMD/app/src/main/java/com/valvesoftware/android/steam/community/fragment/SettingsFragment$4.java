// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.fragment;


// Referenced classes of package com.valvesoftware.android.steam.community.fragment:
//            SettingsFragment

static class 
{

    static final int $SwitchMap$com$valvesoftware$android$steam$community$SettingInfo$AccessRight[];
    static final int $SwitchMap$com$valvesoftware$android$steam$community$SettingInfo$SettingType[];

    static 
    {
        $SwitchMap$com$valvesoftware$android$steam$community$SettingInfo$SettingType = new int[com.valvesoftware.android.steam.community.Type.values().length];
        try
        {
            $SwitchMap$com$valvesoftware$android$steam$community$SettingInfo$SettingType[com.valvesoftware.android.steam.community.Type.INFO.ordinal()] = 1;
        }
        catch (NoSuchFieldError nosuchfielderror) { }
        try
        {
            $SwitchMap$com$valvesoftware$android$steam$community$SettingInfo$SettingType[com.valvesoftware.android.steam.community.Type.CHECK.ordinal()] = 2;
        }
        catch (NoSuchFieldError nosuchfielderror1) { }
        try
        {
            $SwitchMap$com$valvesoftware$android$steam$community$SettingInfo$SettingType[com.valvesoftware.android.steam.community.Type.DATE.ordinal()] = 3;
        }
        catch (NoSuchFieldError nosuchfielderror2) { }
        try
        {
            $SwitchMap$com$valvesoftware$android$steam$community$SettingInfo$SettingType[com.valvesoftware.android.steam.community.Type.URI.ordinal()] = 4;
        }
        catch (NoSuchFieldError nosuchfielderror3) { }
        try
        {
            $SwitchMap$com$valvesoftware$android$steam$community$SettingInfo$SettingType[com.valvesoftware.android.steam.community.Type.MARKET.ordinal()] = 5;
        }
        catch (NoSuchFieldError nosuchfielderror4) { }
        try
        {
            $SwitchMap$com$valvesoftware$android$steam$community$SettingInfo$SettingType[com.valvesoftware.android.steam.community.Type.RADIOSELECTOR.ordinal()] = 6;
        }
        catch (NoSuchFieldError nosuchfielderror5) { }
        try
        {
            $SwitchMap$com$valvesoftware$android$steam$community$SettingInfo$SettingType[com.valvesoftware.android.steam.community.Type.RINGTONESELECTOR.ordinal()] = 7;
        }
        catch (NoSuchFieldError nosuchfielderror6) { }
        try
        {
            $SwitchMap$com$valvesoftware$android$steam$community$SettingInfo$SettingType[com.valvesoftware.android.steam.community.Type.UNREADMSG.ordinal()] = 8;
        }
        catch (NoSuchFieldError nosuchfielderror7) { }
        try
        {
            $SwitchMap$com$valvesoftware$android$steam$community$SettingInfo$SettingType[com.valvesoftware.android.steam.community.Type.SECTION.ordinal()] = 9;
        }
        catch (NoSuchFieldError nosuchfielderror8) { }
        $SwitchMap$com$valvesoftware$android$steam$community$SettingInfo$AccessRight = new int[com.valvesoftware.android.steam.community.ight.values().length];
        try
        {
            $SwitchMap$com$valvesoftware$android$steam$community$SettingInfo$AccessRight[com.valvesoftware.android.steam.community.ight.USER.ordinal()] = 1;
        }
        catch (NoSuchFieldError nosuchfielderror9) { }
        try
        {
            $SwitchMap$com$valvesoftware$android$steam$community$SettingInfo$AccessRight[com.valvesoftware.android.steam.community.ight.VALID_ACCOUNT.ordinal()] = 2;
        }
        catch (NoSuchFieldError nosuchfielderror10) { }
        try
        {
            $SwitchMap$com$valvesoftware$android$steam$community$SettingInfo$AccessRight[com.valvesoftware.android.steam.community.ight.CODE.ordinal()] = 3;
        }
        catch (NoSuchFieldError nosuchfielderror11)
        {
            return;
        }
    }
}
