// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.fragment;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import com.valvesoftware.android.steam.community.SteamWebApi;
import com.valvesoftware.android.steam.community.activity.ActivityHelper;

public class BaseFragmentWithLogin
{

    private android.view.View.OnClickListener loginButtonListener;
    private Fragment m_fragment;
    private LinearLayout m_loggedIn;
    private Button m_loginButton;
    private RelativeLayout m_notLoggedIn;

    BaseFragmentWithLogin(Fragment fragment)
    {
        m_loginButton = null;
        m_loggedIn = null;
        m_notLoggedIn = null;
        m_fragment = null;
        loginButtonListener = new android.view.View.OnClickListener() {

            final BaseFragmentWithLogin this$0;

            public void onClick(View view)
            {
                ActivityHelper.PresentLoginActivity(getActivity(), com.valvesoftware.android.steam.community.activity.LoginActivity.LoginAction.LOGIN_DEFAULT);
            }

            
            {
                this$0 = BaseFragmentWithLogin.this;
                super();
            }
        };
        m_fragment = fragment;
    }

    private void UpdateListVisibilityToMatchLoggedInState()
    {
        if (m_notLoggedIn == null || m_loggedIn == null)
        {
            return;
        }
        if (SteamWebApi.IsLoggedIn())
        {
            m_notLoggedIn.setVisibility(8);
            m_loggedIn.setVisibility(0);
            return;
        } else
        {
            m_loggedIn.setVisibility(8);
            m_notLoggedIn.setVisibility(0);
            return;
        }
    }

    private Activity getActivity()
    {
        return m_fragment.getActivity();
    }

    public void UpdateGlobalInformationPreSort()
    {
        UpdateListVisibilityToMatchLoggedInState();
    }

    public void onActivityCreated(Bundle bundle)
    {
        m_loginButton = (Button)getActivity().findViewById(0x7f09001b);
        m_loggedIn = (LinearLayout)getActivity().findViewById(0x7f09001c);
        m_notLoggedIn = (RelativeLayout)getActivity().findViewById(0x7f090019);
        m_loginButton.setOnClickListener(loginButtonListener);
    }

    public void onResume()
    {
        UpdateListVisibilityToMatchLoggedInState();
    }

}
