// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;

import android.widget.TextView;

public class AndroidUtils
{

    public AndroidUtils()
    {
    }

    public static void setTextViewText(TextView textview, String s)
    {
        if (s == null)
        {
            s = "";
        }
        textview.setText(s);
_L2:
        return;
        Exception exception;
        exception;
        int i = s.length();
        if (i <= 0) goto _L2; else goto _L1
_L1:
        char ac[] = new char[i];
        int j = 0;
_L4:
        if (j >= i)
        {
            break; /* Loop/switch isn't completed */
        }
        char c = s.charAt(j);
        if (c < 0 || c > '\177')
        {
            c = '?';
        }
        ac[j] = c;
        j++;
        if (true) goto _L4; else goto _L3
_L3:
        try
        {
            textview.setText(ac, 0, i);
            return;
        }
        catch (Exception exception1) { }
        try
        {
            textview.setText(" ");
            return;
        }
        catch (Exception exception2)
        {
            return;
        }
    }
}
