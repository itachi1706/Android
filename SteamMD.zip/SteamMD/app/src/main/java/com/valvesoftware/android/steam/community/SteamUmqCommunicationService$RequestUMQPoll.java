// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;

import android.content.Context;
import android.content.Intent;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.concurrent.ConcurrentHashMap;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

// Referenced classes of package com.valvesoftware.android.steam.community:
//            SteamUmqCommunicationService, SteamDBService, SteamCommunityApplication, FriendInfoDB, 
//            FriendInfo, SteamUmqCommunicationDatabase

private class SetUriAndDocumentType extends SetUriAndDocumentType
{

    private ArrayList m_arrSteamIdsPersonaState;
    private ArrayList m_arrSteamIdsRelationshipChanges;
    private onThisRequestFailed m_cmd;
    private HashMap m_mapMessagesFromSteamIds;
    final SteamUmqCommunicationService this$0;

    private void DispatchIncomingMessagesNotifications()
    {
        if (m_mapMessagesFromSteamIds == null || m_mapMessagesFromSteamIds.isEmpty())
        {
            return;
        }
        Intent intent;
        for (Iterator iterator = m_mapMessagesFromSteamIds.values().iterator(); iterator.hasNext(); SteamUmqCommunicationService.access$700(SteamUmqCommunicationService.this).getApplicationContext().sendBroadcast(intent))
        {
            intent = (Intent)iterator.next();
            if (intent.hasExtra("notifymsgtext"))
            {
                SteamUmqCommunicationService.access$1900(SteamUmqCommunicationService.this, intent.getStringExtra("steamid"), intent.getStringExtra("notifymsgtext"), intent.getIntExtra("incoming", 1));
                intent.removeExtra("notifymsgtext");
            }
        }

        SteamUmqCommunicationService.access$1300(SteamUmqCommunicationService.this).m_timeLastApplicationActivity = System.currentTimeMillis();
    }

    private void DispatchPersonaStateNotifications()
    {
        if (m_arrSteamIdsPersonaState == null || m_arrSteamIdsPersonaState.isEmpty())
        {
            return;
        } else
        {
            Intent intent = new Intent("com.valvesoftware.android.steam.community.SteamUmqCommunicationIntent");
            intent.putExtra("type", "personastate");
            String as[] = new String[m_arrSteamIdsPersonaState.size()];
            intent.putExtra("steamids", (String[])m_arrSteamIdsPersonaState.toArray(as));
            SteamUmqCommunicationService.access$700(SteamUmqCommunicationService.this).getApplicationContext().sendBroadcast(intent);
            m_arrSteamIdsPersonaState.clear();
            return;
        }
    }

    private void DispatchRelationshipChangesNotifications()
    {
        if (m_arrSteamIdsRelationshipChanges == null || m_arrSteamIdsRelationshipChanges.isEmpty())
        {
            return;
        } else
        {
            Intent intent = new Intent("com.valvesoftware.android.steam.community.SteamUmqCommunicationIntent");
            intent.putExtra("type", "personarelationship");
            String as[] = new String[m_arrSteamIdsRelationshipChanges.size()];
            intent.putExtra("steamids", (String[])m_arrSteamIdsRelationshipChanges.toArray(as));
            SteamUmqCommunicationService.access$700(SteamUmqCommunicationService.this).getApplicationContext().sendBroadcast(intent);
            m_arrSteamIdsRelationshipChanges.clear();
            return;
        }
    }

    private boolean isSecure()
    {
        return m_cmd.ommand == Q_POLL;
    }

    private void notifyMessage(JSONObject jsonobject, long l, int i)
    {
        String s1;
        int k;
        String s;
        Q_POLL q_poll;
        int j;
        Long long1;
        FriendInfo friendinfo;
        Intent intent;
        String s2;
        String s3;
        try
        {
            s = jsonobject.getString("type");
        }
        catch (JSONException jsonexception)
        {
            return;
        }
        if (s == null)
        {
            return;
        }
        if (!s.equals("saytext") && !s.equals("my_saytext") && !s.equals("emote") && !s.equals("my_emote") && !s.equals("typing"))
        {
            break MISSING_BLOCK_LABEL_535;
        }
        boolean flag;
        if (!s.startsWith("my_"))
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (flag)
        {
            break MISSING_BLOCK_LABEL_90;
        }
        s = s.substring(3);
        q_poll = new >();
        q_poll.eamID = m_cmd.ySteamID;
        q_poll.SteamID = jsonobject.getString("steamid_from");
        q_poll.ming = flag;
        q_poll.ad = flag;
        if (i == 0)
        {
            break MISSING_BLOCK_LABEL_184;
        }
        j = jsonobject.optInt("timestamp", 0);
        if (j == 0 || j >= i)
        {
            break MISSING_BLOCK_LABEL_184;
        }
        l = (l + (long)j) - (long)i;
        if (l < SteamUmqCommunicationService.access$2000())
        {
            l = SteamUmqCommunicationService.access$2000();
        }
        q_poll.me = Calendar.getInstance();
        q_poll.me.setTimeInMillis(l);
        SteamUmqCommunicationService.access$2002(l);
        long1 = Long.valueOf(q_poll.SteamID);
        friendinfo = (FriendInfo)SteamCommunityApplication.GetInstance().GetFriendInfoDB().GetItemsMap().get(long1);
        if (friendinfo == null)
        {
            break MISSING_BLOCK_LABEL_685;
        }
        if (friendinfo.m_relationship != SteamID)
        {
            break MISSING_BLOCK_LABEL_685;
        }
        q_poll.pe = s;
        q_poll.ta = "";
        if (!s.equals("typing"))
        {
            q_poll.ta = jsonobject.getString("text");
            SteamUmqCommunicationService.access$2100(SteamUmqCommunicationService.this).insertMessage(q_poll);
        }
        if (m_mapMessagesFromSteamIds == null)
        {
            m_mapMessagesFromSteamIds = new HashMap();
        }
        intent = (Intent)m_mapMessagesFromSteamIds.get(long1);
        if (intent != null)
        {
            break MISSING_BLOCK_LABEL_396;
        }
        intent = new Intent("com.valvesoftware.android.steam.community.SteamUmqCommunicationIntent");
        intent.putExtra("type", "chatmsg");
        intent.putExtra("action", "incoming");
        intent.putExtra("steamid", q_poll.SteamID);
        m_mapMessagesFromSteamIds.put(long1, intent);
        if (s.equals("typing"))
        {
            break MISSING_BLOCK_LABEL_451;
        }
        if (flag)
        {
            s1 = "incoming";
        } else
        {
            s1 = "my_incoming";
        }
        intent.putExtra(s1, 1 + intent.getIntExtra(s1, 0));
        if (!flag)
        {
            break MISSING_BLOCK_LABEL_451;
        }
        intent.putExtra("notifymsgtext", q_poll.ta);
        if (!flag)
        {
            break MISSING_BLOCK_LABEL_479;
        }
        if (s.equals("typing"))
        {
            k = 1;
        } else
        {
            k = 0;
        }
        intent.putExtra("typing", k);
        if (q_poll.ta > 0 && !intent.hasExtra("msgidFirst"))
        {
            intent.putExtra("msgidFirst", q_poll.ta);
        }
        if (q_poll.ta > 0)
        {
            intent.putExtra("msgidLast", q_poll.ta);
            return;
        }
        break MISSING_BLOCK_LABEL_685;
        if (s.equals("personastate"))
        {
            s3 = jsonobject.getString("steamid_from");
            if (m_arrSteamIdsPersonaState == null)
            {
                m_arrSteamIdsPersonaState = new ArrayList();
            }
            m_arrSteamIdsPersonaState.add(s3);
            SteamUmqCommunicationService.access$2200(SteamUmqCommunicationService.this, s3, jsonobject.optString("persona_name"));
            return;
        }
        if (s.equals("personarelationship"))
        {
            s2 = jsonobject.getString("steamid_from");
            if (m_arrSteamIdsRelationshipChanges == null)
            {
                m_arrSteamIdsRelationshipChanges = new ArrayList();
            }
            m_arrSteamIdsRelationshipChanges.add(s2);
            return;
        }
        if (s.equals("push2poll"))
        {
            if (m_arrSteamIdsRelationshipChanges == null)
            {
                m_arrSteamIdsRelationshipChanges = new ArrayList();
            }
            m_arrSteamIdsRelationshipChanges.add("");
        }
    }

    private void onThisRequestFailed(String s)
    {
        m_arrSteamIdsRelationshipChanges m_arrsteamidsrelationshipchanges = new t>();
        m_arrsteamidsrelationshipchanges.ommand = Q_LOGON;
        m_arrsteamidsrelationshipchanges.AuthToken = m_cmd.AuthToken;
        m_arrsteamidsrelationshipchanges.ySteamID = m_cmd.ySteamID;
        m_arrsteamidsrelationshipchanges.essage = m_cmd.essage;
        SteamUmqCommunicationService.access$1400(SteamUmqCommunicationService.this, m_arrsteamidsrelationshipchanges);
        onThisRequestFinished(s);
    }

    private void onThisRequestFinished(String s)
    {
        SteamUmqCommunicationService.access$1600(SteamUmqCommunicationService.this, m_cmd);
    }

    protected HttpParams GetDefaultHttpParams()
    {
        HttpParams httpparams = super.GetDefaultHttpParams();
        if (m_cmd.imeout > 0)
        {
            HttpConnectionParams.setSoTimeout(httpparams, Math.max(1000 * (7 + m_cmd.imeout), 25000));
        }
        return httpparams;
    }

    public void RequestFailedOnResponseWorkerThread()
    {
        onThisRequestFailed("error");
    }

    public void RequestSucceededOnResponseWorkerThread()
    {
        if (m_jsonDocument == null) goto _L2; else goto _L1
_L1:
        String s = "";
        String s1 = m_jsonDocument.getString("error");
        s = s1;
_L16:
        if (!"OK".equals(s) && !"Timeout".equals(s)) goto _L2; else goto _L3
_L3:
        int i;
        boolean flag;
        boolean flag1;
        i = m_cmd.essage;
        flag = m_jsonDocument.has("messages");
        flag1 = false;
        if (!flag) goto _L5; else goto _L4
_L4:
        JSONArray jsonarray1 = m_jsonDocument.getJSONArray("messages");
        JSONArray jsonarray = jsonarray1;
_L14:
        long l;
        int j;
        int k;
        int i1;
        l = System.currentTimeMillis();
        j = m_jsonDocument.optInt("timestamp", 0);
        k = 0;
        if (jsonarray != null)
        {
            k = jsonarray.length();
        }
        i1 = 0;
_L11:
        flag1 = false;
        if (i1 >= k) goto _L5; else goto _L6
_L6:
        JSONObject jsonobject1 = jsonarray.getJSONObject(i1);
        JSONObject jsonobject = jsonobject1;
_L12:
        if (jsonobject == null) goto _L8; else goto _L7
_L7:
        if (isSecure() || !jsonobject.has("secure_message_id")) goto _L10; else goto _L9
_L9:
        i = jsonobject.optInt("secure_message_id", m_cmd.essage);
        flag1 = true;
_L5:
        DispatchIncomingMessagesNotifications();
        DispatchPersonaStateNotifications();
        DispatchRelationshipChangesNotifications();
        onThisRequestFailed onthisrequestfailed = new t>();
        onthisrequestfailed.ommand = Q_POLL_STATUS;
        onthisrequestfailed.AuthToken = m_cmd.AuthToken;
        onthisrequestfailed.ySteamID = m_cmd.ySteamID;
        onthisrequestfailed.essage = m_cmd.essage;
        if (flag1)
        {
            onthisrequestfailed.essage = i;
            onthisrequestfailed.ommand = Q_POLL;
        } else
        if (m_jsonDocument.has("messagelast"))
        {
            try
            {
                onthisrequestfailed.essage = m_jsonDocument.getInt("messagelast");
            }
            catch (JSONException jsonexception1) { }
        }
        JSONException jsonexception4;
        if (m_jsonDocument.has("nextsectimeout"))
        {
            try
            {
                onthisrequestfailed.imeout = m_jsonDocument.getInt("nextsectimeout");
            }
            catch (JSONException jsonexception2) { }
        }
        SteamUmqCommunicationService.access$1400(SteamUmqCommunicationService.this, onthisrequestfailed);
        SteamUmqCommunicationService.access$1600(SteamUmqCommunicationService.this, m_cmd);
        return;
_L10:
        notifyMessage(jsonobject, l, j);
_L8:
        i1++;
          goto _L11
_L2:
        onThisRequestFailed("error");
        return;
        jsonexception4;
        jsonobject = null;
          goto _L12
        JSONException jsonexception3;
        jsonexception3;
        jsonarray = null;
        if (true) goto _L14; else goto _L13
_L13:
        JSONException jsonexception;
        jsonexception;
        if (true) goto _L16; else goto _L15
_L15:
    }

    public iver(iver iver)
    {
        this$0 = SteamUmqCommunicationService.this;
        super(SteamUmqCommunicationService.this);
        m_arrSteamIdsPersonaState = null;
        m_arrSteamIdsRelationshipChanges = null;
        m_mapMessagesFromSteamIds = null;
        m_cmd = iver;
        m_cmd.quest = this;
        String s;
        if (isSecure())
        {
            s = SteamUmqCommunicationService.access$1700();
        } else
        {
            s = SteamUmqCommunicationService.access$1800();
        }
        SetUriAndDocumentType(s, SetUriAndDocumentType);
    }
}
