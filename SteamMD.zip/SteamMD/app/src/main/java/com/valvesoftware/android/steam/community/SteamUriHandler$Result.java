// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;

import java.util.Properties;

// Referenced classes of package com.valvesoftware.android.steam.community:
//            SteamUriHandler

public static class handled
{

    public  command;
    public boolean handled;
    public Properties props;

    public String getProperty(Property property)
    {
        return props.getProperty(property.toString());
    }

    public String getProperty(Property property, String s)
    {
        return props.getProperty(property.toString(), s);
    }

    public Property()
    {
        handled = false;
    }
}
