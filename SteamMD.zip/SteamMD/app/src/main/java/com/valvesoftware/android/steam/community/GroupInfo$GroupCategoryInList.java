// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;


// Referenced classes of package com.valvesoftware.android.steam.community:
//            GroupInfo

public static final class  extends Enum
{

    private static final .VALUES $VALUES[];
    public static final .VALUES OFFICIAL;
    public static final .VALUES PRIVATE;
    public static final .VALUES PUBLIC;
    public static final .VALUES REQUEST_INVITE;
    public static final .VALUES SEARCH_ALL;

    public static  valueOf(String s)
    {
        return ()Enum.valueOf(com/valvesoftware/android/steam/community/GroupInfo$GroupCategoryInList, s);
    }

    public static [] values()
    {
        return ([])$VALUES.clone();
    }

    public int GetDisplayString()
    {
        switch (vesoftware.android.steam.community.GroupInfo.GroupCategoryInList[ordinal()])
        {
        default:
            return 0x7f070027;

        case 1: // '\001'
            return 0x7f070060;

        case 2: // '\002'
            return 0x7f070061;

        case 3: // '\003'
            return 0x7f070063;

        case 4: // '\004'
            return 0x7f070062;

        case 5: // '\005'
            return 0x7f070004;
        }
    }

    static 
    {
        REQUEST_INVITE = new <init>("REQUEST_INVITE", 0);
        PRIVATE = new <init>("PRIVATE", 1);
        PUBLIC = new <init>("PUBLIC", 2);
        OFFICIAL = new <init>("OFFICIAL", 3);
        SEARCH_ALL = new <init>("SEARCH_ALL", 4);
        ordinal aordinal[] = new <init>[5];
        aordinal[0] = REQUEST_INVITE;
        aordinal[1] = PRIVATE;
        aordinal[2] = PUBLIC;
        aordinal[3] = OFFICIAL;
        aordinal[4] = SEARCH_ALL;
        $VALUES = aordinal;
    }

    private (String s, int i)
    {
        super(s, i);
    }
}
