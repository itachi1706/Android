// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.fragment;

import android.content.Intent;

// Referenced classes of package com.valvesoftware.android.steam.community.fragment:
//            NavigationFragment

public class this._cls0 extends this._cls0
{

    final NavigationFragment this$0;

    public Intent getNewActivityIntent()
    {
        return super.ntent().setData(NavigationFragment.URI_Feeds_SteamSpecials);
    }

    public ()
    {
        this$0 = NavigationFragment.this;
        super(NavigationFragment.this);
    }
}
