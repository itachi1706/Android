// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;


// Referenced classes of package com.valvesoftware.android.steam.community:
//            SteamDBService

public static final class  extends Enum
{

    private static final .VALUES $VALUES[];
    public static final .VALUES RequestError;
    public static final .VALUES RequestIsLive;

    public static  valueOf(String s)
    {
        return ()Enum.valueOf(com/valvesoftware/android/steam/community/SteamDBService$UriDataState, s);
    }

    public static [] values()
    {
        return ([])$VALUES.clone();
    }

    static 
    {
        RequestIsLive = new <init>("RequestIsLive", 0);
        RequestError = new <init>("RequestError", 1);
        e_3B_.clone aclone[] = new <init>[2];
        aclone[0] = RequestIsLive;
        aclone[1] = RequestError;
        $VALUES = aclone;
    }

    private (String s, int i)
    {
        super(s, i);
    }
}
