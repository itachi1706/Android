// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.fragment;

import android.content.Intent;

// Referenced classes of package com.valvesoftware.android.steam.community.fragment:
//            NavigationFragment

public class this._cls0 extends this._cls0
{

    final NavigationFragment this$0;

    public Intent getNewActivityIntent()
    {
        Intent intent = super.vityIntent().addFlags(0x20000000);
        intent.setFlags(0xf7ffffff & intent.getFlags());
        return intent;
    }

    public ()
    {
        this$0 = NavigationFragment.this;
        super(NavigationFragment.this);
    }
}
