// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;

import android.content.Context;
import android.content.Intent;
import android.os.Process;

// Referenced classes of package com.valvesoftware.android.steam.community:
//            SteamUmqCommunicationService, SteamCommunityApplication, SteamDBService

private class SetUriAndDocumentType extends SetUriAndDocumentType
{

    private onThisRequestFinished m_cmd;
    private int m_numRetriesLeft;
    final SteamUmqCommunicationService this$0;

    private void onThisRequestFinished(String s)
    {
        if (SteamCommunityApplication.GetInstance().m_bApplicationExiting)
        {
            Process.killProcess(Process.myPid());
            return;
        } else
        {
            SteamUmqCommunicationService.access$1600(SteamUmqCommunicationService.this, m_cmd);
            Intent intent = new Intent("com.valvesoftware.android.steam.community.SteamUmqCommunicationIntent");
            intent.putExtra("type", "umqlogoff");
            intent.putExtra("umqlogoff", s);
            SteamUmqCommunicationService.access$700(SteamUmqCommunicationService.this).getApplicationContext().sendBroadcast(intent);
            return;
        }
    }

    public void RequestFailedOnResponseWorkerThread()
    {
        if (m_numRetriesLeft > 0)
        {
            m_numRetriesLeft = -1 + m_numRetriesLeft;
            SteamUmqCommunicationService.access$700(SteamUmqCommunicationService.this).SubmitRequest(this);
            return;
        } else
        {
            onThisRequestFinished("error");
            return;
        }
    }

    public void RequestSucceededOnResponseWorkerThread()
    {
        onThisRequestFinished("OK");
    }

    public ( )
    {
        this$0 = SteamUmqCommunicationService.this;
        super(SteamUmqCommunicationService.this);
        m_numRetriesLeft = 2;
        m_cmd = ;
        m_cmd.est = this;
        SetUriAndDocumentType(SteamUmqCommunicationService.access$2400(), SetUriAndDocumentType);
    }
}
