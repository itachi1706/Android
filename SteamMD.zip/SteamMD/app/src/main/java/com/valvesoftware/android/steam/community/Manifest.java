// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;


public final class Manifest
{
    public static final class permission
    {

        public static final String C2D_MESSAGE = "com.valvesoftware.android.steam.community.permission.C2D_MESSAGE";

        public permission()
        {
        }
    }


    public Manifest()
    {
    }
}
