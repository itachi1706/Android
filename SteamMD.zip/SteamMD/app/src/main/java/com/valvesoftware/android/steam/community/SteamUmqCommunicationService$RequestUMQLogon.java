// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import org.json.JSONException;
import org.json.JSONObject;

// Referenced classes of package com.valvesoftware.android.steam.community:
//            SteamUmqCommunicationService, SteamDBService, SteamCommunityApplication

private class SetUriAndDocumentType extends SetUriAndDocumentType
{

    private onThisRequestFailed m_cmd;
    final SteamUmqCommunicationService this$0;

    private void onThisRequestFailed(String s)
    {
        SetUriAndDocumentType seturianddocumenttype = new >();
        seturianddocumenttype.mmand = _LOGON_RETRY;
        seturianddocumenttype.uthToken = m_cmd.uthToken;
        seturianddocumenttype.SteamID = m_cmd.SteamID;
        seturianddocumenttype.ssage = m_cmd.ssage;
        SteamUmqCommunicationService.access$1400(SteamUmqCommunicationService.this, seturianddocumenttype);
        onThisRequestFinished(s);
    }

    private void onThisRequestFinished(String s)
    {
        SteamUmqCommunicationService.access$1600(SteamUmqCommunicationService.this, m_cmd);
        Intent intent = new Intent("com.valvesoftware.android.steam.community.SteamUmqCommunicationIntent");
        intent.putExtra("type", "umqlogon");
        intent.putExtra("umqlogon", s);
        SteamUmqCommunicationService.access$700(SteamUmqCommunicationService.this).getApplicationContext().sendBroadcast(intent);
    }

    public void RequestFailedOnResponseWorkerThread()
    {
        if (GetHttpResponseUriData().GetHttpResponseUriData != 401)
        {
            onThisRequestFailed("error");
            return;
        } else
        {
            onThisRequestFinished("invalidcredentials");
            SteamUmqCommunicationService.access$1500(SteamUmqCommunicationService.this, te.invalidcredentials);
            te te = new te.invalidcredentials();
            te.oken = null;
            te.D = null;
            SvcReq_SetUmqCommunicationSettings(te);
            return;
        }
    }

    public void RequestSucceededOnResponseWorkerThread()
    {
        if (m_jsonDocument == null) goto _L2; else goto _L1
_L1:
        String s = "";
        String s1 = m_jsonDocument.getString("error");
        s = s1;
_L6:
        int i;
        boolean flag;
        municationSettings municationsettings;
        int j;
        if (m_jsonDocument.has("umqid"))
        {
            try
            {
                SteamUmqCommunicationService.access$1102(m_jsonDocument.getString("umqid"));
                android.content.onService.UmqCommand umqcommand = SteamCommunityApplication.GetInstance().getApplicationContext().getSharedPreferences("steamumqcommunication", 0).edit();
                umqcommand.getApplicationContext("umqid", SteamUmqCommunicationService.access$1100());
                umqcommand._mth1100();
            }
            catch (JSONException jsonexception2)
            {
                s = "";
            }
        }
        if (m_jsonDocument.has("push"))
        {
            boolean flag1 = m_jsonDocument.optBoolean("push", false);
            if (SteamUmqCommunicationService.access$1200(SteamUmqCommunicationService.this).hActive() != flag1)
            {
                SteamUmqCommunicationService.access$1200(SteamUmqCommunicationService.this).dBeSentToServer = true;
            }
        }
        flag = m_jsonDocument.has("message");
        i = 0;
        if (!flag)
        {
            break MISSING_BLOCK_LABEL_171;
        }
        j = m_jsonDocument.getInt("message");
        i = j;
_L4:
        if ("OK".equals(s))
        {
            SteamUmqCommunicationService.access$1300(SteamUmqCommunicationService.this).m_timeLastApplicationActivity = System.currentTimeMillis();
            municationsettings = new >();
            municationsettings.mmand = _POLL_STATUS;
            municationsettings.uthToken = m_cmd.uthToken;
            municationsettings.SteamID = m_cmd.SteamID;
            municationsettings.ssage = i;
            SteamUmqCommunicationService.access$1400(SteamUmqCommunicationService.this, municationsettings);
            onThisRequestFinished("OK");
            return;
        }
_L2:
        onThisRequestFailed("error");
        return;
        JSONException jsonexception1;
        jsonexception1;
        i = 0;
        if (true) goto _L4; else goto _L3
_L3:
        JSONException jsonexception;
        jsonexception;
        if (true) goto _L6; else goto _L5
_L5:
    }

    public ver(ver ver)
    {
        this$0 = SteamUmqCommunicationService.this;
        super(SteamUmqCommunicationService.this);
        m_cmd = ver;
        m_cmd.uest = this;
        SetUriAndDocumentType(SteamUmqCommunicationService.access$1000(), SetUriAndDocumentType);
    }
}
