// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.fragment;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

// Referenced classes of package com.valvesoftware.android.steam.community.fragment:
//            ChatFragment

class this._cls0 extends BroadcastReceiver
{

    final ChatFragment this$0;

    public void onReceive(Context context, Intent intent)
    {
        if (getActivity() == null)
        {
            return;
        } else
        {
            OnChatUpdated(intent);
            return;
        }
    }

    ()
    {
        this$0 = ChatFragment.this;
        super();
    }
}
