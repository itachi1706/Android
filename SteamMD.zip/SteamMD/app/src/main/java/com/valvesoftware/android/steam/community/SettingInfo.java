// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;

import android.app.DatePickerDialog;
import android.content.Context;
import android.content.SharedPreferences;
import java.text.DateFormat;
import java.util.Calendar;

// Referenced classes of package com.valvesoftware.android.steam.community:
//            SteamWebApi

public class SettingInfo
{
    public static final class AccessRight extends Enum
    {

        private static final AccessRight $VALUES[];
        public static final AccessRight CODE;
        public static final AccessRight NONE;
        public static final AccessRight USER;
        public static final AccessRight VALID_ACCOUNT;

        public static AccessRight valueOf(String s)
        {
            return (AccessRight)Enum.valueOf(com/valvesoftware/android/steam/community/SettingInfo$AccessRight, s);
        }

        public static AccessRight[] values()
        {
            return (AccessRight[])$VALUES.clone();
        }

        static 
        {
            NONE = new AccessRight("NONE", 0);
            VALID_ACCOUNT = new AccessRight("VALID_ACCOUNT", 1);
            USER = new AccessRight("USER", 2);
            CODE = new AccessRight("CODE", 3);
            AccessRight aaccessright[] = new AccessRight[4];
            aaccessright[0] = NONE;
            aaccessright[1] = VALID_ACCOUNT;
            aaccessright[2] = USER;
            aaccessright[3] = CODE;
            $VALUES = aaccessright;
        }

        private AccessRight(String s, int i)
        {
            super(s, i);
        }
    }

    public static class CustomDatePickerDialog extends DatePickerDialog
    {

        private boolean m_bAllowSetTitle;

        public void setTitle(CharSequence charsequence)
        {
            if (m_bAllowSetTitle)
            {
                super.setTitle(charsequence);
            }
        }

        public CustomDatePickerDialog(Context context, android.app.DatePickerDialog.OnDateSetListener ondatesetlistener, Calendar calendar, int i)
        {
            super(context, ondatesetlistener, calendar.get(1), calendar.get(2), calendar.get(5));
            m_bAllowSetTitle = true;
            setTitle(i);
            m_bAllowSetTitle = false;
        }
    }

    public static class DateConverter
    {

        public static String formatDate(String s)
        {
            Calendar calendar = makeCalendar(s);
            return DateFormat.getDateInstance(0).format(calendar.getTime());
        }

        public static Calendar makeCalendar(String s)
        {
            Calendar calendar = Calendar.getInstance();
            if (s != null && !s.equals(""))
            {
                int i = Integer.valueOf(s).intValue();
                calendar.set(i / 10000, (i - 10000 * (i / 10000)) / 100, i % 100);
            }
            return calendar;
        }

        public static String makeUnixTime(String s)
        {
            Calendar calendar = makeCalendar(s);
            return (new StringBuilder()).append("").append(calendar.getTimeInMillis() / 1000L).toString();
        }

        public static String makeValue(int i, int j, int k)
        {
            int l = k + (i * 10000 + j * 100);
            return (new StringBuilder()).append("").append(l).toString();
        }

        public DateConverter()
        {
        }
    }

    public static class RadioSelectorItem
    {

        public int resid_text;
        public int value;

        public RadioSelectorItem()
        {
        }
    }

    public static final class SettingType extends Enum
    {

        private static final SettingType $VALUES[];
        public static final SettingType CHECK;
        public static final SettingType DATE;
        public static final SettingType INFO;
        public static final SettingType MARKET;
        public static final SettingType RADIOSELECTOR;
        public static final SettingType RINGTONESELECTOR;
        public static final SettingType SECTION;
        public static final SettingType UNREADMSG;
        public static final SettingType URI;

        public static SettingType valueOf(String s)
        {
            return (SettingType)Enum.valueOf(com/valvesoftware/android/steam/community/SettingInfo$SettingType, s);
        }

        public static SettingType[] values()
        {
            return (SettingType[])$VALUES.clone();
        }

        static 
        {
            SECTION = new SettingType("SECTION", 0);
            INFO = new SettingType("INFO", 1);
            CHECK = new SettingType("CHECK", 2);
            DATE = new SettingType("DATE", 3);
            URI = new SettingType("URI", 4);
            MARKET = new SettingType("MARKET", 5);
            UNREADMSG = new SettingType("UNREADMSG", 6);
            RADIOSELECTOR = new SettingType("RADIOSELECTOR", 7);
            RINGTONESELECTOR = new SettingType("RINGTONESELECTOR", 8);
            SettingType asettingtype[] = new SettingType[9];
            asettingtype[0] = SECTION;
            asettingtype[1] = INFO;
            asettingtype[2] = CHECK;
            asettingtype[3] = DATE;
            asettingtype[4] = URI;
            asettingtype[5] = MARKET;
            asettingtype[6] = UNREADMSG;
            asettingtype[7] = RADIOSELECTOR;
            asettingtype[8] = RINGTONESELECTOR;
            $VALUES = asettingtype;
        }

        private SettingType(String s, int i)
        {
            super(s, i);
        }
    }

    public static class Transaction
    {

        private boolean m_bCookiesMarkedForSync;
        private android.content.SharedPreferences.Editor m_editor;

        public void commit()
        {
            if (m_bCookiesMarkedForSync)
            {
                SteamWebApi.SyncAllCookies();
                m_bCookiesMarkedForSync = false;
            }
            if (m_editor != null)
            {
                m_editor.commit();
            }
        }

        public void markCookiesForSync()
        {
            m_bCookiesMarkedForSync = true;
        }

        public void setValue(SettingInfo settinginfo, String s)
        {
            if (m_editor != null)
            {
                m_editor.putString(settinginfo.m_key, s);
            }
            if (settinginfo.m_pUpdateListener != null)
            {
                settinginfo.m_pUpdateListener.OnSettingInfoValueUpdate(settinginfo, s, this);
            }
        }

        public Transaction(Context context)
        {
            m_editor = null;
            m_bCookiesMarkedForSync = false;
            String s = SteamWebApi.GetLoginSteamID();
            if (s != null && !s.equals(""))
            {
                m_editor = context.getSharedPreferences((new StringBuilder()).append("steam.settings.").append(s).toString(), 0).edit();
            }
        }
    }

    public static interface UpdateListener
    {

        public abstract void OnSettingInfoValueUpdate(SettingInfo settinginfo, String s, Transaction transaction);
    }


    private static final String m_sPrefs = "steam.settings.";
    public AccessRight m_access;
    public String m_defaultValue;
    public Object m_extraData;
    public String m_key;
    public UpdateListener m_pUpdateListener;
    public int m_resid;
    public int m_resid_detailed;
    public SettingType m_type;

    public SettingInfo()
    {
        m_resid = 0;
        m_resid_detailed = 0;
        m_key = null;
        m_type = SettingType.SECTION;
        m_access = AccessRight.NONE;
        m_defaultValue = null;
        m_extraData = null;
        m_pUpdateListener = null;
    }

    public static RadioSelectorItem findRadioSelectorItemByValue(int i, RadioSelectorItem aradioselectoritem[])
    {
        for (int j = 0; j < aradioselectoritem.length; j++)
        {
            if (aradioselectoritem[j].value == i)
            {
                return aradioselectoritem[j];
            }
        }

        return null;
    }

    public boolean getBooleanValue(Context context)
    {
        String s = getValue(context);
        return s != null && !s.equals("");
    }

    public RadioSelectorItem getRadioSelectorItemValue(Context context)
    {
        RadioSelectorItem aradioselectoritem[];
        String s;
        Exception exception1;
        Exception exception2;
        RadioSelectorItem radioselectoritem1;
        RadioSelectorItem radioselectoritem2;
        RadioSelectorItem radioselectoritem3;
        try
        {
            aradioselectoritem = (RadioSelectorItem[])(RadioSelectorItem[])m_extraData;
        }
        catch (Exception exception)
        {
            aradioselectoritem = null;
        }
        if (aradioselectoritem != null) goto _L2; else goto _L1
_L1:
        radioselectoritem2 = null;
_L4:
        return radioselectoritem2;
_L2:
        s = getValue(context);
        radioselectoritem3 = findRadioSelectorItemByValue(Integer.valueOf(s).intValue(), aradioselectoritem);
        radioselectoritem2 = radioselectoritem3;
        if (radioselectoritem2 != null) goto _L4; else goto _L3
_L3:
        radioselectoritem1 = findRadioSelectorItemByValue(Integer.valueOf(m_defaultValue).intValue(), aradioselectoritem);
        radioselectoritem2 = radioselectoritem1;
        if (radioselectoritem2 != null) goto _L4; else goto _L5
_L5:
        RadioSelectorItem radioselectoritem;
        try
        {
            radioselectoritem = aradioselectoritem[0];
        }
        catch (Exception exception3)
        {
            return null;
        }
        return radioselectoritem;
        exception2;
        if (true) goto _L5; else goto _L6
_L6:
        exception1;
          goto _L3
    }

    public String getValue(Context context)
    {
        String s = SteamWebApi.GetLoginSteamID();
        if (s == null || s.equals(""))
        {
            return m_defaultValue;
        } else
        {
            return context.getSharedPreferences((new StringBuilder()).append("steam.settings.").append(s).toString(), 0).getString(m_key, m_defaultValue);
        }
    }

    public void setValueAndCommit(Context context, String s)
    {
        Transaction transaction = new Transaction(context);
        transaction.setValue(this, s);
        transaction.commit();
    }
}
