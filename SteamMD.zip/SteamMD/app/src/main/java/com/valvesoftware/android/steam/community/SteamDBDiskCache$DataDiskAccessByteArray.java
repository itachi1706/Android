// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;

// Referenced classes of package com.valvesoftware.android.steam.community:
//            SteamDBDiskCache

private static class <init>
    implements <init>
{

    byte m_data[];

    public void onRead(FileInputStream fileinputstream, long l)
        throws IOException
    {
        byte abyte0[] = new byte[(int)l];
        int i = fileinputstream.read(abyte0);
        if ((long)i != l)
        {
            throw new IOException((new StringBuilder()).append("File read produced ").append(i).append(" when ").append(l).append(" was expected").toString());
        } else
        {
            m_data = abyte0;
            return;
        }
    }

    public void onWrite(OutputStream outputstream)
        throws IOException
    {
        if (m_data != null)
        {
            outputstream.write(m_data);
        }
    }

    private ()
    {
    }

    ( )
    {
        this();
    }
}
