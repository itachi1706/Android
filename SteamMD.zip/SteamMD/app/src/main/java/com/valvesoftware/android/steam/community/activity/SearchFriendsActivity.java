// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.activity;

import android.content.Intent;
import android.os.Bundle;
import com.valvesoftware.android.steam.community.SteamWebApi;
import com.valvesoftware.android.steam.community.fragment.SearchFriendListFragment;

// Referenced classes of package com.valvesoftware.android.steam.community.activity:
//            FragmentActivityWithNavigationSupport, ActivityHelper

public class SearchFriendsActivity extends FragmentActivityWithNavigationSupport
{

    public SearchFriendsActivity()
    {
    }

    public void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        setContentView(0x7f03000f);
    }

    protected void onDestroy()
    {
        super.onDestroy();
    }

    protected void onNewIntent(Intent intent)
    {
        super.onNewIntent(intent);
        android.support.v4.app.Fragment fragment = ActivityHelper.GetFragmentForActivityById(this, 0x7f090011);
        if (fragment != null && (fragment instanceof SearchFriendListFragment))
        {
            ((SearchFriendListFragment)fragment).SwitchConfiguration(intent.getStringExtra("query"));
        }
    }

    protected void onResume()
    {
        SteamWebApi.SubmitSimpleActionRequest("UmqActivity", new com.valvesoftware.android.steam.community.SteamDBService.REQ_ACT_UMQACTIVITY_DATA());
        super.onResume();
    }
}
