// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.activity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.valvesoftware.android.steam.community.SteamDBResponseListener;

// Referenced classes of package com.valvesoftware.android.steam.community.activity:
//            ActivityHelper

class this._cls0 extends BroadcastReceiver
{

    final ActivityHelper this$0;

    public void onReceive(Context context, Intent intent)
    {
        ((SteamDBResponseListener)ActivityHelper.access$000(ActivityHelper.this)).OnRequestCompleted(Integer.valueOf(intent.getIntExtra("intent_id", -1)));
    }

    ()
    {
        this$0 = ActivityHelper.this;
        super();
    }
}
