// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.fragment;

import android.view.View;

// Referenced classes of package com.valvesoftware.android.steam.community.fragment:
//            TitlebarFragment

class tlebarButtonHander
    implements android.view.r
{

    final TitlebarFragment this$0;
    final int val$btnid;
    final tlebarButtonHander val$hdlr;

    public void onClick(View view)
    {
        while (val$btnid == 0x7f090038 && TitlebarFragment.access$000(TitlebarFragment.this) || val$hdlr == null) 
        {
            return;
        }
        val$hdlr.onTitlebarButtonClicked(val$btnid);
    }

    tlebarButtonHander()
    {
        this$0 = final_titlebarfragment;
        val$btnid = i;
        val$hdlr = tlebarButtonHander.this;
        super();
    }
}
