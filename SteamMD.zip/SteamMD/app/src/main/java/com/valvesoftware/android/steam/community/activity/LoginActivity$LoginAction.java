// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.activity;


// Referenced classes of package com.valvesoftware.android.steam.community.activity:
//            LoginActivity

public static final class  extends Enum
{

    private static final .VALUES $VALUES[];
    public static final .VALUES LOGIN_DEFAULT;
    public static final .VALUES LOGIN_EVEN_IF_LOGGED_IN;
    public static final .VALUES LOGOUT;

    public static  valueOf(String s)
    {
        return ()Enum.valueOf(com/valvesoftware/android/steam/community/activity/LoginActivity$LoginAction, s);
    }

    public static [] values()
    {
        return ([])$VALUES.clone();
    }

    static 
    {
        LOGOUT = new <init>("LOGOUT", 0);
        LOGIN_DEFAULT = new <init>("LOGIN_DEFAULT", 1);
        LOGIN_EVEN_IF_LOGGED_IN = new <init>("LOGIN_EVEN_IF_LOGGED_IN", 2);
        n_3B_.clone aclone[] = new <init>[3];
        aclone[0] = LOGOUT;
        aclone[1] = LOGIN_DEFAULT;
        aclone[2] = LOGIN_EVEN_IF_LOGGED_IN;
        $VALUES = aclone;
    }

    private (String s, int i)
    {
        super(s, i);
    }
}
