// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;

import android.app.DatePickerDialog;
import android.content.Context;
import java.util.Calendar;

// Referenced classes of package com.valvesoftware.android.steam.community:
//            SettingInfo

public static class m_bAllowSetTitle extends DatePickerDialog
{

    private boolean m_bAllowSetTitle;

    public void setTitle(CharSequence charsequence)
    {
        if (m_bAllowSetTitle)
        {
            super.setTitle(charsequence);
        }
    }

    public (Context context, android.app.ngInfo.CustomDatePickerDialog customdatepickerdialog, Calendar calendar, int i)
    {
        super(context, customdatepickerdialog, calendar.get(1), calendar.get(2), calendar.get(5));
        m_bAllowSetTitle = true;
        setTitle(i);
        m_bAllowSetTitle = false;
    }
}
