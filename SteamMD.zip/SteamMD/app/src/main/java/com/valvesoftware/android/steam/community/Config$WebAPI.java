// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;


// Referenced classes of package com.valvesoftware.android.steam.community:
//            Config

public static class iverse
{

    public static final int MAX_IDS_PER_CALL = 100;
    public static final String OAUTH_CLIENT_ID;

    static 
    {
        String s;
        if (Config.STEAM_UNIVERSE_WEBAPI == iverse.Public)
        {
            s = "DE45CD61";
        } else
        if (Config.STEAM_UNIVERSE_WEBAPI == iverse.Beta)
        {
            s = "7DC60112";
        } else
        {
            s = "E77327FA";
        }
        OAUTH_CLIENT_ID = s;
    }

    public iverse()
    {
    }
}
