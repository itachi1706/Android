// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.fragment;


// Referenced classes of package com.valvesoftware.android.steam.community.fragment:
//            FriendListFragment

static class yInList
{

    static final int $SwitchMap$com$valvesoftware$android$steam$community$FriendInfo$PersonaStateCategoryInList[];

    static 
    {
        $SwitchMap$com$valvesoftware$android$steam$community$FriendInfo$PersonaStateCategoryInList = new int[com.valvesoftware.android.steam.community.teCategoryInList.values().length];
        try
        {
            $SwitchMap$com$valvesoftware$android$steam$community$FriendInfo$PersonaStateCategoryInList[com.valvesoftware.android.steam.community.teCategoryInList.CHATS.ordinal()] = 1;
        }
        catch (NoSuchFieldError nosuchfielderror) { }
    }
}
