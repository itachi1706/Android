// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.fragment;

import com.valvesoftware.android.steam.community.GroupInfo;
import java.util.Comparator;

// Referenced classes of package com.valvesoftware.android.steam.community.fragment:
//            GroupListFragment

class this._cls0
    implements Comparator
{

    final GroupListFragment this$0;

    public int compare(GroupInfo groupinfo, GroupInfo groupinfo1)
    {
        if (groupinfo.m_categoryInList != groupinfo1.m_categoryInList)
        {
            return groupinfo.m_categoryInList.ordinal() >= groupinfo1.m_categoryInList.ordinal() ? 1 : -1;
        } else
        {
            return groupinfo.m_groupName.compareToIgnoreCase(groupinfo1.m_groupName);
        }
    }

    public volatile int compare(Object obj, Object obj1)
    {
        return compare((GroupInfo)obj, (GroupInfo)obj1);
    }

    ()
    {
        this$0 = GroupListFragment.this;
        super();
    }
}
