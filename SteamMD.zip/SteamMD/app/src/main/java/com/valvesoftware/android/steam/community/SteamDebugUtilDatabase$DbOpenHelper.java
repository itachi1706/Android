// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

// Referenced classes of package com.valvesoftware.android.steam.community:
//            SteamDebugUtilDatabase

private class this._cls0 extends SQLiteOpenHelper
{

    final SteamDebugUtilDatabase this$0;

    public void onCreate(SQLiteDatabase sqlitedatabase)
    {
        sqlitedatabase.execSQL("CREATE TABLE dbgutil (   _id integer primary key autoincrement , parent_id integer default null , threadid integer not null , msgtime integer not null , key text default null , value text default null , sessionstate integer default null  )");
        sqlitedatabase.execSQL("CREATE INDEX idxDbgSessionState ON dbgutil ( sessionstate )");
    }

    public void onUpgrade(SQLiteDatabase sqlitedatabase, int i, int j)
    {
        sqlitedatabase.execSQL("DROP TABLE if exists dbgutil");
        onCreate(sqlitedatabase);
    }

    public (Context context)
    {
        this$0 = SteamDebugUtilDatabase.this;
        super(context, "dbgutil.db", null, 1);
    }
}
