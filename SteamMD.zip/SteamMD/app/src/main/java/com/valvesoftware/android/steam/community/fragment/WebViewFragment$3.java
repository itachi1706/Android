// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community.fragment;

import com.valvesoftware.android.steam.community.activity.SteamMobileUriActivity;

// Referenced classes of package com.valvesoftware.android.steam.community.fragment:
//            WebViewFragment

class this._cls0
    implements itlebarButtonHander
{

    final WebViewFragment this$0;

    public void onTitlebarButtonClicked(int i)
    {
        if (getActivity() instanceof SteamMobileUriActivity)
        {
            ((SteamMobileUriActivity)getActivity()).ReloadPage();
        }
    }

    vity()
    {
        this$0 = WebViewFragment.this;
        super();
    }
}
