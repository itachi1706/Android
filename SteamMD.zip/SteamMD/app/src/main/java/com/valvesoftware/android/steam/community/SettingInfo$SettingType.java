// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;


// Referenced classes of package com.valvesoftware.android.steam.community:
//            SettingInfo

public static final class  extends Enum
{

    private static final .VALUES $VALUES[];
    public static final .VALUES CHECK;
    public static final .VALUES DATE;
    public static final .VALUES INFO;
    public static final .VALUES MARKET;
    public static final .VALUES RADIOSELECTOR;
    public static final .VALUES RINGTONESELECTOR;
    public static final .VALUES SECTION;
    public static final .VALUES UNREADMSG;
    public static final .VALUES URI;

    public static  valueOf(String s)
    {
        return ()Enum.valueOf(com/valvesoftware/android/steam/community/SettingInfo$SettingType, s);
    }

    public static [] values()
    {
        return ([])$VALUES.clone();
    }

    static 
    {
        SECTION = new <init>("SECTION", 0);
        INFO = new <init>("INFO", 1);
        CHECK = new <init>("CHECK", 2);
        DATE = new <init>("DATE", 3);
        URI = new <init>("URI", 4);
        MARKET = new <init>("MARKET", 5);
        UNREADMSG = new <init>("UNREADMSG", 6);
        RADIOSELECTOR = new <init>("RADIOSELECTOR", 7);
        RINGTONESELECTOR = new <init>("RINGTONESELECTOR", 8);
        e_3B_.clone aclone[] = new <init>[9];
        aclone[0] = SECTION;
        aclone[1] = INFO;
        aclone[2] = CHECK;
        aclone[3] = DATE;
        aclone[4] = URI;
        aclone[5] = MARKET;
        aclone[6] = UNREADMSG;
        aclone[7] = RADIOSELECTOR;
        aclone[8] = RINGTONESELECTOR;
        $VALUES = aclone;
    }

    private (String s, int i)
    {
        super(s, i);
    }
}
