// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;


// Referenced classes of package com.valvesoftware.android.steam.community:
//            SteamUriHandler

public static final class  extends Enum
{

    private static final .VALUES $VALUES[];
    public static final .VALUES agecheck;
    public static final .VALUES agecheckfailed;
    public static final .VALUES application_internal;
    public static final .VALUES chat;
    public static final .VALUES closethis;
    public static final .VALUES errorrecovery;
    public static final .VALUES login;
    public static final .VALUES mobileloginsucceeded;
    public static final .VALUES notfound;
    public static final .VALUES opencategoryurl;
    public static final .VALUES openexternalurl;
    public static final .VALUES openurl;
    public static final .VALUES reloadpage;
    public static final .VALUES settitle;

    public static  valueOf(String s)
    {
        return ()Enum.valueOf(com/valvesoftware/android/steam/community/SteamUriHandler$Command, s);
    }

    public static [] values()
    {
        return ([])$VALUES.clone();
    }

    static 
    {
        openurl = new <init>("openurl", 0);
        settitle = new <init>("settitle", 1);
        login = new <init>("login", 2);
        closethis = new <init>("closethis", 3);
        notfound = new <init>("notfound", 4);
        agecheck = new <init>("agecheck", 5);
        agecheckfailed = new <init>("agecheckfailed", 6);
        opencategoryurl = new <init>("opencategoryurl", 7);
        errorrecovery = new <init>("errorrecovery", 8);
        reloadpage = new <init>("reloadpage", 9);
        chat = new <init>("chat", 10);
        openexternalurl = new <init>("openexternalurl", 11);
        mobileloginsucceeded = new <init>("mobileloginsucceeded", 12);
        application_internal = new <init>("application_internal", 13);
        d_3B_.clone aclone[] = new <init>[14];
        aclone[0] = openurl;
        aclone[1] = settitle;
        aclone[2] = login;
        aclone[3] = closethis;
        aclone[4] = notfound;
        aclone[5] = agecheck;
        aclone[6] = agecheckfailed;
        aclone[7] = opencategoryurl;
        aclone[8] = errorrecovery;
        aclone[9] = reloadpage;
        aclone[10] = chat;
        aclone[11] = openexternalurl;
        aclone[12] = mobileloginsucceeded;
        aclone[13] = application_internal;
        $VALUES = aclone;
    }

    private (String s, int i)
    {
        super(s, i);
    }
}
