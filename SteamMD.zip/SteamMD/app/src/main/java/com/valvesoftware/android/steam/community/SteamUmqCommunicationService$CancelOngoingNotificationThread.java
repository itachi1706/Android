// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;

import java.util.concurrent.locks.Lock;

// Referenced classes of package com.valvesoftware.android.steam.community:
//            SteamUmqCommunicationService

private class <init> extends Thread
{

    public long m_timeToClearOngoingNotification;
    final SteamUmqCommunicationService this$0;

    public void run()
    {
_L2:
        SteamUmqCommunicationService.access$400(SteamUmqCommunicationService.this).lock();
        if (m_timeToClearOngoingNotification != 0L)
        {
            break MISSING_BLOCK_LABEL_43;
        }
        SteamUmqCommunicationService.access$502(SteamUmqCommunicationService.this, null);
        SteamUmqCommunicationService.access$400(SteamUmqCommunicationService.this).unlock();
        return;
        long l = m_timeToClearOngoingNotification - System.currentTimeMillis();
        if (l > 0L)
        {
            break MISSING_BLOCK_LABEL_87;
        }
        SteamUmqCommunicationService.access$600(SteamUmqCommunicationService.this);
        SteamUmqCommunicationService.access$502(SteamUmqCommunicationService.this, null);
        SteamUmqCommunicationService.access$400(SteamUmqCommunicationService.this).unlock();
        return;
        SteamUmqCommunicationService.access$400(SteamUmqCommunicationService.this).unlock();
        long l1 = 100L + l;
        try
        {
            Thread.sleep(l1);
        }
        catch (InterruptedException interruptedexception) { }
        if (true) goto _L2; else goto _L1
_L1:
        Exception exception;
        exception;
        SteamUmqCommunicationService.access$400(SteamUmqCommunicationService.this).unlock();
        throw exception;
    }

    private ()
    {
        this$0 = SteamUmqCommunicationService.this;
        super();
        m_timeToClearOngoingNotification = 0L;
    }

    m_timeToClearOngoingNotification(m_timeToClearOngoingNotification m_timetoclearongoingnotification)
    {
        this();
    }
}
