// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.valvesoftware.android.steam.community;

import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;

// Referenced classes of package com.valvesoftware.android.steam.community:
//            SteamUmqCommunicationService

private class this._cls0 extends this._cls0
{

    final SteamUmqCommunicationService this$0;

    protected HttpParams GetDefaultHttpParams()
    {
        HttpParams httpparams = super.();
        HttpConnectionParams.setSoTimeout(httpparams, 25000);
        return httpparams;
    }

    public Counter()
    {
        this$0 = SteamUmqCommunicationService.this;
        super(m_ThreadPoolCounter.GetThreadPoolQueueId());
    }

    public Counter.GetThreadPoolQueueId(String s)
    {
        this$0 = SteamUmqCommunicationService.this;
        super(s);
    }
}
