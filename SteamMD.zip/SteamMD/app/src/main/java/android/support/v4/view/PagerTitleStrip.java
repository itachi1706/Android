// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.view;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.ViewGroup;
import android.widget.TextView;

// Referenced classes of package android.support.v4.view:
//            ViewPager, PagerAdapter

public class PagerTitleStrip extends ViewGroup
    implements ViewPager.Decor
{
    private class PageListener extends DataSetObserver
        implements ViewPager.OnPageChangeListener, ViewPager.OnAdapterChangeListener
    {

        private int mScrollState;
        final PagerTitleStrip this$0;

        public void onAdapterChanged(PagerAdapter pageradapter, PagerAdapter pageradapter1)
        {
            updateAdapter(pageradapter, pageradapter1);
        }

        public void onChanged()
        {
            updateText(mPager.getCurrentItem(), mPager.getAdapter());
        }

        public void onPageScrollStateChanged(int i)
        {
            mScrollState = i;
        }

        public void onPageScrolled(int i, float f, int j)
        {
            if (f > 0.5F)
            {
                i++;
            }
            updateTextPositions(i, f);
        }

        public void onPageSelected(int i)
        {
            if (mScrollState == 0)
            {
                updateText(mPager.getCurrentItem(), mPager.getAdapter());
            }
        }

        private PageListener()
        {
            this$0 = PagerTitleStrip.this;
            super();
        }

    }


    private static final int ATTRS[] = {
        0x1010034, 0x1010098, 0x1010095
    };
    private static final int SIDE_ALPHA = 153;
    private static final String TAG = "PagerTitleStrip";
    private static final int TEXT_SPACING = 16;
    private TextView mCurrText;
    private int mLastKnownCurrentPage;
    private float mLastKnownPositionOffset;
    private TextView mNextText;
    private final PageListener mPageListener;
    ViewPager mPager;
    private TextView mPrevText;
    private int mScaledTextSpacing;
    private boolean mUpdatingPositions;
    private boolean mUpdatingText;

    public PagerTitleStrip(Context context)
    {
        this(context, null);
    }

    public PagerTitleStrip(Context context, AttributeSet attributeset)
    {
        super(context, attributeset);
        mLastKnownCurrentPage = -1;
        mLastKnownPositionOffset = -1F;
        mPageListener = new PageListener();
        TextView textview = new TextView(context);
        mPrevText = textview;
        addView(textview);
        TextView textview1 = new TextView(context);
        mCurrText = textview1;
        addView(textview1);
        TextView textview2 = new TextView(context);
        mNextText = textview2;
        addView(textview2);
        TypedArray typedarray = context.obtainStyledAttributes(attributeset, ATTRS);
        int i = typedarray.getResourceId(0, 0);
        if (i != 0)
        {
            mPrevText.setTextAppearance(context, i);
            mCurrText.setTextAppearance(context, i);
            mNextText.setTextAppearance(context, i);
        }
        if (typedarray.hasValue(1))
        {
            int l = typedarray.getColor(1, 0);
            mPrevText.setTextColor(l);
            mCurrText.setTextColor(l);
            mNextText.setTextColor(l);
        }
        int j = typedarray.getDimensionPixelSize(2, 0);
        if (j != 0)
        {
            mPrevText.setTextSize(0, j);
            mCurrText.setTextSize(0, j);
            mNextText.setTextSize(0, j);
        }
        typedarray.recycle();
        int k = 0x99000000 | 0xffffff & mPrevText.getTextColors().getDefaultColor();
        mPrevText.setTextColor(k);
        mNextText.setTextColor(k);
        mPrevText.setEllipsize(android.text.TextUtils.TruncateAt.END);
        mCurrText.setEllipsize(android.text.TextUtils.TruncateAt.END);
        mNextText.setEllipsize(android.text.TextUtils.TruncateAt.END);
        mPrevText.setSingleLine();
        mCurrText.setSingleLine();
        mNextText.setSingleLine();
        mScaledTextSpacing = (int)(16F * context.getResources().getDisplayMetrics().density);
    }

    protected void onAttachedToWindow()
    {
        super.onAttachedToWindow();
        android.view.ViewParent viewparent = getParent();
        if (!(viewparent instanceof ViewPager))
        {
            throw new IllegalStateException("PagerTitleStrip must be a direct child of a ViewPager.");
        } else
        {
            ViewPager viewpager = (ViewPager)viewparent;
            PagerAdapter pageradapter = viewpager.getAdapter();
            viewpager.setInternalPageChangeListener(mPageListener);
            viewpager.setOnAdapterChangeListener(mPageListener);
            mPager = viewpager;
            updateAdapter(null, pageradapter);
            return;
        }
    }

    protected void onDetachedFromWindow()
    {
        updateAdapter(mPager.getAdapter(), null);
        mPager.setInternalPageChangeListener(null);
        mPager.setOnAdapterChangeListener(null);
        mPager = null;
    }

    protected void onLayout(boolean flag, int i, int j, int k, int l)
    {
        if (mPager != null)
        {
            updateTextPositions(mPager.getCurrentItem(), 0.0F);
        }
    }

    protected void onMeasure(int i, int j)
    {
        int k = android.view.View.MeasureSpec.getMode(i);
        int l = android.view.View.MeasureSpec.getMode(j);
        int i1 = android.view.View.MeasureSpec.getSize(i);
        int j1 = android.view.View.MeasureSpec.getSize(j);
        if (k != 0x40000000)
        {
            throw new IllegalStateException("Must measure with an exact width");
        }
        Drawable drawable = getBackground();
        int k1 = 0;
        if (drawable != null)
        {
            k1 = drawable.getIntrinsicHeight();
        }
        int l1 = getPaddingTop() + getPaddingBottom();
        int i2 = j1 - l1;
        int j2 = android.view.View.MeasureSpec.makeMeasureSpec((int)(0.8F * (float)i1), 0x80000000);
        int k2 = android.view.View.MeasureSpec.makeMeasureSpec(i2, l);
        mPrevText.measure(j2, k2);
        mCurrText.measure(j2, k2);
        mNextText.measure(j2, k2);
        if (l == 0x40000000)
        {
            setMeasuredDimension(i1, j1);
            return;
        } else
        {
            setMeasuredDimension(i1, Math.max(k1, l1 + mCurrText.getMeasuredHeight()));
            return;
        }
    }

    public void requestLayout()
    {
        if (!mUpdatingText)
        {
            super.requestLayout();
        }
    }

    void updateAdapter(PagerAdapter pageradapter, PagerAdapter pageradapter1)
    {
        if (pageradapter != null)
        {
            pageradapter.unregisterDataSetObserver(mPageListener);
        }
        if (pageradapter1 != null)
        {
            pageradapter1.registerDataSetObserver(mPageListener);
        }
        if (mPager != null)
        {
            mLastKnownCurrentPage = -1;
            mLastKnownPositionOffset = -1F;
            updateText(mPager.getCurrentItem(), pageradapter1);
            requestLayout();
        }
    }

    void updateText(int i, PagerAdapter pageradapter)
    {
        int j;
        CharSequence charsequence;
        TextView textview;
        CharSequence charsequence1;
        int k;
        CharSequence charsequence2;
        int l;
        int i1;
        int j1;
        int k1;
        if (pageradapter != null)
        {
            j = pageradapter.getCount();
        } else
        {
            j = 0;
        }
        mUpdatingText = true;
        charsequence = null;
        if (i >= 1)
        {
            charsequence = null;
            if (pageradapter != null)
            {
                charsequence = pageradapter.getPageTitle(i - 1);
            }
        }
        mPrevText.setText(charsequence);
        textview = mCurrText;
        if (pageradapter != null)
        {
            charsequence1 = pageradapter.getPageTitle(i);
        } else
        {
            charsequence1 = null;
        }
        textview.setText(charsequence1);
        k = i + 1;
        charsequence2 = null;
        if (k < j)
        {
            charsequence2 = null;
            if (pageradapter != null)
            {
                charsequence2 = pageradapter.getPageTitle(i + 1);
            }
        }
        mNextText.setText(charsequence2);
        l = getWidth() - getPaddingLeft() - getPaddingRight();
        i1 = getHeight() - getPaddingTop() - getPaddingBottom();
        j1 = android.view.View.MeasureSpec.makeMeasureSpec((int)(0.8F * (float)l), 0x80000000);
        k1 = android.view.View.MeasureSpec.makeMeasureSpec(i1, 0x40000000);
        mPrevText.measure(j1, k1);
        mCurrText.measure(j1, k1);
        mNextText.measure(j1, k1);
        mLastKnownCurrentPage = i;
        if (!mUpdatingPositions)
        {
            updateTextPositions(i, mLastKnownPositionOffset);
        }
        mUpdatingText = false;
    }

    void updateTextPositions(int i, float f)
    {
        int j;
        int k;
        int l;
        int i1;
        int j1;
        int k1;
        int l1;
        int i2;
        int j2;
        int k2;
        int l2;
        float f1;
        int i3;
        int j3;
        int k3;
        int l3;
        if (i != mLastKnownCurrentPage)
        {
            updateText(i, mPager.getAdapter());
        } else
        if (f == mLastKnownPositionOffset)
        {
            return;
        }
        mUpdatingPositions = true;
        j = mPrevText.getMeasuredWidth();
        k = mCurrText.getMeasuredWidth();
        l = mNextText.getMeasuredWidth();
        i1 = k / 2;
        j1 = getWidth();
        k1 = getPaddingLeft();
        l1 = getPaddingRight();
        i2 = getPaddingTop();
        j2 = k1 + i1;
        k2 = l1 + i1;
        l2 = j1 - j2 - k2;
        f1 = f + 0.5F;
        if (f1 > 1.0F)
        {
            f1--;
        }
        i3 = j1 - k2 - (int)(f1 * (float)l2) - k / 2;
        j3 = i3 + k;
        mCurrText.layout(i3, i2, j3, i2 + mCurrText.getMeasuredHeight());
        k3 = Math.min(k1, i3 - mScaledTextSpacing - j);
        mPrevText.layout(k3, i2, k3 + j, i2 + mPrevText.getMeasuredHeight());
        l3 = Math.max(j1 - l1 - l, j3 + mScaledTextSpacing);
        mNextText.layout(l3, i2, l3 + l, i2 + mNextText.getMeasuredHeight());
        mLastKnownPositionOffset = f;
        mUpdatingPositions = false;
    }

}
