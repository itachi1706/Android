// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;

// Referenced classes of package android.support.v4.view:
//            ViewPager

public static class gravity extends android.view.youtParams
{

    public int gravity;
    public boolean isDecor;

    public ()
    {
        super(-1, -1);
    }

    public (Context context, AttributeSet attributeset)
    {
        super(context, attributeset);
        TypedArray typedarray = context.obtainStyledAttributes(attributeset, ViewPager.access$100());
        gravity = typedarray.getInteger(0, 0);
        typedarray.recycle();
    }
}
