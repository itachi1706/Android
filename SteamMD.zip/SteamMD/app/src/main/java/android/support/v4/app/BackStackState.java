// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.app;

import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.Log;
import java.util.ArrayList;

// Referenced classes of package android.support.v4.app:
//            BackStackRecord, Fragment, FragmentManagerImpl

final class BackStackState
    implements Parcelable
{

    public static final android.os.Parcelable.Creator CREATOR = new android.os.Parcelable.Creator() {

        public BackStackState createFromParcel(Parcel parcel)
        {
            return new BackStackState(parcel);
        }

        public volatile Object createFromParcel(Parcel parcel)
        {
            return createFromParcel(parcel);
        }

        public BackStackState[] newArray(int i)
        {
            return new BackStackState[i];
        }

        public volatile Object[] newArray(int i)
        {
            return newArray(i);
        }

    };
    final int mBreadCrumbShortTitleRes;
    final CharSequence mBreadCrumbShortTitleText;
    final int mBreadCrumbTitleRes;
    final CharSequence mBreadCrumbTitleText;
    final int mIndex;
    final String mName;
    final int mOps[];
    final int mTransition;
    final int mTransitionStyle;

    public BackStackState(Parcel parcel)
    {
        mOps = parcel.createIntArray();
        mTransition = parcel.readInt();
        mTransitionStyle = parcel.readInt();
        mName = parcel.readString();
        mIndex = parcel.readInt();
        mBreadCrumbTitleRes = parcel.readInt();
        mBreadCrumbTitleText = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        mBreadCrumbShortTitleRes = parcel.readInt();
        mBreadCrumbShortTitleText = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
    }

    public BackStackState(FragmentManagerImpl fragmentmanagerimpl, BackStackRecord backstackrecord)
    {
        int i = 0;
        for (BackStackRecord.Op op = backstackrecord.mHead; op != null; op = op.next)
        {
            if (op.removed != null)
            {
                i += op.removed.size();
            }
        }

        mOps = new int[i + 7 * backstackrecord.mNumOp];
        if (!backstackrecord.mAddToBackStack)
        {
            throw new IllegalStateException("Not on back stack");
        }
        BackStackRecord.Op op1 = backstackrecord.mHead;
        int j = 0;
        while (op1 != null) 
        {
            int ai[] = mOps;
            int k = j + 1;
            ai[j] = op1.cmd;
            int ai1[] = mOps;
            int l = k + 1;
            ai1[k] = op1.fragment.mIndex;
            int ai2[] = mOps;
            int i1 = l + 1;
            ai2[l] = op1.enterAnim;
            int ai3[] = mOps;
            int j1 = i1 + 1;
            ai3[i1] = op1.exitAnim;
            int ai4[] = mOps;
            int k1 = j1 + 1;
            ai4[j1] = op1.popEnterAnim;
            int ai5[] = mOps;
            int l1 = k1 + 1;
            ai5[k1] = op1.popExitAnim;
            int i2;
            if (op1.removed != null)
            {
                int j2 = op1.removed.size();
                int ai7[] = mOps;
                int k2 = l1 + 1;
                ai7[l1] = j2;
                int l2 = 0;
                int i3;
                int j3;
                for (i3 = k2; l2 < j2; i3 = j3)
                {
                    int ai8[] = mOps;
                    j3 = i3 + 1;
                    ai8[i3] = ((Fragment)op1.removed.get(l2)).mIndex;
                    l2++;
                }

                i2 = i3;
            } else
            {
                int ai6[] = mOps;
                i2 = l1 + 1;
                ai6[l1] = 0;
            }
            op1 = op1.next;
            j = i2;
        }
        mTransition = backstackrecord.mTransition;
        mTransitionStyle = backstackrecord.mTransitionStyle;
        mName = backstackrecord.mName;
        mIndex = backstackrecord.mIndex;
        mBreadCrumbTitleRes = backstackrecord.mBreadCrumbTitleRes;
        mBreadCrumbTitleText = backstackrecord.mBreadCrumbTitleText;
        mBreadCrumbShortTitleRes = backstackrecord.mBreadCrumbShortTitleRes;
        mBreadCrumbShortTitleText = backstackrecord.mBreadCrumbShortTitleText;
    }

    public int describeContents()
    {
        return 0;
    }

    public BackStackRecord instantiate(FragmentManagerImpl fragmentmanagerimpl)
    {
        BackStackRecord backstackrecord = new BackStackRecord(fragmentmanagerimpl);
        for (int i = 0; i < mOps.length;)
        {
            BackStackRecord.Op op = new BackStackRecord.Op();
            int ai[] = mOps;
            int j = i + 1;
            op.cmd = ai[i];
            if (FragmentManagerImpl.DEBUG)
            {
                Log.v("FragmentManager", (new StringBuilder()).append("BSE ").append(backstackrecord).append(" set base fragment #").append(mOps[j]).toString());
            }
            ArrayList arraylist = fragmentmanagerimpl.mActive;
            int ai1[] = mOps;
            int k = j + 1;
            op.fragment = (Fragment)arraylist.get(ai1[j]);
            int ai2[] = mOps;
            int l = k + 1;
            op.enterAnim = ai2[k];
            int ai3[] = mOps;
            int i1 = l + 1;
            op.exitAnim = ai3[l];
            int ai4[] = mOps;
            int j1 = i1 + 1;
            op.popEnterAnim = ai4[i1];
            int ai5[] = mOps;
            int k1 = j1 + 1;
            op.popExitAnim = ai5[j1];
            int ai6[] = mOps;
            int l1 = k1 + 1;
            int i2 = ai6[k1];
            if (i2 > 0)
            {
                op.removed = new ArrayList(i2);
                for (int j2 = 0; j2 < i2;)
                {
                    if (FragmentManagerImpl.DEBUG)
                    {
                        Log.v("FragmentManager", (new StringBuilder()).append("BSE ").append(backstackrecord).append(" set remove fragment #").append(mOps[l1]).toString());
                    }
                    ArrayList arraylist1 = fragmentmanagerimpl.mActive;
                    int ai7[] = mOps;
                    int k2 = l1 + 1;
                    Fragment fragment = (Fragment)arraylist1.get(ai7[l1]);
                    op.removed.add(fragment);
                    j2++;
                    l1 = k2;
                }

            }
            i = l1;
            backstackrecord.addOp(op);
        }

        backstackrecord.mTransition = mTransition;
        backstackrecord.mTransitionStyle = mTransitionStyle;
        backstackrecord.mName = mName;
        backstackrecord.mIndex = mIndex;
        backstackrecord.mAddToBackStack = true;
        backstackrecord.mBreadCrumbTitleRes = mBreadCrumbTitleRes;
        backstackrecord.mBreadCrumbTitleText = mBreadCrumbTitleText;
        backstackrecord.mBreadCrumbShortTitleRes = mBreadCrumbShortTitleRes;
        backstackrecord.mBreadCrumbShortTitleText = mBreadCrumbShortTitleText;
        backstackrecord.bumpBackStackNesting(1);
        return backstackrecord;
    }

    public void writeToParcel(Parcel parcel, int i)
    {
        parcel.writeIntArray(mOps);
        parcel.writeInt(mTransition);
        parcel.writeInt(mTransitionStyle);
        parcel.writeString(mName);
        parcel.writeInt(mIndex);
        parcel.writeInt(mBreadCrumbTitleRes);
        TextUtils.writeToParcel(mBreadCrumbTitleText, parcel, 0);
        parcel.writeInt(mBreadCrumbShortTitleRes);
        TextUtils.writeToParcel(mBreadCrumbShortTitleText, parcel, 0);
    }

}
