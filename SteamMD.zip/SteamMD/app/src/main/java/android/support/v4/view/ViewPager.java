// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.view;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.SystemClock;
import android.support.v4.os.ParcelableCompat;
import android.support.v4.os.ParcelableCompatCreatorCallbacks;
import android.support.v4.widget.EdgeEffectCompat;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.FocusFinder;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.SoundEffectConstants;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.animation.Interpolator;
import android.widget.Scroller;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

// Referenced classes of package android.support.v4.view:
//            MotionEventCompat, PagerAdapter, ViewCompat, VelocityTrackerCompat, 
//            KeyEventCompat, ViewConfigurationCompat

public class ViewPager extends ViewGroup
{
    static interface Decor
    {
    }

    static class ItemInfo
    {

        Object object;
        int position;
        boolean scrolling;

        ItemInfo()
        {
        }
    }

    public static class LayoutParams extends android.view.ViewGroup.LayoutParams
    {

        public int gravity;
        public boolean isDecor;

        public LayoutParams()
        {
            super(-1, -1);
        }

        public LayoutParams(Context context, AttributeSet attributeset)
        {
            super(context, attributeset);
            TypedArray typedarray = context.obtainStyledAttributes(attributeset, ViewPager.LAYOUT_ATTRS);
            gravity = typedarray.getInteger(0, 0);
            typedarray.recycle();
        }
    }

    static interface OnAdapterChangeListener
    {

        public abstract void onAdapterChanged(PagerAdapter pageradapter, PagerAdapter pageradapter1);
    }

    public static interface OnPageChangeListener
    {

        public abstract void onPageScrollStateChanged(int i);

        public abstract void onPageScrolled(int i, float f, int j);

        public abstract void onPageSelected(int i);
    }

    private class PagerObserver extends DataSetObserver
    {

        final ViewPager this$0;

        public void onChanged()
        {
            dataSetChanged();
        }

        public void onInvalidated()
        {
            dataSetChanged();
        }

        private PagerObserver()
        {
            this$0 = ViewPager.this;
            super();
        }

    }

    public static class SavedState extends android.view.View.BaseSavedState
    {

        public static final android.os.Parcelable.Creator CREATOR = ParcelableCompat.newCreator(new ParcelableCompatCreatorCallbacks() {

            public SavedState createFromParcel(Parcel parcel, ClassLoader classloader)
            {
                return new SavedState(parcel, classloader);
            }

            public volatile Object createFromParcel(Parcel parcel, ClassLoader classloader)
            {
                return createFromParcel(parcel, classloader);
            }

            public SavedState[] newArray(int i)
            {
                return new SavedState[i];
            }

            public volatile Object[] newArray(int i)
            {
                return newArray(i);
            }

        });
        Parcelable adapterState;
        ClassLoader loader;
        int position;

        public String toString()
        {
            return (new StringBuilder()).append("FragmentPager.SavedState{").append(Integer.toHexString(System.identityHashCode(this))).append(" position=").append(position).append("}").toString();
        }

        public void writeToParcel(Parcel parcel, int i)
        {
            super.writeToParcel(parcel, i);
            parcel.writeInt(position);
            parcel.writeParcelable(adapterState, i);
        }


        SavedState(Parcel parcel, ClassLoader classloader)
        {
            super(parcel);
            if (classloader == null)
            {
                classloader = getClass().getClassLoader();
            }
            position = parcel.readInt();
            adapterState = parcel.readParcelable(classloader);
            loader = classloader;
        }

        public SavedState(Parcelable parcelable)
        {
            super(parcelable);
        }
    }

    public static class SimpleOnPageChangeListener
        implements OnPageChangeListener
    {

        public void onPageScrollStateChanged(int i)
        {
        }

        public void onPageScrolled(int i, float f, int j)
        {
        }

        public void onPageSelected(int i)
        {
        }

        public SimpleOnPageChangeListener()
        {
        }
    }


    private static final Comparator COMPARATOR = new Comparator() {

        public int compare(ItemInfo iteminfo, ItemInfo iteminfo1)
        {
            return iteminfo.position - iteminfo1.position;
        }

        public volatile int compare(Object obj, Object obj1)
        {
            return compare((ItemInfo)obj, (ItemInfo)obj1);
        }

    };
    private static final boolean DEBUG = false;
    private static final int DEFAULT_OFFSCREEN_PAGES = 1;
    private static final int INVALID_POINTER = -1;
    private static final int LAYOUT_ATTRS[] = {
        0x10100b3
    };
    private static final int MAX_SETTLE_DURATION = 600;
    private static final int MIN_DISTANCE_FOR_FLING = 25;
    public static final int SCROLL_STATE_DRAGGING = 1;
    public static final int SCROLL_STATE_IDLE = 0;
    public static final int SCROLL_STATE_SETTLING = 2;
    private static final String TAG = "ViewPager";
    private static final boolean USE_CACHE;
    private static final Interpolator sInterpolator = new Interpolator() {

        public float getInterpolation(float f)
        {
            float f1 = f - 1.0F;
            return 1.0F + f1 * (f1 * (f1 * (f1 * f1)));
        }

    };
    private int mActivePointerId;
    private PagerAdapter mAdapter;
    private OnAdapterChangeListener mAdapterChangeListener;
    private int mBottomPageBounds;
    private boolean mCalledSuper;
    private int mChildHeightMeasureSpec;
    private int mChildWidthMeasureSpec;
    private int mCurItem;
    private int mDecorChildCount;
    private long mFakeDragBeginTime;
    private boolean mFakeDragging;
    private boolean mFirstLayout;
    private int mFlingDistance;
    private boolean mInLayout;
    private float mInitialMotionX;
    private OnPageChangeListener mInternalPageChangeListener;
    private boolean mIsBeingDragged;
    private boolean mIsUnableToDrag;
    private final ArrayList mItems;
    private float mLastMotionX;
    private float mLastMotionY;
    private EdgeEffectCompat mLeftEdge;
    private Drawable mMarginDrawable;
    private int mMaximumVelocity;
    private int mMinimumVelocity;
    private PagerObserver mObserver;
    private int mOffscreenPageLimit;
    private OnPageChangeListener mOnPageChangeListener;
    private int mPageMargin;
    private boolean mPopulatePending;
    private Parcelable mRestoredAdapterState;
    private ClassLoader mRestoredClassLoader;
    private int mRestoredCurItem;
    private EdgeEffectCompat mRightEdge;
    private int mScrollState;
    private Scroller mScroller;
    private boolean mScrolling;
    private boolean mScrollingCacheEnabled;
    private int mTopPageBounds;
    private int mTouchSlop;
    private VelocityTracker mVelocityTracker;

    public ViewPager(Context context)
    {
        super(context);
        mItems = new ArrayList();
        mRestoredCurItem = -1;
        mRestoredAdapterState = null;
        mRestoredClassLoader = null;
        mOffscreenPageLimit = 1;
        mActivePointerId = -1;
        mFirstLayout = true;
        mScrollState = 0;
        initViewPager();
    }

    public ViewPager(Context context, AttributeSet attributeset)
    {
        super(context, attributeset);
        mItems = new ArrayList();
        mRestoredCurItem = -1;
        mRestoredAdapterState = null;
        mRestoredClassLoader = null;
        mOffscreenPageLimit = 1;
        mActivePointerId = -1;
        mFirstLayout = true;
        mScrollState = 0;
        initViewPager();
    }

    private void completeScroll()
    {
        boolean flag = mScrolling;
        if (flag)
        {
            setScrollingCacheEnabled(false);
            mScroller.abortAnimation();
            int j = getScrollX();
            int k = getScrollY();
            int l = mScroller.getCurrX();
            int i1 = mScroller.getCurrY();
            if (j != l || k != i1)
            {
                scrollTo(l, i1);
            }
            setScrollState(0);
        }
        mPopulatePending = false;
        mScrolling = false;
        for (int i = 0; i < mItems.size(); i++)
        {
            ItemInfo iteminfo = (ItemInfo)mItems.get(i);
            if (iteminfo.scrolling)
            {
                flag = true;
                iteminfo.scrolling = false;
            }
        }

        if (flag)
        {
            populate();
        }
    }

    private int determineTargetPage(int i, float f, int j, int k)
    {
        if (Math.abs(k) > mFlingDistance && Math.abs(j) > mMinimumVelocity)
        {
            if (j > 0)
            {
                return i;
            } else
            {
                return i + 1;
            }
        } else
        {
            return (int)(0.5F + (f + (float)i));
        }
    }

    private void endDrag()
    {
        mIsBeingDragged = false;
        mIsUnableToDrag = false;
        if (mVelocityTracker != null)
        {
            mVelocityTracker.recycle();
            mVelocityTracker = null;
        }
    }

    private void onSecondaryPointerUp(MotionEvent motionevent)
    {
        int i = MotionEventCompat.getActionIndex(motionevent);
        if (MotionEventCompat.getPointerId(motionevent, i) == mActivePointerId)
        {
            int j;
            if (i == 0)
            {
                j = 1;
            } else
            {
                j = 0;
            }
            mLastMotionX = MotionEventCompat.getX(motionevent, j);
            mActivePointerId = MotionEventCompat.getPointerId(motionevent, j);
            if (mVelocityTracker != null)
            {
                mVelocityTracker.clear();
            }
        }
    }

    private void pageScrolled(int i)
    {
        int j = getWidth() + mPageMargin;
        int k = i / j;
        int l = i % j;
        float f = (float)l / (float)j;
        mCalledSuper = false;
        onPageScrolled(k, f, l);
        if (!mCalledSuper)
        {
            throw new IllegalStateException("onPageScrolled did not call superclass implementation");
        } else
        {
            return;
        }
    }

    private void recomputeScrollPosition(int i, int j, int k, int l)
    {
        int i1 = i + k;
        if (j > 0)
        {
            int k1 = getScrollX();
            int l1 = j + l;
            int i2 = k1 / l1;
            int j2 = (int)(((float)(k1 % l1) / (float)l1 + (float)i2) * (float)i1);
            scrollTo(j2, getScrollY());
            if (!mScroller.isFinished())
            {
                int k2 = mScroller.getDuration() - mScroller.timePassed();
                mScroller.startScroll(j2, 0, i1 * mCurItem, 0, k2);
            }
        } else
        {
            int j1 = i1 * mCurItem;
            if (j1 != getScrollX())
            {
                completeScroll();
                scrollTo(j1, getScrollY());
                return;
            }
        }
    }

    private void removeNonDecorViews()
    {
        for (int i = 0; i < getChildCount(); i++)
        {
            if (!((LayoutParams)getChildAt(i).getLayoutParams()).isDecor)
            {
                removeViewAt(i);
                i--;
            }
        }

    }

    private void setScrollState(int i)
    {
        if (mScrollState != i)
        {
            mScrollState = i;
            if (mOnPageChangeListener != null)
            {
                mOnPageChangeListener.onPageScrollStateChanged(i);
                return;
            }
        }
    }

    private void setScrollingCacheEnabled(boolean flag)
    {
        if (mScrollingCacheEnabled != flag)
        {
            mScrollingCacheEnabled = flag;
        }
    }

    public void addFocusables(ArrayList arraylist, int i, int j)
    {
        int k = arraylist.size();
        int l = getDescendantFocusability();
        if (l != 0x60000)
        {
            for (int i1 = 0; i1 < getChildCount(); i1++)
            {
                View view = getChildAt(i1);
                if (view.getVisibility() == 0)
                {
                    ItemInfo iteminfo = infoForChild(view);
                    if (iteminfo != null && iteminfo.position == mCurItem)
                    {
                        view.addFocusables(arraylist, i, j);
                    }
                }
            }

        }
        while (l == 0x40000 && k != arraylist.size() || !isFocusable() || (j & 1) == 1 && isInTouchMode() && !isFocusableInTouchMode() || arraylist == null) 
        {
            return;
        }
        arraylist.add(this);
    }

    void addNewItem(int i, int j)
    {
        ItemInfo iteminfo = new ItemInfo();
        iteminfo.position = i;
        iteminfo.object = mAdapter.instantiateItem(this, i);
        if (j < 0)
        {
            mItems.add(iteminfo);
            return;
        } else
        {
            mItems.add(j, iteminfo);
            return;
        }
    }

    public void addTouchables(ArrayList arraylist)
    {
        for (int i = 0; i < getChildCount(); i++)
        {
            View view = getChildAt(i);
            if (view.getVisibility() != 0)
            {
                continue;
            }
            ItemInfo iteminfo = infoForChild(view);
            if (iteminfo != null && iteminfo.position == mCurItem)
            {
                view.addTouchables(arraylist);
            }
        }

    }

    public void addView(View view, int i, android.view.ViewGroup.LayoutParams layoutparams)
    {
        if (!checkLayoutParams(layoutparams))
        {
            layoutparams = generateLayoutParams(layoutparams);
        }
        LayoutParams layoutparams1 = (LayoutParams)layoutparams;
        layoutparams1.isDecor = layoutparams1.isDecor | (view instanceof Decor);
        if (mInLayout)
        {
            if (layoutparams1 != null && layoutparams1.isDecor)
            {
                throw new IllegalStateException("Cannot add pager decor view during layout");
            } else
            {
                addViewInLayout(view, i, layoutparams);
                view.measure(mChildWidthMeasureSpec, mChildHeightMeasureSpec);
                return;
            }
        } else
        {
            super.addView(view, i, layoutparams);
            return;
        }
    }

    public boolean arrowScroll(int i)
    {
        View view;
        View view1;
        view = findFocus();
        if (view == this)
        {
            view = null;
        }
        view1 = FocusFinder.getInstance().findNextFocus(this, view, i);
        if (view1 == null || view1 == view) goto _L2; else goto _L1
_L1:
        if (i != 17) goto _L4; else goto _L3
_L3:
        boolean flag;
        if (view != null && view1.getLeft() >= view.getLeft())
        {
            flag = pageLeft();
        } else
        {
            flag = view1.requestFocus();
        }
_L6:
        if (flag)
        {
            playSoundEffect(SoundEffectConstants.getContantForFocusDirection(i));
        }
        return flag;
_L4:
        flag = false;
        if (i == 66)
        {
            if (view != null && view1.getLeft() <= view.getLeft())
            {
                flag = pageRight();
            } else
            {
                flag = view1.requestFocus();
            }
        }
        continue; /* Loop/switch isn't completed */
_L2:
        if (i == 17 || i == 1)
        {
            flag = pageLeft();
            continue; /* Loop/switch isn't completed */
        }
        if (i != 66)
        {
            flag = false;
            if (i != 2)
            {
                continue; /* Loop/switch isn't completed */
            }
        }
        flag = pageRight();
        if (true) goto _L6; else goto _L5
_L5:
    }

    public boolean beginFakeDrag()
    {
        if (mIsBeingDragged)
        {
            return false;
        }
        mFakeDragging = true;
        setScrollState(1);
        mLastMotionX = 0.0F;
        mInitialMotionX = 0.0F;
        long l;
        MotionEvent motionevent;
        if (mVelocityTracker == null)
        {
            mVelocityTracker = VelocityTracker.obtain();
        } else
        {
            mVelocityTracker.clear();
        }
        l = SystemClock.uptimeMillis();
        motionevent = MotionEvent.obtain(l, l, 0, 0.0F, 0.0F, 0);
        mVelocityTracker.addMovement(motionevent);
        motionevent.recycle();
        mFakeDragBeginTime = l;
        return true;
    }

    protected boolean canScroll(View view, boolean flag, int i, int j, int k)
    {
        if (view instanceof ViewGroup)
        {
            ViewGroup viewgroup = (ViewGroup)view;
            int l = view.getScrollX();
            int i1 = view.getScrollY();
            for (int j1 = -1 + viewgroup.getChildCount(); j1 >= 0; j1--)
            {
                View view1 = viewgroup.getChildAt(j1);
                if (j + l >= view1.getLeft() && j + l < view1.getRight() && k + i1 >= view1.getTop() && k + i1 < view1.getBottom() && canScroll(view1, true, i, (j + l) - view1.getLeft(), (k + i1) - view1.getTop()))
                {
                    return true;
                }
            }

        }
        return flag && ViewCompat.canScrollHorizontally(view, -i);
    }

    protected boolean checkLayoutParams(android.view.ViewGroup.LayoutParams layoutparams)
    {
        return (layoutparams instanceof LayoutParams) && super.checkLayoutParams(layoutparams);
    }

    public void computeScroll()
    {
        if (!mScroller.isFinished() && mScroller.computeScrollOffset())
        {
            int i = getScrollX();
            int j = getScrollY();
            int k = mScroller.getCurrX();
            int l = mScroller.getCurrY();
            if (i != k || j != l)
            {
                scrollTo(k, l);
                pageScrolled(k);
            }
            invalidate();
            return;
        } else
        {
            completeScroll();
            return;
        }
    }

    void dataSetChanged()
    {
        boolean flag;
        int i;
        boolean flag1;
        int j;
        if (mItems.size() < 3 && mItems.size() < mAdapter.getCount())
        {
            flag = true;
        } else
        {
            flag = false;
        }
        i = -1;
        flag1 = false;
        j = 0;
        while (j < mItems.size()) 
        {
            ItemInfo iteminfo = (ItemInfo)mItems.get(j);
            int k = mAdapter.getItemPosition(iteminfo.object);
            if (k != -1)
            {
                if (k == -2)
                {
                    mItems.remove(j);
                    j--;
                    if (!flag1)
                    {
                        mAdapter.startUpdate(this);
                        flag1 = true;
                    }
                    mAdapter.destroyItem(this, iteminfo.position, iteminfo.object);
                    flag = true;
                    if (mCurItem == iteminfo.position)
                    {
                        i = Math.max(0, Math.min(mCurItem, -1 + mAdapter.getCount()));
                    }
                } else
                if (iteminfo.position != k)
                {
                    if (iteminfo.position == mCurItem)
                    {
                        i = k;
                    }
                    iteminfo.position = k;
                    flag = true;
                }
            }
            j++;
        }
        if (flag1)
        {
            mAdapter.finishUpdate(this);
        }
        Collections.sort(mItems, COMPARATOR);
        if (i >= 0)
        {
            setCurrentItemInternal(i, false, true);
            flag = true;
        }
        if (flag)
        {
            populate();
            requestLayout();
        }
    }

    public boolean dispatchKeyEvent(KeyEvent keyevent)
    {
        return super.dispatchKeyEvent(keyevent) || executeKeyEvent(keyevent);
    }

    public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent accessibilityevent)
    {
        int i = getChildCount();
        for (int j = 0; j < i; j++)
        {
            View view = getChildAt(j);
            if (view.getVisibility() != 0)
            {
                continue;
            }
            ItemInfo iteminfo = infoForChild(view);
            if (iteminfo != null && iteminfo.position == mCurItem && view.dispatchPopulateAccessibilityEvent(accessibilityevent))
            {
                return true;
            }
        }

        return false;
    }

    float distanceInfluenceForSnapDuration(float f)
    {
        return (float)Math.sin((float)(0.4712389167638204D * (double)(f - 0.5F)));
    }

    public void draw(Canvas canvas)
    {
        int i = 1;
        super.draw(canvas);
        int j = ViewCompat.getOverScrollMode(this);
        boolean flag1;
        if (j == 0 || j == i && mAdapter != null && mAdapter.getCount() > i)
        {
            boolean flag = mLeftEdge.isFinished();
            flag1 = false;
            if (!flag)
            {
                int j1 = canvas.save();
                int k1 = getHeight() - getPaddingTop() - getPaddingBottom();
                canvas.rotate(270F);
                canvas.translate(-k1 + getPaddingTop(), 0.0F);
                mLeftEdge.setSize(k1, getWidth());
                flag1 = false | mLeftEdge.draw(canvas);
                canvas.restoreToCount(j1);
            }
            if (!mRightEdge.isFinished())
            {
                int k = canvas.save();
                int l = getWidth();
                int i1 = getHeight() - getPaddingTop() - getPaddingBottom();
                if (mAdapter != null)
                {
                    i = mAdapter.getCount();
                }
                canvas.rotate(90F);
                canvas.translate(-getPaddingTop(), -i * (l + mPageMargin) + mPageMargin);
                mRightEdge.setSize(i1, l);
                flag1 |= mRightEdge.draw(canvas);
                canvas.restoreToCount(k);
            }
        } else
        {
            mLeftEdge.finish();
            mRightEdge.finish();
            flag1 = false;
        }
        if (flag1)
        {
            invalidate();
        }
    }

    protected void drawableStateChanged()
    {
        super.drawableStateChanged();
        Drawable drawable = mMarginDrawable;
        if (drawable != null && drawable.isStateful())
        {
            drawable.setState(getDrawableState());
        }
    }

    public void endFakeDrag()
    {
        if (!mFakeDragging)
        {
            throw new IllegalStateException("No fake drag in progress. Call beginFakeDrag first.");
        } else
        {
            VelocityTracker velocitytracker = mVelocityTracker;
            velocitytracker.computeCurrentVelocity(1000, mMaximumVelocity);
            int i = (int)VelocityTrackerCompat.getYVelocity(velocitytracker, mActivePointerId);
            mPopulatePending = true;
            int j = (int)(mLastMotionX - mInitialMotionX);
            int k = getScrollX();
            int l = getWidth() + mPageMargin;
            setCurrentItemInternal(determineTargetPage(k / l, (float)(k % l) / (float)l, i, j), true, true, i);
            endDrag();
            mFakeDragging = false;
            return;
        }
    }

    public boolean executeKeyEvent(KeyEvent keyevent)
    {
        if (keyevent.getAction() != 0) goto _L2; else goto _L1
_L1:
        keyevent.getKeyCode();
        JVM INSTR lookupswitch 3: default 44
    //                   21: 46
    //                   22: 53
    //                   61: 60;
           goto _L2 _L3 _L4 _L5
_L2:
        return false;
_L3:
        return arrowScroll(17);
_L4:
        return arrowScroll(66);
_L5:
        if (android.os.Build.VERSION.SDK_INT >= 11)
        {
            if (KeyEventCompat.hasNoModifiers(keyevent))
            {
                return arrowScroll(2);
            }
            if (KeyEventCompat.hasModifiers(keyevent, 1))
            {
                return arrowScroll(1);
            }
        }
        if (true) goto _L2; else goto _L6
_L6:
    }

    public void fakeDragBy(float f)
    {
        float f1;
        float f2;
        float f3;
        if (!mFakeDragging)
        {
            throw new IllegalStateException("No fake drag in progress. Call beginFakeDrag first.");
        }
        mLastMotionX = f + mLastMotionX;
        f1 = (float)getScrollX() - f;
        int i = getWidth() + mPageMargin;
        f2 = Math.max(0, i * (-1 + mCurItem));
        f3 = i * Math.min(1 + mCurItem, -1 + mAdapter.getCount());
        if (f1 >= f2) goto _L2; else goto _L1
_L1:
        f1 = f2;
_L4:
        mLastMotionX = mLastMotionX + (f1 - (float)(int)f1);
        scrollTo((int)f1, getScrollY());
        pageScrolled((int)f1);
        long l = SystemClock.uptimeMillis();
        MotionEvent motionevent = MotionEvent.obtain(mFakeDragBeginTime, l, 2, mLastMotionX, 0.0F, 0);
        mVelocityTracker.addMovement(motionevent);
        motionevent.recycle();
        return;
_L2:
        if (f1 > f3)
        {
            f1 = f3;
        }
        if (true) goto _L4; else goto _L3
_L3:
    }

    protected android.view.ViewGroup.LayoutParams generateDefaultLayoutParams()
    {
        return new LayoutParams();
    }

    public android.view.ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeset)
    {
        return new LayoutParams(getContext(), attributeset);
    }

    protected android.view.ViewGroup.LayoutParams generateLayoutParams(android.view.ViewGroup.LayoutParams layoutparams)
    {
        return generateDefaultLayoutParams();
    }

    public PagerAdapter getAdapter()
    {
        return mAdapter;
    }

    public int getCurrentItem()
    {
        return mCurItem;
    }

    public int getOffscreenPageLimit()
    {
        return mOffscreenPageLimit;
    }

    public int getPageMargin()
    {
        return mPageMargin;
    }

    ItemInfo infoForAnyChild(View view)
    {
        do
        {
            android.view.ViewParent viewparent = view.getParent();
            if (viewparent != this)
            {
                if (viewparent == null || !(viewparent instanceof View))
                {
                    return null;
                }
                view = (View)viewparent;
            } else
            {
                return infoForChild(view);
            }
        } while (true);
    }

    ItemInfo infoForChild(View view)
    {
        for (int i = 0; i < mItems.size(); i++)
        {
            ItemInfo iteminfo = (ItemInfo)mItems.get(i);
            if (mAdapter.isViewFromObject(view, iteminfo.object))
            {
                return iteminfo;
            }
        }

        return null;
    }

    void initViewPager()
    {
        setWillNotDraw(false);
        setDescendantFocusability(0x40000);
        setFocusable(true);
        Context context = getContext();
        mScroller = new Scroller(context, sInterpolator);
        ViewConfiguration viewconfiguration = ViewConfiguration.get(context);
        mTouchSlop = ViewConfigurationCompat.getScaledPagingTouchSlop(viewconfiguration);
        mMinimumVelocity = viewconfiguration.getScaledMinimumFlingVelocity();
        mMaximumVelocity = viewconfiguration.getScaledMaximumFlingVelocity();
        mLeftEdge = new EdgeEffectCompat(context);
        mRightEdge = new EdgeEffectCompat(context);
        mFlingDistance = (int)(25F * context.getResources().getDisplayMetrics().density);
    }

    public boolean isFakeDragging()
    {
        return mFakeDragging;
    }

    protected void onAttachedToWindow()
    {
        super.onAttachedToWindow();
        mFirstLayout = true;
    }

    protected void onDraw(Canvas canvas)
    {
        super.onDraw(canvas);
        if (mPageMargin > 0 && mMarginDrawable != null)
        {
            int i = getScrollX();
            int j = getWidth();
            int k = i % (j + mPageMargin);
            if (k != 0)
            {
                int l = j + (i - k);
                mMarginDrawable.setBounds(l, mTopPageBounds, l + mPageMargin, mBottomPageBounds);
                mMarginDrawable.draw(canvas);
            }
        }
    }

    public boolean onInterceptTouchEvent(MotionEvent motionevent)
    {
        int i;
        i = 0xff & motionevent.getAction();
        if (i == 3 || i == 1)
        {
            mIsBeingDragged = false;
            mIsUnableToDrag = false;
            mActivePointerId = -1;
            if (mVelocityTracker != null)
            {
                mVelocityTracker.recycle();
                mVelocityTracker = null;
            }
            return false;
        }
        if (i != 0)
        {
            if (mIsBeingDragged)
            {
                return true;
            }
            if (mIsUnableToDrag)
            {
                return false;
            }
        }
        i;
        JVM INSTR lookupswitch 3: default 112
    //                   0: 310
    //                   2: 146
    //                   6: 385;
           goto _L1 _L2 _L3 _L4
_L1:
        if (!mIsBeingDragged)
        {
            if (mVelocityTracker == null)
            {
                mVelocityTracker = VelocityTracker.obtain();
            }
            mVelocityTracker.addMovement(motionevent);
        }
        return mIsBeingDragged;
_L3:
        int j = mActivePointerId;
        if (j != -1)
        {
            int k = MotionEventCompat.findPointerIndex(motionevent, j);
            float f1 = MotionEventCompat.getX(motionevent, k);
            float f2 = f1 - mLastMotionX;
            float f3 = Math.abs(f2);
            float f4 = MotionEventCompat.getY(motionevent, k);
            float f5 = Math.abs(f4 - mLastMotionY);
            if (canScroll(this, false, (int)f2, (int)f1, (int)f4))
            {
                mLastMotionX = f1;
                mInitialMotionX = f1;
                mLastMotionY = f4;
                return false;
            }
            if (f3 > (float)mTouchSlop && f3 > f5)
            {
                mIsBeingDragged = true;
                setScrollState(1);
                mLastMotionX = f1;
                setScrollingCacheEnabled(true);
            } else
            if (f5 > (float)mTouchSlop)
            {
                mIsUnableToDrag = true;
            }
        }
        continue; /* Loop/switch isn't completed */
_L2:
        float f = motionevent.getX();
        mInitialMotionX = f;
        mLastMotionX = f;
        mLastMotionY = motionevent.getY();
        mActivePointerId = MotionEventCompat.getPointerId(motionevent, 0);
        if (mScrollState == 2)
        {
            mIsBeingDragged = true;
            mIsUnableToDrag = false;
            setScrollState(1);
        } else
        {
            completeScroll();
            mIsBeingDragged = false;
            mIsUnableToDrag = false;
        }
        continue; /* Loop/switch isn't completed */
_L4:
        onSecondaryPointerUp(motionevent);
        if (true) goto _L1; else goto _L5
_L5:
    }

    protected void onLayout(boolean flag, int i, int j, int k, int l)
    {
        int i1;
        int j1;
        int k1;
        int l1;
        int i2;
        int j2;
        int k2;
        int l2;
        int i3;
        int j3;
        mInLayout = true;
        populate();
        mInLayout = false;
        i1 = getChildCount();
        j1 = k - i;
        k1 = l - j;
        l1 = getPaddingLeft();
        i2 = getPaddingTop();
        j2 = getPaddingRight();
        k2 = getPaddingBottom();
        l2 = getScrollX();
        i3 = 0;
        j3 = 0;
_L18:
        if (j3 >= i1) goto _L2; else goto _L1
_L1:
        View view = getChildAt(j3);
        if (view.getVisibility() == 8) goto _L4; else goto _L3
_L3:
        LayoutParams layoutparams = (LayoutParams)view.getLayoutParams();
        if (!layoutparams.isDecor) goto _L6; else goto _L5
_L5:
        int i4;
        int j4;
        i4 = 7 & layoutparams.gravity;
        j4 = 0x70 & layoutparams.gravity;
        i4;
        JVM INSTR tableswitch 1 5: default 168
    //                   1 270
    //                   2 168
    //                   3 253
    //                   4 168
    //                   5 290;
           goto _L7 _L8 _L7 _L9 _L7 _L10
_L7:
        int k4 = l1;
_L15:
        j4;
        JVM INSTR lookupswitch 3: default 208
    //                   16: 333
    //                   48: 316
    //                   80: 353;
           goto _L11 _L12 _L13 _L14
_L11:
        int l4 = i2;
_L16:
        int i5 = k4 + l2;
        i3++;
        view.layout(i5, l4, i5 + view.getMeasuredWidth(), l4 + view.getMeasuredHeight());
_L4:
        j3++;
        continue; /* Loop/switch isn't completed */
_L9:
        k4 = l1;
        l1 += view.getMeasuredWidth();
          goto _L15
_L8:
        k4 = Math.max((j1 - view.getMeasuredWidth()) / 2, l1);
          goto _L15
_L10:
        k4 = j1 - j2 - view.getMeasuredWidth();
        j2 += view.getMeasuredWidth();
          goto _L15
_L13:
        l4 = i2;
        i2 += view.getMeasuredHeight();
          goto _L16
_L12:
        l4 = Math.max((k1 - view.getMeasuredHeight()) / 2, i2);
          goto _L16
_L14:
        l4 = k1 - k2 - view.getMeasuredHeight();
        k2 += view.getMeasuredHeight();
          goto _L16
_L6:
        ItemInfo iteminfo = infoForChild(view);
        if (iteminfo != null)
        {
            int k3 = l1 + (j1 + mPageMargin) * iteminfo.position;
            int l3 = i2;
            view.layout(k3, l3, k3 + view.getMeasuredWidth(), l3 + view.getMeasuredHeight());
        }
          goto _L4
_L2:
        mTopPageBounds = i2;
        mBottomPageBounds = k1 - k2;
        mDecorChildCount = i3;
        mFirstLayout = false;
        return;
        if (true) goto _L18; else goto _L17
_L17:
    }

    protected void onMeasure(int i, int j)
    {
        setMeasuredDimension(getDefaultSize(0, i), getDefaultSize(0, j));
        int k = getMeasuredWidth() - getPaddingLeft() - getPaddingRight();
        int l = getMeasuredHeight() - getPaddingTop() - getPaddingBottom();
        int i1 = getChildCount();
        int j1 = 0;
        do
        {
            if (j1 < i1)
            {
                View view1 = getChildAt(j1);
                if (view1.getVisibility() != 8)
                {
                    LayoutParams layoutparams1 = (LayoutParams)view1.getLayoutParams();
                    if (layoutparams1 != null && layoutparams1.isDecor)
                    {
                        int i2 = 7 & layoutparams1.gravity;
                        int j2 = 0x70 & layoutparams1.gravity;
                        Log.d("ViewPager", (new StringBuilder()).append("gravity: ").append(layoutparams1.gravity).append(" hgrav: ").append(i2).append(" vgrav: ").append(j2).toString());
                        int k2 = 0x80000000;
                        int l2 = 0x80000000;
                        boolean flag;
                        boolean flag1;
                        if (j2 == 48 || j2 == 80)
                        {
                            flag = true;
                        } else
                        {
                            flag = false;
                        }
                        if (i2 == 3 || i2 == 5)
                        {
                            flag1 = true;
                        } else
                        {
                            flag1 = false;
                        }
                        if (flag)
                        {
                            k2 = 0x40000000;
                        } else
                        if (flag1)
                        {
                            l2 = 0x40000000;
                        }
                        view1.measure(android.view.View.MeasureSpec.makeMeasureSpec(k, k2), android.view.View.MeasureSpec.makeMeasureSpec(l, l2));
                        if (flag)
                        {
                            l -= view1.getMeasuredHeight();
                        } else
                        if (flag1)
                        {
                            k -= view1.getMeasuredWidth();
                        }
                    }
                }
                j1++;
                continue;
            }
            mChildWidthMeasureSpec = android.view.View.MeasureSpec.makeMeasureSpec(k, 0x40000000);
            mChildHeightMeasureSpec = android.view.View.MeasureSpec.makeMeasureSpec(l, 0x40000000);
            mInLayout = true;
            populate();
            mInLayout = false;
            int k1 = getChildCount();
            for (int l1 = 0; l1 < k1; l1++)
            {
                View view = getChildAt(l1);
                if (view.getVisibility() == 8)
                {
                    continue;
                }
                LayoutParams layoutparams = (LayoutParams)view.getLayoutParams();
                if (layoutparams == null || !layoutparams.isDecor)
                {
                    view.measure(mChildWidthMeasureSpec, mChildHeightMeasureSpec);
                }
            }

            return;
        } while (true);
    }

    protected void onPageScrolled(int i, float f, int j)
    {
        int k;
        int l;
        int i1;
        int j1;
        int k1;
        int l1;
        if (mDecorChildCount <= 0)
        {
            break MISSING_BLOCK_LABEL_215;
        }
        k = getScrollX();
        l = getPaddingLeft();
        i1 = getPaddingRight();
        j1 = getWidth();
        k1 = getChildCount();
        l1 = 0;
_L2:
        View view;
        LayoutParams layoutparams;
        if (l1 >= k1)
        {
            break MISSING_BLOCK_LABEL_215;
        }
        view = getChildAt(l1);
        layoutparams = (LayoutParams)view.getLayoutParams();
        if (layoutparams.isDecor)
        {
            break; /* Loop/switch isn't completed */
        }
_L7:
        l1++;
        if (true) goto _L2; else goto _L1
_L1:
        7 & layoutparams.gravity;
        JVM INSTR tableswitch 1 5: default 120
    //                   1 169
    //                   2 120
    //                   3 152
    //                   4 120
    //                   5 189;
           goto _L3 _L4 _L3 _L5 _L3 _L6
_L6:
        break MISSING_BLOCK_LABEL_189;
_L3:
        int i2 = l;
_L8:
        int j2 = (i2 + k) - view.getLeft();
        if (j2 != 0)
        {
            view.offsetLeftAndRight(j2);
        }
          goto _L7
_L5:
        i2 = l;
        l += view.getWidth();
          goto _L8
_L4:
        i2 = Math.max((j1 - view.getMeasuredWidth()) / 2, l);
          goto _L8
        i2 = j1 - i1 - view.getMeasuredWidth();
        i1 += view.getMeasuredWidth();
          goto _L8
        if (mOnPageChangeListener != null)
        {
            mOnPageChangeListener.onPageScrolled(i, f, j);
        }
        if (mInternalPageChangeListener != null)
        {
            mInternalPageChangeListener.onPageScrolled(i, f, j);
        }
        mCalledSuper = true;
        return;
          goto _L7
    }

    protected boolean onRequestFocusInDescendants(int i, Rect rect)
    {
        int j = getChildCount();
        int k;
        byte byte0;
        int l;
        int i1;
        if ((i & 2) != 0)
        {
            k = 0;
            byte0 = 1;
            l = j;
        } else
        {
            k = j - 1;
            byte0 = -1;
            l = -1;
        }
        for (i1 = k; i1 != l; i1 += byte0)
        {
            View view = getChildAt(i1);
            if (view.getVisibility() != 0)
            {
                continue;
            }
            ItemInfo iteminfo = infoForChild(view);
            if (iteminfo != null && iteminfo.position == mCurItem && view.requestFocus(i, rect))
            {
                return true;
            }
        }

        return false;
    }

    public void onRestoreInstanceState(Parcelable parcelable)
    {
        if (!(parcelable instanceof SavedState))
        {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        SavedState savedstate = (SavedState)parcelable;
        super.onRestoreInstanceState(savedstate.getSuperState());
        if (mAdapter != null)
        {
            mAdapter.restoreState(savedstate.adapterState, savedstate.loader);
            setCurrentItemInternal(savedstate.position, false, true);
            return;
        } else
        {
            mRestoredCurItem = savedstate.position;
            mRestoredAdapterState = savedstate.adapterState;
            mRestoredClassLoader = savedstate.loader;
            return;
        }
    }

    public Parcelable onSaveInstanceState()
    {
        SavedState savedstate = new SavedState(super.onSaveInstanceState());
        savedstate.position = mCurItem;
        if (mAdapter != null)
        {
            savedstate.adapterState = mAdapter.saveState();
        }
        return savedstate;
    }

    protected void onSizeChanged(int i, int j, int k, int l)
    {
        super.onSizeChanged(i, j, k, l);
        if (i != k)
        {
            recomputeScrollPosition(i, k, mPageMargin, mPageMargin);
        }
    }

    public boolean onTouchEvent(MotionEvent motionevent)
    {
        int i;
        boolean flag;
        if (mFakeDragging)
        {
            return true;
        }
        if (motionevent.getAction() == 0 && motionevent.getEdgeFlags() != 0)
        {
            return false;
        }
        if (mAdapter == null || mAdapter.getCount() == 0)
        {
            return false;
        }
        if (mVelocityTracker == null)
        {
            mVelocityTracker = VelocityTracker.obtain();
        }
        mVelocityTracker.addMovement(motionevent);
        i = 0xff & motionevent.getAction();
        flag = false;
        i;
        JVM INSTR tableswitch 0 6: default 120
    //                   0 130
    //                   1 511
    //                   2 166
    //                   3 652
    //                   4 120
    //                   5 703
    //                   6 734;
           goto _L1 _L2 _L3 _L4 _L5 _L1 _L6 _L7
_L1:
        if (flag)
        {
            invalidate();
        }
        return true;
_L2:
        completeScroll();
        float f10 = motionevent.getX();
        mInitialMotionX = f10;
        mLastMotionX = f10;
        mActivePointerId = MotionEventCompat.getPointerId(motionevent, 0);
        flag = false;
        continue; /* Loop/switch isn't completed */
_L4:
        float f2;
        int j1;
        int k1;
        int l1;
        float f3;
        float f4;
        if (!mIsBeingDragged)
        {
            int l2 = MotionEventCompat.findPointerIndex(motionevent, mActivePointerId);
            float f7 = MotionEventCompat.getX(motionevent, l2);
            float f8 = Math.abs(f7 - mLastMotionX);
            float f9 = Math.abs(MotionEventCompat.getY(motionevent, l2) - mLastMotionY);
            if (f8 > (float)mTouchSlop && f8 > f9)
            {
                mIsBeingDragged = true;
                mLastMotionX = f7;
                setScrollState(1);
                setScrollingCacheEnabled(true);
            }
        }
        boolean flag3 = mIsBeingDragged;
        flag = false;
        if (!flag3)
        {
            continue; /* Loop/switch isn't completed */
        }
        float f = MotionEventCompat.getX(motionevent, MotionEventCompat.findPointerIndex(motionevent, mActivePointerId));
        float f1 = mLastMotionX - f;
        mLastMotionX = f;
        f2 = f1 + (float)getScrollX();
        j1 = getWidth();
        k1 = j1 + mPageMargin;
        l1 = -1 + mAdapter.getCount();
        f3 = Math.max(0, k1 * (-1 + mCurItem));
        f4 = k1 * Math.min(1 + mCurItem, l1);
        if (f2 >= f3) goto _L9; else goto _L8
_L8:
        int k2 = f3 != 0.0F;
        flag = false;
        if (k2 == 0)
        {
            float f6 = -f2;
            flag = mLeftEdge.onPull(f6 / (float)j1);
        }
        f2 = f3;
_L10:
        mLastMotionX = mLastMotionX + (f2 - (float)(int)f2);
        scrollTo((int)f2, getScrollY());
        pageScrolled((int)f2);
        continue; /* Loop/switch isn't completed */
_L9:
        int i2 = f2 != f4;
        flag = false;
        if (i2 > 0)
        {
            int j2 = f4 != (float)(l1 * k1);
            flag = false;
            if (j2 == 0)
            {
                float f5 = f2 - f4;
                flag = mRightEdge.onPull(f5 / (float)j1);
            }
            f2 = f4;
        }
        if (true) goto _L10; else goto _L3
_L3:
        boolean flag2 = mIsBeingDragged;
        flag = false;
        if (flag2)
        {
            VelocityTracker velocitytracker = mVelocityTracker;
            velocitytracker.computeCurrentVelocity(1000, mMaximumVelocity);
            int k = (int)VelocityTrackerCompat.getXVelocity(velocitytracker, mActivePointerId);
            mPopulatePending = true;
            int l = getWidth() + mPageMargin;
            int i1 = getScrollX();
            setCurrentItemInternal(determineTargetPage(i1 / l, (float)(i1 % l) / (float)l, k, (int)(MotionEventCompat.getX(motionevent, MotionEventCompat.findPointerIndex(motionevent, mActivePointerId)) - mInitialMotionX)), true, true, k);
            mActivePointerId = -1;
            endDrag();
            flag = mLeftEdge.onRelease() | mRightEdge.onRelease();
        }
        continue; /* Loop/switch isn't completed */
_L5:
        boolean flag1 = mIsBeingDragged;
        flag = false;
        if (flag1)
        {
            setCurrentItemInternal(mCurItem, true, true);
            mActivePointerId = -1;
            endDrag();
            flag = mLeftEdge.onRelease() | mRightEdge.onRelease();
        }
        continue; /* Loop/switch isn't completed */
_L6:
        int j = MotionEventCompat.getActionIndex(motionevent);
        mLastMotionX = MotionEventCompat.getX(motionevent, j);
        mActivePointerId = MotionEventCompat.getPointerId(motionevent, j);
        flag = false;
        continue; /* Loop/switch isn't completed */
_L7:
        onSecondaryPointerUp(motionevent);
        mLastMotionX = MotionEventCompat.getX(motionevent, MotionEventCompat.findPointerIndex(motionevent, mActivePointerId));
        flag = false;
        if (true) goto _L1; else goto _L11
_L11:
    }

    boolean pageLeft()
    {
        if (mCurItem > 0)
        {
            setCurrentItem(-1 + mCurItem, true);
            return true;
        } else
        {
            return false;
        }
    }

    boolean pageRight()
    {
        if (mAdapter != null && mCurItem < -1 + mAdapter.getCount())
        {
            setCurrentItem(1 + mCurItem, true);
            return true;
        } else
        {
            return false;
        }
    }

    void populate()
    {
_L2:
        return;
        if (mAdapter == null || mPopulatePending || getWindowToken() == null) goto _L2; else goto _L1
_L1:
        int k1;
        mAdapter.startUpdate(this);
        int i = mOffscreenPageLimit;
        int j = Math.max(0, mCurItem - i);
        int k = Math.min(-1 + mAdapter.getCount(), i + mCurItem);
        int l = -1;
        int i1 = 0;
        while (i1 < mItems.size()) 
        {
            ItemInfo iteminfo3 = (ItemInfo)mItems.get(i1);
            if ((iteminfo3.position < j || iteminfo3.position > k) && !iteminfo3.scrolling)
            {
                mItems.remove(i1);
                i1--;
                mAdapter.destroyItem(this, iteminfo3.position, iteminfo3.object);
            } else
            if (l < k && iteminfo3.position > j)
            {
                int l2 = l + 1;
                if (l2 < j)
                {
                    l2 = j;
                }
                while (l2 <= k && l2 < iteminfo3.position) 
                {
                    addNewItem(l2, i1);
                    l2++;
                    i1++;
                }
            }
            l = iteminfo3.position;
            i1++;
        }
        int j1;
        if (mItems.size() > 0)
        {
            j1 = ((ItemInfo)mItems.get(-1 + mItems.size())).position;
        } else
        {
            j1 = -1;
        }
        if (j1 < k)
        {
            int k2 = j1 + 1;
            if (k2 <= j)
            {
                k2 = j;
            }
            for (; k2 <= k; k2++)
            {
                addNewItem(k2, -1);
            }

        }
        k1 = 0;
_L8:
        int l1 = mItems.size();
        ItemInfo iteminfo = null;
        if (k1 < l1)
        {
            if (((ItemInfo)mItems.get(k1)).position != mCurItem)
            {
                break MISSING_BLOCK_LABEL_516;
            }
            iteminfo = (ItemInfo)mItems.get(k1);
        }
        PagerAdapter pageradapter = mAdapter;
        int i2 = mCurItem;
        Object obj;
        View view;
        int j2;
        View view1;
        ItemInfo iteminfo2;
        if (iteminfo != null)
        {
            obj = iteminfo.object;
        } else
        {
            obj = null;
        }
        pageradapter.setPrimaryItem(this, i2, obj);
        mAdapter.finishUpdate(this);
        if (!hasFocus()) goto _L2; else goto _L3
_L3:
        view = findFocus();
        ItemInfo iteminfo1;
        if (view != null)
        {
            iteminfo1 = infoForAnyChild(view);
        } else
        {
            iteminfo1 = null;
        }
        if (iteminfo1 != null && iteminfo1.position == mCurItem) goto _L2; else goto _L4
_L4:
        j2 = 0;
_L7:
        if (j2 >= getChildCount()) goto _L2; else goto _L5
_L5:
        view1 = getChildAt(j2);
        iteminfo2 = infoForChild(view1);
        if (iteminfo2 != null && iteminfo2.position == mCurItem && view1.requestFocus(2)) goto _L2; else goto _L6
_L6:
        j2++;
          goto _L7
        k1++;
          goto _L8
    }

    public void setAdapter(PagerAdapter pageradapter)
    {
        if (mAdapter != null)
        {
            mAdapter.unregisterDataSetObserver(mObserver);
            mAdapter.startUpdate(this);
            for (int i = 0; i < mItems.size(); i++)
            {
                ItemInfo iteminfo = (ItemInfo)mItems.get(i);
                mAdapter.destroyItem(this, iteminfo.position, iteminfo.object);
            }

            mAdapter.finishUpdate(this);
            mItems.clear();
            removeNonDecorViews();
            mCurItem = 0;
            scrollTo(0, 0);
        }
        PagerAdapter pageradapter1 = mAdapter;
        mAdapter = pageradapter;
        if (mAdapter != null)
        {
            if (mObserver == null)
            {
                mObserver = new PagerObserver();
            }
            mAdapter.registerDataSetObserver(mObserver);
            mPopulatePending = false;
            if (mRestoredCurItem >= 0)
            {
                mAdapter.restoreState(mRestoredAdapterState, mRestoredClassLoader);
                setCurrentItemInternal(mRestoredCurItem, false, true);
                mRestoredCurItem = -1;
                mRestoredAdapterState = null;
                mRestoredClassLoader = null;
            } else
            {
                populate();
            }
        }
        if (mAdapterChangeListener != null && pageradapter1 != pageradapter)
        {
            mAdapterChangeListener.onAdapterChanged(pageradapter1, pageradapter);
        }
    }

    public void setCurrentItem(int i)
    {
        mPopulatePending = false;
        boolean flag;
        if (!mFirstLayout)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        setCurrentItemInternal(i, flag, false);
    }

    public void setCurrentItem(int i, boolean flag)
    {
        mPopulatePending = false;
        setCurrentItemInternal(i, flag, false);
    }

    void setCurrentItemInternal(int i, boolean flag, boolean flag1)
    {
        setCurrentItemInternal(i, flag, flag1, 0);
    }

    void setCurrentItemInternal(int i, boolean flag, boolean flag1, int j)
    {
        boolean flag2 = true;
        if (mAdapter != null && mAdapter.getCount() > 0) goto _L2; else goto _L1
_L1:
        setScrollingCacheEnabled(false);
_L8:
        return;
_L2:
        if (!flag1 && mCurItem == i && mItems.size() != 0)
        {
            setScrollingCacheEnabled(false);
            return;
        }
        if (i >= 0) goto _L4; else goto _L3
_L3:
        i = 0;
_L6:
        int k = mOffscreenPageLimit;
        if (i > k + mCurItem || i < mCurItem - k)
        {
            for (int l = 0; l < mItems.size(); l++)
            {
                ((ItemInfo)mItems.get(l)).scrolling = flag2;
            }

        }
        break; /* Loop/switch isn't completed */
_L4:
        if (i >= mAdapter.getCount())
        {
            i = -1 + mAdapter.getCount();
        }
        if (true) goto _L6; else goto _L5
_L5:
        int i1;
        if (mCurItem == i)
        {
            flag2 = false;
        }
        mCurItem = i;
        populate();
        i1 = i * (getWidth() + mPageMargin);
        if (flag)
        {
            smoothScrollTo(i1, 0, j);
            if (flag2 && mOnPageChangeListener != null)
            {
                mOnPageChangeListener.onPageSelected(i);
            }
            if (flag2 && mInternalPageChangeListener != null)
            {
                mInternalPageChangeListener.onPageSelected(i);
                return;
            }
        } else
        {
            if (flag2 && mOnPageChangeListener != null)
            {
                mOnPageChangeListener.onPageSelected(i);
            }
            if (flag2 && mInternalPageChangeListener != null)
            {
                mInternalPageChangeListener.onPageSelected(i);
            }
            completeScroll();
            scrollTo(i1, 0);
            return;
        }
        if (true) goto _L8; else goto _L7
_L7:
    }

    OnPageChangeListener setInternalPageChangeListener(OnPageChangeListener onpagechangelistener)
    {
        OnPageChangeListener onpagechangelistener1 = mInternalPageChangeListener;
        mInternalPageChangeListener = onpagechangelistener;
        return onpagechangelistener1;
    }

    public void setOffscreenPageLimit(int i)
    {
        if (i < 1)
        {
            Log.w("ViewPager", (new StringBuilder()).append("Requested offscreen page limit ").append(i).append(" too small; defaulting to ").append(1).toString());
            i = 1;
        }
        if (i != mOffscreenPageLimit)
        {
            mOffscreenPageLimit = i;
            populate();
        }
    }

    void setOnAdapterChangeListener(OnAdapterChangeListener onadapterchangelistener)
    {
        mAdapterChangeListener = onadapterchangelistener;
    }

    public void setOnPageChangeListener(OnPageChangeListener onpagechangelistener)
    {
        mOnPageChangeListener = onpagechangelistener;
    }

    public void setPageMargin(int i)
    {
        int j = mPageMargin;
        mPageMargin = i;
        int k = getWidth();
        recomputeScrollPosition(k, k, i, j);
        requestLayout();
    }

    public void setPageMarginDrawable(int i)
    {
        setPageMarginDrawable(getContext().getResources().getDrawable(i));
    }

    public void setPageMarginDrawable(Drawable drawable)
    {
        mMarginDrawable = drawable;
        if (drawable != null)
        {
            refreshDrawableState();
        }
        boolean flag;
        if (drawable == null)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        setWillNotDraw(flag);
        invalidate();
    }

    void smoothScrollTo(int i, int j)
    {
        smoothScrollTo(i, j, 0);
    }

    void smoothScrollTo(int i, int j, int k)
    {
        if (getChildCount() == 0)
        {
            setScrollingCacheEnabled(false);
            return;
        }
        int l = getScrollX();
        int i1 = getScrollY();
        int j1 = i - l;
        int k1 = j - i1;
        if (j1 == 0 && k1 == 0)
        {
            completeScroll();
            setScrollState(0);
            return;
        }
        setScrollingCacheEnabled(true);
        mScrolling = true;
        setScrollState(2);
        int l1 = getWidth();
        int i2 = l1 / 2;
        float f = Math.min(1.0F, (1.0F * (float)Math.abs(j1)) / (float)l1);
        float f1 = (float)i2 + (float)i2 * distanceInfluenceForSnapDuration(f);
        int j2 = Math.abs(k);
        int k2;
        int l2;
        if (j2 > 0)
        {
            k2 = 4 * Math.round(1000F * Math.abs(f1 / (float)j2));
        } else
        {
            k2 = (int)(100F * (1.0F + (float)Math.abs(j1) / (float)(l1 + mPageMargin)));
        }
        l2 = Math.min(k2, 600);
        mScroller.startScroll(l, i1, j1, k1, l2);
        invalidate();
    }

    protected boolean verifyDrawable(Drawable drawable)
    {
        return super.verifyDrawable(drawable) || drawable == mMarginDrawable;
    }


}
