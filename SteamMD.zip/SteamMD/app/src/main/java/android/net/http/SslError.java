// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.net.http;

import java.security.cert.X509Certificate;

// Referenced classes of package android.net.http:
//            SslCertificate

public class SslError
{

    public static final int SSL_EXPIRED = 1;
    public static final int SSL_IDMISMATCH = 2;
    public static final int SSL_MAX_ERROR = 4;
    public static final int SSL_NOTYETVALID = 0;
    public static final int SSL_UNTRUSTED = 3;
    SslCertificate mCertificate;
    int mErrors;

    public SslError(int i, SslCertificate sslcertificate)
    {
        addError(i);
        mCertificate = sslcertificate;
    }

    public SslError(int i, X509Certificate x509certificate)
    {
        addError(i);
        mCertificate = new SslCertificate(x509certificate);
    }

    public boolean addError(int i)
    {
        boolean flag;
        if (i >= 0 && i < 4)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (flag)
        {
            mErrors = mErrors | 1 << i;
        }
        return flag;
    }

    public SslCertificate getCertificate()
    {
        return mCertificate;
    }

    public int getPrimaryError()
    {
        if (mErrors != 0)
        {
            for (int i = 3; i >= 0; i--)
            {
                if ((mErrors & 1 << i) != 0)
                {
                    return i;
                }
            }

        }
        return 0;
    }

    public boolean hasError(int i)
    {
label0:
        {
            boolean flag;
            if (i >= 0 && i < 4)
            {
                flag = true;
            } else
            {
                flag = false;
            }
            if (flag)
            {
                if ((mErrors & 1 << i) == 0)
                {
                    break label0;
                }
                flag = true;
            }
            return flag;
        }
        return false;
    }

    public String toString()
    {
        return (new StringBuilder()).append("primary error: ").append(getPrimaryError()).append(" certificate: ").append(getCertificate()).toString();
    }
}
